"""Gemini Live API provider for realtime speech-to-speech (and live video) sessions.

Built on the `google-genai` SDK, which manages the WebSocket transport for you. Available via the
`google` optional group:

    pip install "pydantic-ai-slim[google-realtime]"

Unlike the OpenAI provider, Gemini wants **16 kHz** PCM input audio (output is 24 kHz), produces a
single response modality per session (audio *or* text), and natively accepts a stream of video
frames sent as [`BinaryImage`][pydantic_ai.messages.BinaryImage].

Use `provider='google'` for the Gemini Developer API, or `provider='google-cloud'` /
[`GoogleCloudProvider`][pydantic_ai.providers.google_cloud.GoogleCloudProvider] for Google Cloud with
Application Default Credentials.
"""

from __future__ import annotations as _annotations

import asyncio
import time
import warnings
from collections import deque
from collections.abc import AsyncGenerator, AsyncIterator, Awaitable, Callable, Generator, Sequence
from contextlib import AbstractAsyncContextManager, ExitStack, asynccontextmanager, contextmanager, suppress
from dataclasses import KW_ONLY, dataclass, field
from typing import Any, Literal, assert_never, cast

from anyio import Lock
from anyio.lowlevel import RunVar
from pydantic_core import to_json
from typing_extensions import TypedDict, deprecated

try:
    import websockets
    from google.genai import Client, errors as genai_errors, types as genai_types
    from google.genai.live import AsyncSession, ConnectionClosed
except ImportError as _import_error:
    raise ImportError(
        'Please install the `google-genai` package to use the Gemini realtime model, '
        'you can use the `google-realtime` optional group - `pip install "pydantic-ai-slim[google-realtime]"`'
    ) from _import_error

from .._utils import generate_tool_call_id
from .._warnings import PydanticAIDeprecationWarning
from ..exceptions import ModelHTTPError, UserError
from ..messages import (
    ERROR_OUTCOMES,
    INTERRUPTED_TOOL_RETURN_CONTENT,
    AudioUrl,
    BinaryAudio,
    BinaryContent,
    BinaryImage,
    CachePoint,
    CompactionPart,
    DocumentUrl,
    FilePart,
    FinishReason,
    ImageUrl,
    InstructionBaselinePart,
    InstructionDeltaPart,
    ModelMessage,
    ModelRequest,
    ModelRequestPart,
    ModelResponse,
    ModelResponsePart,
    NativeToolCallPart,
    NativeToolReturnPart,
    PartEndEvent,
    PartStartEvent,
    RealtimeResponseInterruptedEvent,
    RealtimeSessionErrorEvent,
    RealtimeSessionReconnectEvent,
    RetryFeedbackPart,
    RetryPromptPart,  # pyright: ignore[reportDeprecated]  # TODO(v3): remove RetryPromptPart
    SpeechPart,
    SystemPromptPart,
    TextContent,
    TextPart,
    ThinkingPart,
    ToolAvailabilityDeltaPart,
    ToolCallPart,
    ToolReturnPart,
    UploadedFile,
    UserPromptPart,
    VideoUrl,
    _tool_result_provenance_tags,  # pyright: ignore[reportPrivateUsage]
    _translate_legacy_retry_part,  # pyright: ignore[reportPrivateUsage]
)
from ..models import (
    ModelRequestParameters,
    download_item,
)
from ..models._speech import assistant_speech_text

# Reuse the classic `GoogleModel`'s native tool mappers so a realtime turn's grounding / code-execution
# native tool parts are byte-identical in shape to a classic request's, rather than duplicating the
# mapping and risking drift.
from ..models.google import (
    _FINISH_REASON_MAP,  # pyright: ignore[reportPrivateUsage]
    _map_api_error,  # pyright: ignore[reportPrivateUsage]
    _map_code_execution_result,  # pyright: ignore[reportPrivateUsage]
    _map_executable_code,  # pyright: ignore[reportPrivateUsage]
    _map_grounding_metadata,  # pyright: ignore[reportPrivateUsage]
    _map_url_context_metadata,  # pyright: ignore[reportPrivateUsage]
    _snap_thinking_level,  # pyright: ignore[reportPrivateUsage]
    _thinking_effort_to_level,  # pyright: ignore[reportPrivateUsage]
    _usage_metadata_as_usage,  # pyright: ignore[reportPrivateUsage]
)
from ..native_tools import AbstractNativeTool, CodeExecutionTool, WebFetchTool, WebSearchTool
from ..profiles import DEFAULT_THINKING_TAGS
from ..profiles.google import (
    GoogleOpenAPISchemaTransformer,
    GoogleThinkingLevel,
    _drop_unsupported_schema_keywords,  # pyright: ignore[reportPrivateUsage]
)
from ..providers import Provider, infer_provider
from ..settings import ThinkingEffort, ThinkingLevel
from ..tools import ToolDefinition
from ..usage import RequestUsage
from ._inferred_lifecycle import InferredLifecycle
from ._lifecycle import InputId, LifecycleEvent, RealtimeFrame, StaleEvent
from ._utils import (
    DEFAULT_MAX_RECONNECTS,
    inject_trace_context,
    reconnect_with_backoff,
    require_pcm_audio,
    resolve_advertised_tools,
    seed_pcm_audio,
    seed_retry_feedback_text,
    seed_speech_content,
    seed_user_content,
    session_instructions,
    wrap_seeded_system_prompts,
)
from .codec import (
    AudioDelta,
    InputRejected,
    InputTranscript,
    OutputTranscript,
    RealtimeCodecEvent,
    RealtimeConnection,
    RealtimeInput,
    ResponseDone,
    SessionUsage,
    TextContext,
    ToolCall,
    ToolCallCancelled,
    ToolResult,
)
from .model import RealtimeError, RealtimeModel
from .profiles import DEFAULT_REALTIME_PROFILE, RealtimeModelProfile, RealtimeModelProfileSpec, merge_realtime_profile
from .settings import RealtimeModelSettings, ReconnectPolicy, TurnDetection

LatestGoogleRealtimeModelNames = Literal[
    'gemini-2.5-flash-native-audio-latest',
    'gemini-3.1-flash-live-preview',
    'gemini-3.8-live',
    'gemini-3.8-live-extended-thinking',
]
GoogleRealtimeModelName = str | LatestGoogleRealtimeModelNames

__all__ = (
    'GoogleRealtimeModel',
    'GoogleRealtimeModelSettings',
    'GoogleRealtimeConnection',
    'AutomaticVAD',
    'MultiSpeaker',
    'ContextCompression',
)


class AutomaticVAD(TypedDict, total=False):
    """Server-side voice activity detection — the default turn-taking mode for Gemini Live."""

    disabled: bool
    """Turn off automatic VAD entirely. Defaults to `False`.

    Do not set this through `RealtimeSession`: Pydantic AI does not expose Gemini activity markers or
    manual turn controls. Use automatic VAD instead; the shared `turn_detection=False` setting is
    rejected for the same reason.
    """
    start_sensitivity: Literal['high', 'low']
    """How readily speech onset is detected. `high` triggers on quieter audio; `low` is stricter.
    Defaults to the provider default."""
    end_sensitivity: Literal['high', 'low']
    """How readily the end of speech is detected. `high` ends turns sooner; `low` waits longer.
    Defaults to the provider default."""
    prefix_padding_ms: int
    """Audio to include before detected speech, in milliseconds. Defaults to the provider default."""
    silence_duration_ms: int
    """Silence required to detect the end of speech, in milliseconds. Defaults to the provider default."""


# TODO(v3): remove, along with the `google_multi_speaker` setting.
@deprecated(
    '`MultiSpeaker` is deprecated: no Gemini Live model supports multi-speaker voices, so '
    '`google_multi_speaker` can never take effect. Use `google_voice` instead.',
    category=PydanticAIDeprecationWarning,
)
class MultiSpeaker(TypedDict, total=False):
    """Deprecated: no Gemini Live model supports multi-speaker voices; see `google_multi_speaker`."""

    voices: dict[str, str]
    """Mapping of speaker label to prebuilt voice name, e.g. `{'Joe': 'Puck', 'Jane': 'Kore'}`.
    Defaults to an empty mapping."""


class ContextCompression(TypedDict, total=False):
    """Sliding-window context compression so long sessions don't exceed the context window."""

    trigger_tokens: int
    """Compress once the context passes this many tokens. Defaults to the provider default."""
    target_tokens: int
    """Target size (in tokens) of the retained sliding window after compression.
    Defaults to the provider default."""


class GoogleRealtimeModelSettings(RealtimeModelSettings, total=False):
    """Settings used for a Gemini Live session."""

    temperature: float
    """Amount of randomness injected into the response."""

    top_p: float
    """Nucleus sampling probability mass."""

    top_k: int
    """Only sample from the top K options for each subsequent token."""

    seed: int
    """The random seed to use for the session."""

    google_thinking_config: genai_types.ThinkingConfigDict
    """The thinking configuration to use for the model."""

    google_video_resolution: genai_types.MediaResolution
    """The video resolution to use for the model."""

    google_language_code: str
    """BCP-47 language code for audio output."""
    google_voice: str
    """Prebuilt voice used for audio output, e.g. `Puck`."""
    google_multi_speaker: MultiSpeaker  # pyright: ignore[reportDeprecated]
    """Deprecated: no Gemini Live model supports multi-speaker voices, so `connect` raises
    [`UserError`][pydantic_ai.exceptions.UserError] if this is set. Use `google_voice` instead.

    A Live session speaks in one voice. `google-genai` refuses a multi-speaker voice config on the Live
    path, Gemini 2.5 native-audio models reject it, and the Gemini 3.1 Flash Live and 3.8 Live models
    accept it but ignore the per-speaker voices.
    """
    google_affective_dialog: bool
    """Whether to enable emotion-aware delivery.

    Not supported by the Gemini 3.1 Flash Live and 3.8 Live models, so `connect` raises
    [`UserError`][pydantic_ai.exceptions.UserError] if it's enabled for one of them (see
    [`google_supports_affective_dialog`][pydantic_ai.realtime.google.GoogleRealtimeModelProfile.google_supports_affective_dialog])."""
    google_proactive_audio: bool
    """Whether the model may decide *when* to respond, including staying silent on input not
    addressed to it. Useful for "react to the camera" experiences.

    Always on for the Gemini 3.8 Live models, so there it can be left unset. They reject an explicit
    `False`, which is never sent: `False` just leaves the field out.

    Gemini serves `proactivity` on the Developer API's `v1alpha` only, and the API version belongs to
    the client, so the client has to be built for it — `connect` raises
    [`UserError`][pydantic_ai.exceptions.UserError] naming the fix rather than letting the session fail
    to open. Unavailable on Vertex AI, whose version line has no `v1alpha`."""
    google_input_transcription: bool
    """Whether to transcribe input audio. Defaults to `True`.

    When `False`, user turns are recorded as retained audio when available, or as content-less
    placeholders otherwise. Takes precedence over the shared
    [`input_transcription_model`][pydantic_ai.realtime.RealtimeModelSettings.input_transcription_model],
    whose `None` also turns transcription off here.
    """
    google_output_transcription: bool
    """Whether to transcribe output audio. Defaults to `True`.

    When `False`, retain output audio if assistant audio turns need to appear in history. Assistant
    audio without a transcript cannot be handed off or seeded.
    """
    google_transcription_language_codes: list[str]
    """Language hints applied to input and output transcription."""
    google_vad: AutomaticVAD
    """Gemini-specific server-side voice activity detection settings.

    When present, this fully overrides the cross-provider `turn_detection` setting.
    `google_vad={'disabled': True}` raises a `UserError`, like `turn_detection=False`: Pydantic AI does
    not expose Gemini activity markers or manual turn controls, so the resulting session could not
    drive turns.
    """
    google_activity_handling: Literal['interrupts', 'no_interruption']
    """Whether detected user activity interrupts the model."""
    google_turn_coverage: Literal['activity_only', 'all_input', 'all_video']
    """Which realtime input is attached to a turn — `'activity_only'`, `'all_input'` (everything
    between turns too), or `'all_video'` (all video frames plus audio during activity; ideal for
    live-camera use). Absent uses the provider default."""
    google_context_compression: ContextCompression
    """Sliding-window context compression for long-running sessions."""
    google_config_overrides: dict[str, Any]
    """Raw values merged last into the Google `LiveConnectConfig`."""

    google_enable_session_resumption: bool
    """Whether to request session-resumption handles, which let a re-dial restore the server-side
    conversation.

    When absent, handles are requested exactly when a
    [`reconnect`][pydantic_ai.realtime.RealtimeModelSettings.reconnect] policy is set. An explicit
    `False` cannot be combined with a `reconnect` policy: a re-dial without resumption would lose the
    conversation, so `connect` raises [`UserError`][pydantic_ai.exceptions.UserError] rather than
    silently reconnecting into a model that remembers nothing.
    """

    google_async_tool_calls: bool
    """Deprecated: use the shared [`async_tool_calls`][pydantic_ai.realtime.RealtimeModelSettings.async_tool_calls] setting instead.

    Translated (with a deprecation warning) when a session connects; an `async_tool_calls` in the same
    settings wins.
    """


class GoogleRealtimeModelProfile(RealtimeModelProfile, total=False):
    """Profile for Gemini Live models, adding the Gemini-specific fields to the shared realtime profile.

    Mirrors the [`GoogleModelProfile`][pydantic_ai.profiles.google.GoogleModelProfile] /
    [`ModelProfile`][pydantic_ai.profiles.ModelProfile] split on the request-response side.
    """

    google_thinking_levels: frozenset[GoogleThinkingLevel]
    """Thinking levels the Live model accepts. Default: unset.

    Same meaning as [`google_thinking_levels`][pydantic_ai.profiles.google.GoogleModelProfile.google_thinking_levels]
    on a standard model: unset means the full [`GOOGLE_THINKING_LEVELS`][pydantic_ai.profiles.google.GOOGLE_THINKING_LEVELS]
    scale, and a unified [`thinking`][pydantic_ai.realtime.RealtimeModelSettings.thinking] effort snaps to the
    nearest level in the set.
    """

    google_thinking_always_enabled: bool
    """Whether the model always reasons, so its API requires a thinking level. Default: `False`.

    Mirrors [`ModelProfile.thinking_always_enabled`][pydantic_ai.profiles.ModelProfile.thinking_always_enabled].
    A session that sets no [`thinking`][pydantic_ai.realtime.RealtimeModelSettings.thinking] still sends
    the cheapest level the model accepts, and `thinking=False` means "as little as possible" rather than a
    `thinking_budget=0` the model would reject. `gemini-3.8-live-extended-thinking` closes the handshake
    with `1007 Thinking level must be specified for this model` without a level.
    """

    google_async_tool_calls_by_default: bool
    """Whether the model runs a tool call asynchronously when its declaration sets no `behavior`. Default: `False`.

    True of the Gemini 3.8 Live family, where Google made `NON_BLOCKING` the default. Tool calls stay
    blocking unless [`async_tool_calls`][pydantic_ai.realtime.RealtimeModelSettings.async_tool_calls]
    asks otherwise, so on such a model the declaration says `BLOCKING` explicitly instead of leaving it unset.
    """

    google_requires_async_tool_calls: bool
    """Deprecated: use [`async_tool_call_mode='always'`][pydantic_ai.realtime.RealtimeModelProfile.async_tool_call_mode] instead.

    Translated (with a deprecation warning) when the profile is resolved: `True` becomes
    `async_tool_call_mode='always'`, and `False`, which left the choice to the other flags, is dropped.
    """

    google_closes_tool_call_turn_separately: bool
    """Whether the model closes a tool-call turn with a `turn_complete` of its own. Default: `False`.

    Vertex's half-cascade `gemini-live-2.5-flash` sends one when the tool-call generation ends (usage
    only, no output), whether or not the results have arrived yet, and another after speaking the
    answer (verified live); other Live models send only the answer's. With
    this set, the first of the two is reported as the tool-call response's usage rather than a turn
    boundary, so the exchange isn't reported complete before the answer is spoken. Set by default on
    Vertex AI only, where it was verified.
    """
    google_input_cuts_off_reply: bool
    """Whether text or a tool result that reaches the model mid-generation cuts the reply off. Default: `False`.

    The model then reports the reply `interrupted` and complete (cancelling the tool calls it was waiting on, on
    `gemini-3.1-flash-live-preview`) and answers the input in the next turn, so the cut-off reply answers only the
    request that started it. Verified live for `gemini-3.1-flash-live-preview` and `gemini-3.8-live`, which also report
    the user's speech (`voice_activity`) when that is what cut the reply off. Vertex's `gemini-live-2.5-flash` cuts
    a reply off too, but doesn't say whether speech did it, so it is left off; the native-audio models finish the
    reply instead, and answer the input after it.
    """
    google_supports_async_tool_call_scheduling: bool
    """Whether the model takes a `scheduling` field on an async tool call's result. Default: `False`.

    Separate from whether the call runs asynchronously at all: that is decided when the call is
    declared, while scheduling says how its result enters the speech the model is producing when it
    arrives. Pydantic AI sends `FunctionResponseScheduling.INTERRUPT`, so the result cuts in rather
    than waiting for the model to go idle. `gemini-3.8-live-extended-thinking` runs every call
    asynchronously but paces results against its own reasoning, and closes the session with `1007
    Function response scheduling is not supported for this model` if the field is sent at all.
    """

    google_supports_affective_dialog: bool
    """Whether the model takes [`google_affective_dialog`][pydantic_ai.realtime.google.GoogleRealtimeModelSettings.google_affective_dialog]. Default: `True`.

    When `False`, `connect` raises [`UserError`][pydantic_ai.exceptions.UserError] for a session that
    enables it, rather than opening one the provider rejects. `False` for the `gemini-3.1-flash-live` and
    `gemini-3.8-live` families, which don't support affective dialog: `gemini-3.1-flash-live-preview`
    refuses the handshake with `1007 Request contains an invalid argument`, and the 3.8 models open the
    session and then close it with the same error on the first send.
    """

    google_supported_mime_types_in_tool_returns: tuple[str, ...]
    """Media types a tool result can carry inside its function response. Default: `()`.

    The realtime counterpart of
    [`google_supported_mime_types_in_tool_returns`][pydantic_ai.profiles.google.GoogleModelProfile.google_supported_mime_types_in_tool_returns]
    on a standard model: content of these types attached to a tool return (a
    [`BinaryContent`][pydantic_ai.messages.BinaryContent] or a downloaded
    [`ImageUrl`][pydantic_ai.messages.ImageUrl]) goes in `FunctionResponse.parts`, and any other media
    raises [`UserError`][pydantic_ai.exceptions.UserError] with the result unsent. PNG, JPEG, WebP, and
    plain text on the Gemini 3.x Live models, which read them; `gemini-2.5-flash-native-audio-*`
    doesn't, and the 3.x models close the session on a PDF.
    """

    google_supports_seeding_function_parts: bool
    """Whether seeded tool calls and results go in as native function parts. Default: `False`.

    When `True`, prior [`ToolCallPart`][pydantic_ai.messages.ToolCallPart]s and
    [`ToolReturnPart`][pydantic_ai.messages.ToolReturnPart]s are seeded as `function_call` and
    `function_response` parts, sent as the session's initial history (`history_config`), rather than
    projected as readable text. True of the Gemini 3.8 Live models. `gemini-2.5-flash-native-audio-*`
    rejects function parts in seeded turns, and `gemini-3.1-flash-live-preview` loses history seeded
    that way when a [`reconnect`][pydantic_ai.realtime.RealtimeModelSettings.reconnect] resumes the
    session.
    """

    google_text_turns_see_video_frames: bool
    """Whether a typed turn sees an image sent just before it as a live video frame. Default: `True`.

    `session.send(image)` sends the image as a video frame, which a spoken turn sees. On a model where
    a typed turn doesn't, the most recent image sent in the last 10 seconds is sent again in the typed
    turn's own content, ahead of the text. Every Gemini Live model probed misses it:
    `gemini-3.1-flash-live-preview`, `gemini-3.8-live` and its extended-thinking variant answer that
    they can't see an image, and `gemini-2.5-flash-native-audio-*` and Vertex's `gemini-live-2.5-flash`
    misread it.
    """


_MIN_WEBSOCKET_CLOSE_CODE = 1000
"""The lowest WebSocket close code (RFC 6455 section 7.4), above every HTTP status."""

INPUT_SAMPLE_RATE = 16000
"""Sample rate (Hz) Gemini expects for PCM16 input audio."""

# How recently an image must have been sent for a typed turn to carry it again, on a model whose typed
# turns don't see video frames. Long enough for someone to type a short question about an image they
# just shared, short enough that a question well after it doesn't re-send a stale one. A camera stream
# always has a fresh frame.
_RECENT_IMAGE_SECONDS = 10.0


# Literal -> SDK enum mappings, kept as small tables so the public API stays string-friendly.
_START_SENSITIVITY = {
    'high': genai_types.StartSensitivity.START_SENSITIVITY_HIGH,
    'low': genai_types.StartSensitivity.START_SENSITIVITY_LOW,
}
_END_SENSITIVITY = {
    'high': genai_types.EndSensitivity.END_SENSITIVITY_HIGH,
    'low': genai_types.EndSensitivity.END_SENSITIVITY_LOW,
}
_ACTIVITY_HANDLING = {
    'interrupts': genai_types.ActivityHandling.START_OF_ACTIVITY_INTERRUPTS,
    'no_interruption': genai_types.ActivityHandling.NO_INTERRUPTION,
}
_TURN_COVERAGE = {
    'activity_only': genai_types.TurnCoverage.TURN_INCLUDES_ONLY_ACTIVITY,
    'all_input': genai_types.TurnCoverage.TURN_INCLUDES_ALL_INPUT,
    'all_video': genai_types.TurnCoverage.TURN_INCLUDES_AUDIO_ACTIVITY_AND_ALL_VIDEO,
}

# Live's refusals of prohibited input or unsafe generated content, which end the turn the way a content
# filter ends a standard response. The names Live shares with a standard response's finish reason (a
# malformed function call, a blocklist match) are looked up in `GoogleModel`'s table instead.
_CONTENT_FILTER_TURN_COMPLETE_REASONS = frozenset(
    {
        genai_types.TurnCompleteReason.PROHIBITED_INPUT_CONTENT,
        genai_types.TurnCompleteReason.IMAGE_PROHIBITED_INPUT_CONTENT,
        genai_types.TurnCompleteReason.INPUT_TEXT_CONTAIN_PROMINENT_PERSON_PROHIBITED,
        genai_types.TurnCompleteReason.INPUT_IMAGE_CELEBRITY,
        genai_types.TurnCompleteReason.INPUT_IMAGE_PHOTO_REALISTIC_CHILD_PROHIBITED,
        genai_types.TurnCompleteReason.INPUT_TEXT_NCII_PROHIBITED,
        genai_types.TurnCompleteReason.INPUT_IP_PROHIBITED,
        genai_types.TurnCompleteReason.UNSAFE_PROMPT_FOR_IMAGE_GENERATION,
        genai_types.TurnCompleteReason.GENERATED_IMAGE_SAFETY,
        genai_types.TurnCompleteReason.GENERATED_CONTENT_SAFETY,
        genai_types.TurnCompleteReason.GENERATED_AUDIO_SAFETY,
        genai_types.TurnCompleteReason.GENERATED_VIDEO_SAFETY,
        genai_types.TurnCompleteReason.GENERATED_CONTENT_PROHIBITED,
        genai_types.TurnCompleteReason.GENERATED_CONTENT_BLOCKLIST,
        genai_types.TurnCompleteReason.GENERATED_IMAGE_PROHIBITED,
        genai_types.TurnCompleteReason.GENERATED_IMAGE_CELEBRITY,
        genai_types.TurnCompleteReason.GENERATED_IMAGE_PROMINENT_PEOPLE_DETECTED_BY_REWRITER,
        genai_types.TurnCompleteReason.GENERATED_IMAGE_IDENTIFIABLE_PEOPLE,
        genai_types.TurnCompleteReason.GENERATED_IMAGE_MINORS,
        genai_types.TurnCompleteReason.OUTPUT_IMAGE_IP_PROHIBITED,
    }
)


def _turn_complete_finish_reason(reason: genai_types.TurnCompleteReason) -> FinishReason | None:
    """Map why Gemini Live ended a turn to a [`FinishReason`][pydantic_ai.messages.FinishReason].

    A reason with no clear counterpart (`NEED_MORE_INPUT`, `RESPONSE_REJECTED`, the `*_OTHER` catch-alls)
    maps to `None`, as `OTHER` does on a standard response; its raw value is still kept in
    `provider_details`.
    """
    if reason.value in _FINISH_REASON_MAP:
        return _FINISH_REASON_MAP[reason.value]
    return 'content_filter' if reason in _CONTENT_FILTER_TURN_COMPLETE_REASONS else None


_WS_CONNECT_LOCK: RunVar[Lock] = RunVar('gemini_live_ws_connect_lock')


def _ws_connect_lock() -> Lock:
    """Return the lock serializing the temporary mutations a Gemini Live handshake needs.

    Process-wide, not per-client, because one of those mutations — the gateway URL rewrite — replaces
    `google.genai.live.ws_connect`, a module global. Two sessions on *different* clients would each
    take their own lock, and whichever restored second would put the other's replacement back as the
    "original", leaving every later Vertex session pointed at the gateway path. A handshake is short,
    so serializing them costs little next to that.

    One lock per running event loop rather than a single module-level one: an `anyio.Lock` binds to
    the loop (and async backend) it is first used on, so a shared instance breaks an app that opens
    sessions from more than one runtime — the same hazard `Provider._enter_lock` defers construction
    to avoid. Sessions racing this rewrite from different loops is the far-fetched case; sessions
    racing it from one is the case that has to hold. A `RunVar` holds them because its storage is
    weak-keyed on the running loop, so an app that starts and tears down loops repeatedly doesn't
    accumulate one lock per loop it ever ran.
    """
    lock = _WS_CONNECT_LOCK.get(None)
    if lock is None:
        lock = Lock()
        _WS_CONNECT_LOCK.set(lock)
    return lock


_IMPLIED_THINKING_EFFORT: ThinkingEffort = 'minimal'
"""The thinking effort implied for a model that requires a thinking level when the session set none.

`gemini-3.8-live-extended-thinking` rejects the handshake without a level, so one has to be chosen on
the session's behalf. It snaps to the cheapest level the model accepts, because reasoning costs latency
and latency is what a voice conversation can least afford; a session that wants more says so with
`thinking='medium'` or `thinking='high'`.
"""


def _thinking_to_config(thinking: ThinkingLevel, profile: GoogleRealtimeModelProfile) -> genai_types.ThinkingConfig:
    """Map the unified `thinking` setting to a Gemini `ThinkingConfig`.

    A model that always reasons has no "off": `thinking=False` snaps to the cheapest level it accepts
    rather than a `thinking_budget=0` it would reject, mirroring how the request-response path resolves
    `thinking=False` on a Gemini 3+ model.
    """
    if thinking is False and not profile.get('google_thinking_always_enabled', False):
        return genai_types.ThinkingConfig(thinking_budget=0)  # disable thinking
    effort: ThinkingEffort = (
        _IMPLIED_THINKING_EFFORT if thinking is False else 'medium' if thinking is True else thinking
    )
    level = _snap_thinking_level(_thinking_effort_to_level(effort), profile.get('google_thinking_levels'))
    return genai_types.ThinkingConfig(thinking_level=genai_types.ThinkingLevel(level))


def _automatic_vad_from_turn_detection(turn_detection: TurnDetection) -> AutomaticVAD:
    """Map cross-provider turn detection to Gemini's automatic-VAD shape."""
    sensitivity = turn_detection.get('sensitivity')
    result: AutomaticVAD = {}
    if sensitivity is not None and sensitivity != 'medium':
        result['start_sensitivity'] = sensitivity
        result['end_sensitivity'] = sensitivity
    if (prefix_padding_ms := turn_detection.get('prefix_padding_ms')) is not None:
        result['prefix_padding_ms'] = prefix_padding_ms
    if (silence_duration_ms := turn_detection.get('silence_duration_ms')) is not None:
        result['silence_duration_ms'] = silence_duration_ms
    return result


async def _seed_turns(
    messages: Sequence[ModelMessage], *, profile: RealtimeModelProfile, provider_name: str, function_parts: bool
) -> list[genai_types.Content]:
    """Map prior history to Gemini `clientContent.turns`.

    Text, transcripts, inline images, and tag-wrapped thinking are replayed in part order. With
    `function_parts` (a model whose profile sets `google_supports_seeding_function_parts`), function
    calls and results are seeded as native `function_call` / `function_response` parts, a failed call's
    under the `error` key. Other Live models reject function parts in
    `clientContent.turns`, so there they are projected as structured text: `[Tool call: name(args)]`,
    `[Tool "name" returned: result]`, and `[Tool "name" error: error]`. Native-tool parts are skipped
    because they describe provider-executed work whose answer text is already retained.

    Thinking signatures and `provider_details` are provider-session-bound and are not replayed.
    The standing system prompt the history opens with is routed through `system_instruction`, a later
    `SystemPromptPart` is seeded as `<system>`-tagged user text, and `CachePoint`s are ignored. User
    speech is seeded as its transcript, or as its retained 16 kHz audio on a model whose profile sets
    `supports_seeding_audio`; on other models (Gemini 2.5 rejects audio in seeded turns) speech
    requires a transcript. Other unrepresentable content raises [`UserError`][pydantic_ai.exceptions.UserError].
    """
    turns: list[genai_types.Content] = []
    supports_images = profile.get('supports_seeding_images', False)
    supports_audio = profile.get('supports_seeding_audio', False)
    for message in wrap_seeded_system_prompts(messages):
        if isinstance(message, ModelRequest):
            parts = await _seed_request_parts(
                message.parts,
                provider_name=provider_name,
                supports_images=supports_images,
                function_parts=function_parts,
                supports_audio=supports_audio,
            )
            role = 'user'
        else:
            parts = _seed_response_parts(message, provider_name=provider_name, function_parts=function_parts)
            role = 'model'
        if parts:
            turns.append(genai_types.Content(role=role, parts=parts))
    return turns


async def _seed_request_parts(
    message_parts: Sequence[ModelRequestPart],
    *,
    provider_name: str,
    supports_images: bool,
    function_parts: bool,
    supports_audio: bool,
) -> list[genai_types.Part]:
    parts: list[genai_types.Part] = []
    for part in message_parts:
        # TODO(v3): remove `RetryPromptPart`. Translated ahead of the branches rather than inside one
        # of them, so a tool-bound legacy retry seeds through the `ToolReturnPart` branch below and
        # reads exactly like the retried return the framework emits for the same failure.
        if isinstance(part, RetryPromptPart):  # pyright: ignore[reportDeprecated]
            part = _translate_legacy_retry_part(part)
        if isinstance(
            part, (SystemPromptPart, InstructionDeltaPart, InstructionBaselinePart, ToolAvailabilityDeltaPart)
        ):
            # System prompts are seeded through session instructions, and tool-availability news
            # from a prior standard run is stale here: the session advertises its own tools.
            # Instruction deltas likewise belong to the standard run; the session resolves current instructions.
            continue
        elif isinstance(part, UserPromptPart):
            parts.extend(
                _genai_user_parts(
                    await seed_user_content(part=part, provider_name=provider_name, supports_images=supports_images)
                )
            )
        elif isinstance(part, SpeechPart):
            content = seed_speech_content(part=part, provider_name=provider_name, supports_audio=supports_audio)
            if isinstance(content, str):
                if content:
                    parts.append(genai_types.Part(text=content))
            else:
                # Seeded audio has to be at the live input rate: 24 kHz audio closes the session with
                # `1008 Operation is not implemented, or supported, or enabled` (verified live).
                pcm = seed_pcm_audio(audio=content, provider_name=provider_name, sample_rate=INPUT_SAMPLE_RATE)
                parts.append(
                    genai_types.Part(
                        inline_data=genai_types.Blob(data=pcm, mime_type=f'audio/pcm;rate={INPUT_SAMPLE_RATE}')
                    )
                )
        elif isinstance(part, ToolReturnPart):
            output, user_content = part.model_response_str_and_user_content()
            if function_parts:
                # Gemini's function response has an `error` key for a failed call, as on a standard request.
                response = (
                    {'error': part.model_response_str(wrap_if_error=False)}
                    if part.outcome in ERROR_OUTCOMES
                    else {'output': output}
                )
                parts.append(
                    genai_types.Part(
                        function_response=genai_types.FunctionResponse(
                            id=part.tool_call_id, name=part.tool_name, response=response
                        )
                    )
                )
            else:
                parts.append(genai_types.Part(text=f'[Tool {part.tool_call_id}: {part.tool_name} returned: {output}]'))
            if user_content:
                parts.extend(
                    _genai_user_parts(
                        await seed_user_content(
                            part=UserPromptPart(content=user_content),
                            provider_name=provider_name,
                            supports_images=supports_images,
                        )
                    )
                )
        elif isinstance(part, RetryFeedbackPart):
            parts.append(genai_types.Part(text=seed_retry_feedback_text(part)))
        else:
            assert_never(part)
    return parts


def _seed_response_parts(message: ModelResponse, *, provider_name: str, function_parts: bool) -> list[genai_types.Part]:
    parts: list[genai_types.Part] = []
    for index, part in enumerate(message.parts):
        if isinstance(part, TextPart):
            if part.content:
                parts.append(genai_types.Part(text=part.content))
        elif isinstance(part, ThinkingPart):
            if part.content:
                start_tag, end_tag = DEFAULT_THINKING_TAGS
                parts.append(genai_types.Part(text='\n'.join([start_tag, part.content, end_tag])))
        elif isinstance(part, ToolCallPart):
            if function_parts:
                parts.append(
                    genai_types.Part(
                        function_call=genai_types.FunctionCall(
                            id=part.tool_call_id, name=part.tool_name, args=part.args_as_dict()
                        )
                    )
                )
            else:
                parts.append(
                    genai_types.Part(text=f'[Tool {part.tool_call_id}: {part.tool_name}({part.args_as_json_str()})]')
                )
        elif isinstance(part, (NativeToolCallPart, NativeToolReturnPart)):
            continue
        elif isinstance(part, SpeechPart):
            # Assistant audio can't be replayed on any provider, so it's seeded as its transcript, marked where a
            # barge-in cut it off: the model never heard what came after.
            if seed_speech_content(part=part, provider_name=provider_name, supports_audio=False):
                parts.append(genai_types.Part(text=assistant_speech_text(message, index)))
        elif isinstance(part, CompactionPart):
            # Provider-session-bound compaction state can't round-trip into another session; classic
            # model adapters skip it when crossing APIs (e.g. Chat Completions), and seeding matches.
            continue
        elif isinstance(part, FilePart):
            raise UserError(
                f'`FilePart` cannot be seeded into {provider_name} realtime history. '
                'Convert it to text or filter it from `message_history` before connecting.'
            )
        else:
            assert_never(part)
    return parts


def _genai_user_parts(content: Sequence[str | BinaryContent]) -> list[genai_types.Part]:
    return [
        genai_types.Part(text=item)
        if isinstance(item, str)
        else genai_types.Part(inline_data=genai_types.Blob(data=item.data, mime_type=item.media_type))
        for item in content
        if not isinstance(item, str) or item
    ]


def _schema_from_json_schema(json_schema: dict[str, Any]) -> genai_types.Schema:
    """Convert a JSON schema to the `Schema` a Gemini Live function declaration carries.

    A declaration's parameters are *either* `parametersJsonSchema` (full JSON Schema, which
    [`GoogleModel`][pydantic_ai.models.google.GoogleModel] sends) *or* `parameters` — and Live only
    implements the latter, silently ignoring the former, which leaves the model guessing at argument
    names. So the schema goes through
    [`GoogleOpenAPISchemaTransformer`][pydantic_ai.profiles.google.GoogleOpenAPISchemaTransformer]
    into the OpenAPI subset instead, exactly as a standard request did before it moved to JSON Schema.

    `Schema.from_json_schema` would be the obvious builder, but it routes through
    `genai_types.JSONSchema`, which has no `nullable` — every optional argument would arrive
    advertised as non-nullable.
    """
    transformed = GoogleOpenAPISchemaTransformer(json_schema, strict=None).walk()
    accepted_keywords = frozenset(field.alias or name for name, field in genai_types.Schema.model_fields.items())
    return genai_types.Schema.model_validate(
        _drop_unsupported_schema_keywords(transformed, accepted_keywords=accepted_keywords)
    )


def _translate_legacy_settings(
    settings: GoogleRealtimeModelSettings, *, stacklevel: int = 2
) -> GoogleRealtimeModelSettings:
    """Translate the deprecated `google_async_tool_calls` into the shared `async_tool_calls`, warning."""
    # TODO(v3): remove, along with the `google_async_tool_calls` setting.
    if 'google_async_tool_calls' not in settings:
        return settings
    # Session settings reach the model at connect time, where no stack level points at the code that set
    # them, so the message names the setting.
    warnings.warn(
        '`google_async_tool_calls` is deprecated, use the shared `async_tool_calls` setting instead.',
        PydanticAIDeprecationWarning,
        stacklevel=stacklevel,
    )
    translated = settings.copy()
    translated.setdefault('async_tool_calls', translated.pop('google_async_tool_calls'))
    return translated


def _tool_def_to_genai(
    tool: ToolDefinition, *, async_tool_calls: bool = False, explicit_blocking: bool = False
) -> genai_types.FunctionDeclaration:
    """Convert a [`ToolDefinition`][pydantic_ai.tools.ToolDefinition] to a Gemini function declaration.

    `explicit_blocking` declares a blocking call `BLOCKING` rather than leaving the behavior unset, for a
    model whose unset default is non-blocking.
    """
    return genai_types.FunctionDeclaration(
        name=tool.name,
        description=tool.description or '',
        parameters=_schema_from_json_schema(tool.parameters_json_schema),
        response=_schema_from_json_schema(tool.return_schema) if tool.return_schema else None,
        behavior=genai_types.Behavior.NON_BLOCKING
        if async_tool_calls
        else genai_types.Behavior.BLOCKING
        if explicit_blocking
        else None,
    )


def _native_tool_to_genai(tool: AbstractNativeTool) -> genai_types.Tool:
    """Map a supported Gemini built-in native tool to a genai `Tool`.

    Today's Live profile enables Google Search only. URL context and code execution remain class-level
    capabilities so a future model profile can enable them through the standard capability/profile
    intersection without another adapter change.
    """
    if isinstance(tool, WebSearchTool):
        return genai_types.Tool(google_search=genai_types.GoogleSearch())
    if isinstance(tool, WebFetchTool):
        return genai_types.Tool(url_context=genai_types.UrlContext())
    if isinstance(tool, CodeExecutionTool):
        return genai_types.Tool(code_execution=genai_types.ToolCodeExecution())
    raise UserError(f'Google realtime does not support the native tool {type(tool).__name__!r}.')


def _map_grounding_parts(content: genai_types.LiveServerContent, provider_name: str) -> list[ModelResponsePart]:
    """Reconstruct the native tool call/return parts for a grounded turn, for history.

    Reuses [`GoogleModel`][pydantic_ai.models.google.GoogleModel]'s grounding mappers so a grounded
    realtime turn's history is byte-identical in shape to a classic request's — a
    [`NativeToolCallPart`][pydantic_ai.messages.NativeToolCallPart] /
    [`NativeToolReturnPart`][pydantic_ai.messages.NativeToolReturnPart] pair for Google Search grounding
    and another for URL context. The session folds these parts into the turn's `ModelResponse`.
    """
    parts: list[ModelResponsePart] = []
    search_call, search_return = _map_grounding_metadata(content.grounding_metadata, provider_name)
    if search_call and search_return:
        parts += [search_call, search_return]
    fetch_call, fetch_return = _map_url_context_metadata(content.url_context_metadata, provider_name)
    if fetch_call and fetch_return:
        parts += [fetch_call, fetch_return]
    return parts


def _map_usage(usage: genai_types.UsageMetadata, *, provider_name: str, provider_url: str) -> RequestUsage:
    """Map Gemini Live `usage_metadata` through the standard Gemini usage mapper.

    Live's metadata is the generate-content shape with its output fields renamed from `candidates*`
    to `response*`, so the counts pass straight through and only the extraction payload — which
    genai-prices reads by the generate-content names — is translated back.

    `provider_url` is the provider's HTTP base URL, not the WebSocket the session actually dialed:
    it's what genai-prices matches providers on, and it's the same URL a standard request would
    have reported, so Vertex and the Gemini API resolve exactly as they do off a realtime session.
    """
    extract_data = usage.model_dump(by_alias=True, exclude={'response_token_count', 'response_tokens_details'})
    extract_data['candidatesTokenCount'] = usage.response_token_count
    extract_data['candidatesTokensDetails'] = [
        item.model_dump(by_alias=True) for item in usage.response_tokens_details or ()
    ]
    return _usage_metadata_as_usage(
        prompt_token_count=usage.prompt_token_count,
        output_token_count=usage.response_token_count,
        cached_content_token_count=usage.cached_content_token_count,
        thoughts_token_count=usage.thoughts_token_count,
        tool_use_prompt_token_count=usage.tool_use_prompt_token_count,
        prompt_tokens_details=usage.prompt_tokens_details,
        cache_tokens_details=usage.cache_tokens_details,
        output_tokens_details=usage.response_tokens_details,
        tool_use_prompt_tokens_details=usage.tool_use_prompt_tokens_details,
        output_details_prefix='response',
        extract_data={'usageMetadata': extract_data},
        provider=provider_name,
        provider_url=provider_url,
    )


@contextmanager
def _single_ws_user_agent(client: Client) -> Generator[None]:
    """Drop a duplicate `User-Agent` header for the duration of a Gemini Live WebSocket handshake.

    `google-genai` forwards the client's HTTP headers verbatim as the Live WebSocket's
    `additional_headers`. The `GoogleProvider` adds a capitalized `User-Agent` (for HTTP, where `httpx`
    folds it together with the SDK's own lowercase `user-agent`), but the `websockets` library stores
    headers case-insensitively and rejects the two as a duplicate, failing the handshake. We remove our
    capitalized variant just for the connect and restore it after, so a single user-agent reaches the
    socket while HTTP requests keep pydantic-ai's user-agent.
    """
    headers = client._api_client._http_options.headers  # pyright: ignore[reportPrivateUsage]
    assert headers is not None
    duplicates = [key for key in headers if key.lower() == 'user-agent']
    if len(duplicates) < 2:
        yield
        return
    # Keep the SDK's own lowercase `user-agent` if present, otherwise the first seen; drop the rest.
    keep = 'user-agent' if 'user-agent' in duplicates else duplicates[0]
    removed = {key: headers.pop(key) for key in duplicates if key != keep}
    try:
        yield
    finally:
        headers.update(removed)


_PROACTIVITY_API_VERSION = 'v1alpha'
"""The Gemini Developer API version that serves `proactivity` on the Live setup message."""


@contextmanager
def _ws_trace_context(client: Client) -> Generator[None]:
    """Add the current trace context to the Gemini Live handshake headers for the connect only.

    `google-genai` forwards the client's HTTP headers as the Live WebSocket's `additional_headers`, so
    injecting `traceparent` here propagates trace context to the server (e.g. a gateway) over the
    handshake — see `inject_trace_context` for the rationale. The keys it added are removed afterwards
    so the shared client's later HTTP requests don't carry a stale trace context.
    """
    headers = client._api_client._http_options.headers  # pyright: ignore[reportPrivateUsage]
    assert headers is not None
    carrier: dict[str, str] = {}
    inject_trace_context(carrier)
    # Compared case-insensitively: header names are, and `websockets` stores them that way, so adding a
    # lowercase `traceparent` next to a `Traceparent` the client already carries is a duplicate header
    # the handshake can be rejected for (the same hazard `_single_ws_user_agent` above reconciles).
    existing = {key.lower() for key in headers}
    added = {key: value for key, value in carrier.items() if key.lower() not in existing}
    headers.update(added)
    try:
        yield
    finally:
        for key in added:
            headers.pop(key, None)


@dataclass(init=False)
class GoogleRealtimeModel(RealtimeModel):
    """Gemini Live API model.

    Session and generation configuration is read from
    [`GoogleRealtimeModelSettings`][pydantic_ai.realtime.google.GoogleRealtimeModelSettings], passed
    through `settings` as model-level defaults or as `model_settings` when opening a session.

    Authentication and the underlying `google-genai` client come from a
    [`Provider`][pydantic_ai.providers.Provider], mirroring [`GoogleModel`][pydantic_ai.models.google.GoogleModel].
    Pass `provider='google'` (the default) for the Gemini Developer API (reads `GOOGLE_API_KEY` /
    `GEMINI_API_KEY`), `provider='google-cloud'` for Vertex AI (Application Default Credentials, useful
    where org policy disallows API keys), or a [`GoogleProvider`][pydantic_ai.providers.google.GoogleProvider] /
    [`GoogleCloudProvider`][pydantic_ai.providers.google_cloud.GoogleCloudProvider] instance for a custom
    key, client, or region. Gemini Live is available on both surfaces.

    Args:
        model: The model name, e.g. `gemini-3.8-live` (low-latency voice), `gemini-3.8-live-extended-thinking`
            (reasons in the background while it speaks, and always runs tools asynchronously), or
            `gemini-2.5-flash-native-audio-latest` (an alias that tracks the newest native-audio Live model).
        provider: The provider to use for authentication and API access — `'google'` (Gemini Developer
            API, the default) or `'google-cloud'` (Vertex AI), or a `Provider` instance.
        settings: Model-level defaults for session and generation configuration.
        profile: Optional override for the [realtime model profile][pydantic_ai.realtime.RealtimeModelProfile],
            merged over the provider's — a partial dict, or a callable taking the resolved profile and
            returning the one to use. Mirrors `profile=` on a standard
            [`Model`][pydantic_ai.models.Model], and is the escape hatch when a model name doesn't
            identify the model (e.g. an Azure deployment named something other than its model).
    """

    model: GoogleRealtimeModelName
    _: KW_ONLY
    settings: RealtimeModelSettings | None = None
    _provider: Provider[Client] = field(init=False, repr=False)

    # Written out rather than generated because `profile` has to be an init argument while
    # `RealtimeModel.profile` stays the *resolved* profile, exactly as on a standard `Model` — a
    # dataclass field of that name would shadow the property.
    def __init__(
        self,
        model: GoogleRealtimeModelName,
        *,
        provider: Literal['google', 'google-cloud', 'gateway'] | Provider[Client] = 'google',
        settings: RealtimeModelSettings | None = None,
        profile: RealtimeModelProfileSpec | None = None,
    ) -> None:
        if settings:
            # Translated here so the deprecation warning points at the caller's line.
            settings = _translate_legacy_settings(cast(GoogleRealtimeModelSettings, settings), stacklevel=3)
        super().__init__(settings=settings, profile=profile)
        self.model = model
        if isinstance(provider, str):
            provider_name = 'gateway/google-cloud' if provider == 'gateway' else provider
            provider = cast('Provider[Client]', infer_provider(provider_name))
        self._provider = provider

    @property
    def client(self) -> Client:
        """The underlying `google.genai.Client` from the provider."""
        return self._provider.client

    @property
    def model_name(self) -> GoogleRealtimeModelName:
        return self.model

    @property
    def system(self) -> str:
        return self._provider.name

    def _adjust_provider_profile(self, profile: RealtimeModelProfile) -> RealtimeModelProfile:
        # `google_closes_tool_call_turn_separately` was verified on Vertex AI only, so it's off on the Gemini
        # Developer API unless a `profile=` override (applied after this) turns it back on.
        if cast(GoogleRealtimeModelProfile, profile).get('google_closes_tool_call_turn_separately', False) and (
            not self.client.vertexai
        ):
            profile = merge_realtime_profile(
                profile, GoogleRealtimeModelProfile(google_closes_tool_call_turn_separately=False)
            )
        return profile

    @property
    def profile(self) -> RealtimeModelProfile:
        profile = cast(GoogleRealtimeModelProfile, super().profile)
        # TODO(v3): remove, along with the `google_requires_async_tool_calls` profile field.
        if 'google_requires_async_tool_calls' not in profile:
            return profile
        warnings.warn(
            '`GoogleRealtimeModelProfile` key `google_requires_async_tool_calls` is deprecated, use '
            "`async_tool_call_mode='always'` instead.",
            PydanticAIDeprecationWarning,
            stacklevel=2,
        )
        translated = profile.copy()
        if translated.pop('google_requires_async_tool_calls'):
            translated.update(async_tool_call_mode='always', supports_async_tool_calls=True)
        return translated

    @property
    def _google_profile(self) -> GoogleRealtimeModelProfile:
        """[`profile`][pydantic_ai.realtime.RealtimeModel.profile], narrowed to the Gemini-specific fields."""
        return cast(GoogleRealtimeModelProfile, self.profile)

    def _merge_model_settings(self, model_settings: RealtimeModelSettings | None) -> RealtimeModelSettings | None:
        # Each layer is translated on its own, so a deprecated setting keeps its layer's precedence.
        merged: GoogleRealtimeModelSettings | None = None
        for layer in (self.settings, model_settings):
            if layer:
                translated = _translate_legacy_settings(cast(GoogleRealtimeModelSettings, layer))
                merged = {**merged, **translated} if merged is not None else translated.copy()
        return merged

    @classmethod
    def supported_native_tools(cls) -> frozenset[type[AbstractNativeTool]]:
        return frozenset({WebSearchTool, WebFetchTool, CodeExecutionTool})

    def unsupported_native_tool_settings(self, native_tool: AbstractNativeTool) -> frozenset[str]:
        """Return all of `native_tool`'s restricting settings, as Gemini's native tools apply none of them."""
        return native_tool.restricting_settings

    def _speech_config(self, model_settings: GoogleRealtimeModelSettings) -> genai_types.SpeechConfig | None:
        """Build the speech/voice config from `google_voice` and `google_language_code`."""
        voice_config: genai_types.VoiceConfig | None = None
        voice = model_settings.get('google_voice')
        language_code = model_settings.get('google_language_code')
        if voice:
            voice_config = genai_types.VoiceConfig(
                prebuilt_voice_config=genai_types.PrebuiltVoiceConfig(voice_name=voice)
            )
        if voice_config is None and language_code is None:
            return None
        return genai_types.SpeechConfig(voice_config=voice_config, language_code=language_code)

    def _check_proactive_audio_api_version(self, settings: GoogleRealtimeModelSettings) -> None:
        """Reject a proactive-audio session on a client that can't carry the setting.

        `proactivity` is served on the Gemini Developer API's `v1alpha` only: on any other version the
        API answers `1007 Invalid JSON payload received. Unknown name "proactivity" at 'setup'` and the
        session never opens (verified live 2026-09-16 on the SDK default `v1beta` and on an explicit one,
        against `gemini-2.5-flash-native-audio-latest`, `gemini-3.8-live`, and
        `gemini-3.8-live-extended-thinking`).

        The version is a property of the *client*, which `google-genai` reads when it builds the
        WebSocket path and which ordinary `GoogleModel` requests on the same client read too — so it is
        the caller's to set, not ours to swap for the duration of a handshake. Saying so here turns an
        opaque close code into an instruction.

        Vertex AI is left alone: its version line has no `v1alpha`, and what it does with `proactivity`
        isn't something this has been checked against.
        """
        if not settings.get('google_proactive_audio', False) or self.client.vertexai:
            return
        api_version = self.client._api_client._http_options.api_version  # pyright: ignore[reportPrivateUsage]
        if api_version == _PROACTIVITY_API_VERSION:
            return
        raise UserError(
            f'`google_proactive_audio=True` needs a client on the `{_PROACTIVITY_API_VERSION}` API version, '
            f'but this one is on `{api_version}`, where Gemini Live rejects the setting and the session '
            'fails to open. Build the client with that version and hand it to the provider:\n\n'
            '    from google import genai\n'
            '    from google.genai import types\n'
            '    from pydantic_ai.providers.google import GoogleProvider\n\n'
            f'    client = genai.Client(api_key=..., http_options=types.HttpOptions(api_version={_PROACTIVITY_API_VERSION!r}))\n'
            '    provider = GoogleProvider(client=client)'
        )

    def _check_voice_settings(self, settings: GoogleRealtimeModelSettings) -> None:
        """Reject voice settings this model can't honor, before a session opens for nothing."""
        # TODO(v3): remove, along with the `google_multi_speaker` setting.
        if 'google_multi_speaker' in settings:
            raise UserError(
                '`google_multi_speaker` is deprecated and not supported by any Gemini Live model: a Live '
                'session speaks in one voice. Remove it and set `google_voice` instead.'
            )
        if settings.get('google_affective_dialog', False) and not self._google_profile.get(
            'google_supports_affective_dialog', True
        ):
            raise UserError(
                f'`google_affective_dialog=True` is not supported by {self.model!r}; Gemini Live rejects it. '
                'Leave it unset for this model.'
            )

    def _input_transcription(self, settings: GoogleRealtimeModelSettings) -> bool:
        """Whether to transcribe the user's audio.

        Gemini has no separate transcription model to point at, so a *pinned* `input_transcription_model`
        can't be honored — but `None` ("don't transcribe") can be, and must be: it's the setting someone
        reaches for to keep the user's words out of history, and silently transcribing anyway would defeat
        the one thing it exists to do. The provider-specific `google_input_transcription` still wins where
        both are given.
        """
        if (enabled := settings.get('google_input_transcription')) is not None:
            return enabled
        # Absent and `None` are different here: only an explicit `None` asks for transcription off.
        if 'input_transcription_model' in settings and settings['input_transcription_model'] is None:
            return False
        return True

    def _session_resumption_enabled(self, settings: GoogleRealtimeModelSettings) -> bool:
        """Whether to request session-resumption handles.

        An explicit `google_enable_session_resumption` wins; when absent, a `reconnect` policy implies
        resumption, since a re-dial without a handle would lose the conversation.
        """
        if (enabled := settings.get('google_enable_session_resumption')) is not None:
            return enabled
        return settings.get('reconnect') is not None

    def _realtime_input_config(
        self, model_settings: GoogleRealtimeModelSettings
    ) -> genai_types.RealtimeInputConfig | None:
        """Build the turn-taking config from `vad`, `activity_handling`, and `turn_coverage`."""
        detection: genai_types.AutomaticActivityDetection | None = None
        vad: AutomaticVAD | None
        if 'google_vad' in model_settings:
            vad = model_settings['google_vad']
        elif 'turn_detection' in model_settings:
            turn_detection = model_settings['turn_detection']
            # `True` means the provider default (on), same as an absent setting. `False` asks for the
            # same thing as `google_vad={'disabled': True}`, so both land on the check below.
            if turn_detection is False:
                vad = {'disabled': True}
            else:
                vad = None if turn_detection is True else _automatic_vad_from_turn_detection(turn_detection)
        else:
            vad = None
        if vad is not None:
            if vad.get('disabled', False):
                # Disabling VAD is push-to-talk, which needs manual turn control Gemini Live doesn't
                # expose through this session API yet (no `commit_audio()`/`create_response()`), so a
                # disabled session would connect but never take a turn. Fail loudly instead.
                raise UserError(
                    'Gemini Live does not support disabling automatic turn detection (push-to-talk) '
                    'through the realtime session API yet, as it has no manual turn controls. Use '
                    'automatic turn detection (the default) instead.'
                )
            detection = genai_types.AutomaticActivityDetection(
                start_of_speech_sensitivity=_START_SENSITIVITY[start_sensitivity]
                if (start_sensitivity := vad.get('start_sensitivity'))
                else None,
                end_of_speech_sensitivity=_END_SENSITIVITY[end_sensitivity]
                if (end_sensitivity := vad.get('end_sensitivity'))
                else None,
                prefix_padding_ms=vad.get('prefix_padding_ms'),
                silence_duration_ms=vad.get('silence_duration_ms'),
            )
        activity_handling = model_settings.get('google_activity_handling')
        turn_coverage = model_settings.get('google_turn_coverage')
        activity = _ACTIVITY_HANDLING[activity_handling] if activity_handling else None
        coverage = _TURN_COVERAGE[turn_coverage] if turn_coverage else None
        if detection is None and activity is None and coverage is None:
            return None
        return genai_types.RealtimeInputConfig(
            automatic_activity_detection=detection, activity_handling=activity, turn_coverage=coverage
        )

    def _apply_generation(
        self, config: genai_types.LiveConnectConfig, model_settings: GoogleRealtimeModelSettings | None
    ) -> None:
        """Apply generation params from `model_settings` (base keys + Google-specific ones)."""
        model_settings = model_settings or {}
        if (max_tokens := model_settings.get('max_tokens')) is not None:
            config.max_output_tokens = max_tokens
        if (temperature := model_settings.get('temperature')) is not None:
            config.temperature = temperature
        if (top_p := model_settings.get('top_p')) is not None:
            config.top_p = top_p
        if (top_k := model_settings.get('top_k')) is not None:
            config.top_k = top_k
        if (seed := model_settings.get('seed')) is not None:
            config.seed = seed
        profile = self._google_profile
        if (google_thinking := model_settings.get('google_thinking_config')) is not None:
            # The Gemini-native config takes precedence over the cross-provider `thinking` setting.
            thinking_config = genai_types.ThinkingConfig(**google_thinking)
            if (
                thinking_config.thinking_level is None
                and thinking_config.thinking_budget is None
                and profile.get('google_thinking_always_enabled', False)
            ):
                # A raw config that only turns on, say, `include_thoughts` still has to carry a level on a
                # model that demands one, or the handshake is rejected outright. An explicit level or
                # budget is left exactly as given: the escape hatch's whole point is going around us.
                thinking_config.thinking_level = _thinking_to_config(_IMPLIED_THINKING_EFFORT, profile).thinking_level
            config.thinking_config = thinking_config
        elif (thinking := model_settings.get('thinking')) is not None:
            if profile.get('supports_thinking', False):
                config.thinking_config = _thinking_to_config(thinking, profile)
        elif profile.get('google_thinking_always_enabled', False):
            # The session asked for nothing, but the model's API demands a level: `gemini-3.8-live-extended-thinking`
            # closes the handshake with `1007 Thinking level must be specified for this model` when it's absent.
            config.thinking_config = _thinking_to_config(_IMPLIED_THINKING_EFFORT, profile)
        if (resolution := model_settings.get('google_video_resolution')) is not None:
            config.media_resolution = resolution

    def _config(
        self,
        instructions: str,
        tools: list[ToolDefinition] | None,
        *,
        model_settings: GoogleRealtimeModelSettings | None,
        native_tools: list[AbstractNativeTool] | None = None,
        resumption_handle: str | None = None,
        initial_history_in_client_content: bool = False,
    ) -> genai_types.LiveConnectConfig:
        settings = cast('GoogleRealtimeModelSettings', self._merge_model_settings(model_settings) or {})
        modality = (
            genai_types.Modality.AUDIO
            if settings.get('output_modality', 'audio') == 'audio'
            else genai_types.Modality.TEXT
        )
        config = genai_types.LiveConnectConfig(response_modalities=[modality])
        if instructions:
            config.system_instruction = instructions
        config.speech_config = self._speech_config(settings)
        transcription_language_codes = settings.get('google_transcription_language_codes')
        if self._input_transcription(settings):
            config.input_audio_transcription = genai_types.AudioTranscriptionConfig(
                language_codes=transcription_language_codes
            )
        if settings.get('google_output_transcription', True):
            config.output_audio_transcription = genai_types.AudioTranscriptionConfig(
                language_codes=transcription_language_codes
            )
        config.realtime_input_config = self._realtime_input_config(settings)
        if settings.get('google_affective_dialog', False):
            config.enable_affective_dialog = True
        if settings.get('google_proactive_audio', False):
            config.proactivity = genai_types.ProactivityConfig(proactive_audio=True)
        if (context_compression := settings.get('google_context_compression')) is not None:
            config.context_window_compression = genai_types.ContextWindowCompressionConfig(
                trigger_tokens=context_compression.get('trigger_tokens'),
                sliding_window=genai_types.SlidingWindow(target_tokens=context_compression.get('target_tokens')),
            )
        if self._session_resumption_enabled(settings):
            config.session_resumption = genai_types.SessionResumptionConfig(handle=resumption_handle)
        if initial_history_in_client_content:
            config.history_config = genai_types.HistoryConfig(initial_history_in_client_content=True)
        # Typed as `list[Any]` because `LiveConnectConfig.tools` is a broad union (Tool | Callable |
        # MCP types); a precisely-typed `list[Tool]` isn't assignable to it (list invariance).
        genai_tools: list[Any] = []
        # Gemini's live config has no `tool_config`, so the only expressible restriction is which
        # functions are advertised; the mode the resolution asks for is dropped.
        advertised_tools, _ = resolve_advertised_tools(tools, settings.get('tool_choice'))
        if advertised_tools:
            async_tool_calls = self._async_tool_calls(settings)
            genai_tools.append(
                genai_types.Tool(
                    function_declarations=[
                        _tool_def_to_genai(
                            t,
                            async_tool_calls=async_tool_calls,
                            explicit_blocking=self._google_profile.get('google_async_tool_calls_by_default', False),
                        )
                        for t in advertised_tools
                    ]
                )
            )
        genai_tools.extend(_native_tool_to_genai(t) for t in native_tools or [])
        if genai_tools:
            config.tools = genai_tools
        self._apply_generation(config, settings)
        if config_overrides := settings.get('google_config_overrides'):
            for key, value in config_overrides.items():
                setattr(config, key, value)
        return config

    @asynccontextmanager
    async def connect(
        self,
        *,
        messages: Sequence[ModelMessage],
        model_settings: RealtimeModelSettings | None,
        model_request_parameters: ModelRequestParameters,
    ) -> AsyncGenerator[GoogleRealtimeConnection]:
        client = self._provider.client
        settings = cast('GoogleRealtimeModelSettings', self._merge_model_settings(model_settings) or {})
        instructions = session_instructions(messages, model_request_parameters)
        # Transparent reconnect needs session resumption, so the server restores state on re-dial;
        # a `reconnect` policy requests it automatically (see `_session_resumption_enabled`). An
        # explicit opt-out alongside a policy would silently reconnect into a model that remembers
        # nothing, so it fails loudly instead.
        reconnect = settings.get('reconnect')
        handshake_timeout = settings.get('handshake_timeout', 30.0)
        if reconnect is not None and settings.get('google_enable_session_resumption') is False:
            raise UserError(
                'A `reconnect` policy requires Gemini session resumption, but '
                '`google_enable_session_resumption=False` explicitly disables it. Remove the '
                '`reconnect` policy, or leave `google_enable_session_resumption` unset so the '
                'policy enables resumption.'
            )
        self._check_proactive_audio_api_version(settings)
        self._check_voice_settings(settings)
        # Prior conversation is seeded once, after the initial connect. Normalized before dialing, so
        # unsupported content is a caller `UserError` rather than a session opened for nothing.
        turns = await _seed_turns(
            messages,
            profile=self.profile,
            provider_name=self.system,
            function_parts=self._google_profile.get('google_supports_seeding_function_parts', False),
        )
        # A seed with native function parts goes in as the session's initial history, which ends with
        # `turn_complete` without triggering a reply; one without is sent as before. Only the first dial
        # asks for it: a session resumed from a handle already has the history, and one that isn't
        # wouldn't get it again, so either way a server waiting for initial history would take the next
        # typed turn as history and not answer it.
        history_in_client_content = any(
            part.function_call or part.function_response for turn in turns for part in turn.parts or ()
        )
        # The live connection's context manager. A reconnect closes the previous one before opening
        # the next (so they don't accumulate), and teardown closes whatever is current.
        cm: AbstractAsyncContextManager[AsyncSession] | None = None
        dialed = False

        async def dial(handle: str | None) -> AsyncSession:
            nonlocal cm, dialed
            if cm is not None:
                previous, cm = cm, None
                await previous.__aexit__(None, None, None)
            config = self._config(
                instructions,
                model_request_parameters.function_tools,
                model_settings=settings,
                native_tools=model_request_parameters.native_tools,
                resumption_handle=handle,
                initial_history_in_client_content=history_in_client_content and not dialed,
            )
            dialed = True
            opening = client.aio.live.connect(model=self.model, config=config)
            async with _ws_connect_lock():
                with ExitStack() as stack:
                    stack.enter_context(_single_ws_user_agent(client))
                    stack.enter_context(_ws_trace_context(client))
                    # A gateway route needs nothing extra here: the relay routes the SDK's native
                    # Vertex Bidi path, and the gateway bearer auth reaches the handshake via a
                    # static header set on the client at build time (see `_set_google_ws_gateway_auth`).
                    # The SDK waits for `setup_complete` without a deadline of its own, so a server that
                    # accepts the socket and never answers the setup would hang the dial forever.
                    # `asyncio.wait_for` rather than an anyio scope: its cancellation is edge-triggered,
                    # so the SDK's `async with ws_connect(...)` still gets to close the socket it opened,
                    # where a level-triggered scope would cancel that close too and leak the socket.
                    try:
                        session = await asyncio.wait_for(opening.__aenter__(), timeout=handshake_timeout)
                    except TimeoutError as e:
                        raise TimeoutError(f'no setup_complete within {handshake_timeout} seconds') from e
            cm = opening
            return session

        try:
            # A rejected config (unsupported `voice`, unknown model) closes the WebSocket, which the SDK
            # surfaces as an `APIError`. Map it to a typed exception rather than leaking the SDK's.
            # Reconnects dial from the receive loop, which keeps handling the `APIError` as a retryable drop.
            try:
                session = await dial(None)
            except genai_errors.APIError as e:
                if e.code >= _MIN_WEBSOCKET_CLOSE_CODE:
                    # The server closed the socket during setup, and the SDK reports the WebSocket close
                    # code (`1007` for a rejected config, `1008` for an unknown model) where an HTTP status
                    # would go. A close code is not an HTTP status, so this is a `RealtimeError`, worded like
                    # a close later in the session and like the OpenAI-protocol providers' handshake closes.
                    raise RealtimeError(model_name=self.model, message=f'Gemini Live connection closed: {e}') from e
                mapped_error = _map_api_error(e, self.model)
                if isinstance(mapped_error, ModelHTTPError):
                    raise mapped_error from e
                raise RealtimeError(model_name=self.model, message=str(e)) from e  # pragma: no cover
            except websockets.InvalidStatus as e:
                # A rejected WebSocket upgrade (e.g. bad key → 401) surfaces from `google-genai` as a raw
                # `websockets` error rather than an `APIError`; the WebSocket is the API here, so map its
                # HTTP status to `ModelHTTPError` like a regular request.
                response = e.response
                body = response.body.decode(errors='replace') if response.body else response.reason_phrase
                raise ModelHTTPError(
                    status_code=response.status_code,
                    model_name=self.model,
                    body=body,
                    headers=dict(response.headers),
                ) from e
            except websockets.WebSocketException as e:
                # Any other raw `websockets` handshake failure the SDK didn't wrap as an `APIError`; no HTTP
                # status, so surface it as a `RealtimeError` rather than letting it escape untyped.
                raise RealtimeError(model_name=self.model, message=f'WebSocket error during connect: {e}') from e
            except TimeoutError as e:
                # `handshake_timeout` ran out before the session was set up, or the socket's own
                # opening timeout did: a `RealtimeError`, like an OpenAI-protocol handshake timeout.
                raise RealtimeError(
                    model_name=self.model, message=f'Timed out opening the Gemini Live session: {e}'
                ) from e
            except OSError as e:
                # The connection never came up: DNS failure, refused, or reset. No HTTP status exists,
                # so this is a `RealtimeError` too, rather than a bare built-in from what looks like an
                # ordinary model call.
                raise RealtimeError(model_name=self.model, message=f'Could not reach the realtime API: {e}') from e
            # Seed prior conversation as inactive context turns: without `turn_complete` the model doesn't
            # respond yet, and initial history ends with one without prompting a reply. Reconnects don't
            # re-seed: session resumption restores server state, and a `RealtimeSessionReconnectEvent`
            # starts a fresh turn.
            if turns:
                # Unpacked into a new list, which the SDK's invariant `list[Content | ContentDict]` accepts.
                await session.send_client_content(turns=[*turns], turn_complete=history_in_client_content)
            yield GoogleRealtimeConnection(
                session,
                profile=self.profile,
                provider_name=self._provider.name,
                provider_url=self._provider.base_url,
                dial=dial if reconnect is not None else None,
                reconnect=reconnect,
                input_transcription_enabled=self._input_transcription(settings),
                async_tool_calls=self._async_tool_calls(settings),
                text_output=settings.get('output_modality', 'audio') == 'text',
            )
        finally:
            if cm is not None:
                await cm.__aexit__(None, None, None)


@dataclass
class _TypedTurn:
    """A typed turn sent on a Gemini connection, tracked until a resumption handle covers it."""

    input_index: int
    answered: bool = False
    # Still on the wire: if the send then fails, the session takes the turn back itself.
    sending: bool = True


class _CutOffLifecycle(InferredLifecycle):
    """The inferred lifecycle of a Gemini Live model that cuts its reply off for an input that reaches it mid-generation.

    See `GoogleRealtimeModelProfile.google_input_cuts_off_reply`.
    """

    inputs_cut_off_replies = True


class GoogleRealtimeConnection(RealtimeConnection):
    """A live connection to the Gemini Live API, backed by a `google-genai` session."""

    # The SDK surfaces a closed socket as `ConnectionClosed` or an `APIError`; `OSError` covers the
    # socket-level failures underneath both.
    transport_errors = (ConnectionClosed, genai_errors.APIError, OSError)
    # How this provider names itself in error messages.
    _provider_label = 'Gemini Live'

    def __init__(
        self,
        session: AsyncSession,
        *,
        profile: RealtimeModelProfile | None = None,
        provider_name: str = 'google',
        dial: Callable[[str | None], Awaitable[AsyncSession]] | None = None,
        reconnect: ReconnectPolicy | None = None,
        input_transcription_enabled: bool = True,
        async_tool_calls: bool = False,
        provider_url: str = '',
        text_output: bool = False,
    ) -> None:
        self._session = session
        # Whether the session asked for text rather than audio (`output_modality='text'`). A text-only model
        # streams its text answer as `output_transcription` (`gemini-robotics-er-2-streaming-preview`, verified
        # live), which is then the answer itself, written rather than spoken.
        self._text_output = text_output
        self._profile = profile if profile is not None else DEFAULT_REALTIME_PROFILE
        self._input_transcription_enabled = input_transcription_enabled
        self._reconnects_used = 0
        self._gave_up = False
        self._async_tool_calls_enabled = async_tool_calls
        # Whether the model takes a `scheduling` field at all: extended thinking paces results against its
        # own reasoning and closes the session if one is sent. A connection built without a profile keeps
        # sending it, as it did before the flag existed; `GoogleRealtimeModel.connect` always passes one.
        self._async_tool_call_scheduling_enabled = profile is None or cast('GoogleRealtimeModelProfile', profile).get(
            'google_supports_async_tool_call_scheduling', False
        )
        self._closes_tool_call_turn_separately = profile is not None and cast(
            'GoogleRealtimeModelProfile', profile
        ).get('google_closes_tool_call_turn_separately', False)
        # Provider name stamped onto native-tool history parts (grounding / code execution), matching the
        # classic `GoogleModel` (`NativeToolCallPart.provider_name`), so a turn's history is provider-tagged
        # identically whether it came from a realtime session or a classic run.
        self._provider_name = provider_name
        # The provider's HTTP base URL, which is how genai-prices identifies a provider for pricing.
        self._provider_url = provider_url
        # internal call id -> (tool name, Gemini call id), so a `ToolResult` can echo the name and id
        # Gemini requires. Calls Gemini sends without an id get a synthetic one so parallel id-less
        # calls don't collide.
        self._tool_calls: dict[str, tuple[str, str | None]] = {}
        # (tool name, Gemini call id) of calls a resumed session lost but still waits on, and whether they
        # have been answered on the current session; see `_answer_lost_tool_calls`.
        self._unanswered_lost_tool_calls: list[tuple[str, str | None]] = []
        self._lost_tool_calls_answered = False
        # The typed turns a resumed session may not have, oldest first: each stays until a handle arrives
        # after the exchange that answered it ended. A handle's arrival time says nothing about which inputs it
        # covers, but a server that withholds handles mid-turn only issues one once a turn is over.
        self._uncovered_typed_turns: list[_TypedTurn] = []
        # How much audio has gone out on this connection, in seconds: where Gemini's `voice_activity` offsets point.
        self._audio_seconds = 0.0
        # Where in that audio each recent input other than audio went out, oldest first (see `_voice_activity`).
        self._sent_at: deque[tuple[float, InputId]] = deque(maxlen=64)
        # Whether the server withholds handles while it works on a turn, seen as an update without a
        # handle while a typed turn is outstanding. Gemini 2.5 takes up every typed turn that way, and a
        # session resumed from the handle before it doesn't have the turn. 3.8 never does, and (verified
        # live) resumes with the turn known. Learned once rather than from the latest update, which a
        # drop right after a send can beat.
        self._withholds_handles_mid_turn = False
        # Orders the answers for lost calls, which both the receive loop and `send()` may send, so an
        # input waiting on them never overtakes them.
        self._send_lock = Lock()
        self._native_part_index = 0
        # The `tool_call_id` generated for the most recent `executable_code` part, reused to pair the
        # following `code_execution_result` return with its call — mirroring the classic `GoogleModel`
        # streaming path, which threads a single id from the code part to its result.
        self._code_execution_tool_call_id: str | None = None
        # `dial` re-establishes a configured session from the latest resumption handle; with a
        # `reconnect` policy it recovers a dropped connection.
        self._dial = dial
        self._reconnect = reconnect
        self._resumption_handle: str | None = None
        self._turn_interrupted = False
        # Whether the model has streamed response output (audio, transcript, text, or native-tool
        # parts) since the last `turn_complete`. A dropped-and-redialed connection never continues an
        # in-flight turn (session resumption restores conversation state, not the generation;
        # verified live), so when this is set at reconnect time the turn's boundary would otherwise
        # never arrive — see `frames`, which closes the orphaned turn before the reconnect event.
        self._turn_open = False
        # On a model whose typed turns don't see video frames, the most recent image sent and when (by
        # `time.monotonic()`), for the next typed turn to carry again. See `send`.
        self._text_turns_see_video_frames = cast('GoogleRealtimeModelProfile', self._profile).get(
            'google_text_turns_see_video_frames', True
        )
        self._tool_return_mime_types = cast('GoogleRealtimeModelProfile', self._profile).get(
            'google_supported_mime_types_in_tool_returns', ()
        )
        self._recent_image: tuple[BinaryImage, float] | None = None
        # Whether the turn's latest output is a tool-call frame, with nothing said since. A model that
        # `google_closes_tool_call_turn_separately` closes that turn with its own `turn_complete` when the
        # tool-call generation ends, before speaking the answer; see `_map_message`. It's taken for that
        # only once every result is sent (with results still pending, the session holds the reply open
        # anyway), and only the first time: the next boundary always ends the turn, so an empty answer
        # completes.
        self._tool_call_turn_unanswered = False
        # Which response, user turn, and input each message is about (see `frames()`).
        cuts_off = cast('GoogleRealtimeModelProfile', self._profile).get('google_input_cuts_off_reply', False)
        self._lifecycle = (_CutOffLifecycle if cuts_off else InferredLifecycle)(transcribes=input_transcription_enabled)

    @property
    def _can_reconnect(self) -> bool:
        return (
            not self._gave_up
            and self._dial is not None
            and self._reconnect is not None
            and self._reconnects_used < self._reconnect.get('max_reconnects', DEFAULT_MAX_RECONNECTS)
        )

    @property
    def _talks_through_tool_calls(self) -> bool:
        # A model whose asynchronous calls' results cut into what it's saying (`scheduling: INTERRUPT`) keeps
        # talking in the turn that made them while they run (recorded on the native-audio models). Extended
        # thinking, which takes no scheduling, ends what it says before the call and answers after the result.
        return self._async_tool_calls_enabled and self._async_tool_call_scheduling_enabled

    @property
    def _answers_tool_calls_per_response(self) -> bool:
        # A blocking tool-call frame is answered once, when every call has its result. A non-blocking
        # call's result cuts into the speech on its own, so it may get an answer of its own.
        return not self._async_tool_calls_enabled

    @property
    def _sends_failed_tool_results(self) -> bool:
        # A call left without a response stays open: a blocking call holds the model waiting on it, so no later
        # turn is answered (2.5), and a non-blocking one is made again on every later input (3.8). Checked live.
        return True

    @property
    def input_transcription_enabled(self) -> bool:
        return self._input_transcription_enabled

    async def send(self, content: RealtimeInput) -> Sequence[LifecycleEvent]:
        """Send content to the Gemini Live API.

        Accepts `BinaryAudio` (raw PCM16, 16kHz, mono), a `str` text turn, `TextContext` (text sent
        with `turn_complete=False`, so it waits for the next turn), `BinaryImage` (a live video
        frame), and `ToolResult`. The manual turn-taking verbs are not supported (Gemini uses
        automatic VAD).
        """
        turn: _TypedTurn | None = None
        with self._lifecycle.sending(content) as input_index:
            while self._unanswered_lost_tool_calls and not self._lost_tool_calls_answered:
                # Whatever reaches a resumed session first is consumed by an exchange stuck on calls it lost,
                # so those are answered ahead of any input (see `_answer_lost_tool_calls`). The lock orders
                # this with the receive loop's own answer, so the input can't overtake it; the loop answers
                # again if a re-dial replaced the session while an answer was on the wire.
                async with self._send_lock:
                    await self._answer_lost_tool_calls()
            # Tracked from before the send, so a handle or answer arriving while it is on the wire counts.
            # Only needed to tell a reconnect what it lost, so not tracked without a reconnect policy.
            turn = _TypedTurn(input_index) if isinstance(content, str) and self._reconnect is not None else None
            if turn is not None:
                self._uncovered_typed_turns.append(turn)
            try:
                await self._send(content)
            except BaseException:
                # A reconnect noticed meanwhile has already let go of the list it was in.
                if turn is not None and turn in self._uncovered_typed_turns:
                    self._uncovered_typed_turns.remove(turn)
                raise
            if isinstance(content, BinaryAudio):
                self._audio_seconds += len(content.data) / (2 * INPUT_SAMPLE_RATE)
            else:
                self._sent_at.append((self._audio_seconds, input_index))
        if turn is not None:
            turn.sending = False
        # Gemini acknowledges nothing: where the input joined the conversation is known now, if it is.
        return self._lifecycle.take_pending()

    async def _send(self, content: RealtimeInput) -> None:
        # `send_realtime_input` is typed against a PIL.Image union the SDK leaves partially untyped.
        if isinstance(content, BinaryAudio):
            require_pcm_audio(content, provider_name=self._provider_name)
            await self._session.send_realtime_input(  # pyright: ignore[reportUnknownMemberType]
                audio=genai_types.Blob(data=content.data, mime_type=f'audio/pcm;rate={INPUT_SAMPLE_RATE}')
            )
        elif isinstance(content, str):
            parts = [genai_types.Part(text=content)]
            recent_image = self._recent_image
            if recent_image is not None and time.monotonic() - recent_image[1] <= _RECENT_IMAGE_SECONDS:
                # This model's typed turns don't see video frames: send the image again, in the turn.
                image = recent_image[0]
                parts.insert(
                    0, genai_types.Part(inline_data=genai_types.Blob(data=image.data, mime_type=image.media_type))
                )
            # A typed message is a discrete turn: commit it with `send_client_content(turn_complete=True)`
            # so the model replies, rather than buffering it as streaming realtime input.
            await self._session.send_client_content(
                turns=genai_types.Content(role='user', parts=parts), turn_complete=True
            )
            if self._recent_image is recent_image:
                self._recent_image = None  # carried (or stale): a later typed turn doesn't send it again
        elif isinstance(content, TextContext):
            await self._session.send_client_content(
                turns=genai_types.Content(role='user', parts=[genai_types.Part(text=content.text)]),
                turn_complete=False,
            )
        elif isinstance(content, BinaryImage):
            await self._session.send_realtime_input(  # pyright: ignore[reportUnknownMemberType]
                video=genai_types.Blob(data=content.data, mime_type=content.media_type)
            )
            if not self._text_turns_see_video_frames:
                self._recent_image = (content, time.monotonic())
        elif isinstance(content, ToolResult):
            await self._send_tool_result(content)
        else:
            raise UserError(f'{self._provider_label} does not support {type(content).__name__} input.')

    async def _send_tool_result(self, content: ToolResult) -> None:
        # Forgotten once sent, or once refused below. A send that fails on a dropped connection leaves
        # the call for the reconnect, which cancels it and answers the resumed session for it.
        name, gemini_id = self._tool_calls.get(content.tool_call_id, ('', None))
        # Text attachments are folded into the JSON `response`. Media goes in `FunctionResponse.parts`
        # on a model that reads it there, the analog of the standard Gemini 3 multimodal function
        # response; any other media raises, with the tool result unsent, never a silent
        # placeholder. Every other live channel was probed and fails: content in a
        # `send_client_content(turn_complete=False)` turn or a `send_realtime_input` frame is
        # invisible to the generation `send_tool_response` triggers (the model guesses), and a
        # `turn_complete=True` turn is seen but first triggers a spurious extra spoken response.
        output = content.output
        media: list[genai_types.FunctionResponsePart] = []
        if content.content:
            text_content: list[str] = []
            items = content.content
            dropped_tags: set[int] = set()
            try:
                for index, item in enumerate(items):
                    if index in dropped_tags:
                        continue
                    if isinstance(item, str):
                        text_content.append(item)
                    elif isinstance(item, TextContent):
                        text_content.append(item.content)
                    elif isinstance(item, CachePoint):
                        continue
                    elif isinstance(item, (ImageUrl, AudioUrl, DocumentUrl, VideoUrl, BinaryContent, UploadedFile)):
                        media.append(await self._tool_result_media(item))
                        # A file the tool returned comes framed in provenance tags for the user channel.
                        # Inside the function response it is the tool's by construction, as on a
                        # standard Gemini request, so the tags, which would frame nothing, are dropped.
                        open_tag, close_tag = _tool_result_provenance_tags(name, content.tool_call_id, item.identifier)
                        if text_content[-1:] == [open_tag] and index + 1 < len(items) and items[index + 1] == close_tag:
                            text_content.pop()
                            dropped_tags.add(index + 1)
                    else:
                        assert_never(item)
            except BaseException:
                # Refused, or its media couldn't be fetched: the result is never sent, so the call is
                # forgotten as a sent one would be.
                self._tool_calls.pop(content.tool_call_id, None)
                raise
            output = '\n\n'.join(part for part in (output, *text_content) if part)
        function_response = genai_types.FunctionResponse(
            id=gemini_id,
            name=name,
            response={'output': output},
            parts=media or None,
            # `INTERRUPT`, not `WHEN_IDLE`: a non-blocking model keeps talking while the
            # tool runs, and `WHEN_IDLE` holds the result until it stops — by which point it
            # has usually answered from its own knowledge, so the tool's answer contradicts
            # what was already said. (Recorded live: a tool returning "foggy and 12 degrees"
            # while the model said "15 degrees with clouds".) A model calls a tool because it
            # needs the result, so cut in with it.
            scheduling=genai_types.FunctionResponseScheduling.INTERRUPT
            if self._async_tool_calls_enabled and self._async_tool_call_scheduling_enabled
            else None,
        )
        if media:
            # `google-genai`'s `send_tool_response` (as of 2.25) hands the parts' raw bytes to
            # `json.dumps`, which can't encode them, so the message is serialized with the SDK's own
            # types, which base64-encode bytes, and sent over the session's socket as it would be.
            # https://github.com/googleapis/python-genai/issues/3022
            message = genai_types.LiveClientMessage(
                tool_response=genai_types.LiveClientToolResponse(function_responses=[function_response])
            )
            # `_ws` is typed as a union with the legacy `websockets` client the SDK falls back to on
            # older versions, whose `send` pyright can't resolve; both take a text frame.
            await self._session._ws.send(  # pyright: ignore[reportPrivateUsage, reportUnknownMemberType, reportAttributeAccessIssue]
                message.model_dump_json(by_alias=True, exclude_none=True)
            )
        else:
            await self._session.send_tool_response(function_responses=function_response)
        self._tool_calls.pop(content.tool_call_id, None)

    async def _tool_result_media(
        self, item: ImageUrl | AudioUrl | DocumentUrl | VideoUrl | BinaryContent | UploadedFile
    ) -> genai_types.FunctionResponsePart:
        """Map media attached to a tool return to a function-response part, or raise if this model can't carry it."""
        supported = self._tool_return_mime_types
        data: bytes | None = None
        media_type: str | None = None
        if isinstance(item, BinaryContent):
            data, media_type = item.data, item.media_type
        elif isinstance(item, ImageUrl) and any(mime_type.startswith('image/') for mime_type in supported):
            downloaded = await download_item(item, data_format='bytes')
            data, media_type = downloaded['data'], downloaded['data_type']
        if data is None or media_type not in supported:
            carries = f'{", ".join(supported)} content, inline or from an `ImageUrl`' if supported else 'only text'
            raise UserError(
                f'{self._provider_label} tool results on this model carry {carries}, so `{type(item).__name__}` '
                + (f'content of type {media_type!r} ' if media_type is not None else 'content ')
                + 'attached to a tool return cannot be delivered. Return text instead, or use a model or '
                'realtime provider that supports this tool-result media.'
            )
        return genai_types.FunctionResponsePart(
            inline_data=genai_types.FunctionResponseBlob(data=data, mime_type=media_type)
        )

    async def frames(self) -> AsyncIterator[RealtimeFrame]:
        # `session.receive()` yields a single model turn and then returns, so loop to keep serving
        # subsequent turns. When the server closes the WebSocket — its connection-time limit, or on
        # teardown — `receive()` raises (the SDK surfaces a closed socket as an `APIError`). Without a
        # reconnect policy that ends the stream; with one, re-dial from the latest resumption handle.
        while True:
            try:
                # Coverage cannot attribute the normal async-generator exhaustion back to this outer
                # loop; `test_connect_continues_after_empty_server_turn` exercises that continuation.
                async for message in self._session.receive():  # pragma: no branch
                    yield self._lifecycle.frame_for(self._map_message(message))
            except self.transport_errors as e:
                # Nothing under way on the dropped connection will finish, whether or not it is re-dialed.
                lost: RealtimeFrame = [*self._lifecycle.connection_lost()]
                if self._dial is None or self._reconnect is None:
                    # No reconnect policy: a dropped connection is fatal. Surface it as a
                    # non-recoverable error and end the stream cleanly, rather than returning silently
                    # (mirroring the OpenAI provider), so callers don't treat a truncated turn as complete.
                    error = RealtimeSessionErrorEvent(
                        message=f'{self._provider_label} connection closed: {e}', recoverable=False
                    )
                    yield [*lost, error]
                    return
                # Gemini issues no resumption handle while a call is executing, so the re-dialed session
                # never has a call still running at the drop, and won't answer its result (verified live:
                # 2.5 ignores it, 3.8 closes the turn without speaking).
                lost_tool_calls = dict(self._tool_calls)
                state_resumed = self._resumption_handle is not None
                # Likewise the typed turns no handle has covered yet, on a server that withholds handles
                # mid-turn (or without any handle). Those still awaiting their reply are released, unless
                # the reply had already started (it took the response, and is closed as interrupted below).
                # A turn still on the wire is left out: its send fails, and the session takes it back.
                uncovered = [
                    turn
                    for turn in self._uncovered_typed_turns
                    if not turn.sending and (not state_resumed or self._withholds_handles_mid_turn)
                ]
                unanswered = [turn.input_index for turn in uncovered if not turn.answered]
                lost_typed_turns = unanswered[1:] if self._turn_open else unanswered
                self._uncovered_typed_turns = []
                # The new session's audio, and the offsets it reports, start over.
                self._audio_seconds = 0.0
                self._sent_at.clear()
                # Losing a call or a turn loses the exchange it belongs to, so that isn't a restored state.
                state_restored = state_resumed and not lost_tool_calls and not uncovered
                if await self._try_reconnect():
                    reconnect_frame: RealtimeFrame = [*lost, *self._lifecycle.take_pending()]
                    # The new session hasn't been answered for anything yet.
                    self._lost_tool_calls_answered = False
                    if not state_resumed:
                        # A fresh session has no stale exchange left to answer.
                        self._unanswered_lost_tool_calls.clear()
                    if lost_tool_calls:
                        # Abandon them the way Gemini's own `tool_call_cancellation` does: the tasks are
                        # cancelled and each call still gets a matching return in history. Nothing
                        # awaits between the re-dial and this event, so no tool task can send a result
                        # for one of these calls onto the new socket before the session cancels it. A
                        # result sent while re-dialing went to the dead socket, so the call is still owed.
                        for call_id, call in lost_tool_calls.items():
                            self._tool_calls.pop(call_id, None)
                            if state_resumed:
                                self._unanswered_lost_tool_calls.append(call)
                        reconnect_frame.append(ToolCallCancelled(tool_call_ids=list(lost_tool_calls)))
                    if self._turn_open:
                        # The dropped connection was mid-turn. Gemini never continues an in-flight
                        # generation on the re-dialed connection (resumption restores conversation
                        # state only), so its `turn_complete` will never arrive — without a synthetic
                        # boundary the session would keep the partial response open forever, never
                        # ending the turn or delivering messages queued behind it.
                        self._turn_open = False
                        self._turn_interrupted = False
                        self._tool_call_turn_unanswered = False
                        self._native_part_index = 0
                        # The lifecycle already lost the response: this terminal is the codec stream's alone.
                        reconnect_frame.append(StaleEvent(ResponseDone(interrupted=True)))
                    for input_index in lost_typed_turns:
                        # Nothing will answer it, so the reply it asked for is released rather than awaited
                        # forever; the turn stays in history, and `state_restored=False` tells the app to
                        # send it again.
                        reconnect_frame.append(InputRejected(input_index=input_index, refused='response'))
                    reconnect_frame.append(RealtimeSessionReconnectEvent(state_restored=state_restored))
                    yield reconnect_frame
                    if self._unanswered_lost_tool_calls:
                        # Answered right away rather than only ahead of the next input, so the resumed
                        # session has closed the stale exchange by the time the user speaks. A new socket
                        # that is already gone keeps them owed; receiving notices the drop next.
                        with suppress(*self.transport_errors):
                            async with self._send_lock:
                                await self._answer_lost_tool_calls()
                    continue
                # Out of attempts: no reconnect is coming any more.
                self._gave_up = True
                lost += self._lifecycle.take_pending()
                error = RealtimeSessionErrorEvent(
                    message=f'{self._provider_label} connection closed; reconnect failed: {e}', recoverable=False
                )
                yield [*lost, error]
                return
            # `receive()` returned normally → the turn ended; loop for the next one.

    async def _answer_lost_tool_calls(self) -> None:
        """Answer calls a resumed session lost with an error, so they don't swallow the next input.

        The session resumes still waiting on the exchange the calls belong to, but no longer accepts
        their results. Verified live: on `gemini-3.8-live` the next input only closes that stale
        exchange, so the user's next turn goes unanswered. Answering the calls closes it instead, with
        an empty `turn_complete`. Gemini 2.5 ignores the response. They stay owed until a handle issued
        after the answer covers it: a session resumed from an older handle is stuck on them again and is
        answered again. Called under `_send_lock`.
        """
        if not self._unanswered_lost_tool_calls or self._lost_tool_calls_answered:
            return
        session = self._session
        await session.send_tool_response(
            function_responses=[
                genai_types.FunctionResponse(
                    id=gemini_id, name=name, response={'error': INTERRUPTED_TOOL_RETURN_CONTENT}
                )
                for name, gemini_id in self._unanswered_lost_tool_calls
            ]
        )
        # An answer that completes after a re-dial went to the old session; the new one is still owed.
        if self._session is session:
            self._lost_tool_calls_answered = True

    async def _try_reconnect(self) -> bool:
        """Re-dial with exponential backoff, resuming from the latest handle; return whether it worked."""
        assert self._dial is not None and self._reconnect is not None
        if not await reconnect_with_backoff(
            self._reconnect, self._attempt_reconnect, reconnects_used=self._reconnects_used
        ):
            return False
        self._reconnects_used += 1
        return True

    async def _attempt_reconnect(self) -> bool:
        assert self._dial is not None
        try:
            self._session = await self._dial(self._resumption_handle)
        except (genai_errors.APIError, ConnectionClosed, OSError, TimeoutError):
            # Expected dial failures: SDK-reported API errors, a closed socket, and network/timeout
            # errors. A retry may still succeed. Anything else is a bug in `dial()` and propagates
            # rather than masquerading as a failed reconnect.
            return False
        return True

    def _map_server_content(self, content: genai_types.LiveServerContent) -> list[RealtimeCodecEvent]:
        """Translate a `server_content` message (audio/transcripts/native tools/turn boundary) to events."""
        events: list[RealtimeCodecEvent] = []
        # Native tool call/return parts reconstructed for history (code execution here, web grounding
        # below), folded into the turn's `ModelResponse` by the session rather than yielded live.
        native_tool_parts: list[ModelResponsePart] = []
        if content.model_turn is not None:
            for part in content.model_turn.parts or []:
                if part.inline_data is not None and part.inline_data.data:
                    events.append(AudioDelta(data=part.inline_data.data))
                elif part.executable_code is not None:
                    # Reuse the classic `GoogleModel` mapper so the code-execution call part is
                    # byte-identical; generate and stash the id to pair the following result with it.
                    self._code_execution_tool_call_id = generate_tool_call_id()
                    native_tool_parts.append(
                        _map_executable_code(
                            part.executable_code, self._provider_name, self._code_execution_tool_call_id
                        )
                    )
                elif part.code_execution_result is not None:
                    if self._code_execution_tool_call_id is None:
                        # No code ran: native-audio models announce a Google Search with a bare
                        # `code_execution_result` ("Looking up information on Google Search.") and no
                        # `executable_code` before it (verified live). The search itself arrives as
                        # grounding metadata, mapped below, so this status line has nothing to pair with.
                        continue
                    native_tool_parts.append(
                        _map_code_execution_result(
                            part.code_execution_result, self._provider_name, self._code_execution_tool_call_id
                        )
                    )
                    # Each `executable_code` has exactly one result, as the classic path assumes, so the
                    # pairing ends here: a search status line later in the session must not pair with it.
                    self._code_execution_tool_call_id = None
                elif part.text and not part.thought:
                    # Skip thinking parts: native-audio models stream their reasoning as `thought`
                    # text alongside the spoken answer, and it must not leak into the transcript. A
                    # model-turn text part is the model's plain text output (`response_modality='text'`),
                    # distinct from the spoken-audio transcription in `output_transcription` below, so it
                    # becomes a `TextPart` rather than a `SpeechPart`.
                    events.append(OutputTranscript(text=part.text, is_final=False, output_text=True))
        # Gemini 3.x models transcribe the user's speech even when the setup asks for no input
        # transcription (verified live), so honor the setting here: with it off, the user's words must
        # stay out of history.
        if (
            self._input_transcription_enabled
            and content.input_transcription is not None
            and content.input_transcription.text
        ):
            events.append(
                InputTranscript(
                    text=content.input_transcription.text, is_final=bool(content.input_transcription.finished)
                )
            )
        if content.output_transcription is not None and content.output_transcription.text:
            events.append(
                OutputTranscript(
                    text=content.output_transcription.text,
                    is_final=bool(content.output_transcription.finished),
                    output_text=self._text_output,
                )
            )
        if content.interrupted:
            self._turn_interrupted = True
            events.append(RealtimeResponseInterruptedEvent())
        native_tool_parts += _map_grounding_parts(content, self._provider_name)
        for part in native_tool_parts:
            index = self._native_part_index
            self._native_part_index += 1
            events.extend((PartStartEvent(index=index, part=part), PartEndEvent(index=index, part=part)))
        # Only response output opens a turn — input transcripts stream between turns too, and a turn
        # "opened" by one would close as an empty interrupted response if the connection then dropped.
        if native_tool_parts or any(isinstance(event, (AudioDelta, OutputTranscript)) for event in events):
            self._turn_open = True
            self._tool_call_turn_unanswered = False
        # `turn_complete` is emitted by `_map_message` *after* the message's `usage_metadata`, not here:
        # Gemini packs `turnComplete` and `usageMetadata` into the same message, and the session
        # finalizes the response's usage on `ResponseDone`, so the usage must be accounted first
        # (matching OpenAI's codec, which emits usage before the turn boundary).
        return events

    def _voice_activity(self, activity: genai_types.VoiceActivity | None) -> None:
        """Gemini 3.x heard the user start (or stop) speaking, at `audio_offset` into the audio sent.

        It reports that just ahead of the `interrupted` that cuts a reply off for speech, and not for a typed turn that
        does (seen live). Inputs sent before that point in the audio can't have cut the reply off; the reply answers
        them. (The report can be read only after inputs sent since, so where it is read says nothing.)
        """
        if activity is None or activity.voice_activity_type != genai_types.VoiceActivityType.ACTIVITY_START:
            return
        offset = activity.audio_offset
        if offset is None or not offset.endswith('s'):
            self._lifecycle.speech_heard()
            return
        seconds = float(offset.removesuffix('s'))
        before = [input_id for at, input_id in self._sent_at if at < seconds]
        self._lifecycle.speech_heard(after=before[-1] if before else -1)

    def _map_message(self, message: genai_types.LiveServerMessage) -> list[RealtimeCodecEvent]:
        events: list[RealtimeCodecEvent] = []
        self._voice_activity(message.voice_activity)
        if message.server_content is not None:
            events.extend(self._map_server_content(message.server_content))
        if message.tool_call is not None:
            for call in message.tool_call.function_calls or []:
                name = call.name or ''
                # Gemini usually assigns an id, but fall back to the same synthetic id a standard
                # request builds for an id-less call, so parallel calls don't collide on one key and
                # the `pyd_ai_` prefix still marks the id as ours after a handoff to a standard run.
                # The provider's own id (`None` here) is what goes back on the wire — echoing one it
                # never issued is what "Gemini rejects unknown ids" is about.
                call_id = call.id or generate_tool_call_id()
                self._tool_calls[call_id] = (name, call.id)
                # A tool call opens the turn like audio output does: the session holds a partial
                # response for it, so a drop before `turn_complete` needs the same synthetic boundary.
                self._turn_open = True
                # Every call in the frame belongs to one model response, which Gemini answers once all of
                # them have results. `response_usage_follows` keeps them together until the frame's usage
                # below closes the response, unless the model talks on in it while they run.
                events.append(
                    ToolCall(
                        tool_call_id=call_id,
                        tool_name=name,
                        args=to_json(call.args or {}).decode(),
                        response_usage_follows=not self._talks_through_tool_calls,
                        response_continues=self._talks_through_tool_calls,
                    )
                )
        if message.tool_call_cancellation is not None and (cancelled_ids := message.tool_call_cancellation.ids):
            # The cancellation carries Gemini's own call ids, which match the `tool_call_id`s emitted
            # above whenever Gemini assigned them (id-less calls can't be cancelled by id anyway).
            # A cancelled call never sends a result, so nothing else will ever pop it: forget it here
            # or every barge-in leaks an entry for the life of the connection.
            for call_id in cancelled_ids:
                self._tool_calls.pop(call_id, None)
            if not self._tool_calls:
                # A frame the model abandoned has no answer coming, so no boundary after it is taken for
                # the tool-call turn's own.
                self._tool_call_turn_unanswered = False
            events.append(ToolCallCancelled(tool_call_ids=list(cancelled_ids)))
        if message.usage_metadata is not None:
            events.append(
                SessionUsage(
                    usage=_map_usage(
                        message.usage_metadata,
                        provider_name=self._provider_name,
                        provider_url=self._provider_url,
                    )
                )
            )
        elif message.tool_call is not None and message.tool_call.function_calls and not self._talks_through_tool_calls:
            # A tool-call frame carries no usage of its own (the turn's usage comes with a later
            # `turn_complete`), but the calls above were promised some: an empty report closes their
            # response now, since Gemini answers only once it has their results.
            events.append(SessionUsage(usage=RequestUsage()))
        if message.tool_call is not None and message.tool_call.function_calls:
            self._tool_call_turn_unanswered = True
        # Emit the turn boundary last — after this message's usage — so the session folds the turn's
        # tokens into the finalized `ModelResponse` / `chat` span before `ResponseDone` closes it.
        if message.server_content is not None and message.server_content.turn_complete:
            interrupted = self._turn_interrupted
            # A reasoning model rides several responses through one exchange: it speaks a filler, ends
            # the turn, calls a tool in the background, and speaks again. `interaction_status` is what
            # tells the two boundaries apart — `IN_PROGRESS` alongside `turn_complete` means the model
            # is still working, and only `IDLE` ends the exchange. Models without background reasoning
            # send no status at all, which reads as "this was the last response", as it always was.
            more_expected = (
                message.server_content.interaction_status == genai_types.InteractionStatus.IN_PROGRESS
                and not interrupted
            )
            closes_answered_tool_call_turn = (
                self._closes_tool_call_turn_separately
                and self._tool_call_turn_unanswered
                and not interrupted
                and not more_expected
                and not self._tool_calls
            )
            self._tool_call_turn_unanswered = False
            # The model said nothing after its tool calls and has all their results: this closes the
            # tool-call turn, not the answer, which is still to come. Like the OpenAI protocol's
            # function-call-only `response.done`, it reports only its usage (emitted above, folded into
            # the answer's response), and the turn stays open for the answer: the next boundary ends
            # it, even an empty one, and a drop before then closes it as interrupted.
            if closes_answered_tool_call_turn:
                self._turn_open = True
            else:
                # When Gemini says why it ended a turn (a malformed function call, refused input or output),
                # it's reported like a standard response's `finish_reason`, with the raw reason kept alongside.
                reason = message.server_content.turn_complete_reason
                events.append(
                    ResponseDone(
                        interrupted=interrupted,
                        more_expected=more_expected,
                        finish_reason=_turn_complete_finish_reason(reason) if reason is not None else None,
                        provider_details={'finish_reason': reason.value} if reason is not None else None,
                    )
                )
                if not more_expected:
                    self._mark_oldest_typed_turn_answered()
                self._turn_interrupted = False
                # A stalled exchange's response is still open — the model will add a tool call and an
                # answer to it — so the turn stays open too. Closing it here would leave a drop between
                # the filler and the tool call with no synthetic terminal, and the partial response in
                # flight forever.
                self._turn_open = more_expected
                if not more_expected:
                    self._native_part_index = 0
        # Track the resumption handle (internal state, not an event) so a reconnect can resume state.
        if (update := message.session_resumption_update) is not None:
            self._track_resumption_update(update)
        return events

    def _mark_oldest_typed_turn_answered(self) -> None:
        """The exchange that answered the oldest unanswered typed turn is over; the next handle covers it."""
        if turn := next((turn for turn in self._uncovered_typed_turns if not turn.answered), None):
            turn.answered = True

    def _track_resumption_update(self, update: genai_types.LiveServerSessionResumptionUpdate) -> None:
        if update.new_handle:
            self._resumption_handle = update.new_handle
            if self._lost_tool_calls_answered:
                # Issued after the answer, so a session resumed from it is no longer stuck on the calls.
                self._unanswered_lost_tool_calls.clear()
            self._uncovered_typed_turns = [turn for turn in self._uncovered_typed_turns if not turn.answered]
        elif any(not turn.answered for turn in self._uncovered_typed_turns):
            self._withholds_handles_mid_turn = True
