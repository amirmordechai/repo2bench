"""Step-event persistence: append-only event log, continuable snapshots, tool-effect ledger.

`MongoStepStore` needs the `mongodb` extra (`pip install
pydantic-ai-harness[mongodb]`); it is imported lazily so the rest of this
module stays usable without `pymongo` installed. `PostgresStepStore` imports
no driver (it takes a caller-owned asyncpg-compatible pool), so it is exported
eagerly.
"""

from typing import TYPE_CHECKING

from pydantic_ai_harness.media import PostgresConnection, PostgresPool
from pydantic_ai_harness.step_persistence._capability import StepPersistence
from pydantic_ai_harness.step_persistence._events import SnapshotSaved
from pydantic_ai_harness.step_persistence._helpers import (
    annotate_tool_effect,
    continue_run,
    fork_run,
    is_provider_valid,
)
from pydantic_ai_harness.step_persistence._postgres import PostgresStepStore
from pydantic_ai_harness.step_persistence._store import (
    FileStepStore,
    InMemoryStepStore,
    SqliteStepStore,
    StepStore,
)
from pydantic_ai_harness.step_persistence._types import (
    ContinuableSnapshot,
    EventKind,
    RunRecord,
    SnapshotState,
    StepEvent,
    ToolEffectRecord,
    ToolEffectStatus,
)

if TYPE_CHECKING:
    from pydantic_ai_harness.step_persistence._mongo import MongoStepStore

__all__ = [
    'ContinuableSnapshot',
    'EventKind',
    'FileStepStore',
    'InMemoryStepStore',
    'MongoStepStore',
    'PostgresConnection',
    'PostgresPool',
    'PostgresStepStore',
    'RunRecord',
    'SnapshotSaved',
    'SnapshotState',
    'SqliteStepStore',
    'StepEvent',
    'StepPersistence',
    'StepStore',
    'ToolEffectRecord',
    'ToolEffectStatus',
    'annotate_tool_effect',
    'continue_run',
    'fork_run',
    'is_provider_valid',
]


def __getattr__(name: str) -> object:
    if name == 'MongoStepStore':
        from pydantic_ai_harness.step_persistence._mongo import MongoStepStore

        return MongoStepStore
    raise AttributeError(f'module {__name__!r} has no attribute {name!r}')
