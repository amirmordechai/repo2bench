"""Memory tools over a scoped, versioned `MemoryStore`."""

from __future__ import annotations

import hashlib
import json
import posixpath
import re
from collections.abc import Awaitable, Callable
from contextvars import ContextVar
from dataclasses import dataclass
from typing import TYPE_CHECKING, Generic, Literal, NoReturn, TypeVar

from opentelemetry.trace import Span
from typing_extensions import TypedDict

from pydantic_ai import ModelRetry
from pydantic_ai.capabilities import AbstractCapability, WrapperCapability
from pydantic_ai.exceptions import ToolFailed, UserError
from pydantic_ai.tools import AgentDepsT, RunContext, ToolDefinition
from pydantic_ai.toolsets import FunctionToolset, ToolsetTool
from pydantic_ai.workspaces import (
    WorkspaceError,
    WorkspaceReadOnlyError,
    WorkspaceTimeoutError,
    WorkspaceUnavailableError,
)
from pydantic_ai_harness._durable import RetryRequest, raise_retry, retry_as_result
from pydantic_ai_harness._workspace import in_working_dir, raise_tool_failure
from pydantic_ai_harness.filesystem import READ_FILE_KIND
from pydantic_ai_harness.filesystem._tool_kinds import step_aside_for_read_file
from pydantic_ai_harness.memory._file import FileStore
from pydantic_ai_harness.memory._store import (
    MemoryConflictError,
    MemoryMutation,
    MemoryOperation,
    MemoryPathEscapeError,
    MemorySearchMatch,
    MemorySearchResult,
    MemoryStore,
    MetadataMemoryStore,
    SearchableMemoryStore,
    lexical_search,
)

if TYPE_CHECKING:
    from pydantic_ai_harness.memory._capability import Memory

_READ_MEMORY = 'read_memory'

MAIN_FILENAME = 'MEMORY.md'
"""The main notebook file injected as bounded user-role context."""

_FILENAME_RE = re.compile(r'[A-Za-z0-9][A-Za-z0-9._-]{0,79}')
_MAX_CAS_ATTEMPTS = 16
_MAX_SEARCH_QUERY_CHARS = 1_000
_MAX_SEARCH_TERMS = 32
_READ_TRUNCATION_MARKER = (
    '\n\n[Truncated: this file exceeds `max_memory_size`; edit it externally before using `write_memory`.]'
)


MEMORY_DATA_PREFIX = '<memory>\n'
MEMORY_DATA_SUFFIX = '\n</memory>'


def snapshot_content_budget(max_tokens: int, guidance: str | None) -> int:
    """Characters left for the injected snapshot once the guidance and its delimiters are counted."""
    return max_tokens * 4 - len(guidance or '') - len(MEMORY_DATA_PREFIX) - len(MEMORY_DATA_SUFFIX)


def run_workspace_directory(store: MemoryStore, scope: str) -> str | None:
    """Where this scope's files are in the run's workspace, or `None` when the run's file tools cannot see them.

    Known from configuration: a `FileStore` without a `workspace` of its own, whose `directory` is
    inside the working directory, which `FileSystem`'s root contains.
    """
    if not isinstance(store, FileStore) or store.workspace is not None:
        return None
    if not in_working_dir(store.directory):
        return None
    return posixpath.join(posixpath.normpath(store.directory), scope)


def file_reader(ctx: RunContext[AgentDepsT], store: MemoryStore, scope: str) -> tuple[str, str] | None:
    """The file tool that reads this scope's files in place of `read_memory`, and where they are."""
    directory = run_workspace_directory(store, scope)
    if directory is None or (reader := ctx.tool_name_for_kind(READ_FILE_KIND)) is None:
        return None
    return reader, directory


def read_call(found: tuple[str, str] | None, name: str) -> str:
    """How the model reads memory file `name`, given the run's `file_reader` result."""
    if found is None:
        return f'{_READ_MEMORY}("{name}")'
    reader, directory = found
    return f'{reader}(path="{posixpath.join(directory, name)}")'


_WriteStatus = Literal['created', 'appended', 'updated']


class MemoryWriteResult(TypedDict):
    """Content-free result from `write_memory`."""

    file: str
    version: str
    replayed: bool
    status: _WriteStatus


class MemoryDeleteResult(TypedDict):
    """Content-free result from `delete_memory`."""

    file: str
    version: str | None
    replayed: bool
    status: Literal['deleted', 'not_found']


class MemorySearchMatchResult(TypedDict):
    """One model-facing, scope-relative search match."""

    file: str
    snippet: str
    score: float


class MemorySearchResponse(TypedDict):
    """Bounded result from `search_memory`."""

    matches: list[MemorySearchMatchResult]
    scanned: int
    truncated: bool


def normalize_filename(file: str) -> str:
    """Validate a model-supplied memory filename and normalize it to `<name>.md`."""
    name = file.strip()
    if name and not name.endswith('.md'):
        name = f'{name}.md'
    if not _FILENAME_RE.fullmatch(name) or '..' in name:
        raise ModelRetry(
            f'{file!r} is not a valid memory filename -- use a short name like "postgres-migration.md" '
            '(letters, digits, dots, dashes; no slashes).'
        )
    return name


def _normalize_search_query(query: str) -> str:
    if len(query) > _MAX_SEARCH_QUERY_CHARS:
        raise ModelRetry(f'Search queries must be at most {_MAX_SEARCH_QUERY_CHARS} characters.')
    normalized = query.strip()
    if not normalized:
        raise ModelRetry('Pass a non-empty search query.')

    terms: list[str] = []
    seen: set[str] = set()
    for term in normalized.split():
        key = term.lower()
        if key in seen:
            continue
        if len(terms) == _MAX_SEARCH_TERMS:
            raise ModelRetry(f'Search queries must contain at most {_MAX_SEARCH_TERMS} unique terms.')
        seen.add(key)
        terms.append(term)
    return ' '.join(terms)


def _apply_write(
    existing: str | None, content: str, old_text: str | None, name: str, read_current: str
) -> tuple[str, _WriteStatus]:
    if old_text is None:
        if existing is not None and existing.strip():
            return f'{existing.rstrip()}\n{content.rstrip()}\n', 'appended'
        return f'{content.rstrip()}\n', 'created'
    if existing is None:
        raise ModelRetry(f'There is no memory file named {name!r} to edit -- omit `old_text` to create it.')
    occurrences = existing.count(old_text) if old_text else 0
    if occurrences == 0:
        raise ModelRetry(f'`old_text` was not found in {name!r} -- call `{read_current}` to see its current content.')
    if occurrences > 1:
        raise ModelRetry(
            f'`old_text` appears {occurrences} times in {name!r}; it must match exactly once. '
            'Add surrounding context to make it unique.'
        )
    return existing.replace(old_text, content, 1), 'updated'


_T = TypeVar('_T')

_IN_OPERATION: ContextVar[bool] = ContextVar('pydantic_ai_harness.memory.in_operation', default=False)
"""Whether a memory tool is running as `Memory`'s durable operation, so it runs its body directly."""


async def run_as_operation(call: Awaitable[_T]) -> _T | RetryRequest:
    """Run a memory tool's body as the durable operation it routes through."""
    token = _IN_OPERATION.set(True)
    try:
        return await retry_as_result(call)
    finally:
        _IN_OPERATION.reset(token)


def require_metadata_store(store: MemoryStore) -> MetadataMemoryStore:
    """Return `store` if it records write metadata; `Memory(write_metadata=...)` would otherwise lose it."""
    if not isinstance(store, MetadataMemoryStore):
        raise UserError(
            '`Memory(write_metadata=...)` needs a store that records write metadata, and '
            f'`{type(store).__name__}` does not. Use `InMemoryStore`, `SqliteMemoryStore` or '
            '`PostgresMemoryStore`, or implement `MetadataMemoryStore.write_with_metadata` in a custom store.'
        )
    return store


@dataclass(frozen=True)
class MemoryToolOperations(Generic[AgentDepsT]):
    """The durable operations a `Memory` capability runs each memory tool call through."""

    write_memory: Callable[[RunContext[AgentDepsT], str, str, str | None], Awaitable[MemoryWriteResult | RetryRequest]]
    read_memory: Callable[[RunContext[AgentDepsT], str], Awaitable[str | RetryRequest]]
    delete_memory: Callable[[RunContext[AgentDepsT], str], Awaitable[MemoryDeleteResult | RetryRequest]]
    search_memory: Callable[[RunContext[AgentDepsT], str], Awaitable[MemorySearchResponse | RetryRequest]]


class MemoryToolset(FunctionToolset[AgentDepsT]):
    """Scoped read/write/delete/search tools with CAS and durable idempotency.

    The stable `memory` ID lets Temporal and Prefect wrap this static toolset.
    `Memory` passes `operations` so that each tool call runs as one of its
    durable operations, whose result durable execution records instead of
    repeating the call on recovery, including on DBOS, which runs function
    tools in workflow code. A `MemoryToolset` built without `operations` runs
    its tools directly.
    """

    def __init__(
        self, capability: Memory[AgentDepsT], *, operations: MemoryToolOperations[AgentDepsT] | None = None
    ) -> None:
        super().__init__(id='memory')
        self._capability = capability
        self._operations = operations
        self.add_function(self.write_memory, name='write_memory')
        self.add_function(self.read_memory, name=_READ_MEMORY, prepare=self._prepare_read_memory)
        self.add_function(self.delete_memory, name='delete_memory')
        self.add_function(self.search_memory, name='search_memory')

    def _resolve_scope(self, ctx: RunContext[AgentDepsT]) -> tuple[MemoryStore, str]:
        """Resolve the scope through the run's copy of the capability, which shares this toolset.

        The copy holds the scope `for_run` resolved once for the run. A durable worker's tree holds
        the construction-time capability instead, which resolves the scope from `ctx`.
        """
        from pydantic_ai_harness.memory._capability import Memory

        run_capability = self._capability

        def select(capability: AbstractCapability[AgentDepsT]) -> None:
            nonlocal run_capability
            # A wrapper such as `prefix_tools()` may be visited in place of the `Memory` it wraps.
            while isinstance(capability, WrapperCapability):
                capability = capability.wrapped
            if isinstance(capability, Memory) and capability.get_toolset() is self:
                run_capability = capability

        if ctx.root_capability is not None:
            ctx.root_capability.apply(select)
        return run_capability.resolve_scope(ctx)

    async def _prepare_read_memory(self, ctx: RunContext[AgentDepsT], tool_def: ToolDefinition) -> ToolDefinition:
        """Step aside for a tool of `FileSystem`'s `READ_FILE_KIND` when it can read this run's memory files.

        Only the injected snapshot tells the model where the files are, so `read_memory` stays when nothing is
        injected: with `inject_memory=False`, or when the guidance leaves no room for the snapshot.
        """
        capability = self._capability
        guidance = capability.get_instructions()
        if (
            not capability.inject_memory
            or snapshot_content_budget(capability.max_tokens, guidance if isinstance(guidance, str) else None) <= 0
        ):
            return tool_def
        store, scope = self._resolve_scope(ctx)
        if run_workspace_directory(store, scope) is None:
            return tool_def
        return step_aside_for_read_file(ctx, tool_def)

    async def get_tools(self, ctx: RunContext[AgentDepsT]) -> dict[str, ToolsetTool[AgentDepsT]]:
        tools = await super().get_tools(ctx)
        store, _ = self._resolve_scope(ctx)
        # A store with its own workspace need not inherit the run's read-only policy.
        if isinstance(store, FileStore) and store.workspace is None and ctx.workspace.read_only:
            return {name: tool for name, tool in tools.items() if name not in {'write_memory', 'delete_memory'}}
        return tools

    async def write_memory(
        self,
        ctx: RunContext[AgentDepsT],
        content: str,
        file: str = MAIN_FILENAME,
        old_text: str | None = None,
    ) -> MemoryWriteResult:
        """Write persistent memory by appending or uniquely replacing text.

        Omit `old_text` to append, creating the file when necessary. Pass
        `old_text` to replace exactly one matching passage; use an empty
        `content` to remove that passage. Keep short durable facts in
        `MEMORY.md`, and longer or evolving topics in separate files. Update
        stale entries rather than adding contradictory duplicates.

        Args:
            ctx: Framework-provided run context.
            content: Text to append, or replacement text for `old_text`.
            file: Memory filename; defaults to `MEMORY.md`.
            old_text: Exact passage to replace, which must occur once.
        """
        if self._operations is not None and not _IN_OPERATION.get():
            return raise_retry(await self._operations.write_memory(ctx, content, file, old_text))
        capability = self._capability
        name = normalize_filename(file)
        if old_text is None and not content.strip():
            raise ModelRetry('Nothing to write -- pass the text to append, or `old_text` to replace.')
        store, scope = self._resolve_scope(ctx)
        metadata_store = None if capability.write_metadata is None else require_metadata_store(store)
        path = f'{scope}/{name}'
        operation = _operation(ctx, scope, 'write', path, {'content': content, 'file': file, 'old_text': old_text})
        scope_hash = _scope_hash(scope)
        with ctx.tracer.start_as_current_span(
            'memory.write', record_exception=False, set_status_on_exception=False
        ) as span:
            _set_span_base(span, store, scope_hash)
            try:
                previous_mutation = await store.get_operation(operation)
                if previous_mutation is not None:
                    result = _write_result(name, previous_mutation, old_text)
                    _set_span_result(span, 'replayed', replayed=True)
                    return result

                write_metadata = capability.write_metadata
                metadata = write_metadata(ctx) if callable(write_metadata) else write_metadata
                for attempt in range(_MAX_CAS_ATTEMPTS):
                    current = await store.read(path, max_chars=capability.max_memory_size)
                    if current is not None and current.truncated:
                        raise ModelRetry(
                            f'{name!r} exceeds max_memory_size and cannot be changed from partial content; '
                            'edit or replace it through the backing store first.'
                        )
                    updated, status = _apply_write(
                        None if current is None else current.content,
                        content,
                        old_text,
                        name,
                        read_call(file_reader(ctx, store, scope), name),
                    )
                    if len(updated) > capability.max_memory_size:
                        raise ModelRetry(
                            f'{name!r} would grow to {len(updated)} characters; the limit is '
                            f'{capability.max_memory_size}. Split the content into separate memory files.'
                        )
                    expected_version = None if current is None else current.version
                    try:
                        if metadata_store is None:
                            mutation = await store.write(
                                path, updated, expected_version=expected_version, operation=operation
                            )
                        else:
                            mutation = await metadata_store.write_with_metadata(
                                path, updated, expected_version=expected_version, operation=operation, metadata=metadata
                            )
                    except MemoryConflictError:
                        if attempt + 1 == _MAX_CAS_ATTEMPTS:
                            raise ModelRetry('Memory changed repeatedly while writing; retry the operation.')
                        continue
                    result = _write_result(name, mutation, old_text, status=status)
                    _set_span_result(span, 'ok', chars=len(updated), replayed=mutation.replayed)
                    return result
                raise RuntimeError('unreachable CAS retry state')  # pragma: no cover
            except WorkspaceError as exc:
                _set_span_error(span, exc)
                _raise_workspace_failure(exc, name)
            except MemoryPathEscapeError as exc:
                _set_span_error(span, exc)
                raise ModelRetry(_escape_message(name)) from exc
            except Exception as exc:
                _set_span_error(span, exc)
                raise

    async def read_memory(self, ctx: RunContext[AgentDepsT], file: str) -> str:
        """Read a bounded prefix of one memory file.

        Memory may be stale background context, so verify volatile facts before
        relying on them.

        Args:
            ctx: Framework-provided run context.
            file: Memory filename returned by injection or search.
        """
        if self._operations is not None and not _IN_OPERATION.get():
            return raise_retry(await self._operations.read_memory(ctx, file))
        name = normalize_filename(file)
        store, scope = self._resolve_scope(ctx)
        with ctx.tracer.start_as_current_span(
            'memory.read', record_exception=False, set_status_on_exception=False
        ) as span:
            _set_span_base(span, store, _scope_hash(scope))
            try:
                memory_file = await store.read(f'{scope}/{name}', max_chars=self._capability.max_memory_size)
                if memory_file is None:
                    _set_span_result(span, 'not_found')
                    raise ModelRetry(
                        f'There is no memory file named {name!r} -- use `search_memory` to find existing memory.'
                    )
                _set_span_result(span, 'ok', chars=len(memory_file.content))
                return memory_file.content + (_READ_TRUNCATION_MARKER if memory_file.truncated else '')
            except MemoryPathEscapeError as exc:
                _set_span_error(span, exc)
                raise ModelRetry(_escape_message(name)) from exc
            except Exception as exc:
                _set_span_error(span, exc)
                raise

    async def delete_memory(self, ctx: RunContext[AgentDepsT], file: str) -> MemoryDeleteResult:
        """Delete a non-main memory file that is no longer useful.

        `MEMORY.md` cannot be deleted; remove or correct its text with
        `write_memory` instead.

        Args:
            ctx: Framework-provided run context.
            file: Memory filename to delete.
        """
        if self._operations is not None and not _IN_OPERATION.get():
            return raise_retry(await self._operations.delete_memory(ctx, file))
        name = normalize_filename(file)
        if name == MAIN_FILENAME:
            raise ModelRetry(f'{MAIN_FILENAME} is the main notebook; edit it with `write_memory` instead.')
        store, scope = self._resolve_scope(ctx)
        path = f'{scope}/{name}'
        operation = _operation(ctx, scope, 'delete', path, {'file': file})
        with ctx.tracer.start_as_current_span(
            'memory.delete', record_exception=False, set_status_on_exception=False
        ) as span:
            _set_span_base(span, store, _scope_hash(scope))
            try:
                previous_mutation = await store.get_operation(operation)
                if previous_mutation is not None:
                    result = _delete_result(name, previous_mutation)
                    _set_span_result(span, 'replayed', replayed=True)
                    return result

                for attempt in range(_MAX_CAS_ATTEMPTS):
                    current = await store.read(path, max_chars=1)
                    try:
                        mutation = await store.delete(
                            path,
                            expected_version=None if current is None else current.version,
                            operation=operation,
                        )
                    except MemoryConflictError:
                        if attempt + 1 == _MAX_CAS_ATTEMPTS:
                            raise ModelRetry('Memory changed repeatedly while deleting; retry the operation.')
                        continue
                    result = _delete_result(name, mutation)
                    _set_span_result(span, result['status'], replayed=mutation.replayed)
                    return result
                raise RuntimeError('unreachable CAS retry state')  # pragma: no cover
            except WorkspaceError as exc:
                _set_span_error(span, exc)
                _raise_workspace_failure(exc, name)
            except MemoryPathEscapeError as exc:
                _set_span_error(span, exc)
                raise ModelRetry(_escape_message(name)) from exc
            except Exception as exc:
                _set_span_error(span, exc)
                raise

    async def search_memory(self, ctx: RunContext[AgentDepsT], query: str) -> MemorySearchResponse:
        """Search memory files in the current tenant and agent scope.

        Results contain bounded snippets; read the file when a larger
        bounded excerpt is relevant.

        Args:
            ctx: Framework-provided run context.
            query: Terms to find in memory filenames and content.
        """
        if self._operations is not None and not _IN_OPERATION.get():
            return raise_retry(await self._operations.search_memory(ctx, query))
        query = _normalize_search_query(query)
        capability = self._capability
        store, scope = self._resolve_scope(ctx)
        prefix = f'{scope}/'
        with ctx.tracer.start_as_current_span(
            'memory.search', record_exception=False, set_status_on_exception=False
        ) as span:
            _set_span_base(span, store, _scope_hash(scope))
            try:
                if isinstance(store, SearchableMemoryStore):
                    result = await store.search(
                        prefix,
                        query,
                        limit=capability.max_search_results,
                        max_files=capability.max_search_files,
                        max_chars=capability.max_search_result_chars,
                        max_file_chars=capability.max_memory_size,
                    )
                else:
                    result = await _fallback_search(
                        store,
                        prefix,
                        query,
                        limit=capability.max_search_results,
                        max_files=capability.max_search_files,
                        max_chars=capability.max_search_result_chars,
                        max_file_chars=capability.max_memory_size,
                    )
                matches, bounded_truncated = _bounded_search_matches(
                    result.matches,
                    prefix,
                    limit=capability.max_search_results,
                    max_chars=capability.max_search_result_chars,
                )
                scanned = min(max(result.scanned, 0), capability.max_search_files)
                truncated = result.truncated or bounded_truncated or result.scanned > capability.max_search_files
                _set_span_result(
                    span,
                    'ok',
                    matches=len(matches),
                    scanned=scanned,
                    chars=sum(len(match['snippet']) for match in matches),
                    truncated=truncated,
                )
                return {'matches': matches, 'scanned': scanned, 'truncated': truncated}
            except Exception as exc:
                _set_span_error(span, exc)
                raise


def _operation(
    ctx: RunContext[AgentDepsT],
    scope: str,
    kind: Literal['write', 'delete'],
    path: str,
    model_args: dict[str, str | None],
) -> MemoryOperation:
    tool_call_id = ctx.tool_call_id
    if not tool_call_id:
        raise RuntimeError('memory mutations require a stable tool_call_id')
    run_id = ctx.run_id
    if not run_id:
        raise RuntimeError('memory mutations require a stable run_id')
    # Ids are unique within one model response, not across a run's responses, so the step is part of the key.
    operation_id = _digest({'scope': scope, 'run_id': run_id, 'run_step': ctx.run_step, 'tool_call_id': tool_call_id})
    fingerprint = _digest({'kind': kind, 'path': path, 'model_args': model_args})
    return MemoryOperation(id=operation_id, fingerprint=fingerprint)


def _digest(value: dict[str, object]) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()
    return hashlib.sha256(encoded).hexdigest()


def _write_result(
    name: str,
    mutation: MemoryMutation,
    old_text: str | None,
    *,
    status: _WriteStatus | None = None,
) -> MemoryWriteResult:
    if mutation.version is None:
        raise RuntimeError('memory write returned no version')  # pragma: no cover
    if status is None:
        status = 'updated' if old_text is not None else ('appended' if mutation.existed else 'created')
    return {'file': name, 'version': mutation.version, 'replayed': mutation.replayed, 'status': status}


def _delete_result(name: str, mutation: MemoryMutation) -> MemoryDeleteResult:
    status: Literal['deleted', 'not_found'] = 'deleted' if mutation.existed else 'not_found'
    return {'file': name, 'version': mutation.version, 'replayed': mutation.replayed, 'status': status}


def _search_match(match: MemorySearchMatch, prefix: str, snippet: str) -> MemorySearchMatchResult:
    name = match.path.removeprefix(prefix)
    return {'file': name, 'snippet': snippet, 'score': match.score}


async def _fallback_search(
    store: MemoryStore,
    prefix: str,
    query: str,
    *,
    limit: int,
    max_files: int,
    max_chars: int,
    max_file_chars: int,
) -> MemorySearchResult:
    paths = await store.list_paths(prefix, limit=max_files + 1)
    files: list[tuple[str, str]] = []
    scanned = 0
    content_truncated = False
    for path in paths[:max_files]:
        if not path.startswith(prefix):
            raise RuntimeError('memory backend returned a path outside the requested scope')
        name = path.removeprefix(prefix)
        if '/' in name or not _FILENAME_RE.fullmatch(name) or '..' in name:
            continue
        scanned += 1
        memory_file = await store.read(path, max_chars=max_file_chars)
        if memory_file is None:
            continue
        content_truncated = content_truncated or memory_file.truncated
        files.append((path, memory_file.content))
    result = await lexical_search(
        files, query, limit=limit, max_files=max_files, max_chars=max_chars, score_prefix=prefix
    )
    return MemorySearchResult(
        matches=result.matches,
        scanned=scanned,
        truncated=result.truncated or len(paths) > max_files or content_truncated,
    )


def _bounded_search_matches(
    matches: list[MemorySearchMatch],
    prefix: str,
    *,
    limit: int,
    max_chars: int,
) -> tuple[list[MemorySearchMatchResult], bool]:
    bounded: list[MemorySearchMatchResult] = []
    remaining = max_chars
    truncated = len(matches) > limit
    for match in matches[:limit]:
        if not match.path.startswith(prefix):
            raise RuntimeError('memory search backend returned a result outside the requested scope')
        name = match.path.removeprefix(prefix)
        if '/' in name or not _FILENAME_RE.fullmatch(name) or '..' in name:
            raise RuntimeError('memory search backend returned a non-file or nested result')
        remaining -= len(name)
        if remaining < 0:
            truncated = True
            break
        snippet = match.snippet[:remaining]
        if len(snippet) < len(match.snippet):
            truncated = True
        bounded.append(_search_match(match, prefix, snippet))
        remaining -= len(snippet)
    return bounded, truncated


def _raise_workspace_failure(error: WorkspaceError, name: str) -> NoReturn:
    """Report a failed workspace mutation naming only the memory file.

    A backend's message can carry the host path and the scope, which includes the namespace, so
    the model sees only the filename. The original error stays chained as `__cause__`.
    """
    if isinstance(error, WorkspaceUnavailableError | WorkspaceReadOnlyError):
        raise_tool_failure(error)
    if isinstance(error, WorkspaceTimeoutError):
        raise ToolFailed(f'Updating memory file {name!r} timed out.') from error
    raise ToolFailed(f'Could not update memory file {name!r}.') from error


def _escape_message(name: str) -> str:
    # The store's own message names the scope-qualified path, which includes the namespace.
    return f'memory file {name!r} resolves outside the store directory; use a different filename.'


def _scope_hash(scope: str) -> str:
    return hashlib.sha256(scope.encode()).hexdigest()[:16]


def _set_span_base(span: Span, store: MemoryStore, scope_hash: str) -> None:
    if span.is_recording():
        span.set_attributes({'memory.backend': type(store).__name__, 'memory.scope_hash': scope_hash})


def _set_span_result(span: Span, outcome: str, **attributes: str | int | bool) -> None:
    if span.is_recording():
        span.set_attributes(
            {'memory.outcome': outcome, **{f'memory.{key}': value for key, value in attributes.items()}}
        )


def _set_span_error(span: Span, exc: Exception) -> None:
    if span.is_recording():
        span.set_attributes({'memory.outcome': 'error', 'memory.exception_type': type(exc).__name__})
