"""Complete coding-agent harness assembled from regular capabilities."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, replace
from pathlib import Path

from pydantic_ai.capabilities import AbstractCapability, Capability, CombinedCapability
from pydantic_ai.settings import ModelSettings
from pydantic_ai.tools import AgentDepsT, RunContext
from pydantic_ai_harness._warn import warn_argument_ignored
from pydantic_ai_harness._workspace import RequireWorkspace
from pydantic_ai_harness.coder._instructions import INSTRUCTIONS, project_instructions
from pydantic_ai_harness.compaction import ClearToolResults
from pydantic_ai_harness.filesystem import FileSystem
from pydantic_ai_harness.repair_tool_arguments import RepairToolArguments
from pydantic_ai_harness.repo_context import RepoContext
from pydantic_ai_harness.shell import MAX_FOREGROUND_WAIT, Shell
from pydantic_ai_harness.subagents import SubAgents
from pydantic_ai_harness.tool_output_limits import Band, ToolOutputLimits, Truncate

FILE_TOOL_NAMES: tuple[str, ...] = ('read_file', 'write_file', 'edit_file', 'list_files', 'grep')
"""The `FileSystem` tools `Coder` registers; `shell` covers directory creation, file metadata, and the rest."""


class _BoundToolOutputs(ToolOutputLimits[AgentDepsT]):
    # Unsets only the class-level default id, which is what the combine policy reads: two instances
    # sharing an id raise instead of merging as one configuration stated twice, so the `Anonymous`
    # `COMBINE_POLICY` entry holds. Instances still default to `id='tool_output_limits'` through the
    # inherited `__init__`; `Coder` passes `id='coder_tool_output_limits'`, which keeps its bound
    # limits separate from a standalone `ToolOutputLimits`.
    id: str | None = None

    def get_toolset(self) -> None:
        """Coder uses bounded truncation, so no spill-retrieval tool is needed."""
        return None


@dataclass
class _DefaultCaching(AbstractCapability[AgentDepsT]):
    """`Caching()` that yields to a `cache` value set before it, by the model, the agent, or a capability.

    Without `Caching`'s fixed id, so a `Caching` bound next to `Coder` is not combined away.
    """

    def get_model_settings(self) -> Callable[[RunContext[AgentDepsT]], ModelSettings]:
        def unless_configured(ctx: RunContext[AgentDepsT]) -> ModelSettings:
            return ModelSettings() if 'cache' in (ctx.model_settings or {}) else ModelSettings(cache=True)

        return unless_configured


MAX_READ_CHARS = 50_000
"""Characters of complete lines per `read_file`, below the output cap."""

MAX_OUTPUT_CHARS = 64000
"""Characters kept from any tool result."""

MAX_FILE_TOOL_RETRIES = 5
"""Consecutive retries each file tool allows before the run fails.

A denied path or a stale edit is corrected from the error message. With the agent's default
budget of one, a second consecutive mistake with the same tool ends a long autonomous run
and discards its work.
"""


def _file_system(*, unrestricted: bool) -> FileSystem[AgentDepsT]:
    file_system = FileSystem[AgentDepsT](
        content_hashes=False,
        max_read_chars=MAX_READ_CHARS,
        tools=FILE_TOOL_NAMES,
        max_retries=MAX_FILE_TOOL_RETRIES,
    )
    if unrestricted:
        # Workspace paths are POSIX, so the filesystem root is `/` whatever the host platform.
        return replace(file_system, root_dir='/', read_only_patterns=[])
    return file_system


class Coder(CombinedCapability[AgentDepsT]):
    """Autonomous coding with six tools, delegation, and context management, in the run's workspace.

    Files and commands go through `ctx.workspace`, and the project directory is
    its working directory: attach `LocalWorkspace('.')` for a local checkout, or
    a sandbox provider's capability for untrusted work, alongside `Coder()`. A
    run without a workspace fails at its start. Commands are unrestricted and
    can outlive runs. Additional instructions supplement the default guidance.
    `unrestricted_filesystem=True` lets the file tools reach the whole
    workspace filesystem rather than only the working directory.
    `repo_context=False` leaves out the bundled `RepoContext`, for hosts that
    bind their own and would otherwise load the instruction files twice.

    `sub_agents=True` adds `delegate_task`, which hands a self-contained sub-task
    to a fresh run of the same agent `Coder` is bound to, so the delegate has
    everything the agent has, including capabilities bound next to `Coder`.
    That requires binding `Coder` with `Agent(capabilities=[...])` rather than
    passing it to `run()`. `sub_agents=False` leaves delegation out.
    `agent_folders` optionally adds disk-defined delegates using `SubAgents`' folder
    names or explicit workspace paths. It defaults to `None` (no disk discovery).

    `caching=True` turns on prompt caching through the unified `cache` model setting,
    unless the model, the agent, or a capability listed before `Coder` already sets
    `cache`; a capability listed after it and the run's own `model_settings` take
    precedence as usual. `caching=False` leaves it out.
    """

    def __init__(
        self,
        workspace: str | Path | None = None,
        *,
        instructions: str | None = None,
        unrestricted_filesystem: bool = False,
        repo_context: bool = True,
        sub_agents: bool = True,
        agent_folders: str | Sequence[str | Path] | None = None,
        caching: bool = True,
    ) -> None:
        if workspace is not None:
            warn_argument_ignored(
                'Coder',
                'workspace',
                "the project directory is the workspace's working directory; attach "
                f'`LocalWorkspace({str(workspace)!r})` (or a sandbox) alongside `Coder()`.',
                stacklevel=3,
            )
        capabilities: list[AbstractCapability[AgentDepsT]] = [
            RequireWorkspace[AgentDepsT]('Coder'),
            # The id also names its (empty) function toolset, which durable execution requires.
            Capability[AgentDepsT](
                id='coder_instructions',
                instructions=[
                    INSTRUCTIONS + ('\n' + instructions if instructions else ''),
                    # Naming the directory creates a lazily created sandbox, so it comes only with
                    # `RepoContext`, which reads the workspace at run start anyway.
                    *([project_instructions(unrestricted=unrestricted_filesystem)] if repo_context else []),
                ],
            ),
            _file_system(unrestricted=unrestricted_filesystem),
            Shell[AgentDepsT](
                denied_commands=[],
                default_timeout=MAX_FOREGROUND_WAIT,
                allow_interactive=True,
                # No env patterns: the workspace, not the host process, supplies the command environment.
                tools=['shell'],
            ),
        ]
        if repo_context:
            capabilities.append(RepoContext[AgentDepsT](expose_inventory_tool=False))
        if sub_agents:
            capabilities.append(SubAgents[AgentDepsT](include_self=True, agent_folders=agent_folders))
        capabilities += [
            ClearToolResults[AgentDepsT](max_fraction=0.7),
            _BoundToolOutputs[AgentDepsT](
                id='coder_tool_output_limits',
                bands=[Band(over=MAX_OUTPUT_CHARS, action=Truncate(max_chars=MAX_OUTPUT_CHARS))],
            ),
            RepairToolArguments[AgentDepsT](),
        ]
        if caching:
            capabilities.append(_DefaultCaching[AgentDepsT]())
        super().__init__(capabilities)
