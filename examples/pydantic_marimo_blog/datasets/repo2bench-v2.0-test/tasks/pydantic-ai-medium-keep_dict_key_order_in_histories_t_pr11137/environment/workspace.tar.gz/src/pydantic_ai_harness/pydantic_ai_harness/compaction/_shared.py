"""Shared utilities for the compaction capabilities.

Token estimation, the `CompactionStrategy` protocol, tool-pair-safe cutoff logic, first-user
preservation, and in-place tool-result clearing -- anything used by more than one capability.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Sequence
from contextvars import ContextVar
from dataclasses import dataclass, replace
from json import dumps
from typing import TYPE_CHECKING, Protocol, Self, TypeGuard, assert_never, runtime_checkable

from pydantic_ai._context_size import context_input_tokens, context_tokens
from pydantic_ai._instructions import instruction_window_start
from pydantic_ai._utils import is_str_dict
from pydantic_ai.messages import (
    CompactionPart,
    InstructionBaselinePart,
    InstructionDeltaPart,
    ModelMessage,
    ModelRequest,
    ModelRequestPart,
    ModelResponse,
    ModelResponsePart,
    NativeToolCallPart,
    NativeToolReturnPart,
    RetryFeedbackPart,
    RetryPromptPart,  # pyright: ignore[reportDeprecated]  # TODO(v3): remove RetryPromptPart
    SpeechPart,
    SystemPromptPart,
    TextContent,
    TextPart,
    ThinkingPart,
    ToolAvailabilityDeltaPart,
    ToolCallPart,
    ToolReturnPart,
    UserPromptPart,
    is_multi_modal_content,
)
from pydantic_ai.models import AbstractModel, Model
from pydantic_ai.tools import AgentDepsT, RunContext
from pydantic_ai_harness.compaction._context_window import DEFAULT_CONTEXT_WINDOW, resolve_context_window
from pydantic_ai_harness.compaction._pinning import is_pinned
from pydantic_ai_harness.compaction._receipts import (
    RECEIPT_EVENT_NAME,
    drain_receipts,
    is_receipt_part,
    open_receipt_scope,
    reset_receipt_scope,
)
from pydantic_ai_harness.filesystem import READ_FILE_KIND

if TYPE_CHECKING:
    from pydantic_ai.models import ModelRequestContext, ModelRequestParameters
    from pydantic_ai.tools import ToolDefinition

# ---------------------------------------------------------------------------
# Token estimation
# ---------------------------------------------------------------------------

CHARS_PER_TOKEN = 4
"""Rough approximation: ~4 characters per token on average."""

_COMPACTION_RECLAIM: ContextVar[tuple[str | None, int, int] | None] = ContextVar(
    'pydantic_ai_harness.compaction.reclaim', default=None
)
"""`(run_id, run_step, reclaimed)`: heuristic reclaim from compaction earlier in this request's hook chain.

Keyed by the request (`run_step` advances once per model request) rather than by request-context
identity: strategies return `replace()` copies of the context, so an identity key would have to be
re-attached at every hop, and a strategy that forgot would silently drop the correction.
"""


def _collect_message_text(messages: Sequence[ModelMessage]) -> list[str]:
    """Collect all text segments from a sequence of messages, excluding instructions."""
    return [segment for segments in _message_segments(messages) for segment in segments]


def _message_segments(messages: Sequence[ModelMessage]) -> list[list[str]]:
    """The text segments of each message, excluding instructions.

    Every part that carries text the provider is sent counts, including the ones a run only
    grows under load: a retry prompt, an extended-thinking block, the result of a
    provider-side tool. Leaving those out was tolerable while the budget was an absolute
    `max_tokens` the caller had calibrated against this same estimator; a fraction of the
    real window is only meaningful if the numerator measures the same request the
    denominator describes.

    `FilePart` is deliberately absent: its payload is binary, and counting its length as
    characters would be a number with no relation to what the provider bills.
    """
    # Core omits the changes from before the current instruction window.
    baseline_index = instruction_window_start(messages)
    per_message: list[list[str]] = []
    for index, msg in enumerate(messages):
        segments: list[str] = []
        if isinstance(msg, ModelRequest):
            for request_part in msg.parts:
                if isinstance(request_part, InstructionDeltaPart) and index < baseline_index:
                    continue
                segments.extend(_request_part_text(request_part))
        else:
            for response_part in msg.parts:
                segments.extend(_response_part_text(response_part))
        per_message.append(segments)
    return per_message


def _collect_text(messages: Sequence[ModelMessage]) -> list[str]:
    """Collect all text segments from a sequence of messages, instructions included."""
    segments = _collect_message_text(messages)
    segments.extend(_instructions_text(messages))
    return segments


def _request_part_text(part: ModelRequestPart) -> list[str]:
    """Text segments a single request part contributes to the token estimate."""
    if isinstance(part, UserPromptPart):
        return [_user_prompt_text_for_counting(part)]
    elif isinstance(part, SystemPromptPart):
        return [part.content]
    elif isinstance(part, InstructionDeltaPart):
        return [part.render()]
    # Records what the request's instructions were made of, which are counted with the request.
    elif isinstance(part, InstructionBaselinePart):
        return []
    elif isinstance(part, ToolReturnPart):
        # Sent in full, a retried call's feedback included: a retry that answers a call travels as
        # that call's return. The tool-search and capability-load returns subclass `ToolReturnPart`,
        # so they arrive here too.
        return [tool_return_text(part)]
    elif isinstance(part, RetryFeedbackPart):
        # Retry feedback that answers no tool call. It is stored model-neutral and translated at
        # request time into a system prompt or a `<validation_errors>`-fenced user prompt, so it
        # occupies the window like the parts above. `model_response()` rather than
        # `str(part.content)`: the content is a list of `ErrorDetails` for a validation failure,
        # and this renders it the way the model sees it.
        return [part.model_response()]
    # TODO(v3): remove RetryPromptPart
    elif isinstance(part, RetryPromptPart):  # pyright: ignore[reportDeprecated]
        # The part the two above replaced. A stored history loads as one of them, but code that
        # builds one by hand and passes it as `message_history` still puts an instance here, and
        # this reads the history before the model translates it.
        return [str(part.content)]
    # Control bookkeeping rather than message text: it records which tools became available, and
    # the schemas themselves travel in the request's tool definitions. Those schemas are not free
    # -- this estimator counts no tool definitions at all, so revealing tools mid-run costs
    # context it does not see (tracked separately); skipping the part is not a claim that the
    # reveal was free.
    elif isinstance(part, ToolAvailabilityDeltaPart):
        return []
    elif isinstance(part, SpeechPart):
        # A realtime turn arrives as spoken audio plus a transcript. Count the transcript -- the
        # words the provider bills against the window -- not the binary audio, which has no
        # character-count meaning (as with `FilePart`).
        #
        # `SpeechPart` is the last member of the union today, so pyright sees this `isinstance` as
        # redundant, but it is kept explicit so the `else` stays a real branch at runtime rather
        # than dead code -- see the `else` comment.
        return [part.transcript or '']
    else:
        # A part pydantic-ai added after this was written. Skip rather than guess at its payload:
        # this runs on every request to decide whether to compact, so an unrecognised part must
        # not take the run down -- which is exactly what the old `str(part.content)` fallback did
        # once a part without `content` existed (#577).
        #
        # `assert_never` sits under `TYPE_CHECKING` rather than in the branch body on purpose. It
        # still makes the chain exhaustive at type-check time, so a new upstream part fails
        # `make typecheck` and becomes a decision we make; but unlike the usual runtime form it
        # cannot re-crash a user who upgrades pydantic-ai ahead of us, which is the failure this
        # change exists to remove.
        if TYPE_CHECKING:
            assert_never(part)
        return []  # pragma: no cover - reachable only on a pydantic-ai release newer than this one


def _response_part_text(part: ModelResponsePart) -> list[str]:
    """Text segments a single response part contributes to the token estimate."""
    if isinstance(part, TextPart):
        return [part.content]
    elif isinstance(part, ToolCallPart):
        return [part.tool_name, str(part.args)]
    elif isinstance(part, (ThinkingPart, CompactionPart)):
        # A redacted thinking block carries a signature and no text.
        return [part.content or '']
    elif isinstance(part, NativeToolCallPart):
        return [part.tool_name, str(part.args)]
    elif isinstance(part, NativeToolReturnPart):
        return [part.tool_name, part.model_response_str()]
    elif isinstance(part, SpeechPart):
        # `SpeechPart` is in both unions; a realtime assistant turn lands here. Count its
        # transcript for the same reason as on the request side.
        return [part.transcript or '']
    # Any other response part (e.g. `FilePart`) contributes no counted text, as before.
    return []


def _instructions_text(messages: Sequence[ModelMessage]) -> list[str]:
    """The instructions this history would be sent with, counted once.

    Every `ModelRequest` in a history carries the instructions in force when it was made, but
    a request sends one set. Summing them would multiply a system prompt by the number of
    turns, which is the opposite error from ignoring it. The most recent non-empty set is the
    one that goes, mirroring how a model synthesizes instructions from history.
    """
    for msg in reversed(messages):
        if isinstance(msg, ModelRequest) and msg.instructions:
            return [msg.instructions]
    return []


def tool_return_text(part: ToolReturnPart) -> str:
    """The tool return's content as text, with each file named by identifier rather than spelled out.

    A file's `repr` carries its bytes at ~3 characters per byte, so a 1 MB file would be estimated at
    ~700k tokens and render into a summary prompt as escaped bytes. The reference is the one a
    text-only tool result gives the model in its place (`ToolReturnPart.model_response_str_and_user_content`).
    """
    if not part.files:
        return str(part.content)
    return ' '.join(
        f'See file {item.identifier}.' if is_multi_modal_content(item) else str(item) for item in part.content_items()
    )


def _user_prompt_text_for_counting(part: UserPromptPart) -> str:
    """Extract text content from a user prompt part for counting."""
    if isinstance(part.content, str):
        return part.content
    texts: list[str] = []
    for item in part.content:
        if isinstance(item, str):
            texts.append(item)
        elif isinstance(item, TextContent):
            texts.append(item.content)
    return ''.join(texts)


def estimate_text_tokens(text: str, tokenizer: Callable[[str], int] | None = None) -> int:
    """Approximate the token count of a single string.

    Uses *tokenizer* when given, otherwise the ~4 characters-per-token heuristic.
    """
    if tokenizer is not None:
        return tokenizer(text)
    return len(text) // CHARS_PER_TOKEN


def _count_segments(segments: Sequence[str], tokenizer: Callable[[str], int] | None) -> int:
    """Token count of text segments: per segment with *tokenizer*, otherwise the heuristic over their total."""
    if tokenizer is not None:
        return sum(tokenizer(s) for s in segments)
    return sum(len(s) for s in segments) // CHARS_PER_TOKEN


def estimate_token_count(
    messages: Sequence[ModelMessage],
    tokenizer: Callable[[str], int] | None = None,
) -> int:
    """Approximate token count for a sequence of messages.

    Args:
        messages: Messages to count tokens for.
        tokenizer: Optional callable that returns the token count for a string.
            When `None`, falls back to a ~4 characters-per-token heuristic.
    """
    return _count_segments(_collect_text(messages), tokenizer)


def estimate_context_tokens(
    messages: Sequence[ModelMessage],
    tokenizer: Callable[[str], int] | None = None,
    *,
    model_request_parameters: ModelRequestParameters | None = None,
) -> int:
    """Best-available token count for the request this history would produce.

    Anchors on the most recent `ModelResponse` carrying provider-reported usage: its
    `input_tokens` measured everything the provider was actually sent for that request --
    instructions, tool definitions, and every prior message -- and its `output_tokens` measured
    the response's own parts, so their sum is ground truth for the history up to and including
    that response. A response whose usage sums several model requests re-counts the context of each,
    so it anchors on the input tokens of the one that measures the context instead: the first
    request of a Google long decode, the last sampling pass of an Anthropic response that reported
    its passes. Only the messages after the anchor are estimated with the character
    heuristic (or *tokenizer*), without re-counting instructions, which the anchor already
    covers; when the instructions changed since the anchor, the estimate swaps the old set for
    the new one rather than adding the new set on top. Tool schemas named by availability
    deltas after the anchor are estimated from the pending request parameters. This is what makes the estimate robust where the pure heuristic
    is not: token-dense content (minified JSON, base64, non-Latin scripts) and the tool
    definitions the heuristic cannot see at all are both inside the provider's number.

    Without provider usage, the history's message text falls back to `estimate_token_count`,
    while schemas named by availability deltas are still estimated from the pending request
    parameters.

    A history rewritten *after* the anchor's request went out (a compaction strategy editing
    older messages mid-cycle) is overestimated, because the anchor still describes the
    pre-rewrite request; the next real response re-anchors it. `TieredCompaction` compensates
    inside its escalation loop by subtracting each tier's estimated reclaim from its anchored
    baseline. Compacting slightly early is the cheap failure mode; the heuristic's multi-x
    underestimate on dense content, which lets the history blow the context window, is the
    expensive one.
    """
    if anchor := _latest_usage_anchor(messages):
        index, message = anchor
        anchored = context_tokens(message)
        segments = [
            *_collect_message_text(messages[index + 1 :]),
            *_revealed_tool_schema_text(messages[index + 1 :], model_request_parameters),
        ]
        # The anchor paid for the instructions in force when its request was made. When the
        # latest instructions differ (dynamic instructions such as a clock, or a persisted
        # history resumed under a new prompt), the next request sends the new set *instead of*
        # the old one: swap one estimate for the other. Adding the new set on top would count
        # the instructions twice, and when unchanged neither needs counting.
        current_instructions = _instructions_text(messages)
        anchored_instructions = _instructions_text(messages[: index + 1])
        if current_instructions != anchored_instructions:
            anchored += _count_segments(current_instructions, tokenizer)
            anchored -= _count_segments(anchored_instructions, tokenizer)
        return max(anchored + _count_segments(segments, tokenizer), 0)
    return _count_segments(
        [*_collect_text(messages), *_revealed_tool_schema_text(messages, model_request_parameters)], tokenizer
    )


def estimate_message_tokens(
    messages: Sequence[ModelMessage],
    tokenizer: Callable[[str], int] | None = None,
) -> list[int]:
    """Tokens each message adds to a request, measured with provider-reported usage where the history has it.

    The text estimate (`tokenizer`, or ~4 characters per token) misses what a provider counts but
    does not return as text, such as thinking kept as an empty part with a signature, and it
    underestimates token-dense content. Usage measures both. A response counts at least its
    `output_tokens`. Between two responses that carry usage, the later `input_tokens` minus the
    earlier one is exactly what the earlier response and the requests after it added, so those
    messages share that difference in proportion to their estimates. Where the history did not grow
    between two such responses, as across a compaction, the difference measures nothing and the
    estimates stand; so do messages before the first such response and after the last. A response
    whose usage sums several model requests enters the difference with its input tokens as
    `context_input_tokens` reads them, since its summed `input_tokens` re-count each request's context.
    An Anthropic last pass also read that response's own earlier passes, so the difference credits
    them to the messages before it, which the response then counts again: the tail measures high.

    Instructions are left out: they are sent with every request, not carried by any one message.
    """
    counts = [
        max(
            _estimate_segments(segments, tokenizer),
            message.usage.output_tokens if isinstance(message, ModelResponse) else 0,
        )
        for message, segments in zip(messages, _message_segments(messages))
    ]
    anchors = [index for index, message in enumerate(messages) if _reported_input_tokens(message)]
    for start, end in zip(anchors, anchors[1:]):
        span = _reported_input_tokens(messages[end]) - _reported_input_tokens(messages[start])
        if span <= 0:
            continue
        estimated = max(sum(counts[start:end]), 1)
        shares = [count * span // estimated for count in counts[start:end]]
        shares[0] += span - sum(shares)
        counts[start:end] = shares
    return counts


def _estimate_segments(segments: Sequence[str], tokenizer: Callable[[str], int] | None) -> int:
    if tokenizer is not None:
        return sum(tokenizer(s) for s in segments)
    return sum(len(s) for s in segments) // CHARS_PER_TOKEN


def _reported_input_tokens(message: ModelMessage) -> int:
    """The provider-reported input tokens of a response, or 0 for a request or a response without usage.

    For a response whose usage sums several model requests, as `context_input_tokens` reads it.
    """
    return context_input_tokens(message) if isinstance(message, ModelResponse) else 0


def _has_reported_usage(messages: Sequence[ModelMessage]) -> bool:
    """Whether any response carries provider-reported input or output tokens."""
    return any(
        isinstance(message, ModelResponse) and (message.usage.input_tokens or message.usage.output_tokens)
        for message in messages
    )


def has_context_usage_anchor(messages: Sequence[ModelMessage]) -> bool:
    """Return whether `estimate_context_tokens` uses provider-reported usage for *messages*."""
    return _latest_usage_anchor(messages) is not None


def _latest_usage_anchor(messages: Sequence[ModelMessage]) -> tuple[int, ModelResponse] | None:
    """Return the most recent response with provider-reported input usage."""
    for index in range(len(messages) - 1, -1, -1):
        message = messages[index]
        if isinstance(message, ModelResponse) and message.usage.input_tokens:
            return index, message
    return None


def _revealed_tool_names(messages: Sequence[ModelMessage]) -> set[str]:
    """Return tool names recorded as newly available in *messages*."""
    return {
        tool_name
        for message in messages
        if isinstance(message, ModelRequest)
        for part in message.parts
        if isinstance(part, ToolAvailabilityDeltaPart)
        for tool_name in part.tools_added
    }


def _revealed_tool_schema_text(
    messages: Sequence[ModelMessage], model_request_parameters: ModelRequestParameters | None
) -> list[str]:
    """Return schemas added to the request by availability deltas in *messages*."""
    if model_request_parameters is None:
        return []
    return [
        _tool_schema_text(tool)
        for tool_name in _revealed_tool_names(messages)
        if (tool := model_request_parameters.tool_defs.get(tool_name)) is not None
    ]


def _tool_schema_text(tool: ToolDefinition) -> str:
    """Return the model-visible text fields of a tool definition for local estimation."""
    return ''.join((tool.name, tool.description or '', dumps(tool.parameters_json_schema, sort_keys=True)))


def reset_compaction_reclaim() -> None:
    """Start a run without corrections inherited from a previous invocation."""
    _COMPACTION_RECLAIM.set(None)


def record_compaction_reclaim(ctx: RunContext[AgentDepsT], before: int, after: int) -> None:
    """Record a conservative correction for a later usage reporter in this hook chain."""
    previous = _COMPACTION_RECLAIM.get()
    reclaimed = max(before - after, 0)
    if previous is not None and previous[:2] == (ctx.run_id, ctx.run_step):
        reclaimed += previous[2]
    _COMPACTION_RECLAIM.set((ctx.run_id, ctx.run_step, reclaimed))


def get_compaction_reclaim(ctx: RunContext[AgentDepsT]) -> int:
    """Return the reclaim recorded for this request, or 0 for one left over from another."""
    previous = _COMPACTION_RECLAIM.get()
    if previous is None or previous[:2] != (ctx.run_id, ctx.run_step):
        return 0
    return previous[2]


def exceeds(
    messages: Sequence[ModelMessage],
    max_messages: int | None,
    max_tokens: int | None,
    tokenizer: Callable[[str], int] | None,
    *,
    model_request_parameters: ModelRequestParameters | None = None,
) -> bool:
    """Return True if *messages* exceeds either configured size threshold."""
    if max_messages is not None and len(messages) > max_messages:
        return True
    if (
        max_tokens is not None
        and estimate_context_tokens(messages, tokenizer, model_request_parameters=model_request_parameters) > max_tokens
    ):
        return True
    return False


# ---------------------------------------------------------------------------
# Token triggers
# ---------------------------------------------------------------------------


def validate_token_trigger(
    max_tokens: int | None,
    max_fraction: float | None,
    fallback_context_window: int = DEFAULT_CONTEXT_WINDOW,
    context_window: int | None = None,
    *,
    tokens_name: str = 'max_tokens',
    fraction_name: str = 'max_fraction',
) -> None:
    """Validate the absolute/relative token trigger a strategy was configured with.

    The two triggers are mutually exclusive: a strategy that took both would have to pick one
    and discard the other, and the caller could not tell which budget was in force. The names
    are parameterized so `TieredCompaction`'s `target_*` pair reports its own field names.
    """
    if max_tokens is not None and max_fraction is not None:
        raise ValueError(f'Set at most one of {tokens_name} or {fraction_name}.')
    if max_tokens is not None and max_tokens < 1:
        raise ValueError(f'{tokens_name} must be positive.')
    if max_fraction is not None and not 0 < max_fraction <= 1:
        raise ValueError(f'{fraction_name} must be greater than 0 and at most 1.')
    if fallback_context_window < 1:
        raise ValueError('fallback_context_window must be positive.')
    if context_window is not None and context_window < 1:
        raise ValueError('context_window must be positive.')


def context_for_request(
    ctx: RunContext[AgentDepsT],
    request_context: ModelRequestContext,
) -> RunContext[AgentDepsT]:
    """The run context as it applies to *this* request.

    A capability may replace `ModelRequestContext.model` before the request leaves, so a
    strategy driven from `before_model_request` has to see the model the request is going to
    rather than the one the run started with. Everything a strategy reads off the context
    follows: the window a fraction resolves against, the model a summarizing tier calls, and
    the same for a `TieredCompaction` nested inside another one.

    Returns `ctx` itself when no capability replaced the model, which is the common case.
    """
    if request_context.model is ctx.model:
        return ctx
    return replace(ctx, model=request_context.model)


def is_realtime_model(model: AbstractModel | str) -> bool:
    """Whether *model* is a realtime model: an `AbstractModel` that is not a request-response `Model`.

    A realtime model has no request-response context-window/token semantics, so the token
    triggers skip it. Written as a boolean check (rather than an inline `isinstance`) so callers
    keep the `AbstractModel | str` type -- narrowing against the un-parameterized generic `Model`
    would otherwise widen the value to `Model[Unknown]`. #585
    """
    return isinstance(model, AbstractModel) and not isinstance(model, Model)


def resolve_token_trigger(
    max_tokens: int | None,
    max_fraction: float | None,
    model: AbstractModel | str,
    fallback_context_window: int = DEFAULT_CONTEXT_WINDOW,
    context_window: int | None = None,
) -> int | None:
    """Absolute token trigger for this request, or `None` when no token trigger is configured.

    `max_fraction` is resolved against the model's real context window, so one configuration
    behaves correctly on a 128K model and on a 1M one. When the window cannot be resolved
    `fallback_context_window` stands in; it defaults to the conservative
    `DEFAULT_CONTEXT_WINDOW`, because compacting earlier than necessary costs a summary while
    overestimating costs the whole request.

    `context_window` overrides resolution entirely. The registry can be confidently wrong --
    it records the maximum a model can be made to accept, which for a beta-gated or
    tier-gated window is not what an ordinary request gets, and a self-hosted endpoint
    reports an id whose registry entry describes someone else's deployment. `fallback_*`
    cannot cover those: it only applies when resolution *fails*, and here it succeeds.

    Pass the model the request will actually be sent to. A capability may replace
    `ModelRequestContext.model` before the request leaves, so the run's model and the request's
    model are not always the same one.

    `RunContext.model` is typed as the wider `AbstractModel`, but a realtime session never
    compacts: its message history can't be modified mid-run, so the compaction hooks that call
    this never fire, and `model` is a request-response `Model` at runtime. The realtime guard
    below only keeps that wider type sound -- it returns `None`. #585
    """
    if is_realtime_model(model):
        # Unreachable at runtime (a realtime session doesn't compact, see above); the guard exists
        # only because `RunContext.model` is now the wider `AbstractModel`. #585
        return None
    if max_tokens is not None:
        return max_tokens
    if max_fraction is None:
        return None
    if context_window is None:
        context_window = resolve_context_window(model)
    return max(1, int((context_window if context_window is not None else fallback_context_window) * max_fraction))


# ---------------------------------------------------------------------------
# Tracing
# ---------------------------------------------------------------------------

_SPAN_NAME = 'compact_messages'
"""Static, low-cardinality span name emitted whenever a strategy compacts. The strategy name
goes in the `compaction.strategy` attribute rather than the span name to keep cardinality low."""


def _history_changed(before: list[ModelMessage], after: list[ModelMessage]) -> bool:
    """Return True if *after* differs from *before*.

    The same list object, or an equal-length list that compares equal element-wise, counts as
    unchanged; anything else is a change.
    """
    # `!=` short-circuits on identity element-wise, so this also covers `before is after`; an
    # unequal length already implies an unequal list, so a separate length check is redundant.
    return before != after


async def compact_with_span(
    ctx: RunContext[AgentDepsT],
    *,
    strategy: str,
    messages: list[ModelMessage],
    compact: Callable[[], Awaitable[list[ModelMessage]]],
    tokenizer: Callable[[str], int] | None = None,
) -> list[ModelMessage]:
    """Run *compact* and emit a `compact_messages` span when it changes the history.

    *compact* runs before the span so a no-op compaction (a trigger fired but the history is
    returned unchanged) emits nothing. The span is started on `ctx.tracer`, which is a no-op
    tracer unless core's instrumentation is active, so this adds no overhead to a
    non-instrumented run; the before/after attributes are only computed when the span records.

    Args:
        ctx: Run context whose `tracer` the span is started on.
        strategy: Strategy name recorded in the `compaction.strategy` attribute.
        messages: The pre-compaction messages, measured for the `*_before` attributes.
        compact: Zero-argument async callable returning the compacted message list.
        tokenizer: Optional tokenizer for the `compaction.tokens_*` estimates. When `None`,
            uses the same ~4 characters-per-token heuristic as `estimate_token_count`.
    """
    token = open_receipt_scope()
    try:
        compacted = await compact()
        receipts = drain_receipts()
    finally:
        reset_receipt_scope(token)
    if not _history_changed(messages, compacted):
        return messages
    with ctx.tracer.start_as_current_span(_SPAN_NAME) as span:
        if span.is_recording():
            span.set_attributes(
                {
                    # GenAI semconv flag; the convention says set `true` only, never `false`.
                    'gen_ai.conversation.compacted': True,
                    'compaction.strategy': strategy,
                    'compaction.messages_before': len(messages),
                    'compaction.messages_after': len(compacted),
                    'compaction.tokens_before': estimate_token_count(messages, tokenizer),
                    'compaction.tokens_after': estimate_token_count(compacted, tokenizer),
                }
            )
            for receipt in receipts:
                attributes = {
                    'compaction.receipt.strategy': receipt.strategy,
                    'compaction.receipt.messages_dropped': receipt.dropped_messages,
                    'compaction.receipt.tokens_dropped': receipt.dropped_tokens,
                    'compaction.receipt.by': receipt.by,
                }
                if receipt.handle is not None:
                    attributes['compaction.receipt.handle'] = receipt.handle
                span.add_event(RECEIPT_EVENT_NAME, attributes)
    return compacted


# ---------------------------------------------------------------------------
# Compaction strategy protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class SupportsFocus(Protocol):
    """A strategy whose output can be steered toward a topic.

    Only a strategy that *writes* something -- a summary -- can be focused. One that drops or
    blanks content by rule has nothing to steer, so `compact_now` passes a focus it cannot
    honour over rather than rejecting it. A composing strategy is focusable when any strategy
    it wraps is, so the hint reaches the tier that writes the prose.
    """

    def with_focus(self, focus: str) -> Self:
        """Return a copy of this strategy that prioritizes `focus`."""
        ...  # pragma: no cover


class CompactionStrategy(Protocol[AgentDepsT]):
    """A history transform that can be used standalone or as a `TieredCompaction` tier.

    `compact` applies the transform *unconditionally* (the trigger check lives in the
    capability's `before_model_request`).  A strategy that composes others may define its own
    stop condition instead -- `TieredCompaction` escalates only until the history fits its
    target.  Implementations must preserve tool-call / tool-return pairing.
    """

    async def compact(
        self,
        messages: list[ModelMessage],
        ctx: RunContext[AgentDepsT],
    ) -> list[ModelMessage]: ...  # pragma: no cover


# ---------------------------------------------------------------------------
# Safe cutoff logic -- preserves tool-call / tool-return pairs
# ---------------------------------------------------------------------------

_TOOL_PAIR_SEARCH_RANGE = 5
"""Number of messages to search around a cutoff point for tool-call pairs."""


def _is_tool_reply(
    part: ModelRequestPart,
) -> TypeGuard[ToolReturnPart | RetryPromptPart]:  # pyright: ignore[reportDeprecated]
    """Whether *part* answers a tool call, so it is sent paired with that call."""
    # TODO(v3): remove RetryPromptPart; a caller-passed history can still hold one
    return isinstance(part, ToolReturnPart) or (
        isinstance(part, RetryPromptPart)  # pyright: ignore[reportDeprecated]
        and part.tool_name is not None
    )


def _is_safe_cutoff(
    messages: list[ModelMessage],
    cutoff: int,
    search_range: int = _TOOL_PAIR_SEARCH_RANGE,
) -> bool:
    """Return True if cutting at *cutoff* does not orphan any tool-call pair.

    A tool-call pair is a `ToolCallPart` in a `ModelResponse` together with
    the corresponding `ToolReturnPart` (a retried call's included), or a legacy
    `RetryPromptPart` that rejected it, in a subsequent `ModelRequest`.  Both
    sides must end up on the same side of the cut.
    """
    if cutoff >= len(messages):
        return True

    start = max(0, cutoff - search_range)
    end = min(len(messages), cutoff + search_range)

    for i in range(start, end):
        msg = messages[i]
        if not isinstance(msg, ModelResponse):
            continue

        call_ids: set[str] = set()
        for part in msg.parts:
            if isinstance(part, ToolCallPart) and part.tool_call_id:
                call_ids.add(part.tool_call_id)

        if not call_ids:
            continue

        for j in range(i + 1, len(messages)):
            later = messages[j]
            if not isinstance(later, ModelRequest):
                continue
            for rpart in later.parts:
                if _is_tool_reply(rpart) and rpart.tool_call_id in call_ids:
                    call_before = i < cutoff
                    return_before = j < cutoff
                    if call_before != return_before:
                        return False

    return True


def find_safe_cutoff(messages: list[ModelMessage], keep: int) -> int:
    """Find a cutoff index that keeps *keep* tail messages without splitting tool pairs.

    The newest message is always kept, since in a run it is the request being answered, so a
    *keep* of 0 keeps one. Returns 0 if trimming is unnecessary (no more messages than *keep*).
    """
    keep = max(keep, 1)
    if len(messages) <= keep:
        return 0

    target = len(messages) - keep
    for idx in range(target, -1, -1):
        if _is_safe_cutoff(messages, idx):
            return idx
    return 0  # pragma: no cover


def _include_tool_dependencies(messages: list[ModelMessage], cutoff: int) -> int:
    """Expand a suffix to include all original tool calls required by its results."""
    calls: dict[str, int] = {}
    dependencies: list[int] = []
    for index, message in enumerate(messages):
        earliest = index
        if isinstance(message, ModelResponse):
            for part in message.parts:
                if isinstance(part, ToolCallPart) and part.tool_call_id:
                    # Providers can reuse an ID in later turns; match the nearest prior call.
                    calls[part.tool_call_id] = index
        else:
            for part in message.parts:
                if _is_tool_reply(part):
                    earliest = min(earliest, calls.get(part.tool_call_id, index))
        dependencies.append(earliest)

    # Dependencies only point backward, so one reverse pass also covers transitive pairs.
    for index in range(len(messages) - 1, -1, -1):
        if index < cutoff:
            break
        cutoff = min(cutoff, dependencies[index])
    return cutoff


def find_token_cutoff(
    messages: list[ModelMessage],
    target_tokens: int,
    tokenizer: Callable[[str], int] | None = None,
) -> int:
    """Find the shortest original suffix meeting *target_tokens*, including tool dependencies.

    A history with provider-reported usage is measured with `estimate_message_tokens`, so the
    suffix holds *target_tokens* as the provider counts them; one without falls back to the text
    estimate. Attached instructions do not count toward this message-content floor. A zero
    target retains the legacy behavior below.
    """
    if _has_reported_usage(messages):
        counts = estimate_message_tokens(messages, tokenizer)

        def tail_tokens(start: int) -> int:
            return sum(counts[start:])
    elif target_tokens > 0:

        def tail_tokens(start: int) -> int:
            return _count_segments(_collect_message_text(messages[start:]), tokenizer)
    else:

        def tail_tokens(start: int) -> int:
            return estimate_token_count(messages[start:], tokenizer)

    if target_tokens > 0:
        lo, hi = 0, len(messages)
        while lo < hi:
            mid = (lo + hi) // 2
            if tail_tokens(mid) >= target_tokens:
                lo = mid + 1
            else:
                hi = mid
        return _include_tool_dependencies(messages, max(0, lo - 1))

    if not messages or tail_tokens(0) <= target_tokens:
        return 0

    lo, hi = 0, len(messages)
    candidate = len(messages)

    while lo < hi:
        mid = (lo + hi) // 2
        if tail_tokens(mid) <= target_tokens:
            candidate = mid
            hi = mid
        else:
            lo = mid + 1

    if candidate >= len(messages):
        candidate = max(0, len(messages) - 1)

    # Walk backward to a safe point.
    for idx in range(candidate, -1, -1):
        if _is_safe_cutoff(messages, idx):
            return idx
    return 0  # pragma: no cover


# ---------------------------------------------------------------------------
# First user message preservation
# ---------------------------------------------------------------------------


# Interim, deliberately generic rule: a harness capability that tags the content it adds on the user channel
# with an `origin` under this prefix is covered by this one check, without per-capability code. Today that is
# `BackgroundTools` results, `TrajectoryJudge` feedback and `SubAgents` task reports. `Memory` marks its
# snapshot with a bare string instead, so it isn't recognized yet: a known gap. The rule is temporary: once
# core provenance (`CapabilityPart`) lands, recognize that instead of this metadata convention.
HARNESS_ORIGIN_PREFIX = 'pydantic-ai-harness.'
"""The prefix of the `origin` metadata harness capabilities put on content they add on the user channel."""


def harness_data_origin(part: UserPromptPart) -> str | None:
    """The `origin` of user-channel content a harness capability added, or `None` for anything else.

    A part counts when its first item is a `TextContent` whose metadata names a harness origin: that tag
    marks the whole part, as a `BackgroundTools` result marks the files and text that follow it. A part
    that only mentions such content later, after what the user wrote, is never relabeled.
    """
    # TODO: switch to the core provenance field once it exists.
    match part.content:
        case [TextContent(metadata=metadata), *_] if (
            is_str_dict(metadata)
            and isinstance(origin := metadata.get('origin'), str)
            and origin.startswith(HARNESS_ORIGIN_PREFIX)
        ):
            return origin
        case _:
            return None


def is_harness_data(part: ModelRequestPart) -> bool:
    """Whether *part* is user-channel content a harness capability added, such as a `SubAgents` task report."""
    return isinstance(part, UserPromptPart) and harness_data_origin(part) is not None


def _is_harness_marker_part(part: ModelRequestPart) -> bool:
    """Return whether a user-role part is harness bookkeeping or data rather than a user turn."""
    return is_pinned(part) or is_receipt_part(part) or is_harness_data(part)


def find_first_user_message(messages: list[ModelMessage]) -> ModelRequest | None:
    """Return the first `ModelRequest` that contains a `UserPromptPart`, or `None`."""
    for msg in messages:
        if isinstance(msg, ModelRequest) and any(
            isinstance(part, UserPromptPart) and not _is_harness_marker_part(part) for part in msg.parts
        ):
            return msg
    return None


def prepend_first_user_message(
    original: list[ModelMessage],
    cutoff: int,
    trimmed: list[ModelMessage],
) -> list[ModelMessage]:
    """Ensure the first user message from *original* appears in *trimmed*.

    If the first `ModelRequest` containing a `UserPromptPart` in *original*
    was discarded (its index is before *cutoff*) and is not already in *trimmed*,
    prepend it. Harness data merged into that request, such as a `SubAgents` task
    report delivered with the user's prompt, is left out: it isn't the user's turn,
    and keeping it would hold it outside the window on every run.
    """
    first = find_first_user_message(original)
    if first is None:
        return trimmed
    idx = original.index(first)
    if idx < cutoff and first not in trimmed:
        genuine = [part for part in first.parts if not is_harness_data(part)]
        return [first if len(genuine) == len(first.parts) else replace(first, parts=genuine), *trimmed]
    return trimmed


# ---------------------------------------------------------------------------
# Tool-pair inspection and in-place clearing
# ---------------------------------------------------------------------------

_CLEARED_TOOL_ARGS = '{}'
"""Replacement for cleared tool-call arguments.

Kept JSON-valid: `ToolCallPart.args_as_json_str()` returns a `str` arg verbatim, so a
non-JSON placeholder would reach the provider as malformed function arguments.
"""


@dataclass(frozen=True)
class _ToolPair:
    """A matched tool call and its return, with the order the return appeared."""

    tool_call_id: str
    tool_name: str
    call_part: ToolCallPart
    order: int


def iter_tool_pairs(messages: Sequence[ModelMessage]) -> list[_ToolPair]:
    """Return matched tool-call / tool-return pairs in return-appearance order.

    A retried return (`outcome='retried'`) isn't a result: it tells the model to make the call again. It
    is left out, so it is never cleared before the model sees the correction, doesn't count toward
    `ClearToolResults.keep_pairs`, and doesn't supersede an earlier successful read.
    """
    calls: dict[str, ToolCallPart] = {}
    for msg in messages:
        if isinstance(msg, ModelResponse):
            for part in msg.parts:
                if isinstance(part, ToolCallPart) and part.tool_call_id:
                    calls[part.tool_call_id] = part

    pairs: list[_ToolPair] = []
    order = 0
    for msg in messages:
        if isinstance(msg, ModelRequest):
            for part in msg.parts:
                if isinstance(part, ToolReturnPart) and part.outcome != 'retried' and part.tool_call_id in calls:
                    call = calls[part.tool_call_id]
                    pairs.append(_ToolPair(part.tool_call_id, call.tool_name, call, order))
                    order += 1
    return pairs


CLEARED_TOOL_RESULT_METADATA = 'pydantic-ai-harness.compaction.cleared-tool-result.v1'
"""Model-invisible `ToolReturnPart.metadata` key marking a result compaction has cleared."""


def cleared_return(part: ToolReturnPart, placeholder: str) -> ToolReturnPart | None:
    """*part* with its content replaced by *placeholder*, or `None` if it can't be cleared.

    A plain `ToolReturnPart` can always be cleared. Of the typed subclasses, only `FileSystem`'s
    `read_file` returns are: their kind declares no content shape, so a `ReadFileReturnPart` keeps its
    type with the placeholder as content. Other typed returns, like `ToolSearchReturnPart`, carry
    structured content that core re-parses (and trusts) on every request -- see `parse_discovered_tools`
    -- so they are left alone, even when the placeholder happens to fit their shape.

    The cleared part is marked in its `metadata` when that is `None` or a `dict`, so
    `is_cleared_return` recognizes it without trusting its model-visible content. A typed part with
    other metadata can't be marked, so it isn't cleared.
    """
    is_plain = type(part) is ToolReturnPart
    if not is_plain and part.tool_kind != READ_FILE_KIND.id:
        return None
    metadata = part.metadata
    if metadata is None:
        metadata = {CLEARED_TOOL_RESULT_METADATA: True}
    elif is_str_dict(metadata):
        metadata = {**metadata, CLEARED_TOOL_RESULT_METADATA: True}
    elif not is_plain:
        # `is_cleared_return` only falls back to the content for plain parts, so a cleared typed part
        # without the mark would go unrecognized, and `ClearToolResults` would count from the start of
        # history again on every request.
        return None
    return replace(part, content=placeholder, metadata=metadata)


def is_cleared_return(part: ToolReturnPart, placeholder: str) -> bool:
    """Whether a compaction using *placeholder* cleared *part*.

    The content must be *placeholder*, so another strategy's clears, which use their own placeholder,
    don't count. A typed result must also carry the mark `cleared_return` leaves in its metadata, as
    its content is the tool's output and may equal the placeholder by coincidence. A plain
    `ToolReturnPart` counts without the mark: histories cleared before the mark existed only ever
    cleared plain parts.
    """
    if str(part.content) != placeholder:
        return False
    metadata = part.metadata
    return type(part) is ToolReturnPart or (
        is_str_dict(metadata) and metadata.get(CLEARED_TOOL_RESULT_METADATA) is True
    )


def rebuild_with_cleared(
    messages: Sequence[ModelMessage],
    clear_return_ids: set[str],
    clear_input_ids: set[str],
    placeholder: str,
) -> list[ModelMessage]:
    """Return *messages* with selected tool results (and optionally inputs) blanked.

    The `ToolReturnPart` / `ToolCallPart` are kept in place with placeholder content,
    so tool-call pairing is never broken.  Already-blanked parts are left untouched.
    """
    out: list[ModelMessage] = []
    for msg in messages:
        if isinstance(msg, ModelRequest):
            request_parts: list[ModelRequestPart] = []
            changed = False
            for part in msg.parts:
                cleared = (
                    cleared_return(part, placeholder)
                    if isinstance(part, ToolReturnPart)
                    and part.tool_call_id in clear_return_ids
                    and str(part.content) != placeholder
                    else None
                )
                if cleared is not None:
                    request_parts.append(cleared)
                    changed = True
                else:
                    request_parts.append(part)
            out.append(replace(msg, parts=request_parts) if changed else msg)
        else:
            response_parts: list[ModelResponsePart] = []
            changed = False
            for part in msg.parts:
                if (
                    isinstance(part, ToolCallPart)
                    and part.tool_call_id in clear_input_ids
                    and part.args != _CLEARED_TOOL_ARGS
                ):
                    response_parts.append(replace(part, args=_CLEARED_TOOL_ARGS))
                    changed = True
                else:
                    response_parts.append(part)
            out.append(replace(msg, parts=response_parts) if changed else msg)
    return out
