"""Complete research-agent harness assembled from regular capabilities."""

from collections.abc import Sequence

from pydantic_ai import Agent
from pydantic_ai.capabilities import AbstractCapability, Capability, CombinedCapability, WebFetch, WebSearch
from pydantic_ai.tools import AgentDepsT
from pydantic_ai_harness._workspace import RequireWorkspace
from pydantic_ai_harness.subagents import SubAgent, SubAgents
from pydantic_ai_harness.tool_output_limits import ToolOutputLimits, WorkspaceStore
from pydantic_ai_harness.tool_output_limits._store import OverflowStore

DEFAULT_RESEARCHER_INSTRUCTIONS = """\
Search broadly before drawing conclusions.
Read the sources that support each important claim.
Prefer primary and authoritative sources.
Cite every factual claim with a direct source link.
Distinguish sourced facts from your own inference.
"""
"""Default instructions for `Researcher`."""


def _researcher(store: OverflowStore | WorkspaceStore | None = None) -> SubAgent[AgentDepsT]:
    agent = Agent[AgentDepsT](  # pyright: ignore[reportCallIssue, reportArgumentType]
        name='researcher',
        description='Research a focused sub-question on the web and report back with findings and source links',
        capabilities=[
            WebSearch[AgentDepsT](local=True),
            WebFetch[AgentDepsT](local=True),
            ToolOutputLimits[AgentDepsT](store=store),
        ],
    )
    return SubAgent(agent)


class Researcher(CombinedCapability[AgentDepsT]):
    """A complete research-agent harness built as a regular combined capability.

    It comes with concise default instructions. Pass `instructions=` to
    replace them, or `instructions=None` to run with no default instructions.

    Oversized tool results are spilled to files in the run's workspace, so a
    run needs one: attach `LocalWorkspace('.')` or a sandbox capability. A run
    without a workspace fails at its start unless `store=` provides a non-workspace
    overflow store such as `LocalFileStore()`.
    """

    def __init__(
        self,
        *,
        instructions: str | None = DEFAULT_RESEARCHER_INSTRUCTIONS,
        subagents: Sequence[SubAgent[AgentDepsT]] | None = None,
        store: OverflowStore | WorkspaceStore | None = None,
    ) -> None:
        delegates = [_researcher(store)] if subagents is None else subagents
        capabilities: list[AbstractCapability[AgentDepsT]] = []
        if store is None or isinstance(store, WorkspaceStore):
            capabilities.append(RequireWorkspace[AgentDepsT]('Researcher'))
        if instructions is not None:
            # The id also names the capability's (empty) function toolset, which durable
            # execution requires; mirrors `coder_instructions` (coder/_capability.py).
            capabilities.append(Capability[AgentDepsT](id='researcher_instructions', instructions=instructions))
        capabilities.extend(
            [
                WebSearch[AgentDepsT](local=True),
                WebFetch[AgentDepsT](local=True),
            ]
        )
        if delegates:
            capabilities.append(SubAgents[AgentDepsT](agents=delegates, agent_folders=None))
        capabilities.append(ToolOutputLimits[AgentDepsT](store=store))
        super().__init__(capabilities)
