"""Track what an agent spends, and stop it when a budget is gone.

`UsageLimits` in Pydantic AI caps tokens, requests and cost for the duration of
one run. `SpendLimits` covers what that leaves: periods longer than a run,
partitioning by tenant or user, and a counter that several worker processes
share. It prices each model response it records with
[`ModelResponse.cost()`][pydantic_ai.messages.ModelResponse.cost], adds it to every
configured window, and refuses the next request once a window is spent.

The gate is local and immediate. Provider usage APIs and observability backends
aggregate after the fact and are read by polling, so a number there moves only
once the requests behind it have already been made -- enough to reconcile a
counter, not enough to stop the request a runaway loop is about to make.
"""

from __future__ import annotations

import inspect
import warnings
from collections.abc import Awaitable, Callable, Iterator, Mapping, Sequence
from dataclasses import KW_ONLY, dataclass, field, replace
from datetime import datetime, timedelta
from decimal import Decimal
from functools import cache, partial
from hashlib import sha256
from typing import TYPE_CHECKING, Any, Literal, TypeGuard

from pydantic import TypeAdapter

from pydantic_ai.capabilities import AbstractCapability, CapabilityOrdering, durable_operation
from pydantic_ai.exceptions import UsageLimitUnavailableWarning, UserError
from pydantic_ai.messages import ModelMessagesTypeAdapter, ModelRequestAttempt, ModelResponse
from pydantic_ai.models._continuation import (
    billed_beyond,
    merge_responses,
    observe_continuation_segments,
    resumed_response,
)
from pydantic_ai.tools import AgentDepsT, RunContext
from pydantic_ai_harness._warn import HarnessDeprecationWarning
from pydantic_ai_harness.spend._budget import Budget, BudgetSpec, bucket, delimited, scope_key, store_key
from pydantic_ai_harness.spend._events import SpendBudgetStatus, SpendRecordedEvent
from pydantic_ai_harness.spend._exceptions import SpendLimitExceeded, UnpricedModelError, UnpricedModelWarning
from pydantic_ai_harness.spend._snapshot import BudgetStatus, SpendSnapshot, Spent, money_precision
from pydantic_ai_harness.spend._store import (
    BatchSpendStore,
    InMemorySpendStore,
    SpendEntry,
    SpendStore,
    as_batch_store,
    utc_now,
)

if TYPE_CHECKING:
    from pydantic_ai.capabilities import WrapModelRequestHandler
    from pydantic_ai.models import ModelRequestContext
    from pydantic_ai.toolsets import AgentToolset


SpendCallback = Callable[[SpendSnapshot], None | Awaitable[None]]
"""Called after each response `SpendLimits` records."""

PriceFunc = Callable[[ModelResponse], Decimal | None]
"""Prices a response. Return `None` to fall back to the `genai-prices` registry."""

_RUN_SCOPED_WINDOWS = ('run', 'conversation')
_UNPRICED_POLICIES = frozenset({'zero', 'raise'})
_ATTEMPTS_ADAPTER = TypeAdapter(list[ModelRequestAttempt])


@dataclass
class SpendLimits(AbstractCapability[AgentDepsT]):
    """Accumulate spend per window and refuse a request once a window is exhausted.

    ```python
    from decimal import Decimal

    from pydantic_ai import Agent
    from pydantic_ai_harness.spend import Budget, SpendLimits

    agent = Agent(
        'openai:gpt-5.4',
        capabilities=[SpendLimits(budgets=[Budget(usd=Decimal('100'), window='day')])],
    )
    ```

    With no budgets the capability only reports through `SpendRecordedEvent`. Add a
    `Budget` with no ceiling to keep a running total that never blocks.

    Once a recorded response spends a window, `SpendLimits` refuses the next
    request. It does not guarantee that spend stays under the ceiling: the request
    that crosses the line completes, and concurrent runs can each pass the check
    before any of them records anything. This is a brake on a runaway loop, not an
    accounting ledger.

    State lives across runs on purpose, so `for_run` is left alone: a daily
    budget that reset every run would not be a daily budget. Per-run isolation
    comes from `Budget(window='run')`, whose key carries the run id.

    Under a durability capability, clock reads, counter reads, and accruals are durable
    operations. Their recorded results are replayed without re-entering the store. A
    shared store is still required when recovery can move to another worker: the default
    `InMemorySpendStore` loses its counters and deduplication markers with the process.
    A deprecated `SpendStore` also loses token-based deduplication outside the journal
    because its single-key `add` method has nowhere to receive `SpendEntry.token`.
    """

    budgets: Sequence[Budget[AgentDepsT]] = ()
    """Windows to accumulate against, and which of them can refuse a request."""

    store: SpendStore | BatchSpendStore = field(default_factory=InMemorySpendStore)
    """Where counters live. The default holds them for the lifetime of the process.

    A store implementing only the deprecated `SpendStore` pair is driven one window per
    call through an adapter, which warns once at construction about what that costs.
    """

    price: PriceFunc | None = None
    """Prices a response before the registry is consulted.

    Returning `None` falls through to `genai-prices`. This is the way to charge
    a self-hosted model, or a negotiated rate the public registry does not know.

    An amount must be finite and not negative. Anything else fails the run with
    `UserError`, after the response's tokens and request count have been recorded:
    a credit would move a budget away from its ceiling, and a NaN or an infinity
    is a broken pricing function rather than a price.

    Under durable execution this callable must return the same result when replayed
    for the same response. It runs in orchestration after the durable model request,
    outside the journaled accrual.
    """

    on_spend: SpendCallback | None = None
    """Deprecated callback after each response. Subscribe to `SpendRecordedEvent` instead.

    Durable replay can invoke this callback again after the response's journaled
    accrual has run only once, so the callback must be idempotent.
    """

    on_unpriced: Literal['zero', 'raise'] = 'zero'
    """What to do when a response cannot be priced.

    When usage is incomplete, any known cost is still counted and the response
    is marked unpriced because its full cost is unknown. Otherwise, `'zero'`
    counts an unpriced response as free and increments `Spent.unpriced_requests`,
    so the gap shows up instead of disappearing. `'raise'` fails the run with
    `UnpricedModelError`. Token totals still accumulate either way; when usage is
    incomplete, they are lower bounds.
    """

    expose_tools: bool = False
    """Offer the agent a `get_spend` tool.

    Off by default: a tool costs schema tokens on every request, and most
    applications want the number on a screen rather than in the model's context.
    """

    clock: Callable[[], datetime] = utc_now
    """Supplies the time that day and month windows are derived from.

    It does not reach a default-constructed `store`, which keeps its own `utc_now` for
    expiry. Both remain absolute instants, so a custom clock buckets on one and expires on
    the other; pass the same callable to the store when that matters.
    """

    # Override the inherited default ID because durable-operation recovery needs a stable identity.
    _: KW_ONLY
    id: str | None = 'spend_limits'

    _warned_unpriced: set[str] = field(default_factory=set[str], init=False, repr=False, compare=False)
    """Model names already reported by `UnpricedModelWarning`, so each reports once.

    Instance-level and never reset, matching the capability's own posture that state
    outlives a run: a per-run set would warn again on every run for the same model.
    """

    _store: BatchSpendStore = field(init=False, repr=False, compare=False)
    """`store` as something that takes every window at once, adapting a legacy one."""

    def __post_init__(self) -> None:
        """Reject an `on_unpriced` that arrived as plain data and is not one of the two policies.

        Anything other than `'raise'` behaves as `'zero'`, so a typo in a spec
        would quietly turn unpriced responses free instead of failing the run.
        """
        if self.on_spend is not None:
            warnings.warn(
                '`SpendLimits.on_spend` is deprecated; subscribe to `SpendRecordedEvent` with `@agent.on_event` '
                'instead, or with `@on_event` on a capability of your own.',
                HarnessDeprecationWarning,
                stacklevel=2,
            )

        # Budgets sharing a name, window and scope share a counter deliberately, which is how
        # one window carries a USD and a token ceiling. Two ceilings of the SAME kind on one
        # counter is not that: it reads as two independent limits and behaves as the smaller
        # one. Comparing against a single remembered budget per slot missed any collision a
        # later budget displaced, so the slot carries every attribute the counter key does.
        if self.defer_loading is True:
            # Both hooks are skipped while a deferred capability is unloaded, so an
            # exhausted budget would let requests through until the model happened to
            # load it, and the responses it missed would never be counted. A brake that
            # the thing being braked decides when to apply is not a brake.
            raise UserError(
                '`defer_loading` is not supported on `SpendLimits`: the enforcement and accounting '
                'hooks do not run until the capability is loaded, so an exhausted budget would not '
                'stop a request and the requests made meanwhile would go uncounted.'
            )

        # Two budgets that share a name and window but declare different scope callables are
        # different dimensions -- per tenant and per user, say -- keyed only by what each
        # callable returns. Nothing stops those returning the same string, and the counter
        # that results mixes the two, because every update writes every metric. Sharing one
        # callable is how a USD and a token ceiling deliberately share a counter.
        scoped: dict[tuple[str, str], Budget[AgentDepsT]] = {}
        for budget in self.budgets:
            if budget.scope is None:
                continue
            slot = (budget.name, budget.window)
            prior = scoped.get(slot)
            if prior is not None and prior.scope is not budget.scope:
                raise UserError(
                    f'Budgets named {budget.name!r} on the same window declare different `scope` callables, '
                    'so they would share one counter whenever the two return the same string, mixing the '
                    'dimensions. Give them different `name`s, or pass the same callable to both.'
                )
            scoped[slot] = budget

        # Budgets sharing a key share one counter, and one counter has one expiry: the accrual
        # writes whichever `retain` the first of them carries, so declaration order would decide
        # when a `'forever'` ceiling quietly rolls over. Rejected rather than reconciled -- taking
        # the longest would silently extend the shorter budget's horizon, which is the same class
        # of surprise pointing the other way.
        retention: dict[tuple[str, str, bool], Budget[AgentDepsT]] = {}
        for budget in self.budgets:
            counter = (budget.name, budget.window, budget.scope is None)
            prior = retention.get(counter)
            if prior is not None and prior.retain != budget.retain:
                raise UserError(
                    f'Budgets named {budget.name!r} on the same window and scope share one counter but set '
                    f'different `retain` values ({prior.retain!r} and {budget.retain!r}), so the order they '
                    'are listed in would decide when that counter expires. Give them the same `retain`, or '
                    'different `name`s.'
                )
            retention[counter] = budget

        seen: set[tuple[str, str, str, int]] = set()
        for budget in self.budgets:
            for kind, ceiling in (('usd', budget.usd), ('tokens', budget.tokens)):
                if ceiling is None:
                    continue
                slot = (budget.name, kind, budget.window, id(budget.scope))
                if slot in seen:
                    raise UserError(
                        f'Two budgets named {budget.name!r} both set a `{kind}` ceiling on the same window and '
                        'scope, so they would share one counter and only the smaller would ever apply. '
                        'Give them different `name`s.'
                    )
                seen.add(slot)
        if self.on_unpriced not in _UNPRICED_POLICIES:
            raise UserError(
                f'SpendLimits.on_unpriced must be one of {sorted(_UNPRICED_POLICIES)}; got {self.on_unpriced!r}.'
            )
        # Resolved once, and last, so a configuration that was going to be refused is
        # refused before a deprecated store is reported.
        self._store = as_batch_store(self.store)

    @classmethod
    def get_serialization_name(cls) -> str | None:
        """Serialization name for agent-spec support."""
        return 'SpendLimits'

    def get_ordering(self) -> CapabilityOrdering:
        """Keep the established innermost placement around the model-request lifecycle."""
        return CapabilityOrdering(position='innermost')

    def get_toolset(self) -> AgentToolset[AgentDepsT] | None:
        """Offer `get_spend` when `expose_tools` is set."""
        if not self.expose_tools:
            return None
        from pydantic_ai_harness.spend._toolset import build_toolset

        return build_toolset(self)

    async def before_model_request(
        self,
        ctx: RunContext[AgentDepsT],
        request_context: ModelRequestContext,
    ) -> ModelRequestContext:
        """Refuse the request if any budget with a ceiling is already spent."""
        enforcing = [(budget, key) for budget, key in await self._keyed(ctx) if budget.enforces]
        read = await self._read(list(dict.fromkeys(key for _, key in enforcing)))
        for budget, key in enforcing:
            self._check(budget, read[key], ctx)
        return request_context

    async def wrap_model_request(
        self,
        ctx: RunContext[AgentDepsT],
        *,
        request_context: ModelRequestContext,
        handler: WrapModelRequestHandler,
    ) -> ModelResponse:
        """Accrue every response the provider billed during the wrapped lifecycle.

        Core records each billed response on the request context as the model returns it, so
        this sees a response even when a hook nested inside this wrapper rejects or replaces it,
        and never sees a response a hook made up without calling the model (a cache hit or
        `SkipModelRequest`).

        Billed attempts that did not produce the response, such as responses a `FallbackModel`
        rejected, are accrued too: from `ModelResponse.failed_attempts` ahead of the response that
        carries them, and from the attempts core records on the request context when every model
        failed, whether or not a hook then recovered from the error.

        The segments of a continuation chain are observed too, so the merged response they
        produce can be accrued boundary by boundary: see `_accrue_response`.
        """
        usage_response_offset = len(request_context._usage_responses)  # pyright: ignore[reportPrivateUsage]
        usage_attempt_offset = len(request_context._usage_attempts)  # pyright: ignore[reportPrivateUsage]
        segments: list[ModelResponse] = []
        response: ModelResponse | None = None
        try:
            with observe_continuation_segments(request_context, segments.append):
                response = await handler(request_context)
        finally:
            usage_responses = request_context._usage_responses[usage_response_offset:]  # pyright: ignore[reportPrivateUsage]
            # Segments are attributed only to a lifecycle's single committed response, which core merged them into.
            boundaries = _continuation_boundaries(request_context, segments) if len(usage_responses) == 1 else []
            errors: list[Exception | None] = []
            for response_index, usage_response in enumerate(usage_responses, start=usage_response_offset):
                response_token = cache(partial(self._dedup_token, ctx, usage_response, response_index))
                boundary_tokens = [
                    (boundary, cache(partial(self._dedup_token, ctx, boundary, response_index)))
                    for boundary in boundaries
                ]
                anchors = [*boundary_tokens, (usage_response, response_token)]
                for billed in _billed_attempts(usage_response.failed_attempts or (), partial(_anchored_token, anchors)):
                    errors.append(await self._accrue_safely(ctx, *billed, failed_attempt=True))
                errors.append(await self._accrue_safely(ctx, usage_response, response_token, boundary_tokens))
            unanswered = request_context._usage_attempts[usage_attempt_offset:]  # pyright: ignore[reportPrivateUsage]
            if unanswered:
                unanswered_token = cache(partial(_unanswered_token, ctx, unanswered))
                for billed in _billed_attempts(unanswered, partial(_attempt_token, unanswered_token)):
                    errors.append(await self._accrue_safely(ctx, *billed, failed_attempt=True))
            first_error = next((error for error in errors if error is not None), None)
            # Only on the success path: pricing-policy and callback errors have never been
            # able to outrank the request's own exception, and a retryable failure such as
            # `ModelRetry` must keep propagating so the run retries instead of dying on a
            # reporting error. The responses are accrued above either way.
            if first_error is not None and response is not None:
                raise first_error
        assert response is not None
        return response

    async def _accrue_safely(
        self,
        ctx: RunContext[AgentDepsT],
        response: ModelResponse,
        token: Callable[[], str],
        boundaries: Sequence[tuple[ModelResponse, Callable[[], str]]] = (),
        *,
        failed_attempt: bool = False,
    ) -> Exception | None:
        """Accrue one billed response, returning rather than raising what went wrong.

        One failure must not stop the other responses of the lifecycle from accruing.
        """
        try:
            error = await self._accrue_response(ctx, response, token, boundaries, failed_attempt=failed_attempt)
            if (
                error is None
                and response.usage.unmeasured_requests
                and any(budget.tokens is not None for budget in self.budgets)
            ):
                warnings.warn(
                    'Some responses omitted usage information, so `SpendLimits` token totals are lower bounds '
                    'and token ceilings cannot be fully enforced. A custom price does not restore missing tokens; '
                    'check the provider usage reporting or promote `UsageLimitUnavailableWarning` to an error.',
                    UsageLimitUnavailableWarning,
                    stacklevel=3,
                )
            return error
        except Exception as exc:
            return exc

    async def _accrue_response(
        self,
        ctx: RunContext[AgentDepsT],
        response: ModelResponse,
        token: Callable[[], str],
        boundaries: Sequence[tuple[ModelResponse, Callable[[], str]]] = (),
        *,
        failed_attempt: bool = False,
    ) -> Exception | None:
        """Accrue one billed response, then report it once.

        `boundaries` are what a continuation chain had merged into after each segment before
        its last, each with its replay token. Each accrues its USD and token growth over what is
        already applied, and `response` last, so the tokens add up to `response` itself. Under
        durable execution each segment is its own durable model request, and a non-streamed
        lifecycle that failed partway accrued the merged response up to the failure. A retry
        replays those segments and reaches the same boundaries in the same order, so the
        recorded accruals replay and only the segments it newly requested reach the store.
        Accruing the whole merged response in one call would replay the recorded accrual in
        its place instead.

        The request and, when `response` is unpriced, the unpriced request are counted with
        the first accrual. A boundary that cannot be priced adds no USD and `response` catches
        up, so pricing errors and `on_unpriced` apply to `response` alone. USD growth is floored
        at zero against the highest amount applied so far, so a pricing function that values a
        later boundary below an earlier one cannot post a credit. A later boundary that adds
        nothing is skipped, so idle polls of a background job add no store calls. The first is
        always written: it carries the request, and a retry must write it at the same position
        the failed attempt did.
        """
        usd, priced, price_error = self._price_of(response, failed_attempt=failed_attempt)
        keyed = await self._keyed(ctx)
        applied_usd, applied_tokens = Decimal(0), 0
        accrued: Mapping[str, Spent] | None = None
        for boundary, boundary_token in (*boundaries, (response, token)):
            boundary_usd = usd if boundary is response else self._price_of(boundary)[0]
            with money_precision():
                usd_growth = max(Decimal(0), boundary_usd - applied_usd)
            tokens_growth = max(0, boundary.usage.total_tokens - applied_tokens)
            # Never the first write, even with nothing to add: see above.
            if accrued is not None and not (usd_growth or tokens_growth):
                continue
            first = accrued is None
            entries: dict[str, SpendEntry] = {}
            for budget, key in keyed:
                # Budgets sharing a name, window, and scope share a counter, which is
                # how one window carries both a USD and a token ceiling. Adding the
                # response once per budget would double-count it and halve them both.
                if key not in entries:
                    entries[key] = SpendEntry(
                        key=key,
                        usd=usd_growth,
                        tokens=tokens_growth,
                        requests=1 if first else 0,
                        unpriced=0 if priced or not first else 1,
                        ttl=budget.ttl,
                        token=boundary_token(),
                    )
            # Every window in one call, so a failure cannot leave the response counted
            # against the day and not the month. Nothing to apply is not a call: see `_read`.
            accrued = await self._accrue(list(entries.values()))
            missing = sorted({key for _, key in keyed} - accrued.keys())
            if missing:
                raise UserError(
                    f'The spend accrual returned no total for key(s) {missing}. Under durable execution this can '
                    'mean a `Budget.scope` callable returned a different value on replay; scope and price callables '
                    'must be deterministic. Otherwise, the `BatchSpendStore` must return a total for every submitted '
                    'key.'
                )
            with money_precision():
                applied_usd += usd_growth
            applied_tokens += tokens_growth
        assert accrued is not None
        statuses = [_status(budget, key, accrued[key]) for budget, key in keyed]

        error: Exception | None = None
        snapshot = SpendSnapshot(
            model=response.model_name,
            usage=response.usage,
            usd=usd,
            priced=priced,
            budgets=tuple(statuses),
        )
        await ctx.emit(
            SpendRecordedEvent(
                model=snapshot.model,
                usage=snapshot.usage,
                usd=snapshot.usd,
                priced=snapshot.priced,
                failed_attempt=failed_attempt,
                budgets=tuple(
                    SpendBudgetStatus(
                        name=status.budget.name,
                        window=status.budget.window,
                        usd_limit=status.budget.usd,
                        token_limit=status.budget.tokens,
                        key=status.key,
                        spent_usd=status.spent.usd,
                        spent_tokens=status.spent.tokens,
                        requests=status.spent.requests,
                        unpriced_requests=status.spent.unpriced_requests,
                        remaining_usd=status.remaining_usd,
                        remaining_tokens=status.remaining_tokens,
                        warning=status.warning,
                        exhausted=status.exhausted,
                    )
                    for status in snapshot.budgets
                ),
            )
        )
        if self.on_spend is not None:
            try:
                result = self.on_spend(snapshot)
                if inspect.isawaitable(result):
                    await result
            except Exception as exc:
                error = exc

        if price_error is not None:
            # Raised after the store and `on_spend` have seen the response, for the reason
            # `_price_of` gives. Ahead of the `on_unpriced` handling below, which would
            # otherwise report a broken pricing function as an unknown model. Raising from
            # a wrapper rather than from `after_model_request` does not change that: the
            # accrual is already committed above.
            if error is None:
                error = UserError(f'`SpendLimits.price` {price_error} for a response.')

        if not priced and error is None:
            error = self._handle_unpriced(response, usd)
        return error

    def _handle_unpriced(self, response: ModelResponse, usd: Decimal) -> Exception | None:
        """Apply `on_unpriced` to a response whose full price is unknown, returning the error to raise, if any."""
        model = response.model_name or '<unnamed>'
        if self.on_unpriced == 'zero':
            if any(budget.usd is not None for budget in self.budgets) and model not in self._warned_unpriced:
                # A response without a registered price adds nothing in dollars. Incomplete
                # usage can add a known subtotal, but still leaves the USD total understated.
                self._warned_unpriced.add(model)
                if response.usage.unmeasured_requests:
                    warning_message = (
                        f'Usage was incomplete for model {model}; only the known subtotal ${usd} was recorded '
                        'against USD budgets, and known token totals are lower bounds. Supply `SpendLimits.price` '
                        "for the complete price, or set `on_unpriced='raise'` to stop the run."
                    )
                else:
                    warning_message = (
                        f'No price for model {model}, so it counts as $0 against a USD budget. '
                        "Supply `SpendLimits.price` to price it, or set `on_unpriced='raise'` to "
                        'stop the run instead. Token ceilings are unaffected.'
                    )
                warnings.warn(warning_message, UnpricedModelWarning, stacklevel=3)
            return None
        # Raised last, after the store is updated and `on_spend` has seen the
        # response. The request happened and its tokens were really spent, so
        # dropping them would leave a token ceiling understating what the
        # model was asked to do, and an audit that skipped exactly the
        # unpriced responses would be missing the ones worth knowing about.
        if response.usage.unmeasured_requests:
            return UnpricedModelError(
                f'Usage was incomplete for model {model}; only the known subtotal ${usd} was recorded, and known '
                'token totals are lower bounds. Supply `SpendLimits.price` for the complete price, or set '
                "`on_unpriced='zero'` to continue with the known subtotal."
            )
        return UnpricedModelError(
            f'No price for model {model}. Supply `SpendLimits.price`, '
            "or set on_unpriced='zero' to count the request as free."
        )

    async def status(
        self,
        ctx: RunContext[AgentDepsT] | None = None,
        *,
        scope: str | None = None,
    ) -> tuple[BudgetStatus, ...]:
        """Where each budget stands.

        Inside a run, pass `ctx` and every budget resolves. Without one -- the
        reading a cost display wants, and the check to make before starting a
        durable workflow -- budgets on a
        `run` or `conversation` window are omitted, since those periods have no
        meaning outside a run, and a budget declaring a `scope` is omitted
        unless `scope` names the partition to read, since its callable has no
        run context to resolve against.

        Reach for [`exhausted`][pydantic_ai_harness.spend.SpendLimits.exhausted] when the
        answer gates something: `any(s.exhausted for s in ...)` over a tuple that happens to
        be empty is a brake that reads as enforcement and inspects nothing, and a `SpendLimits`
        whose budgets are all scoped returns exactly that tuple.
        """
        statuses, _ = await self._resolve(ctx, scope)
        return statuses

    async def _resolve(
        self, ctx: RunContext[AgentDepsT] | None, scope: str | None
    ) -> tuple[tuple[BudgetStatus, ...], tuple[str, ...]]:
        """The readable budgets, and the names of the ones this call cannot resolve.

        `ctx` and `scope` are two answers to the same question, so supplying both is refused
        rather than resolved by precedence: a run's own scope silently winning would report
        one tenant's money under another tenant's name, and the caller has no way to tell.
        """
        if ctx is not None and scope is not None:
            raise UserError(
                'Pass either a run context or `scope=`, not both: `ctx` already names the partition to read, '
                'so a second answer here would be reporting one scope under the name of another. '
                'Drop `scope=` to read the run, or drop `ctx` to read another partition.'
            )
        now = await self._now()
        keyed: list[tuple[Budget[AgentDepsT], str]] = []
        unresolved: list[str] = []
        for budget in self.budgets:
            if ctx is None and (budget.window in _RUN_SCOPED_WINDOWS or (budget.scope is not None and scope is None)):
                unresolved.append(budget.name)
                continue
            keyed.append((budget, self._key(budget, ctx, now, scope)))
        read = await self._read(list(dict.fromkeys(key for _, key in keyed)))
        return tuple(_status(budget, key, read[key]) for budget, key in keyed), tuple(unresolved)

    async def exhausted(
        self,
        ctx: RunContext[AgentDepsT] | None = None,
        *,
        scope: str | None = None,
    ) -> bool:
        """Whether any budget this call can read is exhausted, refusing to guess about the rest.

        An admission check, and only that. It reads the counters; it reserves nothing and
        records nothing, so work started on the strength of it is measured only if the agent
        also carries this capability. Under durable execution, the agent's clock reads,
        counter reads, and accruals are journaled. The store still has to survive worker
        replacement for a budget shared across those workers.

        `status()` omits what it cannot resolve, and `any(...)` over the remainder is a brake
        that silently checks nothing when every budget is scoped -- so this raises instead,
        naming the budgets that need a `scope` or a `ctx`.
        """
        statuses, unresolved = await self._resolve(ctx, scope)
        if unresolved:
            raise UserError(
                f'Cannot read budget(s) {sorted(unresolved)} without a run context or a `scope`, so this check '
                'would pass having inspected nothing. Pass `scope=` for a scoped budget, or call it inside a run.'
            )
        return any(status.exhausted for status in statuses)

    @classmethod
    def from_spec(
        cls,
        *,
        budgets: Sequence[BudgetSpec] = (),
        on_unpriced: Literal['zero', 'raise'] = 'zero',
        expose_tools: bool = False,
        id: str | None = 'spend_limits',
        description: str | None = None,
        defer_loading: bool = False,
        **unsupported: Any,
    ) -> SpendLimits[Any]:
        """Build from an agent spec, covering the fields a spec can express.

        Every parameter is named because that signature is what core reads to generate
        the spec's JSON schema: `build_schema_types` drops `*args`/`**kwargs`, so a
        catch-all signature publishes the bare string `'SpendLimits'` and an editor
        marks every documented `budgets:` block as invalid even though it loads.

        `budgets` arrive as mappings and become `Budget` instances, with `usd`
        accepted as a string so YAML cannot round a price through a float. The
        callables and the store have no spec representation and are rejected
        rather than dropped: a spec that promises per-tenant scoping and does
        not deliver it is worse than a spec that refuses to load. `**unsupported`
        stays so that rejection keeps naming the field; core drops it from the schema,
        so it costs nothing there.
        """
        callables = sorted({'store', 'price', 'on_spend', 'clock'} & unsupported.keys())
        if callables:
            raise UserError(
                f'SpendLimits cannot be built from a spec with {callables}: these take callables or a live '
                'store. Construct the capability in code to use them.'
            )
        if unsupported:
            raise UserError(f'SpendLimits has no spec field(s) {sorted(unsupported)}.')
        return cls(
            budgets=[_budget_from_spec(entry) for entry in budgets],
            on_unpriced=on_unpriced,
            expose_tools=expose_tools,
            id=id,
            description=description,
            defer_loading=defer_loading,
        )

    @durable_operation('now')
    async def _now(self) -> datetime:
        """Read the clock durably, naming the remedy when Temporal runs it in orchestration.

        These hooks run in workflow code, and the default clock calls `datetime.now`, which
        Temporal's workflow sandbox restricts. The sandbox's own error names
        `datetime.datetime.now` and not what it means here, so it is translated. Matched by
        class name rather than by importing `temporalio`, which this package does not depend
        on, and which core's own `pydantic_ai/durable_exec/AGENTS.md` rules out: "Prefer generic
        capabilities/toolsets/models extension points over engine-specific escape hatches."

        A durability capability dispatches this method to an activity, step, or task. The
        translation remains for an agent run directly inside a Temporal workflow without
        durability attached, where the decorator deliberately calls through to this method.
        Passing the module through the sandbox would only silence the useful symptom.
        """
        try:
            return self.clock()
        except Exception as error:
            if type(error).__name__ != 'RestrictedWorkflowAccessError':
                raise
            raise UserError(
                'SpendLimits needs a durability capability when it runs inside a Temporal workflow. '
                'The clock read that selects the budget window must run in an activity, which attaching '
                '`TemporalDurability` arranges through the durable `now` operation. Without durability, '
                'the hook reads the clock in workflow orchestration and Temporal restricts it.'
            ) from error

    def _key(
        self,
        budget: Budget[AgentDepsT],
        ctx: RunContext[AgentDepsT] | None,
        now: datetime,
        scope: str | None,
    ) -> str:
        """The store key this budget accumulates under right now."""
        bucket_id = bucket(budget.window, ctx, now)
        if bucket_id is None:  # pragma: no cover - callers filter run-scoped windows out first
            raise UserError(f"Budget {budget.name!r} uses window='{budget.window}', which needs a run.")
        return store_key(budget, bucket_id, scope_key(budget, ctx, scope))

    def _dedup_token(self, ctx: RunContext[AgentDepsT], response: ModelResponse, response_index: int) -> str:
        """Identify one response from replay-stable run and response data.

        Durable execution journals `_accrue`, so ordinary replay returns its recorded totals
        without entering the store. The token is the second layer for recovery that presents
        the same entry without consulting that journal, as long as it reaches the store that
        remembers the token.

        `run_id` and `run_step` locate the response in the run. The digest includes semantic
        response parts to distinguish different content, usage to distinguish different
        billing, and provider/model identity fields to distinguish otherwise equal responses
        from different sources. This also distinguishes responses when a provider repeats an id.

        Provider details and metadata are deliberately excluded because providers may put
        arbitrary non-serializable objects there. Timestamps and attempt durations are excluded
        because core measures them on the local clock, and the response's run stamp is excluded
        because core adds it only after this wrapper returns. Length-prefixing prevents boundary
        collisions.
        """
        stable_response = replace(
            response,
            parts=[
                replace(part, provider_details=None) if hasattr(part, 'provider_details') else part
                for part in response.parts
            ],
            timestamp=datetime.min.replace(tzinfo=response.timestamp.tzinfo),
            failed_attempts=response.failed_attempts and [_stable_attempt(a) for a in response.failed_attempts],
            run_id=None,
            conversation_id=None,
            metadata=None,
            provider_details=None,
        )
        digest = sha256(ModelMessagesTypeAdapter.dump_json([stable_response])).hexdigest()
        token = delimited(ctx.run_id or '', str(ctx.run_step), digest)
        # Preserve existing single-response replay keys; distinguish subsequent provider responses.
        return delimited(token, str(response_index)) if response_index else token

    def _check(self, budget: Budget[AgentDepsT], spent: Spent, ctx: RunContext[AgentDepsT]) -> None:
        """Raise if `spent` has reached either of the budget's ceilings."""
        if budget.usd is not None and spent.usd >= budget.usd:
            self._refuse(budget, ctx, f'spent ${spent.usd} of ${budget.usd}')
        if budget.tokens is not None and spent.tokens >= budget.tokens:
            self._refuse(budget, ctx, f'used {spent.tokens} of {budget.tokens} tokens')

    def _refuse(self, budget: Budget[AgentDepsT], ctx: RunContext[AgentDepsT], detail: str) -> None:
        """Record the refusal as a span and raise."""
        attributes: dict[str, str] = {'spend.budget': budget.name, 'spend.window': budget.window}
        if ctx.trace_include_content and budget.scope is not None:
            # A scope key is usually a tenant or user id, and a trace has a wider
            # audience than the application that produced it.
            attributes['spend.scope'] = budget.scope(ctx)
        ctx.tracer.start_span('spend budget exhausted', attributes=attributes).end()
        raise SpendLimitExceeded(f'Budget {budget.name!r} exhausted for this {budget.window}: {detail}')

    @durable_operation('read')
    async def _read(self, keys: Sequence[str]) -> Mapping[str, Spent]:
        """What each key holds, without asking the store about none of them.

        A `SpendLimits` configured to report rather than enforce, or one whose budgets this
        call cannot resolve, has no key to read. Asking anyway spends a round trip on a
        store that answers it and fails outright on one that treats an empty batch as a
        caller error, and neither buys anything. `add_many` is guarded the same way.
        """
        return await self._store.get_many(keys) if keys else {}

    @durable_operation('accrue')
    async def _accrue(self, entries: list[SpendEntry]) -> Mapping[str, Spent]:
        """Apply one response, or a continuation boundary's growth, and journal the store's totals."""
        return await self._store.add_many(entries) if entries else {}

    async def _keyed(self, ctx: RunContext[AgentDepsT]) -> list[tuple[Budget[AgentDepsT], str]]:
        """Each budget paired with the store key it accumulates under right now.

        No collision check here. Every part of a key is fixed at construction -- `name`,
        `window`, and the scope callable -- and `__post_init__` rejects the combinations
        that would collide, so two budgets share a key only where sharing one is the
        point. Checking again would repeat that work on every model request.
        """
        now = await self._now()
        return [(budget, self._key(budget, ctx, now, None)) for budget in self.budgets]

    def _price_of(self, response: ModelResponse, *, failed_attempt: bool = False) -> tuple[Decimal, bool, str | None]:
        """What cost to record, whether it prices the whole response, and why it was rejected.

        A rejected amount is reported rather than raised so the caller can finish
        accruing the response first. The request happened and its tokens were really
        spent, so dropping them would leave a token ceiling understating what the model
        was asked to do -- the same reasoning `on_unpriced='raise'` already follows. A
        response with incomplete usage can still carry a known cost subtotal; that amount
        is recorded while `on_unpriced` handles the missing portion.

        A failed attempt's response only summarizes the rejected one, so the `usage.cost` core
        put on it is used when `price` gives none: core priced it with the provider URL the
        rejected response carried, which the summary does not. Core never overwrites a cost
        the model set itself, so a negative or non-finite one is not trusted and the summary
        is priced from the registry instead.
        """
        if self.price is not None:
            try:
                supplied = self.price(response)
            except Exception as exc:
                return Decimal(0), False, f'raised {type(exc).__name__}: {exc}'
            if supplied is not None:
                if not supplied.is_finite():
                    # Checked before the comparison below, which raises `InvalidOperation`
                    # on a NaN rather than returning False. An infinity would pass that
                    # comparison and then exhaust every budget it reached at once.
                    return Decimal(0), False, f'returned a non-finite amount ({supplied})'
                if supplied < 0:
                    # A credit would move a budget away from its ceiling, which
                    # turns a bug in the pricing function into a gate that never
                    # closes. Corrections belong in the store, not here.
                    return Decimal(0), False, f'returned a negative amount ({supplied})'
                return supplied, True, None
        known_cost = response.usage.cost
        if known_cost is not None and not (known_cost.is_finite() and known_cost >= 0):
            known_cost = None
        if response.usage.unmeasured_requests:
            return known_cost or Decimal(0), False, None
        if failed_attempt and known_cost is not None:
            return known_cost, True, None
        if response.model_name:
            try:
                return response.cost().total_price, True, None
            except (LookupError, ValueError):
                # LookupError: the registry has no entry. ValueError: it rejects the
                # usage shape. Either way this is a pricing failure, and letting it
                # escape would skip `on_unpriced` and drop the accrual with it.
                pass
        return Decimal(0), False, None


def _billed_attempts(
    attempts: Sequence[ModelRequestAttempt], token: Callable[[int], str]
) -> Iterator[tuple[ModelResponse, Callable[[], str]]]:
    """Each attempt the provider billed, as a response to accrue and its replay token.

    The response carries what `price` and the registry read, so a user's `price` prices an attempt the
    same way it would have priced the response had it been accepted. `token` gives an attempt's replay
    token from its position among `attempts`.
    """
    for index, attempt in enumerate(attempts):
        if attempt.usage is None:
            continue
        billed = ModelResponse(
            parts=[],
            usage=attempt.usage,
            model_name=attempt.model_name,
            provider_name=attempt.provider_name,
            timestamp=attempt.timestamp,
        )
        yield billed, partial(token, index)


def _attempt_token(token: Callable[[], str], index: int) -> str:
    """Extend `token`, which identifies what the attempts were recorded on, with an attempt's position among them."""
    return delimited(token(), 'attempt', str(index))


def _anchored_token(anchors: Sequence[tuple[ModelResponse, Callable[[], str]]], index: int) -> str:
    """The replay token of a committed response's attempt at `index`, anchored to the first of `anchors` carrying it.

    `anchors` are a continuation chain's boundaries followed by the response it was merged into. Merging keeps
    earlier segments' attempts first, so the first boundary carrying an attempt is the earliest response it
    could have been committed on: a retry of a chain that failed partway reaches that boundary again and
    replays the attempt's recorded accrual, rather than keying it to a merged response the failed run never
    reached. Without boundaries the anchor is the response itself.
    """
    token = next(token for response, token in anchors if len(response.failed_attempts or ()) > index)
    return _attempt_token(token, index)


def _unanswered_token(ctx: RunContext[Any], attempts: Sequence[ModelRequestAttempt]) -> str:
    """Identify attempts that failed with no response to carry them, the way `_dedup_token` identifies a response."""
    digest = sha256(_ATTEMPTS_ADAPTER.dump_json([_stable_attempt(attempt) for attempt in attempts])).hexdigest()
    return delimited(ctx.run_id or '', str(ctx.run_step), 'unanswered', digest)


def _stable_attempt(attempt: ModelRequestAttempt) -> ModelRequestAttempt:
    """`attempt` without what can differ when the same request is made again.

    That is the local-clock readings, and the error text, which can carry a provider request id.
    """
    return replace(
        attempt,
        timestamp=datetime.min.replace(tzinfo=attempt.timestamp.tzinfo),
        duration=timedelta(0),
        error=None,
    )


def _continuation_boundaries(
    request_context: ModelRequestContext, segments: Sequence[ModelResponse]
) -> list[ModelResponse]:
    """What a continuation chain had merged into after each of its segments but the last.

    Folded the way core's continuation loop folds them, starting from the suspended response
    a resumed request ends in, so each boundary is the response core would have committed had
    the chain failed right after that segment. That suspended response was charged by the run
    that produced it, so it is the baseline: each boundary carries only what was billed beyond it,
    as the response core records for the request does.
    """
    if len(segments) < 2:
        return []
    resumed = resumed_response(request_context.messages)
    merged = resumed
    boundaries: list[ModelResponse] = []
    for segment in segments[:-1]:
        merged = segment if merged is None else merge_responses(merged, segment)
        boundaries.append(billed_beyond(merged, resumed))
    return boundaries


def _status(budget: Budget[Any], key: str, spent: Spent) -> BudgetStatus:
    """Pair a budget with what its window has accumulated.

    `remaining_usd` under `money_precision` for the same reason the counter itself is: an
    application that lowered `Decimal` precision for its own arithmetic would otherwise be
    told a rounded number by a store that holds an exact one.
    """
    with money_precision():
        remaining_usd = None if budget.usd is None else budget.usd - spent.usd
    remaining_tokens = None if budget.tokens is None else budget.tokens - spent.tokens
    return BudgetStatus(
        budget=budget,
        key=key,
        spent=spent,
        remaining_usd=remaining_usd,
        remaining_tokens=remaining_tokens,
        warning=_warning(budget, spent),
        exhausted=(remaining_usd is not None and remaining_usd <= 0)
        or (remaining_tokens is not None and remaining_tokens <= 0),
    )


def _warning(budget: Budget[Any], spent: Spent) -> bool:
    """Whether spend has crossed the budget's warning fraction.

    The USD product is taken under `money_precision`: rounded at the application's, a
    crossing near the fraction reports the wrong side of it.
    """
    if budget.warn_at is None:
        return False
    fraction = Decimal(str(budget.warn_at))
    with money_precision():
        if budget.usd is not None and spent.usd >= budget.usd * fraction:
            return True
    return budget.tokens is not None and spent.tokens >= budget.tokens * fraction


def _is_spec_mapping(entry: object) -> TypeGuard[Mapping[str, Any]]:
    """Whether a spec entry has the shape a `Budget` can be built from.

    Only the mapping shape is checked; a non-string key fails against
    `Budget`'s own signature, in an error that names the field.
    """
    return isinstance(entry, Mapping)


def _budget_from_spec(entry: Any) -> Budget[Any]:
    """Build one `Budget` from its spec mapping."""
    if not _is_spec_mapping(entry):
        raise UserError(f'Each SpendLimits budget in a spec must be a mapping; got {entry!r}.')
    fields = dict(entry)
    if 'scope' in fields:
        raise UserError('A SpendLimits budget scope is a callable and cannot be expressed in a spec.')
    # Every number a spec can carry, not just `usd`: the others reached
    # `Budget.__post_init__` as strings and compared str to int there, which
    # surfaces as a bare TypeError naming no field.
    for name, convert in (('usd', Decimal), ('tokens', int), ('warn_at', float)):
        if name in fields:
            try:
                fields[name] = convert(str(fields[name]))
            except (TypeError, ValueError) as error:
                raise UserError(f'SpendLimits budget {name!r} is not a number: {fields[name]!r}.') from error
    return Budget(**fields)
