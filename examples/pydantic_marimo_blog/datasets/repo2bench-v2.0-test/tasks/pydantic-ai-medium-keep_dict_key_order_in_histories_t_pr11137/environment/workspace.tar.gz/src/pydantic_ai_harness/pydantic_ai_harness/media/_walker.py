"""JSON walkers that swap inline large parts for externalized markers.

Used by step-persistence backends to keep large payloads out of snapshot
records. The walkers operate on JSON-shaped trees (`list`/`dict`/scalars)
so they never need to know about `pydantic_ai.messages` types directly --
they recognize the serialized shapes emitted by
`ModelMessagesTypeAdapter.dump_json`:

- `BinaryContent`: `{"kind": "binary", "data": "<b64>", ...}`.
- Any message part carrying a string `content` -- every part serializes a
  `part_kind` discriminator, so `TextPart`, `ThinkingPart`, `ToolReturnPart`
  with a string return and a string-valued `UserPromptPart` all match:
  `{"content": "<text>", "part_kind": "<kind>", ...}`.
- `TextContent`, the `UserContent`/`ToolReturn` element that carries text
  inside a part rather than being one: `{"content": "<text>", "kind":
  "text-content", ...}`. It has no `part_kind`, so it needs its own
  discriminator match.

Both kinds go to the same content-addressed `MediaStore`; the marker records
which field was externalized so `restore_media` re-inlines the right one.
Externalizing large text (not just binary) keeps a single snapshot below
MongoDB's 16MB document cap when a tool returns a large string.

Round-trip: `externalize_media` (pre-write) and `restore_media` (post-read)
are inverses for payloads whose byte length is >= threshold. Payloads below
the threshold pass through unchanged.

The tree has to be JSON-shaped: a message object or a `dump_python()` tree
(which carries `bytes` and `datetime` values) raises `TypeError`. A message
object matches none of the shapes above, and the binary payloads of a
`dump_python()` tree are `bytes`, not base64, so they would stay inline.

A dict the walker does not externalize but which carries a reserved key
(`_EXTERNAL_MARKER` or `_LITERAL_KEY`) is written wrapped as
`{_LITERAL_KEY: <dict>, _MARKER_FORMAT: _LITERAL_FORMAT}` and unwrapped on
restore, so caller data such as a tool return can never be read back as a
marker.
"""

from __future__ import annotations

import base64
from typing import TypeGuard

from pydantic_ai_harness.media._store import MediaContext, MediaStore

_EXTERNAL_MARKER = '__harness_external_media__'
_TEXT_MARKER = '__harness_external_text__'
# Authoritative location of the externalized-blob reference. It is namespaced so
# a part or arbitrary `ToolReturnPart.content` mapping that already carries its
# own `uri` field round-trips it intact: `ToolReturnContent` permits any
# `Mapping[str, ...]`, so a user payload can legitimately collide on
# `part_kind`/`content`/`uri`, and a plain `uri` key alone would drop the
# original. See `_write_reference` for the backward-compatible `uri` mirror.
_URI_KEY = '__harness_external_uri__'
# A marker can overwrite fields with the same names as its own metadata. New
# markers move those caller-owned values into a versioned mapping before writing
# the metadata, and the reader puts them back after rehydrating the payload.
_ESCAPED_KEYS = '__harness_external_escaped_keys__'
_MARKER_FORMAT = '__harness_external_marker_format__'
# Set to `_URLSAFE_STAMP` on a binary marker whose source `data` used the
# URL-safe base64 alphabet (which is what pydantic serializes `bytes` as), so
# restore writes the same alphabet back. Markers without the stamp restore with
# the standard alphabet; a marker written before the stamp existed can carry
# the key as caller data, so only the stamp value is read as ours.
_URLSAFE_KEY = '__harness_external_urlsafe__'
_URLSAFE_STAMP = 'base64-urlsafe-v1'
# Wraps a dict that is not a marker but carries `_EXTERNAL_MARKER` or this key
# itself, so restore never mistakes caller data for a marker. The wrapper is
# stamped under `_MARKER_FORMAT` so a dict a snapshot from before the wrapper
# stored under `_LITERAL_KEY` alone is not unwrapped.
_LITERAL_KEY = '__harness_external_literal__'
_LITERAL_FORMAT_PREFIX = 'literal-v'
_LITERAL_FORMAT = f'{_LITERAL_FORMAT_PREFIX}1'
# Version stamps this format issues. The prefix is what tells a stamp we wrote
# apart from a caller-owned `_MARKER_FORMAT` value, so only a stamp inside the
# namespace makes the version check apply at all.
_ESCAPED_KEYS_FORMAT_PREFIX = 'escaped-keys-v'
_ESCAPED_KEYS_FORMAT = f'{_ESCAPED_KEYS_FORMAT_PREFIX}1'
_MARKER_METADATA_KEYS = (
    _EXTERNAL_MARKER,
    _TEXT_MARKER,
    _URI_KEY,
    _ESCAPED_KEYS,
    _MARKER_FORMAT,
    _URLSAFE_KEY,
)
_LITERAL_TRIGGER_KEYS = (_EXTERNAL_MARKER, _LITERAL_KEY)
# `TextContent.kind` (`pydantic_ai.messages.TextContent`). Unlike a message
# part it carries no `part_kind`, so it needs its own discriminator match.
_TEXT_CONTENT_KIND = 'text-content'


def _is_json_dict(node: object) -> TypeGuard[dict[str, object]]:
    """Treat any `dict` returned by `json.loads` as `dict[str, object]`.

    JSON guarantees string keys, so the runtime `isinstance(..., dict)` check
    is sufficient -- pyright just needs the explicit TypeGuard to propagate
    the value-type narrowing through the walker.
    """
    return isinstance(node, dict)


def _is_json_list(node: object) -> TypeGuard[list[object]]:
    """Treat any `list` returned by `json.loads` as `list[object]`.

    Same rationale as `_is_json_dict` -- JSON lists contain JSON-compatible
    scalars, and we walk every element regardless.
    """
    return isinstance(node, list)


def _binary_data(node: dict[str, object]) -> str | None:
    """The base64 `data` of a serialized `BinaryContent`, or `None` if `node` is not one."""
    data = node.get('data')
    if node.get('kind') == 'binary' and isinstance(data, str):
        return data
    return None


def _decode_base64(data: str) -> tuple[bytes, bytes | None] | None:
    """Decode standard or URL-safe base64, returning the bytes and the `altchars` it used.

    Invalid characters or a mixed alphabet return `None`: `ToolReturnContent`
    permits arbitrary mappings, so a caller dict can look like `BinaryContent`
    without holding base64, and it must stay inline rather than fail.
    """
    urlsafe = '-' in data or '_' in data
    if urlsafe and ('+' in data or '/' in data):
        return None
    altchars = b'-_' if urlsafe else None
    try:
        return base64.b64decode(data, altchars=altchars, validate=True), altchars
    except ValueError:
        # Malformed input raises `binascii.Error`, a `ValueError`; a non-ASCII string raises `ValueError` itself.
        return None


def _text_content(node: dict[str, object]) -> str | None:
    """The inline text `content` of a serialized node, or `None` if `node` carries none.

    Requires a string `content` plus a discriminator: either a string
    `part_kind` (every `pydantic_ai` message part serializes one) or
    `kind == 'text-content'` (`TextContent`, which travels inside a
    `UserPromptPart.content` sequence or a `ToolReturn`, so it has no
    `part_kind` of its own). Between them these cover `TextPart`,
    `ThinkingPart`, `ToolReturnPart` with a string return, a string-valued
    `UserPromptPart`, and `TextContent` wherever it appears.

    Requiring a known discriminator is what keeps arbitrary payloads out:
    `ToolReturnContent` permits any `Mapping[str, ...]`, so a plain "has a
    string `content`" test would match user data. A payload that does collide
    on one of these discriminators still round-trips losslessly -- the
    externalized `content` re-inlines byte-for-byte, and the reference URI
    lives under the namespaced `_URI_KEY`, so the payload's own `uri` (or any
    other field) survives. A bare string element inside a
    `UserPromptPart.content` list is not a dict, so it is never a candidate
    (replacing it with a marker dict would break `UserContent` validation).
    """
    content = node.get('content')
    if not isinstance(content, str):
        return None
    if isinstance(node.get('part_kind'), str) or node.get('kind') == _TEXT_CONTENT_KIND:
        return content
    return None


def _is_external_marker(node: dict[str, object]) -> bool:
    return node.get(_EXTERNAL_MARKER) is True


def _literal_payload(node: dict[str, object]) -> dict[str, object] | None:
    """The caller dict inside a literal wrapper, or `None` if `node` is not one.

    A wrapper stamped with a later version of this format raises rather than
    passing through as caller data, the same gate the escaped-keys stamp has.
    """
    if node.keys() != {_LITERAL_KEY, _MARKER_FORMAT}:
        return None
    stamp = node[_MARKER_FORMAT]
    payload = node[_LITERAL_KEY]
    if not isinstance(stamp, str) or not stamp.startswith(_LITERAL_FORMAT_PREFIX) or not _is_json_dict(payload):
        return None
    if stamp != _LITERAL_FORMAT:
        raise ValueError(f'externalized media literal wrapper has an unsupported format: {stamp!r}')
    return payload


def _is_json_scalar(node: object) -> bool:
    return node is None or isinstance(node, (str, int, float, bool))


async def externalize_media(node: object, *, media_store: MediaStore, threshold_bytes: int) -> object:
    """Walk `node` and replace inline binary/text parts >= threshold.

    `node` must be a JSON-shaped tree, such as
    `json.loads(ModelMessagesTypeAdapter.dump_json(messages))` or
    `ModelMessagesTypeAdapter.dump_python(messages, mode='json')`; any other
    value raises `TypeError`. Pass a tree that has not been externalized: a
    marker in the input is escaped like any caller dict carrying the marker
    key, so it takes one `restore_media` per `externalize_media`. Each
    qualifying part becomes a marker dict carrying the canonical
    `media+sha256://` URI; the raw bytes are written to `media_store`. Returns
    a new tree -- input is not mutated.
    """
    if _is_json_list(node):
        out_list: list[object] = []
        for item in node:
            out_list.append(await externalize_media(item, media_store=media_store, threshold_bytes=threshold_bytes))
        return out_list
    if _is_json_dict(node):
        replaced: dict[str, object] | None = None
        if (data := _binary_data(node)) is not None:
            replaced = await _maybe_externalize_binary(node, data, media_store, threshold_bytes)
        elif (content := _text_content(node)) is not None:
            replaced = await _maybe_externalize_text(node, content, media_store, threshold_bytes)
        if replaced is not None:
            return replaced
        out_dict: dict[str, object] = {}
        for key, value in node.items():
            out_dict[key] = await externalize_media(value, media_store=media_store, threshold_bytes=threshold_bytes)
        if any(key in node for key in _LITERAL_TRIGGER_KEYS):
            return {_LITERAL_KEY: out_dict, _MARKER_FORMAT: _LITERAL_FORMAT}
        return out_dict
    if _is_json_scalar(node):
        return node
    raise TypeError(
        f'`externalize_media` takes a JSON tree, got {type(node).__name__}; '
        "serialize messages with `ModelMessagesTypeAdapter.dump_python(messages, mode='json')` first"
    )


async def _maybe_externalize_binary(
    node: dict[str, object],
    data: str,
    media_store: MediaStore,
    threshold_bytes: int,
) -> dict[str, object] | None:
    decoded = _decode_base64(data)
    if decoded is None:
        return None
    raw, altchars = decoded
    if len(raw) < threshold_bytes:
        return None
    # Non-canonical padding bits decode fine but would not re-encode to `data`,
    # so restoring them would change the caller's string.
    if base64.b64encode(raw, altchars=altchars).decode('ascii') != data:
        return None
    media_type_value = node.get('media_type')
    media_type = media_type_value if isinstance(media_type_value, str) else None
    uri = await media_store.put(raw, context=MediaContext(media_type=media_type))
    # Preserve every field except the externalized `data`, so the round-trip
    # survives new `BinaryContent` fields added by pydantic_ai upstream. Fields
    # are recursively walked so any nested externalizable payload still goes out.
    marker = await _preserve_fields(node, 'data', media_store, threshold_bytes)
    _escape_marker_metadata(marker)
    marker[_EXTERNAL_MARKER] = True
    if altchars is not None:
        marker[_URLSAFE_KEY] = _URLSAFE_STAMP
    _write_reference(marker, node, uri)
    return marker


async def _maybe_externalize_text(
    node: dict[str, object],
    content_value: str,
    media_store: MediaStore,
    threshold_bytes: int,
) -> dict[str, object] | None:
    # `surrogatepass`: a JSON string can decode to an unpaired surrogate (e.g.
    # "\ud800"), which strict UTF-8 refuses to encode. Encoding it here would
    # raise even for below-threshold content that should pass through untouched.
    # `restore_media` decodes with the same handler, so the round-trip is exact.
    raw = content_value.encode('utf-8', errors='surrogatepass')
    if len(raw) < threshold_bytes:
        return None
    uri = await media_store.put(raw, context=MediaContext(media_type='text/plain'))
    # Preserve every field except the externalized `content`, recursively walked
    # so a nested payload (e.g. binary in `metadata`) still goes external too.
    # `_TEXT_MARKER` tells `restore_media` to decode UTF-8 back into `content`
    # rather than base64 into `data`.
    marker = await _preserve_fields(node, 'content', media_store, threshold_bytes)
    _escape_marker_metadata(marker)
    marker[_EXTERNAL_MARKER] = True
    marker[_TEXT_MARKER] = True
    _write_reference(marker, node, uri)
    return marker


def _write_reference(marker: dict[str, object], node: dict[str, object], uri: str) -> None:
    """Record the blob reference on `marker`, mirroring it to `uri` when that key is free.

    `_URI_KEY` is authoritative. The plain `uri` mirror keeps binary markers
    readable by a compatible reader from before `_URI_KEY`, which resolves
    `node['uri']` and raises without it. It cannot make text markers readable
    by that binary-only reader.

    The mirror is written only when the source node had no `uri` of its own,
    because a genuine `uri` is data that has to round-trip and overwriting it
    is the bug `_URI_KEY` was introduced to fix. A node that does carry one
    therefore gets no mirror, and an older reader fails loudly on it rather
    than restoring the wrong bytes.
    """
    marker[_URI_KEY] = uri
    if 'uri' not in node:
        marker['uri'] = uri


def _escape_marker_metadata(marker: dict[str, object]) -> None:
    """Move caller-owned marker metadata keys aside before writing our values."""
    escaped: dict[str, object] = {}
    for key in _MARKER_METADATA_KEYS:
        if key in marker:
            escaped[key] = marker.pop(key)
    if escaped:
        marker[_MARKER_FORMAT] = _ESCAPED_KEYS_FORMAT
        marker[_ESCAPED_KEYS] = escaped


def _is_escape_stash(value: object) -> TypeGuard[dict[str, object]]:
    """Does `value` have the shape `_escape_marker_metadata` writes?

    `_ESCAPED_KEYS` and `_MARKER_FORMAT` are themselves keys a caller can own, so
    a marker carrying them is not evidence that this format wrote them. The stash
    is only ever a non-empty mapping keyed by metadata names.
    """
    return _is_json_dict(value) and bool(value) and not (value.keys() - _MARKER_METADATA_KEYS)


def _is_escaped_keys_format(value: object) -> bool:
    """Is `value` a version stamp from this format's own namespace?

    Paired with `_is_escape_stash`: both have to hold before the marker is read
    as escaped. A caller-owned `_MARKER_FORMAT` carrying anything else leaves the
    marker in the pre-escaping reading, where both keys are the payload's data.
    """
    return isinstance(value, str) and value.startswith(_ESCAPED_KEYS_FORMAT_PREFIX)


async def _preserve_fields(
    node: dict[str, object],
    externalized_key: str,
    media_store: MediaStore,
    threshold_bytes: int,
) -> dict[str, object]:
    """Recursively externalize every field of `node` except `externalized_key`."""
    out: dict[str, object] = {}
    for key, value in node.items():
        if key == externalized_key:
            continue
        out[key] = await externalize_media(value, media_store=media_store, threshold_bytes=threshold_bytes)
    return out


async def restore_media(node: object, *, media_store: MediaStore) -> object:
    """Inverse of `externalize_media`. Walks `node` and re-inlines external refs.

    Each marker dict's `uri` is resolved via `media_store.get`; a text marker
    re-inlines `content`, a binary marker re-inlines base64 `data`, so the
    result round-trips through `ModelMessagesTypeAdapter.validate_python`.
    """
    if _is_json_list(node):
        out_list: list[object] = []
        for item in node:
            out_list.append(await restore_media(item, media_store=media_store))
        return out_list
    if _is_json_dict(node):
        if (literal := _literal_payload(node)) is not None:
            node = literal
        elif _is_external_marker(node):
            return await _restore_external(node, media_store)
        out_dict: dict[str, object] = {}
        for key, value in node.items():
            out_dict[key] = await restore_media(value, media_store=media_store)
        return out_dict
    return node


async def _restore_external(node: dict[str, object], media_store: MediaStore) -> dict[str, object]:
    dropped = {_EXTERNAL_MARKER, _TEXT_MARKER}
    urlsafe = node.get(_URLSAFE_KEY) == _URLSAFE_STAMP
    if urlsafe:
        dropped.add(_URLSAFE_KEY)
    escaped: dict[str, object] | None = None
    escaped_value = node.get(_ESCAPED_KEYS)
    marker_format = node.get(_MARKER_FORMAT)
    # An ambiguous match degrades to "this is caller data" instead of raising: a
    # marker written before this format existed can carry both keys as the
    # payload's own, and rejecting it would turn a snapshot that reads today into
    # one that cannot be read at all, with no recovery path. So both halves have
    # to look like ours -- the stash's shape and a version stamp from this
    # format's namespace -- before the marker is read as escaped. Once they do,
    # an unrecognized version is a marker this reader genuinely cannot restore,
    # and it says so rather than drop the stash on the floor: this reader is the
    # only one that can refuse a later format.
    if _is_escape_stash(escaped_value) and _is_escaped_keys_format(marker_format):
        if marker_format != _ESCAPED_KEYS_FORMAT:
            raise ValueError(f'externalized media marker has an unsupported escaped-keys format: {marker_format!r}')
        escaped = escaped_value
        dropped.update({_MARKER_FORMAT, _ESCAPED_KEYS})
    if _URI_KEY in node:
        uri_value = node[_URI_KEY]
        dropped.add(_URI_KEY)
        # `_write_reference` mirrors the reference to `uri` only when the source
        # node had none, so a `uri` equal to the reference is that mirror and
        # goes; anything else is the node's own data and stays.
        if node.get('uri') == uri_value:
            dropped.add('uri')
    else:
        # Markers written before `_URI_KEY` existed stored the blob reference
        # under a plain `uri`. Falling back keyed on `_URI_KEY` being absent (not
        # on its value being unusable) keeps a genuine `uri` from ever being read
        # as a reference -- the bug `_URI_KEY` was introduced to fix.
        uri_value = node.get('uri')
        dropped.add('uri')
    if not isinstance(uri_value, str):
        raise ValueError(f'externalized media marker missing string uri: {node!r}')
    is_text = node.get(_TEXT_MARKER) is True
    if is_text:
        context = MediaContext(media_type='text/plain')
    else:
        media_type_value = node.get('media_type')
        media_type = media_type_value if isinstance(media_type_value, str) else None
        context = MediaContext(media_type=media_type)
    raw = await media_store.get(uri_value, context=context)
    # Inverse of `_maybe_externalize_*`: drop the marker and reference keys,
    # restore the externalized field, keep every other field the original part
    # carried. Preserved fields are recursively restored so a nested marker
    # (from the externalize-side recursion) is re-inlined too.
    restored: dict[str, object] = {}
    for key, value in node.items():
        if key in dropped:
            continue
        restored[key] = await restore_media(value, media_store=media_store)
    if escaped is not None:
        for key, value in escaped.items():
            restored[key] = await restore_media(value, media_store=media_store)
    if is_text:
        restored['content'] = raw.decode('utf-8', errors='surrogatepass')
    else:
        altchars = b'-_' if urlsafe else None
        restored['data'] = base64.b64encode(raw, altchars=altchars).decode('ascii')
    return restored
