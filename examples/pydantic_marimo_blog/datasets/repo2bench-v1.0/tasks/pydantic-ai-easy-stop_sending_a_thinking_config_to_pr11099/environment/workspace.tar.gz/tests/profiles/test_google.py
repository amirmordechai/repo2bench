"""Tests for Google JSON schema transformer.

The GoogleJsonSchemaTransformer transforms JSON schemas for compatibility with Gemini API:
- Converts `const` to `enum` with inferred `type` field
- Removes unsupported fields like $schema, title, discriminator, examples
- Handles format fields by moving them to description
"""

from __future__ import annotations as _annotations

from typing import Literal

import pytest
from pydantic import BaseModel

from pydantic_ai._json_schema import JsonSchema
from pydantic_ai.profiles.google import (
    GoogleJsonSchemaTransformer,
    GoogleOpenAPISchemaTransformer,
    google_model_profile,
)

from .._inline_snapshot import snapshot

# =============================================================================
# Transformer Tests - const to enum conversion with type inference
# =============================================================================


def test_const_string_infers_type():
    """When converting const to enum, type should be inferred for string values."""
    schema = {'const': 'hello'}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert transformed == snapshot({'enum': ['hello'], 'type': 'string'})


def test_const_integer_infers_type():
    """When converting const to enum, type should be inferred for integer values."""
    schema = {'const': 42}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert transformed == snapshot({'enum': [42], 'type': 'integer'})


def test_const_float_infers_type():
    """When converting const to enum, type should be inferred for float values."""
    schema = {'const': 3.14}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert transformed == snapshot({'enum': [3.14], 'type': 'number'})


def test_const_boolean_infers_type():
    """When converting const to enum, type should be inferred for boolean values."""
    schema = {'const': True}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert transformed == snapshot({'enum': [True], 'type': 'boolean'})


def test_const_false_boolean_infers_type():
    """When converting const to enum, type should be inferred for False boolean."""
    schema = {'const': False}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert transformed == snapshot({'enum': [False], 'type': 'boolean'})


def test_const_preserves_existing_type():
    """When const has an existing type field, it should be preserved."""
    schema = {'const': 'hello', 'type': 'string'}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert transformed == snapshot({'enum': ['hello'], 'type': 'string'})


def test_const_array_does_not_infer_type():
    """When const is an array, type cannot be inferred and should not be added."""
    schema = {'const': [1, 2, 3]}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert transformed == snapshot({'enum': [[1, 2, 3]]})


def test_const_in_nested_object():
    """const should be properly converted in nested object properties."""

    class TaggedModel(BaseModel):
        tag: Literal['hello']
        value: str

    schema = TaggedModel.model_json_schema()
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    # The tag property should have both enum and type
    assert transformed['properties']['tag'] == snapshot({'enum': ['hello'], 'type': 'string'})


# =============================================================================
# Transformer Tests - field removal
# =============================================================================


def test_removes_schema_field():
    """$schema field should be removed."""
    schema = {'$schema': 'http://json-schema.org/draft-07/schema#', 'type': 'string'}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert '$schema' not in transformed
    assert transformed == snapshot({'type': 'string'})


def test_removes_title_field():
    """title field should be removed."""
    schema = {'title': 'MyString', 'type': 'string'}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert 'title' not in transformed
    assert transformed == snapshot({'type': 'string'})


def test_removes_discriminator_field():
    """discriminator field should be removed."""
    schema = {'discriminator': {'propertyName': 'type'}, 'type': 'object'}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert 'discriminator' not in transformed
    assert transformed == snapshot({'type': 'object'})


def test_removes_examples_field():
    """examples field should be removed."""
    schema = {'examples': ['foo', 'bar'], 'type': 'string'}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert 'examples' not in transformed
    assert transformed == snapshot({'type': 'string'})


def test_removes_exclusive_min_max():
    """exclusiveMinimum and exclusiveMaximum should be removed."""
    schema = {'type': 'integer', 'exclusiveMinimum': 0, 'exclusiveMaximum': 100}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert 'exclusiveMinimum' not in transformed
    assert 'exclusiveMaximum' not in transformed
    assert transformed == snapshot({'type': 'integer'})


# =============================================================================
# Transformer Tests - format handling
# =============================================================================


def test_format_moved_to_description():
    """format should be moved to description for string types."""
    schema = {'type': 'string', 'format': 'date-time'}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert 'format' not in transformed
    assert transformed == snapshot({'type': 'string', 'description': 'Format: date-time'})


def test_format_appended_to_existing_description():
    """format should be appended to existing description."""
    schema = {'type': 'string', 'format': 'email', 'description': 'User email address'}
    transformer = GoogleJsonSchemaTransformer(schema)
    transformed = transformer.walk()

    assert 'format' not in transformed
    assert transformed == snapshot({'type': 'string', 'description': 'User email address (format: email)'})


def test_openapi_schema_transformer_prunes_map_schemas_before_traversal():
    """Direct assertions pin the public walk result and transform hooks hidden by the final Live declaration."""
    schema: JsonSchema = {
        'type': 'object',
        'properties': {'kept': {'type': 'string'}},
        'additionalProperties': {'type': 'integer'},
        'patternProperties': {'^x': {'type': 'boolean'}},
    }
    visited_types: list[str] = []

    class RecordingTransformer(GoogleOpenAPISchemaTransformer):
        def transform(self, schema: JsonSchema) -> JsonSchema:
            schema_type = schema['type']
            assert isinstance(schema_type, str)
            visited_types.append(schema_type)
            return super().transform(schema)

    transformed = RecordingTransformer(schema).walk()

    assert transformed == snapshot({'type': 'object', 'properties': {'kept': {'type': 'string'}}})
    assert visited_types == ['string', 'object']


# =============================================================================
# Model Profile Tests
# =============================================================================


def test_model_profile_gemini_2():
    """Gemini 2.x models should have proper profile settings."""
    profile = google_model_profile('gemini-2.0-flash')
    assert profile is not None
    assert profile.get('json_schema_transformer', None) == GoogleJsonSchemaTransformer
    assert profile.get('supports_json_schema_output', False) is True


def test_model_profile_gemini_3():
    """Gemini 3.x models support tool combination AND server-side tool invocations.

    The two flags happen to flip on together for Gemini 3+ but are separately named so future
    models that gain one capability without the other don't force a model-name proxy flag.
    """
    profile = google_model_profile('gemini-3.0-pro')
    assert profile is not None
    assert profile.get('google_supports_tool_combination', False) is True
    assert profile.get('google_supports_server_side_tool_invocations', False) is True


def test_model_profile_thinking_defaults():
    """Gemini 3+ behaviour is the default for thinking; older models are if-guarded."""
    # Default Gemini 3+ behaviour
    for name in (
        'gemini-3.0-pro',
        'gemini-3-flash-preview',
        'gemini-3.7-flash',
        'gemini-9-flash',
        'some-codename',
        'gemini-flash-latest',
        'gemini-pro-latest',
    ):
        profile = google_model_profile(name)
        assert profile is not None, f'{name} should have a profile'
        assert profile.get('supports_thinking') is True, f'{name} should support thinking'
        assert profile.get('google_supports_thinking_level') is True, f'{name} should support thinking_level'

    # Gemini 2.5: supports thinking, but uses budget (thinking_level=False)
    for name in ('gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.5-flash-image'):
        profile = google_model_profile(name)
        assert profile is not None, f'{name} should have a profile'
        assert profile.get('supports_thinking') is True, f'{name} should support thinking'
        assert profile.get('google_supports_thinking_level') is False, f'{name} should not support thinking_level'

    # Older models without thinking support
    for name in (
        'gemini-2.0-flash',
        'gemini-2.0-flash-lite',
        'gemini-1.5-flash',
        'gemini-1.5-pro',
        'gemini-pro',
        'gemma-3-27b-it',
    ):
        profile = google_model_profile(name)
        assert profile is not None, f'{name} should have a profile'
        assert profile.get('supports_thinking') is False, f'{name} should not support thinking'
        assert profile.get('google_supports_thinking_level') is False, f'{name} should not support thinking_level'


def test_model_profile_gemini_2_disables_tool_combination_capabilities():
    profile = google_model_profile('gemini-2.5-flash')
    assert profile is not None
    assert profile.get('google_supports_tool_combination', False) is False
    assert profile.get('google_supports_server_side_tool_invocations', False) is False


def test_model_profile_image_model():
    """Image models should have limited capabilities."""
    profile = google_model_profile('gemini-2.0-flash-image')
    assert profile is not None
    assert profile.get('supports_image_output', False) is True
    assert profile.get('supports_json_schema_output', False) is False
    assert profile.get('supports_tools', True) is False


@pytest.mark.parametrize(
    ('model_name', 'expected'),
    [
        ('gemini-3.7-flash', False),
        ('gemini-3.8-flash', False),
        ('gemini-3-pro-preview', False),
        ('gemini-3.1-pro-preview', False),
        ('gemini-4-argon', False),
        # `gemini-3.1-flash-lite-image` does accept `MINIMAL` — its levels are `minimal, high`.
        ('gemini-3.1-flash-lite-image', True),
        ('gemini-3-flash-preview', True),
    ],
)
def test_model_profile_supports_minimal_thinking_level(model_name: str, expected: bool):
    profile = google_model_profile(model_name)
    assert profile is not None
    assert profile.get('google_supports_minimal_thinking_level', True) is expected


def test_model_profile_minimal_thinking_level_matches_model_prefix():
    profile = google_model_profile('gemini-3-pro-preview-variant')
    assert profile is not None
    assert profile.get('google_supports_minimal_thinking_level', True) is False


@pytest.mark.parametrize(
    ('model_name', 'expected'),
    [
        ('gemini-3.1-flash-lite-image', frozenset(('MINIMAL', 'HIGH'))),
        ('gemini-3.7-flash', frozenset(('LOW', 'MEDIUM', 'HIGH'))),
        ('gemini-3.8-flash', frozenset(('LOW', 'MEDIUM', 'HIGH'))),
        ('gemini-3.1-pro-preview', frozenset(('LOW', 'MEDIUM', 'HIGH'))),
        ('gemini-3-pro-preview', frozenset(('LOW', 'HIGH'))),
        ('gemini-4-argon', frozenset(('LOW', 'MEDIUM', 'HIGH'))),
        # Models supporting the full scale carry no level set.
        ('gemini-3-flash-preview', None),
        # Budget-based models carry no level set.
        ('gemini-2.5-flash', None),
    ],
)
def test_model_profile_thinking_levels(model_name: str, expected: frozenset[str] | None):
    profile = google_model_profile(model_name)
    assert profile is not None
    assert profile.get('google_thinking_levels') == expected
