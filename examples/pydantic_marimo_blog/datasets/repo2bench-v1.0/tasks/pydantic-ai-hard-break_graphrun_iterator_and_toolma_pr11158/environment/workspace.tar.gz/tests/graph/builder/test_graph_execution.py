"""Tests for graph execution internals and edge cases."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from dataclasses import dataclass, field

import anyio
import pytest
from anyio import Event, create_task_group, fail_after

from pydantic_graph import GraphBuilder, StepContext
from pydantic_graph.graph_builder import EndMarker, GraphTask, _GraphIterator  # pyright: ignore[reportPrivateUsage]
from pydantic_graph.id_types import ForkID, JoinID, NodeRunID, TaskID
from pydantic_graph.join import ReduceFirstValue, reduce_list_append, reduce_list_extend
from pydantic_graph.node import Fork

READINESS_WAIT_TIMEOUT = 5


@dataclass
class ExecutionState:
    log: list[str] = field(default_factory=list[str])
    counter: int = 0


def test_run_sync_replaces_closed_event_loop(closed_event_loop: asyncio.AbstractEventLoop):
    """`Graph.run_sync` must replace a closed thread-current event loop."""
    builder = GraphBuilder(state_type=ExecutionState, output_type=int)

    @builder.step
    async def produce_result(ctx: StepContext[ExecutionState, None, None]) -> int:
        return 42

    builder.add(
        builder.edge_from(builder.start_node).to(produce_result),
        builder.edge_from(produce_result).to(builder.end_node),
    )
    graph = builder.build()

    assert graph.run_sync(state=ExecutionState()) == 42
    replacement_loop = asyncio.get_event_loop()
    assert replacement_loop is not closed_event_loop
    assert not replacement_loop.is_closed()

    assert graph.run_sync(state=ExecutionState()) == 42
    assert asyncio.get_event_loop() is replacement_loop
    assert not asyncio.all_tasks(replacement_loop)


async def test_map_to_end_node_cancels_pending():
    """Test that mapping directly to end_node cancels pending tasks"""
    g = GraphBuilder(state_type=ExecutionState, output_type=int)

    @g.step
    async def generate(ctx: StepContext[ExecutionState, None, None]) -> list[int]:
        return [1, 2, 3, 4, 5]

    @g.step
    async def early_exit(ctx: StepContext[ExecutionState, None, int]) -> int:
        # First item returns immediately
        if ctx.inputs == 1:
            return ctx.inputs
        # Others would take longer
        await asyncio.sleep(1)
        return ctx.inputs  # pragma: no cover

    g.add(
        g.edge_from(g.start_node).to(generate),
        g.edge_from(generate).map().to(early_exit),
        g.edge_from(early_exit).to(g.end_node),
    )

    graph = g.build()
    result = await graph.run(state=ExecutionState())
    # Should complete quickly with the first result
    assert result in [1, 2, 3, 4, 5]


async def test_map_non_iterable_raises_error():
    """Test that mapping a non-iterable raises RuntimeError."""
    g = GraphBuilder(state_type=ExecutionState, output_type=int)

    @g.step
    async def return_non_iterable(ctx: StepContext[ExecutionState, None, None]) -> int:
        return 42  # Not iterable!

    @g.step
    async def process_item(ctx: StepContext[ExecutionState, None, int]) -> int:
        return ctx.inputs  # pragma: no cover

    g.add(
        g.edge_from(g.start_node).to(return_non_iterable),
        g.edge_from(return_non_iterable).map().to(process_item),  # pyright: ignore[reportAttributeAccessIssue, reportUnknownArgumentType, reportUnknownMemberType]  # purposely have a type error here
        g.edge_from(process_item).to(g.end_node),
    )

    graph = g.build()
    with pytest.raises(RuntimeError, match='Cannot map non-iterable value'):
        await graph.run(state=ExecutionState())


async def test_broadcast_marker_handling():
    """Test that BroadcastMarker is handled in paths"""
    g = GraphBuilder(state_type=ExecutionState, output_type=list[str])

    @g.step
    async def source(ctx: StepContext[ExecutionState, None, None]) -> str:
        return 'data'

    @g.step
    async def branch_a(ctx: StepContext[ExecutionState, None, str]) -> str:
        return f'{ctx.inputs}-A'

    @g.step
    async def branch_b(ctx: StepContext[ExecutionState, None, str]) -> str:
        return f'{ctx.inputs}-B'

    collect = g.join(reduce_list_append, initial_factory=list[str])

    g.add(
        g.edge_from(g.start_node).to(source),
        # Use multiple .to() destinations to create broadcast
        g.edge_from(source).to(branch_a, branch_b),
        g.edge_from(branch_a, branch_b).to(collect),
        g.edge_from(collect).to(g.end_node),
    )

    graph = g.build()
    result = await graph.run(state=ExecutionState())
    assert sorted(result) == ['data-A', 'data-B']


async def test_nested_joins_with_different_fork_stacks():
    """Test nested joins with different fork stack depths"""
    g = GraphBuilder(state_type=ExecutionState, output_type=list[int])

    @g.step
    async def generate_outer(ctx: StepContext[ExecutionState, None, None]) -> list[int]:
        return [1, 2]

    @g.step
    async def generate_inner(ctx: StepContext[ExecutionState, None, int]) -> list[int]:
        return [ctx.inputs * 10, ctx.inputs * 20]

    @g.step
    async def process(ctx: StepContext[ExecutionState, None, int]) -> int:
        return ctx.inputs

    final_join = g.join(reduce_list_append, initial_factory=list[int])

    g.add(
        g.edge_from(g.start_node).to(generate_outer),
        g.edge_from(generate_outer).map().to(generate_inner),
        g.edge_from(generate_inner).map().to(process),
        g.edge_from(process).to(final_join),
        g.edge_from(final_join).to(g.end_node),
    )

    graph = g.build()
    result = await graph.run(state=ExecutionState())
    # Should have 4 total elements (2 outer * 2 inner each)
    assert len(result) == 4
    assert sorted(result) == [10, 20, 20, 40]


async def test_reduce_first_value_task_cancellation():
    """Test that ReduceFirstValue properly cancels sibling tasks"""
    import asyncio

    g = GraphBuilder(state_type=ExecutionState, output_type=str)

    @g.step
    async def generate(ctx: StepContext[ExecutionState, None, None]) -> list[int]:
        return [1, 2, 3, 4, 5]

    @g.step
    async def slow_process(ctx: StepContext[ExecutionState, None, int]) -> str:
        if ctx.inputs == 1:
            # First one completes quickly
            await asyncio.sleep(0.01)
        else:
            # Others take longer (should be cancelled)
            await asyncio.sleep(10)
        ctx.state.log.append(f'completed-{ctx.inputs}')
        return f'result-{ctx.inputs}'

    first_join = g.join(ReduceFirstValue[str](), initial='')

    g.add(
        g.edge_from(g.start_node).to(generate),
        g.edge_from(generate).map().to(slow_process),
        g.edge_from(slow_process).to(first_join),
        g.edge_from(first_join).to(g.end_node),
    )

    graph = g.build()
    state = ExecutionState()
    result = await graph.run(state=state)

    # Should get a result
    assert result is not None and result.startswith('result-')
    # Not all tasks should have completed due to cancellation
    assert len(state.log) < 5


async def test_empty_map_handling():
    """Test handling of mapping an empty iterable.

    Note: Empty maps with joins can be tricky and may need the downstream_join_id hint.
    This test documents expected behavior.
    """
    # Skipping this test as empty maps need special handling with downstream_join_id
    # The actual line coverage is achieved through other tests
    pass


async def test_complex_fork_stack_with_multiple_levels():
    """Test complex scenarios with multiple fork levels"""
    g = GraphBuilder(state_type=ExecutionState, output_type=list[int])

    @g.step
    async def level1(ctx: StepContext[ExecutionState, None, None]) -> list[int]:
        return [1, 2]

    @g.step
    async def level2(ctx: StepContext[ExecutionState, None, int]) -> list[int]:
        return [ctx.inputs * 10, ctx.inputs * 10 + 1]

    @g.step
    async def level3(ctx: StepContext[ExecutionState, None, int]) -> int:
        ctx.state.log.append(f'processing-{ctx.inputs}')
        return ctx.inputs

    collect = g.join(reduce_list_append, initial_factory=list[int])

    g.add(
        g.edge_from(g.start_node).to(level1),
        g.edge_from(level1).map().to(level2),
        g.edge_from(level2).map().to(level3),
        g.edge_from(level3).to(collect),
        g.edge_from(collect).to(g.end_node),
    )

    graph = g.build()
    state = ExecutionState()
    result = await graph.run(state=state)

    # Should process 4 items total (2 from level1 * 2 from each level2)
    assert len(result) == 4
    assert sorted(result) == [10, 11, 20, 21]
    assert len(state.log) == 4


async def test_broadcast_with_immediate_join():
    """Test broadcast that immediately joins."""
    g = GraphBuilder(state_type=ExecutionState, output_type=list[int])

    @g.step
    async def source(ctx: StepContext[ExecutionState, None, None]) -> int:
        return 10

    @g.step
    async def path_a(ctx: StepContext[ExecutionState, None, int]) -> int:
        return ctx.inputs * 2

    @g.step
    async def path_b(ctx: StepContext[ExecutionState, None, int]) -> int:
        return ctx.inputs * 3

    @g.step
    async def path_c(ctx: StepContext[ExecutionState, None, int]) -> int:
        return ctx.inputs * 4

    collect = g.join(reduce_list_append, initial_factory=list[int])

    g.add(
        g.edge_from(g.start_node).to(source),
        # Multiple .to() destinations creates a broadcast
        g.edge_from(source).to(path_a, path_b, path_c),
        g.edge_from(path_a, path_b, path_c).to(collect),
        g.edge_from(collect).to(g.end_node),
    )

    graph = g.build()
    result = await graph.run(state=ExecutionState())
    assert sorted(result) == [20, 30, 40]


async def test_implicit_broadcast_with_immediate_join():
    """Test broadcast that immediately joins by just manually adding multiple edges from a single node."""
    g = GraphBuilder(state_type=ExecutionState, output_type=list[int])

    @g.step
    async def source(ctx: StepContext[ExecutionState, None, None]) -> int:
        return 10

    @g.step
    async def path_a(ctx: StepContext[ExecutionState, None, int]) -> int:
        return ctx.inputs * 2

    @g.step
    async def path_b(ctx: StepContext[ExecutionState, None, int]) -> int:
        return ctx.inputs * 3

    @g.step
    async def path_c(ctx: StepContext[ExecutionState, None, int]) -> int:
        return ctx.inputs * 4

    collect = g.join(reduce_list_append, initial_factory=list[int])

    g.add(
        g.edge_from(g.start_node).to(source),
        # Multiple .to() destinations creates a broadcast
        g.edge_from(source).to(path_a),
        g.edge_from(source).to(path_b),
        g.edge_from(source).to(path_c),
        g.edge_from(path_a).to(collect),
        g.edge_from(path_b).to(collect),
        g.edge_from(path_c).to(collect),
        g.edge_from(collect).to(g.end_node),
    )

    graph = g.build()
    result = await graph.run(state=ExecutionState())
    assert sorted(result) == [20, 30, 40]


async def test_mixed_sequential_and_parallel_execution():
    """Test graph with both sequential and parallel sections."""
    g = GraphBuilder(state_type=ExecutionState, output_type=str)

    @g.step
    async def step1(ctx: StepContext[ExecutionState, None, None]) -> int:
        ctx.state.log.append('step1')
        return 5

    @g.step
    async def step2(ctx: StepContext[ExecutionState, None, int]) -> list[int]:
        ctx.state.log.append('step2')
        return [ctx.inputs * 10, ctx.inputs * 20]

    @g.step
    async def parallel_step(ctx: StepContext[ExecutionState, None, int]) -> int:
        ctx.state.log.append(f'parallel-{ctx.inputs}')
        return ctx.inputs + 1

    @g.step
    async def step3(ctx: StepContext[ExecutionState, None, list[int]]) -> str:
        ctx.state.log.append('step3')
        return f'Result: {sum(ctx.inputs)}'

    collect = g.join(reduce_list_append, initial_factory=list[int])

    g.add(
        g.edge_from(g.start_node).to(step1),
        g.edge_from(step1).to(step2),
        g.edge_from(step2).map().to(parallel_step),
        g.edge_from(parallel_step).to(collect),
        g.edge_from(collect).to(step3),
        g.edge_from(step3).to(g.end_node),
    )

    graph = g.build()
    state = ExecutionState()
    result = await graph.run(state=state)

    assert 'step1' in state.log
    assert 'step2' in state.log
    assert 'parallel-50' in state.log
    assert 'parallel-100' in state.log
    assert 'step3' in state.log
    assert result == 'Result: 152'  # (50+1) + (100+1) = 152


async def test_multiple_sequential_joins():
    g = GraphBuilder(output_type=list[int])

    @g.step
    async def source(ctx: StepContext[None, None, None]) -> int:
        return 10

    @g.step
    async def add_one(ctx: StepContext[None, None, int]) -> list[int]:
        return [ctx.inputs + 1]

    @g.step
    async def add_two(ctx: StepContext[None, None, int]) -> list[int]:
        return [ctx.inputs + 2]

    @g.step
    async def add_three(ctx: StepContext[None, None, int]) -> list[int]:
        return [ctx.inputs + 3]

    collect = g.join(reduce_list_extend, initial_factory=list[int], parent_fork_id='source_fork', node_id='collect')
    mediator = g.join(reduce_list_extend, initial_factory=list[int], node_id='mediator')

    # Broadcasting: send the value from source to all three steps
    g.add(
        g.edge_from(g.start_node).to(source),
        g.edge_from(source).to(add_one, add_two, add_three, fork_id='source_fork'),
        g.edge_from(add_one, add_two).to(mediator),
        g.edge_from(mediator).to(collect),
        g.edge_from(add_three).to(collect),
        g.edge_from(collect).to(g.end_node),
    )

    graph = g.build()
    result = await graph.run()
    assert sorted(result) == [11, 12, 13]


@pytest.mark.parametrize(
    'include_plain_producer, skip_fan_result, expected',
    [
        pytest.param(False, False, [[10, 20, 30]], id='fan-only'),
        pytest.param(True, False, [[-1], [10, 20, 30]], id='mixed-producers'),
        pytest.param(True, True, [[-1]], id='discarded-fan-tail'),
    ],
)
async def test_join_with_fanned_producer(
    include_plain_producer: bool, skip_fan_result: bool, expected: list[list[int]]
):
    """A join waits for the fanned producer's tail, unless the caller discards it."""
    g = GraphBuilder(input_type=str, output_type=list[list[int]])
    fan_started = Event()
    execution_order: list[str] = []

    @g.step
    async def root(ctx: StepContext[None, None, str]) -> str:
        return ctx.inputs

    @g.step
    async def fan_prepare(ctx: StepContext[None, None, str]) -> list[int]:
        fan_started.set()
        return [1, 2, 3]

    @g.step
    async def fan_unit(ctx: StepContext[None, None, int]) -> int:
        return ctx.inputs * 10

    fan_join = g.join(reduce_list_append, initial_factory=list[int], node_id='fan_join')

    @g.step
    async def fan_result(ctx: StepContext[None, None, list[int]]) -> list[int]:
        execution_order.append('fan_result')
        return sorted(ctx.inputs)

    merge = g.join(reduce_list_append, initial_factory=list[list[int]], node_id='merge')

    @g.step
    async def downstream(ctx: StepContext[None, None, list[list[int]]]) -> list[list[int]]:
        execution_order.append('downstream')
        return ctx.inputs

    g.add_edge(g.start_node, root)
    g.add_edge(root, fan_prepare)
    if include_plain_producer:

        @g.step
        async def plain_producer(ctx: StepContext[None, None, str]) -> list[int]:
            with fail_after(READINESS_WAIT_TIMEOUT):
                await fan_started.wait()
            return [-1]

        g.add_edge(root, plain_producer)
        g.add_edge(plain_producer, merge)

    g.add_mapping_edge(fan_prepare, fan_unit, fork_id=ForkID('fan_fork'), downstream_join_id=JoinID('fan_join'))
    g.add_edge(fan_unit, fan_join)
    g.add_edge(fan_join, fan_result)
    g.add_edge(fan_result, merge)
    g.add_edge(merge, downstream)
    g.add_edge(downstream, g.end_node)

    with fail_after(READINESS_WAIT_TIMEOUT):
        async with g.build().iter(inputs='go') as run:
            async for batch in run:
                if (
                    skip_fan_result
                    and not isinstance(batch, EndMarker)
                    and any(task.node_id == fan_result.id for task in batch)
                ):
                    run.override_next([])

    result = run.output
    assert result is not None
    assert sorted(result) == expected
    assert execution_order == (['downstream'] if skip_fan_result else ['fan_result', 'downstream'])


async def test_independent_joins_finalize_while_other_tails_are_running():
    """Independent join tails can synchronize without blocking each other's finalization."""
    g = GraphBuilder(output_type=list[int])
    left_received = Event()
    right_received = Event()
    left_started = Event()
    right_started = Event()

    @g.step
    async def root(ctx: StepContext[None, None, None]) -> int:
        return 0

    @g.step
    async def producer(ctx: StepContext[None, None, int]) -> int:
        return 1

    @g.step
    async def gate(ctx: StepContext[None, None, int]) -> int:
        await left_received.wait()
        await right_received.wait()
        return 999

    def collect_left(current: list[int], inputs: int) -> list[int]:
        left_received.set()
        return reduce_list_append(current, inputs)

    def collect_right(current: list[int], inputs: int) -> list[int]:
        right_received.set()
        return reduce_list_append(current, inputs)

    left = g.join(collect_left, initial_factory=list[int], node_id='left')
    right = g.join(collect_right, initial_factory=list[int], node_id='right')

    @g.step
    async def tail_left(ctx: StepContext[None, None, list[int]]) -> int:
        left_started.set()
        await right_started.wait()
        return 10

    @g.step
    async def tail_right(ctx: StepContext[None, None, list[int]]) -> int:
        right_started.set()
        await left_started.wait()
        return 20

    merge = g.join(reduce_list_append, initial_factory=list[int], node_id='merge')
    g.add_edge(g.start_node, root)
    g.add_edge(root, producer)
    g.add_edge(root, gate)
    for source in (producer, gate):
        g.add_edge(source, left)
        g.add_edge(source, right)
    g.add_edge(left, tail_left)
    g.add_edge(right, tail_right)
    g.add_edge(tail_left, merge)
    g.add_edge(tail_right, merge)
    g.add_edge(merge, g.end_node)

    gate_discarded = False
    with fail_after(READINESS_WAIT_TIMEOUT):
        async with g.build().iter() as run:
            async for batch in run:
                if not isinstance(batch, EndMarker) and any(task.inputs == 999 for task in batch):
                    # Leave both joins ready in the same fallback pass, with no active tasks.
                    run.override_next([])
                    gate_discarded = True

    assert gate_discarded
    result = run.output
    assert result is not None
    assert sorted(result) == [10, 20]


async def test_early_termination_from_nested_generator():
    """Test that a generator wrapping an iteration can be terminated early."""
    g = GraphBuilder()
    g.add_edge(g.start_node, g.end_node)
    graph = g.build()

    async def stream_graph():
        async with graph.iter() as run:
            async for node in run:  # pragma: no branch
                yield node

    gen = stream_graph()
    async for _ in gen:  # pragma: no branch
        break
    await gen.aclose()


async def test_tracked_task_send_after_sender_closed_is_swallowed():
    """A node task whose `send` lands after the run's stream sender is closed must not crash the run.

    When a run is cancelled before reaching its end node, teardown closes
    `iter_stream_sender` while node tasks may still be in flight. An in-flight
    `send` to a closed sender raises `anyio.ClosedResourceError` (a closed
    *receiver* would instead raise `BrokenResourceError`); both are benign during
    teardown and must be swallowed rather than escape into the task group.

    The real-world trigger is a teardown race that can't be reproduced reliably
    through the public API, so this drives `_run_tracked_task` directly: closing
    the sender up front guarantees the deterministic equivalent of the race (the
    task finishing its `send` against an already-closed sender). Regression test
    for #6146; without the fix this leaks `ClosedResourceError` out of the group.
    """
    g = GraphBuilder(output_type=int)

    ran = False

    @g.step
    async def produce(ctx: StepContext[None, None, None]) -> int:
        nonlocal ran
        ran = True
        return 42

    g.add(
        g.edge_from(g.start_node).to(produce),
        g.edge_from(produce).to(g.end_node),
    )
    graph = g.build()

    next_task_id_counter = 0

    def next_task_id() -> TaskID:
        nonlocal next_task_id_counter
        next_task_id_counter += 1
        return TaskID(f'task:{next_task_id_counter}')

    def next_node_run_id() -> NodeRunID:  # pragma: no cover
        # Not reached for a single leaf step, but required to construct the iterator.
        return NodeRunID('node-run:0')

    async with create_task_group() as task_group:
        iterator = _GraphIterator(graph, None, None, task_group, next_node_run_id, next_task_id)
        # Simulate run teardown closing the streams while a node task is still in flight.
        # `send_nowait` checks the sender's own closed flag before the receiver's, so the
        # in-flight `send` raises `ClosedResourceError` (not `BrokenResourceError`) here.
        iterator.iter_stream_sender.close()
        iterator.iter_stream_receiver.close()
        task = GraphTask(produce.id, None, (), next_task_id())
        task_group.start_soon(iterator._run_tracked_task, task)  # pyright: ignore[reportPrivateUsage]

    # Reaching here means the task group exited cleanly; the `ClosedResourceError`
    # from the closed-sender `send` was swallowed instead of propagating.
    assert ran, 'the node task should have run and attempted to send its result'


def test_run_sync():
    """`Graph.run_sync` mirrors `Graph.run` from synchronous code."""
    g = GraphBuilder(input_type=int, output_type=int)

    @g.step
    async def increment(ctx: StepContext[None, None, int]) -> int:
        return ctx.inputs + 1

    @g.step
    async def double(ctx: StepContext[None, None, int]) -> int:
        return ctx.inputs * 2

    g.add(
        g.edge_from(g.start_node).to(increment),
        g.edge_from(increment).to(double),
        g.edge_from(double).to(g.end_node),
    )

    graph = g.build()
    # First call infers the name from the calling frame.
    assert graph.run_sync(inputs=3) == 8
    assert graph.name == 'graph'
    # Second call skips name inference because the name is already set.
    assert graph.run_sync(inputs=4) == 10
    assert graph.name == 'graph'


async def test_genuine_cancellation_preserves_cancelled_error():
    """Test that genuine cancellation with an in-flight stream node still surfaces CancelledError."""
    g = GraphBuilder(output_type=int)
    entered = anyio.Event()

    @g.stream()
    async def stream_never(ctx: StepContext[None, None, None]) -> AsyncIterator[int]:
        entered.set()
        await anyio.sleep_forever()
        yield 0  # pragma: no cover

    g.add(
        g.edge_from(g.start_node).to(stream_never),
        # A stream node needs an outgoing edge for the graph runtime to wire up its
        # iterable; the generator below never yields, so no items ever flow through
        # this edge.
        g.edge_from(stream_never).map().to(g.end_node),
    )
    graph = g.build()

    async with create_task_group() as outer:

        async def run_graph():
            with pytest.raises(anyio.get_cancelled_exc_class()):
                async with graph.iter() as run:
                    async for _event in run:
                        pass

        outer.start_soon(run_graph)
        await entered.wait()
        outer.cancel_scope.cancel()


@pytest.mark.parametrize('close_sender', [False, True], ids=['closed-receiver', 'closed-sender'])
async def test_stream_error_during_teardown_is_swallowed(close_sender: bool):
    """Drive the task directly to deterministically reproduce the stream-closing teardown race."""
    entered = False

    async def failing_stream() -> AsyncIterator[int]:
        nonlocal entered
        entered = True
        raise ValueError('stream failed during teardown')
        yield 0  # pragma: no cover

    g = GraphBuilder(input_type=AsyncIterator[int], output_type=int)
    g.add(g.edge_from(g.start_node).map().to(g.end_node))
    graph = g.build()
    fork = next(node for node in graph.nodes.values() if isinstance(node, Fork))

    async with create_task_group() as task_group:
        iterator = _GraphIterator(graph, None, None, task_group, lambda: NodeRunID('run:1'), lambda: TaskID('task:1'))
        with iterator.iter_stream_sender:
            if close_sender:
                iterator.iter_stream_sender.close()
            iterator.iter_stream_receiver.close()
            task = GraphTask(fork.id, failing_stream(), (), TaskID('task:1'))
            await iterator._run_tracked_task(task)  # pyright: ignore[reportPrivateUsage]

    assert entered
