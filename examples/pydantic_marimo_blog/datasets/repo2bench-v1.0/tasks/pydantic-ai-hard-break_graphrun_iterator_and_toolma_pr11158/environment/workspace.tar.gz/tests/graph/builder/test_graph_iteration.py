"""Tests for iterative graph execution and inspection."""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import pytest

from pydantic_graph import GraphBuilder, StepContext
from pydantic_graph.graph_builder import EndMarker, GraphTask, GraphTaskRequest
from pydantic_graph.id_types import NodeID
from pydantic_graph.join import reduce_list_append


@dataclass
class IterState:
    counter: int = 0


async def test_iter_basic():
    """Test basic iteration over graph execution."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.step
    async def increment(ctx: StepContext[IterState, None, None]) -> int:
        ctx.state.counter += 1
        return ctx.state.counter

    @g.step
    async def double(ctx: StepContext[IterState, None, int]) -> int:
        return ctx.inputs * 2

    g.add(
        g.edge_from(g.start_node).to(increment),
        g.edge_from(increment).to(double),
        g.edge_from(double).to(g.end_node),
    )

    graph = g.build()
    state = IterState()

    events: list[Any] = []
    async with graph.iter(state=state) as run:
        async for event in run:
            events.append(event)

    assert len(events) > 0
    last_event = events[-1]
    assert isinstance(last_event, EndMarker)
    assert last_event.value == 2  # pyright: ignore[reportUnknownMemberType]


async def test_iter_with_next():
    """Test manual iteration using next() method."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.step
    async def step_one(ctx: StepContext[IterState, None, None]) -> int:
        return 10

    @g.step
    async def step_two(ctx: StepContext[IterState, None, int]) -> int:
        return ctx.inputs + 5

    g.add(
        g.edge_from(g.start_node).to(step_one),
        g.edge_from(step_one).to(step_two),
        g.edge_from(step_two).to(g.end_node),
    )

    graph = g.build()
    state = IterState()

    async with graph.iter(state=state) as run:
        # Manually advance through each step
        event1 = await run.next()
        assert isinstance(event1, list)

        event2 = await run.next()
        assert isinstance(event2, list)

        event3 = await run.next()
        assert isinstance(event3, EndMarker)
        assert event3.value == 15


async def test_iter_inspect_tasks():
    """Test inspecting GraphTask objects during iteration."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.step
    async def my_step(ctx: StepContext[IterState, None, None]) -> int:
        return 42

    g.add(
        g.edge_from(g.start_node).to(my_step),
        g.edge_from(my_step).to(g.end_node),
    )

    graph = g.build()
    state = IterState()

    task_nodes: list[NodeID] = []
    async with graph.iter(state=state) as run:
        async for event in run:
            if isinstance(event, list):
                for task in event:
                    assert isinstance(task, GraphTask)
                    task_nodes.append(task.node_id)

    assert 'my_step' in [str(n) for n in task_nodes]


async def test_iter_output_property():
    """Test accessing the output property during and after iteration."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.step
    async def compute(ctx: StepContext[IterState, None, None]) -> int:
        return 100

    g.add(
        g.edge_from(g.start_node).to(compute),
        g.edge_from(compute).to(g.end_node),
    )

    graph = g.build()
    state = IterState()

    async with graph.iter(state=state) as run:
        # Output should be None before completion
        assert run.output is None

        async for event in run:
            if isinstance(event, EndMarker):
                # Output should be available once we have an EndMarker
                # (though we're still in the loop)
                pass

        # After iteration completes, output should be available
        assert run.output == 100


async def test_iter_next_task_property():
    """Test accessing the next_task property."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.step
    async def my_step(ctx: StepContext[IterState, None, None]) -> int:
        return 42

    g.add(
        g.edge_from(g.start_node).to(my_step),
        g.edge_from(my_step).to(g.end_node),
    )

    graph = g.build()
    state = IterState()

    async with graph.iter(state=state) as run:
        # Before starting, next_task should be the initial task
        initial_task = run.next_task
        assert isinstance(initial_task, list)

        # Advance one step
        await run.next()

        # next_task should update
        next_task = run.next_task
        assert next_task is not None


async def test_iter_with_map():
    """Test iteration with map operations."""
    g = GraphBuilder(state_type=IterState, output_type=list[int])

    @g.step
    async def generate(ctx: StepContext[IterState, None, None]) -> list[int]:
        return [1, 2, 3]

    @g.step
    async def square(ctx: StepContext[IterState, None, int]) -> int:
        return ctx.inputs * ctx.inputs

    collect = g.join(reduce_list_append, initial_factory=list[int])

    g.add(
        g.edge_from(g.start_node).to(generate),
        g.edge_from(generate).map().to(square),
        g.edge_from(square).to(collect),
        g.edge_from(collect).to(g.end_node),
    )

    graph = g.build()
    state = IterState()

    task_count = 0
    async with graph.iter(state=state) as run:
        async for event in run:
            if isinstance(event, list):
                task_count += len(event)

    # Should see multiple tasks from the map
    assert task_count >= 3


async def test_iter_early_termination():
    """Test that iteration can be terminated early."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.step
    async def step_one(ctx: StepContext[IterState, None, None]) -> int:
        ctx.state.counter += 1
        return 10

    @g.step
    async def step_two(ctx: StepContext[IterState, None, int]) -> int:  # pragma: no cover
        ctx.state.counter += 1
        return ctx.inputs + 5

    @g.step
    async def step_three(ctx: StepContext[IterState, None, int]) -> int:  # pragma: no cover
        ctx.state.counter += 1
        return ctx.inputs * 2

    g.add(
        g.edge_from(g.start_node).to(step_one),
        g.edge_from(step_one).to(step_two),
        g.edge_from(step_two).to(step_three),
        g.edge_from(step_three).to(g.end_node),
    )

    graph = g.build()
    state = IterState()

    async with graph.iter(state=state) as run:
        event_count = 0
        async for _ in run:  # pragma: no branch
            event_count += 1
            if event_count >= 2:
                break  # Early termination

    # State changes should have happened only for completed steps
    # The exact counter value depends on how many steps completed before break
    assert state.counter < 3  # Not all steps completed


async def test_iter_state_inspection():
    """Test inspecting state changes during iteration."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.step
    async def increment(ctx: StepContext[IterState, None, None]) -> None:
        ctx.state.counter += 1

    @g.step
    async def double_counter(ctx: StepContext[IterState, None, None]) -> int:
        ctx.state.counter *= 2
        return ctx.state.counter

    g.add(
        g.edge_from(g.start_node).to(increment),
        g.edge_from(increment).to(double_counter),
        g.edge_from(double_counter).to(g.end_node),
    )

    graph = g.build()
    state = IterState()

    state_snapshots: list[Any] = []
    async with graph.iter(state=state) as run:
        async for _ in run:
            # Take a snapshot of the state after each event
            state_snapshots.append(state.counter)

    # State should have evolved during execution
    assert state_snapshots[-1] == 2  # (0 + 1) * 2


async def test_iter_with_async_iterable_map():
    """Test iteration with map using an async iterable."""

    g = GraphBuilder(state_type=IterState, output_type=list[int])

    @g.stream()
    async def generate_async(ctx: StepContext[IterState, None, None]) -> AsyncIterator[int]:
        for i in [1, 2, 3, 4]:
            yield i

    @g.step
    async def process(ctx: StepContext[IterState, None, int]) -> int:
        ctx.state.counter += 1
        return ctx.inputs * 10

    collect = g.join(reduce_list_append, initial_factory=list[int])

    g.add(
        g.edge_from(g.start_node).to(generate_async),
        g.edge_from(generate_async).map().to(process),
        g.edge_from(process).to(collect),
        g.edge_from(collect).to(g.end_node),
    )

    graph = g.build()
    state = IterState()

    events: list[Any] = []
    async with graph.iter(state=state) as run:
        async for event in run:
            events.append(event)

    assert isinstance(events[-1], EndMarker)
    result = events[-1].value  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
    assert sorted(result) == [10, 20, 30, 40]  # pyright: ignore[reportUnknownArgumentType]
    assert state.counter == 4


async def test_iter_filter_tasks_during_iteration():
    """Test removing tasks from the list during iteration (e.g., filter items > 3)."""
    g = GraphBuilder(state_type=IterState, output_type=list[int])

    @g.step
    async def generate(ctx: StepContext[IterState, None, None]) -> list[int]:
        return [1, 2, 3, 4, 5]

    @g.step
    async def process(ctx: StepContext[IterState, None, int]) -> int:
        ctx.state.counter += 1
        return ctx.inputs * 10

    collect = g.join(reduce_list_append, initial_factory=list[int])

    g.add(
        g.edge_from(g.start_node).to(generate),
        g.edge_from(generate).map().to(process),
        g.edge_from(process).to(collect),
        g.edge_from(collect).to(g.end_node),
    )

    graph = g.build()
    state = IterState()

    async with graph.iter(state=state) as run:
        while True:
            event = await run.next()
            if isinstance(event, list):
                # Filter out tasks where the node is 'process' and input is > 3
                filtered_tasks = [
                    task
                    for task in event
                    if not (task.node_id == NodeID('process') and isinstance(task.inputs, int) and task.inputs > 3)
                ]
                if filtered_tasks != event:
                    # Override with filtered tasks
                    event = await run.next(filtered_tasks)
            if isinstance(event, EndMarker):
                break

    # Only items <= 3 should have been processed
    result = run.output
    assert result is not None
    assert sorted(result) == [10, 20, 30]
    assert state.counter == 3


async def test_iter_turn_end_marker_into_tasks():
    """Test overriding an EndMarker to continue with more tasks."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.step
    async def first_step(ctx: StepContext[IterState, None, None]) -> int:
        ctx.state.counter += 1
        return 10

    @g.step
    async def second_step(ctx: StepContext[IterState, None, int]) -> int:
        ctx.state.counter += 1
        return ctx.inputs * 2

    g.add(
        g.edge_from(g.start_node).to(first_step),
        g.edge_from(first_step).to(g.end_node),
        # We add second_step to the graph with a transition to the end; we'll manually create tasks for it below
        g.edge_from(second_step).to(g.end_node),
    )

    graph = g.build(validate_graph_structure=False)
    state = IterState()

    override_done = False
    async with graph.iter(state=state) as run:
        while True:
            event = await run.next()
            if isinstance(event, EndMarker) and not override_done:
                # Instead of ending, create a new task
                # Get the fork_stack from the EndMarker's source
                fork_stack = run.next_task[0].fork_stack if isinstance(run.next_task, list) else ()

                new_task = GraphTaskRequest(
                    node_id=NodeID('second_step'),
                    inputs=event.value,
                    fork_stack=fork_stack,
                )

                override_done = True
                event = await run.next([new_task])
            if isinstance(event, EndMarker) and override_done:
                break

    result = run.output
    assert result == 20  # 10 * 2
    assert state.counter == 2


async def test_iter_turn_tasks_into_end_marker():
    """Test overriding a sequence of tasks with an EndMarker to terminate early."""
    g = GraphBuilder(state_type=IterState, output_type=str)

    @g.step
    async def step1(ctx: StepContext[IterState, None, None]) -> int:
        ctx.state.counter += 1
        return 10

    @g.step
    async def step2(ctx: StepContext[IterState, None, int]) -> int:  # pragma: no cover
        ctx.state.counter += 1
        return ctx.inputs * 2

    @g.step
    async def step3(ctx: StepContext[IterState, None, int]) -> str:  # pragma: no cover
        ctx.state.counter += 1
        return f'result: {ctx.inputs}'

    g.add(
        g.edge_from(g.start_node).to(step1),
        g.edge_from(step1).to(step2),
        g.edge_from(step2).to(step3),
        g.edge_from(step3).to(g.end_node),
    )

    graph = g.build()
    state = IterState()

    early_exit_done = False
    async with graph.iter(state=state) as run:
        while True:
            try:
                event = await run.next()
                assert isinstance(event, list)
                assert not early_exit_done
                # Check if we're about to execute step2
                assert any(task.node_id == NodeID('step2') for task in event)
                # Override with an EndMarker to terminate early
                early_exit_done = True
                await run.next(EndMarker('early_exit'))
            except StopAsyncIteration:
                break

    result = run.output
    assert result == 'early_exit'
    # Only step1 should have run
    assert state.counter == 1


async def test_iter_error_recovery_with_override_next():
    """Test that a node error can be recovered from using override_next."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    call_count = 0

    @g.step
    async def flaky_step(ctx: StepContext[IterState, None, None]) -> int:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise ValueError('first call fails')
        ctx.state.counter = 42
        return ctx.state.counter

    g.add_edge(g.start_node, flaky_step)
    g.add_edge(flaky_step, g.end_node)

    graph = g.build()
    state = IterState()

    async with graph.iter(state=state) as run:
        while True:
            try:
                event = await run.next()
            except ValueError:
                # Recover by re-running the same node
                retry_task = GraphTaskRequest(
                    node_id=NodeID('flaky_step'),
                    inputs=None,
                    fork_stack=(),
                )
                run.override_next([retry_task])
                continue
            except StopAsyncIteration:  # pragma: no cover
                break
            if isinstance(event, EndMarker):
                break

    assert run.output == 42
    assert call_count == 2


async def test_iter_error_recovery_with_different_node():
    """Test that error recovery can redirect to a different node."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.step
    async def failing_step(ctx: StepContext[IterState, None, None]) -> int:
        raise RuntimeError('always fails')

    @g.step
    async def fallback_step(ctx: StepContext[IterState, None, None]) -> int:
        ctx.state.counter = 99
        return ctx.state.counter

    g.add_edge(g.start_node, failing_step)
    g.add_edge(failing_step, g.end_node)
    g.add_edge(fallback_step, g.end_node)

    graph = g.build(validate_graph_structure=False)
    state = IterState()

    async with graph.iter(state=state) as run:
        while True:
            try:
                event = await run.next()
            except RuntimeError:
                # Redirect to fallback
                fallback_task = GraphTaskRequest(
                    node_id=NodeID('fallback_step'),
                    inputs=None,
                    fork_stack=(),
                )
                run.override_next([fallback_task])
                continue
            except StopAsyncIteration:  # pragma: no cover
                break
            if isinstance(event, EndMarker):
                break

    assert run.output == 99
    assert state.counter == 99


async def test_iter_error_without_recovery_still_raises():
    """Test that errors still raise when not recovered."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.step
    async def bad_step(ctx: StepContext[IterState, None, None]) -> int:
        raise ValueError('intentional error')

    g.add_edge(g.start_node, bad_step)
    g.add_edge(bad_step, g.end_node)

    graph = g.build()
    state = IterState()

    with pytest.raises(ValueError, match='intentional error'):
        async with graph.iter(state=state) as run:
            while True:
                event = await run.next()
                if isinstance(event, EndMarker):  # pragma: no cover
                    break


async def test_iter_error_caught_without_override_re_raises_on_continue():
    """When an error is caught but override_next is NOT called, the next iteration re-raises."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.step
    async def bad_step(ctx: StepContext[IterState, None, None]) -> int:
        raise ValueError('intentional error')

    g.add_edge(g.start_node, bad_step)
    g.add_edge(bad_step, g.end_node)

    graph = g.build()
    state = IterState()

    async with graph.iter(state=state) as run:
        # First call raises the error from the node
        with pytest.raises(ValueError, match='intentional error'):
            await run.next()

        # Second call without override_next echoes the ErrorMarker back,
        # causing the generator to re-raise the original error
        with pytest.raises(ValueError, match='intentional error'):
            await run.next()


@pytest.mark.parametrize('yield_first', [False, True], ids=['before-first-yield', 'after-first-yield'])
@pytest.mark.parametrize('use_next', [False, True], ids=['async-for', 'next'])
async def test_stream_node_error_surfaces_in_context(yield_first: bool, use_next: bool):
    """Stream errors reach the caller inside the graph context, before or after yielding."""
    g = GraphBuilder(output_type=list[int])
    error = RuntimeError('stream node failed')

    @g.stream()
    async def stream_fail(ctx: StepContext[None, None, None]) -> AsyncIterator[int]:
        if yield_first:
            yield 1
        raise error

    collect = g.join(reduce_list_append, initial_factory=list[int])
    g.add(
        g.edge_from(g.start_node).to(stream_fail),
        g.edge_from(stream_fail).map().to(collect),
        g.edge_from(collect).to(g.end_node),
    )
    graph = g.build()

    async with graph.iter() as run:
        with pytest.raises(RuntimeError, match='stream node failed') as exc_info:
            if use_next:
                while True:
                    await run.next()
            else:
                async for _event in run:
                    pass
        assert exc_info.value is error


async def test_stream_node_error_recoverable_via_override_next():
    """Test that a stream-node error surfaced via `run.next()` can be recovered mid-run via `override_next`."""
    g = GraphBuilder(state_type=IterState, output_type=int)

    @g.stream()
    async def stream_fail(ctx: StepContext[IterState, None, None]) -> AsyncIterator[int]:
        raise RuntimeError('stream node failed mid-stream')
        yield 0  # pragma: no cover

    @g.step
    async def fallback_step(ctx: StepContext[IterState, None, int]) -> int:
        ctx.state.counter = 99
        return ctx.state.counter

    g.add(
        g.edge_from(g.start_node).to(stream_fail),
        # A stream node needs an outgoing edge for the graph runtime to wire up its
        # iterable; the generator below raises before yielding anything, so no items
        # ever flow through this edge.
        g.edge_from(stream_fail).map().to(fallback_step),
        g.edge_from(fallback_step).to(g.end_node),
    )
    graph = g.build()
    state = IterState()

    async with graph.iter(state=state) as run:
        while True:
            try:
                event = await run.next()
            except RuntimeError:
                # Recover from the stream-node failure by redirecting to the fallback node.
                fallback_task = GraphTaskRequest(node_id=NodeID('fallback_step'), inputs=0, fork_stack=())
                run.override_next([fallback_task])
                continue
            if isinstance(event, EndMarker):
                break

    assert run.output == 99
    assert state.counter == 99
