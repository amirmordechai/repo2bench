# Copyright 2026 Marimo. All rights reserved.
from __future__ import annotations

import contextlib
import io


def convert_rst_to_html(rst_content: str) -> str:
    """Convert RST content to HTML."""

    from docutils.core import publish_parts
    from docutils.writers.html4css1 import Writer

    # redirect stderr and ignore it to silence error messages
    with contextlib.redirect_stderr(io.StringIO()) as _:
        parts = publish_parts(
            rst_content,
            writer=Writer(),
            settings_overrides={
                "warning_stream": None,
                "file_insertion_enabled": False,
                "report_level": 5,
            },
        )
    return parts["html_body"]  # type: ignore[no-any-return]
