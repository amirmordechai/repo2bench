# Copyright 2026 Marimo. All rights reserved.
from __future__ import annotations

import os


def is_env_true(key: str, default: bool = False) -> bool:
    """Return True if the env var `key` is set to a truthy value ("true"/"1").

    Comparison is case-insensitive and ignores surrounding whitespace. Returns
    `default` when the variable is unset.
    """
    value = os.environ.get(key)
    if value is None:
        return default
    return value.strip().lower() in ("true", "1")


def env_to_value(key: str) -> tuple[str | list[str] | bool | None] | None:
    """Return a typed value from environment variables."""
    if key in os.environ:
        value = os.environ[key]
        if value.lower() in ("true", "false"):
            return (value.lower() == "true",)
        elif value.startswith("[") and value.endswith("]"):
            return (os.environ[key][1:-1].split(","),)
        elif value.lower() == "none":
            return None
        return (os.environ[key],)
    return None
