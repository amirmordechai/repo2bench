# Copyright 2026 Marimo. All rights reserved.
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from marimo import _loggers

if TYPE_CHECKING:
    import duckdb
    import narwhals.stable.v2 as nw
    import pandas as pd
    import pyarrow as pa

LOGGER = _loggers.marimo_logger()

GeometryEncoding = Literal["objects", "wkb", "wkt", "other"]

GEOMETRY_CELL_CAP = 512


@dataclass(frozen=True)
class GeometryColumnInfo:
    """How a detected geometry column stores its values.

    Args:
        encoding (GeometryEncoding): The value encoding. The value is
            `objects` for shapely scalars, `wkb` for WKB bytes, `wkt` for WKT
            strings, or `other` for typing-only detection.
        external_type (str): The native type string that users see.
    """

    encoding: GeometryEncoding
    external_type: str


def find_geometry_columns(
    frame: nw.DataFrame[Any] | nw.LazyFrame[Any],
) -> dict[str, GeometryColumnInfo]:
    """Detect geometry columns from the declared schema of a frame.

    This function returns an empty map if detection fails. A detection error
    must not prevent an ordinary table from loading.
    """
    try:
        if frame.implementation.is_pandas():
            return _pandas_geometry_columns(frame.to_native())
        if frame.implementation.is_pyarrow():
            return _pyarrow_geometry_columns(frame.to_native())
        if frame.implementation.is_duckdb():
            return _duckdb_geometry_columns(frame.to_native())
    except Exception as e:
        LOGGER.debug("Geometry detection failed: %s", e)
    return {}


def _pandas_geometry_columns(
    native: pd.DataFrame,
) -> dict[str, GeometryColumnInfo]:
    infos: dict[str, GeometryColumnInfo] = {}
    for name, dtype in native.dtypes.items():
        if str(dtype) == "geometry":
            infos[str(name)] = GeometryColumnInfo(
                encoding="objects", external_type="geometry"
            )
    return infos


# GeoArrow stores its type name in each field's ARROW:extension:name metadata.
_WKB_EXTENSION_NAMES = ("geoarrow.wkb", "ogc.wkb")
_WKT_EXTENSION_NAME = "geoarrow.wkt"
_GEOARROW_PREFIX = "geoarrow."
# DuckDB spatial type names used for schema-only geometry detection.
_DUCKDB_WKB_TYPE = "GEOMETRY"
_DUCKDB_2D_TYPES = frozenset(
    {"POINT_2D", "LINESTRING_2D", "POLYGON_2D", "BOX_2D"}
)


def arrow_storage_field(field: pa.Field[Any]) -> pa.Field[Any]:
    """Describe a registered geometry extension field as storage plus metadata.

    A registered extension type carries its name and declaration in the field
    type. An unregistered one carries them in the field metadata. Geometry
    fields of both kinds become a storage-typed field with the declaration in
    `ARROW:extension:name` and `ARROW:extension:metadata`. Other fields are
    returned unchanged.

    Args:
        field (pa.Field[Any]): A field from an Arrow schema.
    """
    import pyarrow as pa

    if not isinstance(field.type, pa.ExtensionType):
        return field
    extension = field.type
    if not (
        extension.extension_name.startswith(_GEOARROW_PREFIX)
        or extension.extension_name in _WKB_EXTENSION_NAMES
    ):
        return field
    metadata: dict[bytes | str, bytes | str] = {
        key: value for key, value in (field.metadata or {}).items()
    }
    metadata[b"ARROW:extension:name"] = extension.extension_name.encode()
    serialized = extension.__arrow_ext_serialize__()
    if extension.extension_name == "ogc.wkb" and not serialized:
        metadata.pop(b"ARROW:extension:metadata", None)
    else:
        metadata[b"ARROW:extension:metadata"] = serialized
    return field.with_type(extension.storage_type).with_metadata(metadata)


def _pyarrow_geometry_columns(
    native: pa.Table,
) -> dict[str, GeometryColumnInfo]:
    """Detect geometry columns from pyarrow schema declarations only."""
    infos: dict[str, GeometryColumnInfo] = {}
    for field in native.schema:
        field = arrow_storage_field(field)
        metadata = field.metadata
        if not metadata:
            continue
        raw_name = metadata.get(b"ARROW:extension:name")
        if raw_name is None:
            continue
        extension_name = raw_name.decode()
        encoding: GeometryEncoding
        if extension_name in _WKB_EXTENSION_NAMES:
            encoding = "wkb"
        elif extension_name == _WKT_EXTENSION_NAME:
            encoding = "wkt"
        elif extension_name.startswith(_GEOARROW_PREFIX):
            # Other geoarrow.* types (e.g. point) are geometry for typing only.
            encoding = "other"
        else:
            # Non-geo Arrow extensions (e.g. arrow.uuid) stay ordinary columns.
            continue
        infos[field.name] = GeometryColumnInfo(
            encoding=encoding, external_type=extension_name
        )
    return infos


def _duckdb_geometry_columns(
    native: duckdb.DuckDBPyRelation,
) -> dict[str, GeometryColumnInfo]:
    """Detect geometry columns from declared relation types."""
    infos: dict[str, GeometryColumnInfo] = {}
    for name, dtype in zip(native.columns, native.types, strict=False):
        type_name = str(dtype)
        if type_name == _DUCKDB_WKB_TYPE or type_name.startswith("GEOMETRY("):
            infos[name] = GeometryColumnInfo(
                encoding="wkb", external_type=type_name
            )
        elif type_name in _DUCKDB_2D_TYPES:
            infos[name] = GeometryColumnInfo(
                encoding="other", external_type=type_name
            )
    return infos


def format_geometry_cell(value: Any, encoding: GeometryEncoding) -> Any:
    """Render one geometry cell for the table payload.

    WKB bytes become a size placeholder. Object and WKT values become text
    with a maximum length of `GEOMETRY_CELL_CAP` characters. Other values pass
    through unchanged.
    """
    if value is None:
        return value
    if encoding == "wkb":
        if isinstance(value, (bytes, bytearray)):
            return f"<geometry, {len(value)} B>"
        return value
    if encoding in ("objects", "wkt"):
        text = str(value)
        if len(text) > GEOMETRY_CELL_CAP:
            return text[:GEOMETRY_CELL_CAP] + "..."
        return text
    return value
