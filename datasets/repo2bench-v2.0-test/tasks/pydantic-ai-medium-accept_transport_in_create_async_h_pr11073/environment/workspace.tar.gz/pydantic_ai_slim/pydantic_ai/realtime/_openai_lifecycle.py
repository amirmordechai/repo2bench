"""The OpenAI Realtime protocol's lifecycle events: which response, user turn, and input each frame is about.

`OpenAIRealtimeConnection` feeds this tracker the frames it reads and the inputs it sends, and yields the
[lifecycle events](./_lifecycle.py) it produces alongside the codec events. The protocol identifies almost
everything itself: responses have ids from `response.created` to `response.done`, spoken turns have item
ids from `input_audio_buffer.speech_started` to `.committed`, every item joins the conversation with a
`conversation.item.added`, and a `response.create`'s `metadata` comes back on the response it started.
What it doesn't identify, the tracker works out from the connection's own bookkeeping and says so
(`ResponseStarted.basis='inferred'`).

Shared by the Azure OpenAI and xAI dialects, which inherit the connection.
"""

from __future__ import annotations as _annotations

from collections import deque
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

from openai.types.realtime import (
    InputAudioBufferCommittedEvent,
    InputAudioBufferSpeechStartedEvent,
    InputAudioBufferSpeechStoppedEvent,
    InputAudioBufferTimeoutTriggered,
    RealtimeErrorEvent,
)

from .._utils import is_str_dict
from ..messages import FinishReason
from ._lifecycle import (
    AnswersBasis,
    InputAdded,
    InputId,
    InputLost,
    LifecycleEvent,
    OutputItemDetails,
    ResponseEnded,
    ResponseRequestRefused,
    ResponseStarted,
    ResponseStatus,
    UserTurnClosed,
    UserTurnEnded,
    UserTurnStarted,
)
from ._openai_protocol import (
    ACTIVE_RESPONSE_ERROR_CODE,
    CONVERSATION_ITEM_ADDED_EVENT_ADAPTER,
    CONVERSATION_ITEM_ADDED_EVENTS,
    ProtocolResponse,
    client_item_input,
    is_user_message_item,
    rejected_inputs,
    response_metadata_answers,
)

_TRANSCRIPTION_SETTLED_FRAMES = frozenset(
    {'conversation.item.input_audio_transcription.completed', 'conversation.item.input_audio_transcription.failed'}
)


def _is_final_transcription(data: dict[str, Any]) -> bool:
    """Whether a transcription frame settles its item, as in `_map_input_transcription_event`: xAI and Azure send interim `completed` snapshots too."""
    status = data.get('status')
    return status is None or status == 'completed'


def _output_item_details(data: dict[str, Any]) -> list[LifecycleEvent]:
    """The `phase` of an assistant message a response adds (`commentary` or `final_answer`), for its part."""
    item, response_id = data.get('item'), data.get('response_id')
    if not is_str_dict(item) or not isinstance(response_id, str) or not response_id:
        return []
    item_id, phase = item.get('id'), item.get('phase')
    if not isinstance(item_id, str) or not item_id or not isinstance(phase, str) or not phase:
        return []
    return [OutputItemDetails(response_id=response_id, item_id=item_id, provider_details={'phase': phase})]


def frame_response_id(event_type: str | None, data: dict[str, Any]) -> str | None:
    """The id of the response a server frame is about, if it is about one."""
    if event_type in ('response.created', 'response.done'):
        response = data.get('response')
        response_id = response.get('id') if is_str_dict(response) else None
    elif isinstance(event_type, str) and event_type.startswith('response.'):
        response_id = data.get('response_id')
    else:
        return None
    return response_id if isinstance(response_id, str) and response_id else None


@dataclass(eq=False)
class AudioCommit:
    """An audio commit of ours the provider hasn't acknowledged yet (`input_audio_buffer.committed`)."""

    sent_before: list[InputId]
    """The inputs we sent ahead of it that weren't acknowledged either: the provider handles frames in order, so they
    join the conversation before the turn the commit makes."""
    has_audio: bool
    """Whether audio went out since the buffer was last committed or cleared: a commit of nothing makes no turn."""
    event_id: str | None = None
    """The `event_id` it went out under: the `error` refusing it echoes it."""


class OpenAILifecycle:
    """Turns an OpenAI-protocol connection's frames and sends into lifecycle events."""

    def __init__(
        self,
        *,
        transcribes: bool = True,
        server_vad: bool = False,
        commits_need_speech: bool = False,
        acknowledges_commits: bool = True,
    ) -> None:
        self._transcribes = transcribes
        self._server_vad = server_vad
        """Whether server VAD commits the speech it hears on its own. Its commit always comes right after the
        `speech_stopped` for its item, which a commit of ours never has (checked live on OpenAI and Azure), so
        that is how the two acknowledgements are told apart."""
        self._commits_need_speech = commits_need_speech or server_vad
        """Whether a commit makes a turn only of speech the provider heard start (under server VAD, OpenAI and Azure
        refuse a commit of anything else as empty; xAI ignores a commit of silence): one not acknowledged makes
        none then, unless a turn is under way."""
        self._acknowledges_commits = acknowledges_commits
        """Whether the provider acknowledges or refuses each commit of ours: xAI under server VAD ignores them
        (no acknowledgement, no error; checked live), so they aren't waited for."""
        self._leading: list[LifecycleEvent] = []
        """Events that precede the codec events of the frame being decoded: a response it starts."""
        self._pending: list[LifecycleEvent] = []
        """Events that follow them, or come outside any frame (a reconnect, a close)."""
        self._open: dict[str, None] = {}
        """Responses started and not yet ended, in start order."""
        self._ended: set[str] = set()
        self._synthetic_responses = 0
        self._current_synthetic: str | None = None
        """The id made up for a response the provider gave none, until its terminal."""
        self._metadata_echoed = False
        """Whether the server has echoed a `response.create`'s metadata: from then on, a response without
        ours in its metadata answers nothing of ours, whatever the connection had outstanding."""
        self._requests: dict[str, tuple[tuple[InputId, ...], bool]] = {}
        """Our `response.create`s neither started nor refused yet, by `event_id`: the inputs each answers, and
        whether it carried them as `metadata` (it can't when there are too many to fit)."""
        self._settled: set[InputId] = set()
        """Inputs already answered, refused, or lost. An inferred answer can be wrong (before the server has
        echoed any metadata, a response it started on its own looks like ours), and the response that really
        answers the input then settles nothing a second time."""
        self._speaking: dict[str, None] = {}
        """Spoken turns started and not yet committed or discarded."""
        self._unclaimed_turn: str | None = None
        """The latest committed spoken turn no response of the provider's own has answered yet."""
        self._ids_echoed = False
        """Whether the server has added an item under the id we chose for it: from then on, an item with any
        other id is none of ours, and the order items are added in no longer has to say which input they are."""
        self._messages: deque[InputId | None] = deque()
        """Our user message items awaiting their `conversation.item.added`, in the order they were sent.
        `None` is one that is no input of its own: seeded or replayed history, or a tool result's follow-up."""
        self._tool_outputs: dict[str, InputId] = {}
        """Our tool outputs awaiting their `conversation.item.added`, by call id."""
        self._carried_over: set[InputId] = set()
        """Inputs an old socket never acknowledged, which join the conversation once a reconnect succeeds."""
        self._items_acknowledged = False
        """Whether the server reports the items it adds (`conversation.item.added`), as every recorded one does."""
        self._idle_items: set[str] = set()
        """Audio items the server committed for an idle timeout: a nudge to the model, not a user turn."""
        self._untranscribed: set[str] = set()
        """Spoken turns that joined the conversation and are waiting for their transcript."""
        self._committed: set[str] = set()
        """Spoken turns already committed, so a repeated commit doesn't make a second turn of one, or cleared."""
        self._vad_stopped: set[str] = set()
        """Spoken turns server VAD reported stopped and hasn't acknowledged committing yet: its own commits."""
        self._commits: deque[AudioCommit] = deque()
        """Our audio commits not acknowledged yet, in the order they went out."""
        self._audio_uncommitted = False
        """Whether audio went out since the buffer was last committed or cleared."""
        self._unacknowledged_turns = 0
        """How many turns commits never acknowledged made, to name them: the provider named none."""

    # --- what the connection sends ----------------------------------------------------------------

    def message_sent(self, input_id: InputId | None) -> None:
        """A user message item of ours is on its way: its `conversation.item.added` places the input."""
        self._messages.append(input_id)

    def foreign_messages_sent(self, count: int) -> None:
        """User message items that are no input of the session's (seeded or replayed history) are on their way."""
        self._messages.extend([None] * count)

    def audio_appended(self) -> None:
        """Input audio is going out, into the buffer the next commit commits."""
        self._audio_uncommitted = True

    def audio_clear_sent(self) -> None:
        """A clear of the input audio buffer is going out: the next commit commits only audio sent after it."""
        self._audio_uncommitted = False

    def audio_commit_sent(self, event_id: str | None = None) -> AudioCommit:
        """An audio commit of ours is going out, after everything sent before it: what it notes, for `audio_commit_failed`.

        `event_id` is the one it goes out under, if any.
        """
        sent_before = [*(input_id for input_id in self._messages if input_id is not None), *self._tool_outputs.values()]
        commit = AudioCommit(sent_before=sent_before, has_audio=self._audio_uncommitted, event_id=event_id)
        self._audio_uncommitted = False
        if self._acknowledges_commits:
            self._commits.append(commit)
        return commit

    def audio_commit_failed(self, commit: AudioCommit) -> None:
        """The audio commit `audio_commit_sent` noted never went out (unless a reconnect forgot it already)."""
        if commit in self._commits:
            self._commits.remove(commit)
            self._audio_uncommitted = self._audio_uncommitted or commit.has_audio

    def unacknowledged_commits(self) -> list[LifecycleEvent]:
        """The connection reads nothing more from its socket: the commits it didn't acknowledge made turns all the same.

        The provider had them, as it had the audio they commit, so each is recorded (with no transcript, which can
        no longer come) where it joined the conversation: after what we sent ahead of it.
        """
        events: list[LifecycleEvent] = []
        while self._commits:
            commit = self._commits[0]
            events += self._place_sent_before_commit()
            if not commit.has_audio:
                # A commit of nothing: the provider refuses it, so it makes no turn.
                continue
            if (speaking := next(reversed(self._speaking), None)) is not None:
                # The turn under way (the provider heard it start) is the one the commit ends: it joins the
                # conversation here, unless it already had (xAI adds it at speech start).
                events += self._place(speaking)
                self._speaking.pop(speaking)
            elif not self._commits_need_speech:
                self._unacknowledged_turns += 1
                events += self._place(f'pydantic_ai_audio_commit_{self._unacknowledged_turns}')
        return events

    def tool_output_sent(self, call_id: str, input_id: InputId) -> None:
        self._tool_outputs[call_id] = input_id

    def request_sent(self, event_id: str, answers: tuple[InputId, ...], *, tagged: bool) -> None:
        """A `response.create` for `answers` is on its way under `event_id`, naming them in its metadata if `tagged`."""
        self._requests[event_id] = (answers, tagged)

    def take_leading(self) -> list[LifecycleEvent]:
        leading, self._leading = self._leading, []
        return leading

    def take_pending(self) -> list[LifecycleEvent]:
        pending, self._pending = self._pending, []
        return pending

    # --- what the server says ---------------------------------------------------------------------

    def is_ended(self, response_id: str | None) -> bool:
        return response_id is not None and response_id in self._ended

    def before_frame(self, event_type: str | None, data: dict[str, Any]) -> None:
        """Start the response a frame is the first to name, ahead of the frame's own events."""
        if event_type == 'response.created':
            return
        response_id = frame_response_id(event_type, data)
        if response_id is not None and response_id not in self._open and response_id not in self._ended:
            # A terminal echoes the request's metadata too, so a response first seen at its end is still known.
            response = data.get('response') if event_type == 'response.done' else None
            answers = response_metadata_answers(response.get('metadata')) if is_str_dict(response) else None
            self._leading.append(
                self._start(response_id, answers=self._settle(answers), basis='protocol')
                if answers is not None
                else self._start(response_id, answers=(), basis='inferred')
            )

    def response_created(
        self,
        response: ProtocolResponse,
        *,
        outstanding: tuple[str, tuple[InputId, ...]] | None,
    ) -> list[LifecycleEvent]:
        """A `response.created`: which inputs the response answers, from its metadata or what was outstanding.

        `outstanding` is the `event_id` of the connection's own unstarted `response.create` and the inputs it
        asked for, which the connection takes this response to be.
        """
        response_id = response.id or self._synthetic_id()
        if response_id in self._open or response_id in self._ended:
            return []
        answers = response_metadata_answers(response.metadata)
        basis: AnswersBasis = 'protocol'
        if answers is not None:
            self._metadata_echoed = True
            self._requests = {
                event_id: request for event_id, request in self._requests.items() if not set(request[0]) & set(answers)
            }
        elif (
            outstanding is not None
            and not (
                # Once the server echoes metadata, a response without ours is not the one ours asked for, unless
                # ours carried none.
                self._metadata_echoed and self._requests.get(outstanding[0], ((), True))[1]
            )
            and not self._unacknowledged(outstanding[1])
        ):
            event_id, answers = outstanding
            basis = 'inferred'
            self._requests.pop(event_id, None)
        else:
            answers = ()
        user_turn_id = None
        if not answers:
            # Started by the provider on its own: with server VAD, that is the reply to the spoken turn it just
            # committed.
            user_turn_id, self._unclaimed_turn = self._unclaimed_turn, None
        return [self._start(response_id, answers=self._settle(answers), basis=basis, user_turn_id=user_turn_id)]

    def _unacknowledged(self, answers: Sequence[InputId]) -> bool:
        """Whether an item of ours that a request answers isn't in the conversation yet, on a server that says so.

        The server adds an item before it starts the response a later `response.create` asks for, so a response
        that starts before it is none of that request's: one the provider started on its own (server VAD).
        """
        if not self._items_acknowledged:
            return False
        waiting = {*self._messages, *self._tool_outputs.values()}
        return any(input_id in waiting for input_id in answers)

    def request_outstanding(self, event_id: str) -> bool:
        """Whether a `response.create` of ours is neither started nor refused yet."""
        return event_id in self._requests

    def response_done(
        self,
        response_id: str | None,
        *,
        status: ResponseStatus,
        finish_reason: FinishReason | None,
        provider_details: dict[str, Any] | None,
    ) -> None:
        """A `response.done`: the response ends, once. A repeat ends nothing."""
        if response_id is None:
            response_id = self._current_synthetic or self._synthetic_id()
            self._current_synthetic = None
        if response_id in self._ended:
            return
        if response_id not in self._open:
            self._pending.append(self._start(response_id, answers=(), basis='inferred'))
        self._pending.append(self._end(response_id, status, finish_reason, provider_details))

    def response_unreadable(self, active_response_id: str | None) -> None:
        """A `response.done` too malformed to name its response: it still ended the one being generated.

        A response whose `response.created` carried no id is the current synthetic one.
        """
        if active_response_id is None:
            active_response_id, self._current_synthetic = self._current_synthetic, None
        if active_response_id is not None and active_response_id in self._open:
            self._pending.append(self._end(active_response_id, 'lost', None, None))

    def frame(self, event_type: str | None, data: dict[str, Any]) -> list[LifecycleEvent]:
        """The events a frame about user turns, conversation items, or errors makes."""
        if event_type == 'input_audio_buffer.speech_started':
            return self.speech_started(data)
        if event_type == 'input_audio_buffer.committed':
            return self.audio_committed(data)
        if event_type == 'input_audio_buffer.speech_stopped':
            return self.speech_stopped(data)
        if event_type == 'input_audio_buffer.cleared':
            return self.audio_cleared()
        if event_type in _TRANSCRIPTION_SETTLED_FRAMES and _is_final_transcription(data):
            self._untranscribed.discard(str(data.get('item_id')))
            return []
        if event_type == 'input_audio_buffer.timeout_triggered':
            self._idle_items.add(InputAudioBufferTimeoutTriggered.model_validate(data).item_id)
            return []
        if event_type in CONVERSATION_ITEM_ADDED_EVENTS:
            return self.item_added(data)
        if event_type == 'response.output_item.added':
            return _output_item_details(data)
        if event_type == 'error':
            return self.error(data)
        return []

    def speech_started(self, data: dict[str, Any]) -> list[LifecycleEvent]:
        item_id = InputAudioBufferSpeechStartedEvent.model_validate(data).item_id
        if not item_id or item_id in self._speaking:
            return []
        # A start while an earlier one never stopped: semantic VAD heard a burst of starts, and commits only
        # the last, so the earlier ones merged into it (unless one already joined the conversation).
        merged = [turn_id for turn_id in self._speaking if turn_id not in self._committed]
        for turn_id in merged:
            del self._speaking[turn_id]
        self._speaking[item_id] = None
        return [*(UserTurnClosed(turn_id=turn_id) for turn_id in merged), UserTurnStarted(turn_id=item_id)]

    def audio_committed(self, data: dict[str, Any]) -> list[LifecycleEvent]:
        """The input audio buffer was committed: the spoken turn joins the conversation here, if it hadn't."""
        item_id = InputAudioBufferCommittedEvent.model_validate(data).item_id
        self._vad_committed()
        if item_id in self._vad_stopped:
            # Server VAD's own commit, not the acknowledgement of one of ours, which still waits for its own. What
            # went out ahead of ours and isn't acknowledged yet reached the provider after this commit (it would have
            # been acknowledged first otherwise), so it is placed after this turn, as its acknowledgement comes.
            self._vad_stopped.discard(item_id)
            events = self._place(item_id)
            self._speaking.pop(item_id, None)
            return events
        events = self._place_sent_before_commit()
        events += self._place(item_id)
        self._speaking.pop(item_id, None)
        return events

    def _vad_committed(self) -> None:
        """The provider committed the buffer: on its own, if no commit of ours is waiting for it, so it is empty now.

        (As far as the client can tell: audio it sent while the provider committed may still be in it.)
        """
        if not self._commits:
            self._audio_uncommitted = False

    def _place_sent_before_commit(self) -> list[LifecycleEvent]:
        """Place what we sent ahead of our commit and the provider hasn't acknowledged yet: it came first."""
        sent = self._commits.popleft().sent_before if self._commits else []
        events: list[LifecycleEvent] = []
        for input_id in sent:
            if input_id in self._messages:
                # Its acknowledgement, when it comes, is then for no input of ours (and still keeps the order).
                self._messages[self._messages.index(input_id)] = None
            elif input_id in self._tool_outputs.values():
                del self._tool_outputs[next(call for call, output in self._tool_outputs.items() if output == input_id)]
            else:
                continue
            events.append(InputAdded(input_id=input_id))
        return events

    def speech_stopped(self, data: dict[str, Any]) -> list[LifecycleEvent]:
        """Server VAD heard the user stop: it commits the turn right away, so the turn joins the conversation here."""
        item_id = InputAudioBufferSpeechStoppedEvent.model_validate(data).item_id
        if not item_id:
            return []
        self._vad_committed()
        if self._server_vad:
            self._vad_stopped.add(item_id)
        events = self._place(item_id)
        self._speaking.pop(item_id, None)
        return events

    def _place(self, item_id: str, *, still_speaking: bool = False) -> list[LifecycleEvent]:
        """The spoken turn joins the conversation (once), whatever says so first."""
        if item_id in self._committed:
            return []
        self._committed.add(item_id)
        if item_id in self._idle_items:
            self._idle_items.discard(item_id)
            # An idle timeout's empty audio item: the server nudges the model to speak, nobody said anything.
            self._unclaimed_turn = None
            return []
        # Push-to-talk reports no speech start: the commit both starts and ends the turn.
        events: list[LifecycleEvent] = [] if item_id in self._speaking else [UserTurnStarted(turn_id=item_id)]
        events.append(UserTurnEnded(turn_id=item_id, still_speaking=still_speaking))
        self._unclaimed_turn = item_id
        if self._transcribes:
            self._untranscribed.add(item_id)
        return events

    def audio_cleared(self) -> list[LifecycleEvent]:
        """The input audio buffer was cleared: the spoken turn under way gets no more audio.

        If it hadn't joined the conversation yet, it never will; if it had (xAI adds its item at speech start),
        it stays, with nothing more to come for it.
        """
        events: list[LifecycleEvent] = [UserTurnClosed(turn_id=turn_id) for turn_id in self._speaking]
        # One that hadn't joined never will, whatever the provider still reports about it.
        self._committed.update(self._speaking)
        # Nor is a transcript waited for any more: the turn is settled.
        self._untranscribed.difference_update(self._speaking)
        self._speaking.clear()
        return events

    def item_added(self, data: dict[str, Any]) -> list[LifecycleEvent]:
        """An item joined the conversation: if it is one of our inputs, that input is placed here."""
        self._items_acknowledged = True
        item = CONVERSATION_ITEM_ADDED_EVENT_ADAPTER.validate_python(data).item
        if item.type == 'function_call_output' and item.call_id is not None:
            input_id = self._tool_outputs.pop(item.call_id, None)
        elif item.id is not None and item.id in self._speaking:
            # A spoken turn joins the conversation when its item is added. That can be before the user has
            # stopped speaking: xAI adds it at speech start, and starts responding before the commit.
            return self._place(item.id, still_speaking=True)
        elif not is_user_message_item(item):
            # The model's output, or a spoken turn already committed.
            return []
        elif (input_id := client_item_input(item.id)) is not None:
            if input_id not in self._messages:
                return []
            self._ids_echoed = True
            self._messages.remove(input_id)
        elif self._ids_echoed or not self._messages:
            # No item of ours: seeded or replayed history, or one a browser made on a sideband.
            return []
        else:
            # A server that doesn't keep our ids (or a recording made before we chose them): the server adds
            # items in the order it receives them.
            input_id = self._messages.popleft()
        return [] if input_id is None else [InputAdded(input_id=input_id)]

    def error(self, data: dict[str, Any]) -> list[LifecycleEvent]:
        """An `error` frame: a refused request for a response settles every input it was made for."""
        error = RealtimeErrorEvent.model_validate(data).error
        if error.code == 'input_audio_buffer_commit_empty' and self._commits:
            # The provider refused a commit of ours as empty: no turn. The one the error names, or (if it names none
            # of ours) the oldest one not acknowledged, since the provider handles frames in order.
            refused = next((commit for commit in self._commits if commit.event_id == error.event_id), self._commits[0])
            self._commits.remove(refused)
        for rejected in rejected_inputs(error):
            if rejected.refused == 'content' and rejected.input_index in self._messages:
                # Refused content never joins the conversation, so no `conversation.item.added` will place it.
                self._messages.remove(rejected.input_index)
        if error.event_id is None or (request := self._requests.pop(error.event_id, None)) is None:
            return []
        if error.code == ACTIVE_RESPONSE_ERROR_CODE:
            # Refused only for the moment, as a response the provider started on its own was under way: the
            # connection asks again once it's over, or gives up on it (`requests_refused`).
            return []
        return [ResponseRequestRefused(input_ids=answers)] if (answers := self._settle(request[0])) else []

    # --- the connection's own transitions ----------------------------------------------------------

    def requests_refused(self, answers: Sequence[InputId]) -> None:
        """The connection gave up asking for a response for `answers`, which the provider kept refusing."""
        if refused := self._settle(answers):
            self._pending.append(ResponseRequestRefused(input_ids=refused))

    def requests_dropped(self, answers: Sequence[InputId]) -> None:
        """The connection dropped requests it was holding, so nothing will answer `answers`."""
        if unsettled := self._settle(answers):
            self._pending.append(InputLost(input_ids=unsettled))

    def socket_replaced(self) -> None:
        """A new socket is being dialed: what the old one hadn't acknowledged, it never will.

        Those inputs are in the conversation all the same: the reconnect replays the history that holds them.
        """
        # Ahead of them: what was sent before a commit joined the conversation before the commit's turn.
        self._pending.extend(self.unacknowledged_commits())
        # The new socket's buffer is empty.
        self._audio_uncommitted = False
        self._vad_stopped.clear()
        placed = [input_id for input_id in self._messages if input_id is not None]
        placed += self._tool_outputs.values()
        # Placed once a reconnect succeeds, not before: a connection that never comes back placed nothing.
        self._carried_over.update(placed)
        self._messages.clear()
        self._tool_outputs.clear()

    def reconnected(self, *, lost_inputs: Sequence[InputId], asked_again: Sequence[InputId]) -> None:
        """A reconnect succeeded: settle what it did not carry over, before it is reported.

        `asked_again` are the inputs whose request the connection is about to send again on the new socket.
        """
        self._pending.extend(InputAdded(input_id=input_id) for input_id in sorted(self._carried_over))
        self._carried_over.clear()
        self.requests_dropped(lost_inputs)
        # Whatever the connection still thought of it, a request the old socket neither started nor
        # refused, and that isn't asked for again, will never be answered.
        self.requests_dropped(
            [input_id for answers, _ in self._requests.values() for input_id in answers if input_id not in asked_again]
        )
        self._requests.clear()
        self._lose_everything_open()
        # A transcript still to come for a turn of the old connection never will.
        self._pending.extend(UserTurnClosed(turn_id=turn_id) for turn_id in sorted(self._untranscribed))
        self._untranscribed.clear()

    def closed(self, unanswered: Sequence[InputId]) -> None:
        """The connection is gone for good: nothing still open will ever end on its own, or be answered."""
        self._pending.extend(self.unacknowledged_commits())
        self.requests_dropped(
            [*unanswered, *(input_id for answers, _ in self._requests.values() for input_id in answers)]
        )
        self._requests.clear()
        self._carried_over.clear()
        self._lose_everything_open()

    def _lose_everything_open(self) -> None:
        self._pending.extend(self._end(response_id, 'lost', None, None) for response_id in list(self._open))
        self._pending.extend(self.audio_cleared())
        self._current_synthetic = None

    # --- helpers ------------------------------------------------------------------------------------

    def _settle(self, input_ids: Sequence[InputId]) -> tuple[InputId, ...]:
        """Settle the inputs not settled yet, returning them."""
        unsettled = tuple(input_id for input_id in dict.fromkeys(input_ids) if input_id not in self._settled)
        self._settled.update(unsettled)
        return unsettled

    def _synthetic_id(self) -> str:
        self._synthetic_responses += 1
        self._current_synthetic = f'pydantic_ai_response_{self._synthetic_responses}'
        return self._current_synthetic

    def _start(
        self,
        response_id: str,
        *,
        answers: tuple[InputId, ...],
        basis: AnswersBasis,
        user_turn_id: str | None = None,
    ) -> ResponseStarted:
        self._open[response_id] = None
        return ResponseStarted(response_id=response_id, answers=answers, basis=basis, user_turn_id=user_turn_id)

    def _end(
        self,
        response_id: str,
        status: ResponseStatus,
        finish_reason: FinishReason | None,
        provider_details: dict[str, Any] | None,
    ) -> ResponseEnded:
        self._open.pop(response_id, None)
        self._ended.add(response_id)
        return ResponseEnded(
            response_id=response_id, status=status, finish_reason=finish_reason, provider_details=provider_details
        )
