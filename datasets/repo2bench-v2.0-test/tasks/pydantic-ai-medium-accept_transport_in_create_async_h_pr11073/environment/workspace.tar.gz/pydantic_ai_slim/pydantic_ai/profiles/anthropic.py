from __future__ import annotations as _annotations

from typing import Literal, TypeAlias

from ..native_tools import (
    AdvisorTool,
    CodeExecutionTool,
    MCPServerTool,
    MemoryTool,
    WebFetchTool,
    WebSearchTool,
)
from ..native_tools._tool_search import ToolSearchTool
from ..settings import ThinkingEffort, ThinkingLevel
from . import ModelProfile

_ANTHROPIC_BASE_BUILTINS = frozenset({WebSearchTool, CodeExecutionTool, WebFetchTool, MemoryTool, MCPServerTool})
"""Native tool types Anthropic generally supports across the model line. Mirrors
`AnthropicModel.supported_native_tools()` minus `ToolSearchTool`, which is gated
per-model in the profile below."""

ANTHROPIC_SAMPLING_PARAMS = ('temperature', 'top_p', 'top_k')
"""The unified sampling settings gated by `anthropic_disallows_sampling_settings`.

Models whose profile sets that flag reject these settings outright with a 400, so every provider
serving them has to drop and warn rather than forward. It lives here rather than beside either
model because `models/bedrock.py` cannot import from `models/anthropic.py` without pulling the
`anthropic` SDK into the `bedrock` extra.
"""

AnthropicCodeExecutionToolVersion: TypeAlias = Literal['20250825', '20260120']
"""Concrete Anthropic code execution tool version to send for `CodeExecutionTool`."""

_ANTHROPIC_CODE_EXECUTION_20260120_MODEL_PREFIXES = (
    'claude-fable-5',
    'claude-mythos-5',
    'claude-opus-4-5',
    'claude-opus-4-6',
    'claude-opus-4-7',
    'claude-opus-4-8',
    'claude-opus-5',
    'claude-sonnet-4-5',
    'claude-sonnet-4-6',
    'claude-sonnet-5',
    'claude-haiku-5-5',
)


class AnthropicModelProfile(ModelProfile, total=False):
    """Profile for models used with `AnthropicModel`.

    ALL FIELDS MUST BE `anthropic_` PREFIXED SO YOU CAN MERGE THEM WITH OTHER MODELS.
    """

    anthropic_supports_fast_speed: bool
    """Whether the model supports fast inference speed (`anthropic_speed='fast'`). Default: `False`.

    Currently Claude Opus 4.6, 4.7, 4.8, 5, and 5.5 support fast mode. See the Anthropic docs for the latest list.
    """

    anthropic_supports_adaptive_thinking: bool
    """Whether the model supports adaptive thinking (Sonnet 4.6+, Opus 4.6+, Haiku 5.5). Default: `False`.

    When True, unified `thinking` translates to `{'type': 'adaptive'}`.
    When False, it translates to `{'type': 'enabled', 'budget_tokens': N}`.

    Adaptive thinking, unlike extended thinking, accepts a forced `tool_choice`, so this also decides whether
    an explicit forcing `tool_choice` raises alongside unified `thinking`.
    """

    anthropic_supports_effort: bool
    """Whether the model supports the `effort` parameter in `output_config` (Opus 4.5+, Sonnet 4.6+, Haiku 5.5). Default: `False`.

    When True and the unified thinking level is a string (e.g. 'high'), it is also
    mapped to `output_config.effort`.
    """

    anthropic_supports_dynamic_filtering: bool
    """Whether the model supports Anthropic-managed dynamic filtering for web search/fetch. Default: `False`.

    When enabled, Pydantic AI selects the `web_search_20260209` / `web_fetch_20260209` tool versions,
    which let Claude filter web results via code execution before they enter context.
    """

    anthropic_supports_xhigh_effort: bool
    """Whether the model supports the `xhigh` effort value in `output_config`. Default: `False`.

    Claude Opus 4.7, 4.8, and 5, Sonnet 5, Fable 5, Mythos 5, and Haiku 5.5 accept `xhigh`;
    on other models, unified `thinking='xhigh'` uses `max` instead, or `high` where `max` isn't supported either.
    """

    anthropic_supports_max_effort: bool
    """Whether the model supports the `max` effort value in `output_config`. Default: `True`.

    Disabled for Claude Opus 4.5, which accepts only `low`, `medium`, and `high`. When disabled, unified
    `thinking='max'` falls back to the highest effort the model accepts (`high` on Claude Opus 4.5), and so
    does `thinking='xhigh'` where it would otherwise map to `max`. Explicit `anthropic_effort='max'` settings
    are still passed through unchanged.
    """

    anthropic_disallows_budget_thinking: bool
    """Whether the model rejects budget-based thinking settings. Default: `False`.

    Claude Opus 4.7, 4.8, 5, and Haiku 5.5 require adaptive thinking and return a 400 for
    `{'type': 'enabled', 'budget_tokens': ...}`.
    """

    anthropic_disallows_sampling_settings: bool
    """Whether the model rejects sampling settings like `temperature` and `top_p`. Default: `False`.

    Claude Opus 4.7, 4.8, 5, and 5.5, plus Haiku 5.5, require these settings to be omitted from
    request payloads.
    """

    anthropic_disallows_top_effort_when_thinking_disabled: bool
    """Whether the model rejects `xhigh`/`max` effort while thinking is explicitly disabled. Default: `False`.

    Claude Opus 5 and Haiku 5.5 cap effort at `high` when `anthropic_thinking={'type': 'disabled'}` and return a
    400 for `xhigh` or `max`; Claude Opus 4.8 accepts the same combination. Claude Opus 5.5 rejects
    disabled thinking at every effort level, so the flag doesn't apply to it.
    """

    anthropic_default_code_execution_tool_version: AnthropicCodeExecutionToolVersion
    """The Anthropic code execution tool version used when `anthropic_code_execution_tool_version='auto'`. Default: `'20250825'`."""

    anthropic_supported_code_execution_tool_versions: tuple[AnthropicCodeExecutionToolVersion, ...]
    """The Anthropic code execution tool versions supported by the model. Default: `('20250825',)`."""

    anthropic_supports_task_budgets: bool
    """Whether the model supports `output_config.task_budget`. Default: `False`.

    Anthropic currently documents task budgets as a Claude Opus 4.7 / 4.8 / 5 / 5.5 and Haiku 5.5 beta feature.
    """

    anthropic_supports_forced_tool_choice: bool
    """Deprecated: use [`supports_forced_tool_choice`][pydantic_ai.profiles.ModelProfile.supports_forced_tool_choice] instead.

    Translated (with a deprecation warning) whenever profiles are merged.
    """

    anthropic_max_output_tokens: int | None
    """The most output tokens the model can generate in one response, thinking included. Default: `None` (unknown).

    `AnthropicModel` sends it as `max_tokens` when the request doesn't set one, so responses are only cut off at the
    model's limit, like on APIs where the output limit is optional.
    """

    anthropic_rejects_max_tokens_beyond_context_window: bool
    """Whether the model rejects a request whose input plus `max_tokens` exceeds its context window. Default: `False`.

    Claude models older than Claude Sonnet 4.5 answer such a request with a 400, where later models accept it and stop
    at the context window. When True, a request that doesn't set `max_tokens` gets the lower default of 4096, so a
    conversation close to the context window still fits. It's also set for Claude 3 and 3.5, whose maximum output
    (4,096 or 8,192 tokens) is below the higher default.
    """

    anthropic_binds_thinking_blocks: bool
    """Whether the model binds each thinking block to the conversation prefix that produced it. Default: `False`.

    Claude Fable 5.1, Claude Opus 5.5, Claude Sonnet 5.5, and Claude Haiku 5.5 bind replayed thinking blocks to
    the conversation prefix. Anthropic documents a 400 after `system`, `tools`, or earlier `messages` change; for
    accounts created before 31 August 2026, the error requires `thinking.block_binding.prefix_mismatch_behavior`.
    When True, Pydantic AI preserves the account's default behavior on the first request; if Anthropic
    rejects a stale block, it retries once with `thinking.block_binding.prefix_mismatch_behavior='drop_block'`
    and warns after the retry succeeds. See [Anthropic's thinking troubleshooting
    guide](https://platform.claude.com/docs/en/build-with-claude/thinking-troubleshooting).
    """


ANTHROPIC_THINKING_BUDGET_MAP: dict[ThinkingLevel, int] = {
    True: 10000,
    'minimal': 1024,
    'low': 2048,
    'medium': 10000,
    'high': 16384,
    'xhigh': 32768,
    'max': 32768,
}
"""Maps unified thinking values to Anthropic budget_tokens for non-adaptive models."""


AnthropicEffort: TypeAlias = Literal['low', 'medium', 'high', 'xhigh', 'max']
"""Effort values Anthropic accepts at `output_config.effort`."""


ANTHROPIC_THINKING_EFFORT_MAP: dict[ThinkingEffort, AnthropicEffort] = {
    'minimal': 'low',
    'low': 'low',
    'medium': 'medium',
    'high': 'high',
    'xhigh': 'max',
    'max': 'max',
}
"""Maps unified thinking effort levels to Anthropic `output_config.effort`.

`xhigh` maps to `'max'` by default; callers that target a model with
`anthropic_supports_xhigh_effort` should pass `supports_xhigh=True` to
[`resolve_anthropic_effort`][pydantic_ai.profiles.anthropic.resolve_anthropic_effort]
to preserve `xhigh` instead of upshifting, and `supports_max=False` for a model without
`anthropic_supports_max_effort`, where `'max'` falls back to the highest level it accepts.
"""


def resolve_anthropic_effort(
    level: ThinkingEffort, *, supports_xhigh: bool, supports_max: bool = True
) -> AnthropicEffort:
    """Resolve a unified thinking effort level to the Anthropic `output_config.effort` value.

    Shared between the direct Anthropic path and any provider that translates to the
    Anthropic `output_config` wire shape (e.g. Bedrock Converse for Anthropic models).
    Keeps `ANTHROPIC_THINKING_EFFORT_MAP` as the single source of truth for the
    base mapping, while letting the `xhigh` and `max` support decisions live in one place.
    """
    if level == 'xhigh' and supports_xhigh:
        return 'xhigh'
    effort = ANTHROPIC_THINKING_EFFORT_MAP[level]
    if effort == 'max' and not supports_max:
        return 'xhigh' if supports_xhigh else 'high'
    return effort


def anthropic_model_profile(model_name: str) -> ModelProfile | None:
    """Get the model profile for an Anthropic model."""
    models_that_support_json_schema_output = (
        'claude-fable-5',
        'claude-mythos-5',
        'claude-haiku-4-5',
        'claude-sonnet-4-5',
        'claude-sonnet-4-6',
        'claude-opus-4-1',
        'claude-opus-4-5',
        'claude-opus-4-6',
        'claude-opus-4-7',
        'claude-opus-4-8',
        'claude-opus-5',
        'claude-sonnet-5',
        'claude-haiku-5-5',
    )
    """These models support both structured outputs and strict tool calling."""
    # TODO update when new models are released that support structured outputs
    # https://docs.claude.com/en/docs/build-with-claude/structured-outputs#example-usage

    supports_json_schema_output = model_name.startswith(models_that_support_json_schema_output)
    anthropic_supports_fast_speed = model_name.startswith(
        ('claude-opus-4-6', 'claude-opus-4-7', 'claude-opus-4-8', 'claude-opus-5')
    )

    # Sonnet 4.6+, Opus 4.6+, and Haiku 5.5 support adaptive thinking; older models use budget-based.
    supports_adaptive = model_name.startswith(
        (
            'claude-fable-5',
            'claude-mythos-5',
            'claude-mythos-preview',
            'claude-sonnet-4-6',
            'claude-sonnet-5',
            'claude-opus-4-6',
            'claude-opus-4-7',
            'claude-opus-4-8',
            'claude-opus-5',
            'claude-haiku-5-5',
        )
    )

    supports_effort = model_name.startswith(
        (
            'claude-fable-5',
            'claude-mythos-5',
            'claude-opus-4-5',
            'claude-opus-4-6',
            'claude-opus-4-7',
            'claude-opus-4-8',
            'claude-opus-5',
            'claude-sonnet-4-6',
            'claude-sonnet-5',
            'claude-haiku-5-5',
        )
    )
    supports_xhigh_effort = model_name.startswith(
        (
            'claude-fable-5',
            'claude-mythos-5',
            'claude-opus-4-7',
            'claude-opus-4-8',
            'claude-opus-5',
            'claude-sonnet-5',
            'claude-haiku-5-5',
        )
    )
    disallows_budget_thinking = model_name.startswith(
        (
            'claude-fable-5',
            'claude-mythos-5',
            'claude-opus-4-7',
            'claude-opus-4-8',
            'claude-opus-5',
            'claude-sonnet-5',
            'claude-haiku-5-5',
        )
    )
    disallows_sampling_settings = model_name.startswith(
        (
            'claude-fable-5',
            'claude-mythos-5',
            'claude-opus-4-7',
            'claude-opus-4-8',
            'claude-opus-5',
            'claude-sonnet-5',
            'claude-haiku-5-5',
        )
    )
    # Opus 5 and Haiku 5.5 cap effort at `high` while thinking is disabled; Opus 4.8 and earlier accept every level.
    # Opus 5.5 rejects disabled thinking outright, so the effort-specific error would mislead.
    disallows_top_effort_when_thinking_disabled = (
        model_name.startswith('claude-opus-5') and not model_name.startswith('claude-opus-5-5')
    ) or model_name.startswith('claude-haiku-5-5')
    default_code_execution_tool_version, supported_code_execution_tool_versions = _code_execution_tool_versions(
        model_name
    )
    supports_task_budgets = model_name.startswith(
        (
            'claude-fable-5',
            'claude-mythos-5',
            'claude-opus-4-7',
            'claude-opus-4-8',
            'claude-opus-5',
            'claude-sonnet-5',
            'claude-haiku-5-5',
        )
    )

    # The `max_tokens` Anthropic's Models API reports for each model. Mythos 5 isn't reachable with our credentials;
    # Anthropic documents Mythos 5.1 as having Fable 5.1's capabilities.
    if model_name.startswith(
        (
            'claude-fable-5',
            'claude-mythos-5',
            'claude-opus-4-6',
            'claude-opus-4-7',
            'claude-opus-4-8',
            'claude-opus-5',
            'claude-sonnet-4-6',
            'claude-sonnet-5',
            'claude-haiku-5-5',
        )
    ):
        max_output_tokens: int | None = 128_000
    elif model_name.startswith(('claude-haiku-4-5', 'claude-opus-4-5', 'claude-sonnet-4-5')):
        max_output_tokens = 64_000
    else:
        max_output_tokens = None

    # Before Claude Sonnet 4.5, Anthropic rejects a request whose input plus `max_tokens` exceeds the context window:
    # Bedrock's `claude-sonnet-4-20250514` answers 192K input tokens plus 16384 with a 400 (`Input is too long for
    # requested model.`) and accepts 192K plus 4096, where Haiku 4.5 accepts 192K plus 16384. Claude 3 and 3.5 also
    # need the lower default, since their maximum output is 4,096 or 8,192 tokens.
    rejects_max_tokens_beyond_context_window = model_name in (
        'claude-opus-4',
        'claude-sonnet-4',
    ) or model_name.startswith(
        (
            'claude-3',
            'claude-4-',
            'claude-opus-4-0',
            'claude-opus-4-1',
            'claude-opus-4-2',
            'claude-opus-4@',
            'claude-sonnet-4-0',
            'claude-sonnet-4-2',
            'claude-sonnet-4@',
        )
    )

    # Anthropic documents these models as thinking when the request omits `thinking`; Fable 5, Fable 5.1, Opus 5,
    # Opus 5.5, and Sonnet 5 return thinking tokens live with no thinking parameter, where Opus 4.8 and Sonnet 4.6
    # return none. Haiku 5.5's adaptive default was verified live with `anthropic_effort='high'` and no `thinking`
    # parameter; it returned signed thinking blocks and positive thinking-token usage.
    thinking_enabled_by_default = model_name.startswith(
        (
            'claude-fable-5',
            'claude-mythos-5',
            'claude-mythos-preview',
            'claude-opus-5',
            'claude-sonnet-5',
            'claude-haiku-5-5',
        )
    )
    # Of those, all but Opus 5, Sonnet 5, and Haiku 5.5 reject `thinking={'type': 'disabled'}` with a 400, so thinking
    # can't be turned off.
    thinking_always_enabled = model_name.startswith(
        ('claude-fable-5', 'claude-mythos-5', 'claude-mythos-preview', 'claude-opus-5-5', 'claude-sonnet-5-5')
    )

    # The 5.1 generation, Opus 5.5, and Sonnet 5.5 reject a forced `tool_choice` (`any`/`tool`) outright, unlike
    # other Anthropic models which only reject forcing alongside extended thinking. Anthropic's
    # forcing-tool-use table names Claude Fable 5.1 and Claude Mythos 5.1, and `claude-fable-5` accepts
    # both forcing shapes live (200 on `any` and `tool`, GA and beta endpoints), so Fable 5, Mythos 5,
    # and Mythos Preview no longer belong here. `claude-opus-5-5` returns a 400 for both shapes where
    # `claude-opus-5` returns 200, and likewise `claude-sonnet-5-5` where `claude-sonnet-5` returns 200.
    supports_forced_tool_choice = not model_name.startswith(
        ('claude-fable-5-1', 'claude-mythos-5-1', 'claude-opus-5-5', 'claude-sonnet-5-5')
    )

    # Claude Fable 5.1, Opus 5.5, Sonnet 5.5, and Haiku 5.5 bind thinking blocks to the conversation prefix.
    # Anthropic documents this behavior for Haiku 5.5; a live `drop_block` probe returned the expected transformation
    # after a prefix change, but the explicit `error` behavior was not probed. Claude Fable 5, Opus 5, and Sonnet 5
    # return 200 for a replayed block under explicit `prefix_mismatch_behavior='error'` where Opus 5.5 and Sonnet 5.5
    # return a 400 after the `system` prompt changes. Anthropic documents that Claude Mythos 5.1 "doesn't run this
    # check" — the one capability on which it is not Fable 5.1's mirror.
    binds_thinking_blocks = model_name.startswith(
        ('claude-fable-5-1', 'claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-5-5')
    )

    supports_dynamic_filtering = model_name.startswith(
        (
            'claude-fable-5',
            'claude-mythos-5',
            'claude-mythos-preview',
            'claude-sonnet-4-6',
            'claude-sonnet-5',
            'claude-opus-4-6',
            'claude-opus-4-7',
            'claude-opus-4-8',
            'claude-opus-5',
            'claude-haiku-5-5',
        )
    )
    # Native tool search requires the `tool_search_tool_bm25_20251119` /
    # `tool_search_tool_regex_20251119` API types, which post-date Claude 4.0. In
    # practice, Anthropic enables it for Sonnet 4.5+, Opus 4.5+, and Haiku 4.5+.
    supports_tool_search = model_name.startswith(
        (
            'claude-fable-5',
            'claude-mythos-5',
            'claude-sonnet-4-5',
            'claude-sonnet-4-6',
            'claude-sonnet-5',
            'claude-opus-4-5',
            'claude-opus-4-6',
            'claude-opus-4-7',
            'claude-opus-4-8',
            'claude-opus-5',
            'claude-haiku-4-5',
            'claude-haiku-5-5',
        )
    )
    # The advisor tool's valid *executors* (the model driving generation) are Fable/Mythos 5, Opus
    # 4.6-4.8 and 5, Sonnet 4.6/5, and Haiku 4.5/5.5. The executor/advisor pairing itself is validated API-side.
    supports_advisor = model_name.startswith(
        (
            'claude-fable-5',
            'claude-mythos-5',
            'claude-opus-4-6',
            'claude-opus-4-7',
            'claude-opus-4-8',
            'claude-opus-5',
            'claude-sonnet-4-6',
            'claude-sonnet-5',
            'claude-haiku-4-5',
            'claude-haiku-5-5',
        )
    )
    supported_native_tools = _ANTHROPIC_BASE_BUILTINS
    if supports_tool_search:
        supported_native_tools = supported_native_tools | {ToolSearchTool}
    if supports_advisor:
        supported_native_tools = supported_native_tools | {AdvisorTool}

    profile = AnthropicModelProfile(
        # Read by `OpenAIChatModel`, not by `AnthropicModel`: litellm, vercel, heroku, snowflake and
        # openrouter serve Claude through that adapter and map it onto this profile, so these tags are
        # how it splits thinking out of a Claude response and how it replays a `ThinkingPart` back.
        # `AnthropicModel` parses no tags at all, and only renders them for the
        # `mimics_assistant_message_formatting` opt-out.
        thinking_tags=('<thinking>', '</thinking>'),
        # Measured live on the six-turn history from https://github.com/pydantic/pydantic-ai/issues/5869:
        # `claude-opus-4-5` and `claude-opus-4-8` reproduce replayed `<thinking>` tags in their visible
        # answers on essentially every run, `claude-sonnet-4-6` on 6 of 9. The 5-series showed none in 12
        # runs each, which only rules out a rate above roughly 22% — not the behavior — so this stays on
        # for the whole family rather than gating on model name: a false positive costs an inaccurate
        # authorship answer, a false negative leaks reasoning into what the user reads.
        mimics_assistant_message_formatting=True,
        supports_json_schema_output=supports_json_schema_output,
        anthropic_supports_fast_speed=anthropic_supports_fast_speed,
        supports_thinking=True,
        thinking_always_enabled=thinking_always_enabled,
        thinking_enabled_by_default=thinking_enabled_by_default,
        # A forced `tool_choice` prefills the tool call, so the model answers it without thinking: Opus 5, Sonnet
        # 4.6 and Sonnet 5 return a thinking block for `auto` but none for `any` or `tool`, with adaptive thinking
        # on. Extended thinking rejects forcing outright, which `AnthropicModel` handles itself.
        forced_tool_choice_disables_thinking=True,
        anthropic_supports_adaptive_thinking=supports_adaptive,
        anthropic_supports_effort=supports_effort,
        anthropic_supports_dynamic_filtering=supports_dynamic_filtering,
        anthropic_supports_xhigh_effort=supports_xhigh_effort,
        anthropic_supports_max_effort=not model_name.startswith('claude-opus-4-5'),
        anthropic_disallows_budget_thinking=disallows_budget_thinking,
        anthropic_disallows_sampling_settings=disallows_sampling_settings,
        anthropic_disallows_top_effort_when_thinking_disabled=disallows_top_effort_when_thinking_disabled,
        anthropic_default_code_execution_tool_version=default_code_execution_tool_version,
        anthropic_supported_code_execution_tool_versions=supported_code_execution_tool_versions,
        anthropic_supports_task_budgets=supports_task_budgets,
        supports_forced_tool_choice=supports_forced_tool_choice,
        anthropic_binds_thinking_blocks=binds_thinking_blocks,
        anthropic_max_output_tokens=max_output_tokens,
        anthropic_rejects_max_tokens_beyond_context_window=rejects_max_tokens_beyond_context_window,
        supported_native_tools=supported_native_tools,
    )
    if supports_tool_search:
        profile['tool_deferral_mode'] = 'standalone'
    return profile


def _code_execution_tool_versions(
    model_name: str,
) -> tuple[AnthropicCodeExecutionToolVersion, tuple[AnthropicCodeExecutionToolVersion, ...]]:
    versions: tuple[AnthropicCodeExecutionToolVersion, ...] = ('20250825',)
    default_version: AnthropicCodeExecutionToolVersion = '20250825'
    if model_name.startswith(_ANTHROPIC_CODE_EXECUTION_20260120_MODEL_PREFIXES):
        default_version = '20260120'
        versions = (*versions, default_version)
    return default_version, versions
