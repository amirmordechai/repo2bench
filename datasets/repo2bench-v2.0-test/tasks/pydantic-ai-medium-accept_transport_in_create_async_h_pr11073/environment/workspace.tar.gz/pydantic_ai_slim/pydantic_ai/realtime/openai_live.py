"""OpenAI GPT-Live realtime support.

GPT-Live is a separate protocol from the [OpenAI Realtime API][pydantic_ai.realtime.openai], not a
model served by it, so none of its event mapping is shared: what it borrows from
`_openai_protocol.py` is the parts that are about the *provider* rather than the protocol (deriving
the WebSocket URL, resolving authentication, and mapping handshake failures). The differences that
shape the adapter:

- **Audio drives the session.** Live has no user-turn event for text: a typed turn goes to the
  Responses backend as the user's message, with `response.create` to run it, and, if it fits, to the
  Live model as silent context (`session.thinking.append`, capped at 500 tokens), which is also how
  context sent without asking for a reply arrives. Context is placed on the session's audio timeline, and
  Live only speaks onto it, which only advances while audio flows — so a session whose microphone
  isn't streaming says nothing, unless `openai_live_idle_audio` has the connection stream silence in
  the microphone's place.
- **There is no turn terminal.** Live has no `response.done` equivalent and no transcript-done
  event; transcripts arrive as timeline fragments. The connection synthesizes
  [`ResponseDone`][pydantic_ai.realtime.codec.ResponseDone] once the model has been quiet for
  `openai_live_turn_silence_ms` and no delegated work is outstanding, and the profile reports
  `synthesizes_turn_boundary=True` so consumers know the boundary is inferred.
- **Work is delegated, not tool-called.** The Live model hands a task either to your application
  (`client` delegation) or to a Responses backend it drives itself (`responses` delegation). Only
  the latter produces typed function calls, so it is what this adapter configures: the agent's tools
  are advertised to the backend, its calls arrive nested inside `response.event`, and their results
  go back as Responses input items. See
  [the Live docs](https://pydantic.dev/docs/ai/realtime/openai#gpt-live-models) for the split.
- **Usage has two meters.** Live reports its own audio as a cumulative duration in seconds and no
  tokens at all; the backend it delegates to reports ordinary Responses token usage, which is where
  most of a call's token cost is.
"""

from __future__ import annotations as _annotations

import array
import asyncio
import base64
import sys
import time
from collections.abc import AsyncGenerator, AsyncIterator, Awaitable, Callable, Sequence
from contextlib import AbstractAsyncContextManager, asynccontextmanager, suppress
from dataclasses import KW_ONLY, dataclass, field
from typing import Annotated, Any, ClassVar, Literal, assert_never, cast
from urllib.parse import quote

import anyio
from pydantic import Field, TypeAdapter, ValidationError
from pydantic_core import to_json
from typing_extensions import TypedDict

# The delegated backend is an ordinary Responses call, so its usage is mapped by the same code that
# maps a direct one — including the cache and reasoning breakdowns genai-prices reads.
from .. import _utils
from .._genai_prices import best_effort_price
from .._run_context import get_current_run_context
from ..exceptions import UserError
from ..messages import (
    AudioUrl,
    BinaryContent,
    BinaryImage,
    CachePoint,
    DocumentUrl,
    FinishReason,
    ModelMessage,
    ModelRequest,
    ModelRequestPart,
    ModelResponse,
    ModelResponsePart,
    MultiModalContent,
    PartEndEvent,
    PartStartEvent,
    RealtimeSessionErrorEvent,
    RealtimeSessionReconnectEvent,
    RetryFeedbackPart,
    RetryPromptPart,  # pyright: ignore[reportDeprecated]  # TODO(v3): remove RetryPromptPart
    SpeechPart,
    TextContent,
    TextPart,
    ThinkingPart,
    ToolCallPart,
    ToolReturnPart,
    UploadedFile,
    UserPromptPart,
    VideoUrl,
    _translate_legacy_retry_part,  # pyright: ignore[reportPrivateUsage]
)
from ..models import (
    Model,
    ModelRequestParameters,
    infer_model,
    parse_model_id,
)
from ..models._speech import assistant_speech_text
from ..models.openai import (
    OpenAIResponsesModel,
    _map_api_errors as map_openai_api_errors,  # pyright: ignore[reportPrivateUsage]
    _map_reasoning_item as map_reasoning_item,  # pyright: ignore[reportPrivateUsage]
    _map_usage as map_openai_usage,  # pyright: ignore[reportPrivateUsage]
    _map_web_search_tool_call as map_web_search_tool_call,  # pyright: ignore[reportPrivateUsage]
    _map_web_search_tool_param as map_web_search_tool_param,  # pyright: ignore[reportPrivateUsage]
    _resolve_openai_thinking_effort,  # pyright: ignore[reportPrivateUsage]
    _uploaded_file_to_response_content,  # pyright: ignore[reportPrivateUsage]
)
from ..native_tools import AbstractNativeTool, WebSearchTool
from ..profiles.openai import OpenAIModelProfile, openai_model_profile
from ..providers import Provider, infer_provider
from ..providers.gateway import normalize_gateway_provider
from ..tools import ToolDefinition
from ..usage import RequestUsage
from ._inferred_lifecycle import InferredLifecycle
from ._lifecycle import AnswersRevised, InputId, LifecycleEvent, RealtimeFrame, ResponseStatus, ToolCallsAbandoned
from ._openai_protocol import (
    AUTO_TRANSCRIPTION_MODEL,
    RealtimeHandshakeError,
    _without_media as without_media,  # pyright: ignore[reportPrivateUsage]
    expect_event,
    map_connect_errors,
    openai_websocket_auth_headers,
    realtime_websocket_url,
    tool_choice_config,
)
from ._openai_webrtc import HANG_UP_MAX_RETRIES, HANG_UP_TIMEOUT, ignore_ended_call
from ._utils import (
    DEFAULT_MAX_RECONNECTS,
    SystemPromptText,
    inject_trace_context,
    reconnect_with_backoff,
    resolve_advertised_tools,
    seed_retry_feedback_text,
    session_instructions,
    wrap_seeded_system_prompts,
)
from .codec import (
    AudioDelta,
    CancelResponse,
    ClearAudio,
    CommitAudio,
    CreateResponse,
    InputTranscript,
    OutputTranscript,
    RealtimeCodecEvent,
    RealtimeConnection,
    RealtimeInput,
    ResponseDone,
    SessionUsage,
    TextContext,
    ToolCall,
    ToolResult,
    TruncateOutput,
)
from .model import RealtimeClientSecret, RealtimeModel, RealtimeProviderSession, WebRTCAnswer, WebRTCSession
from .profiles import RealtimeModelProfileSpec
from .settings import RealtimeModelSettings, ReconnectPolicy

try:
    import tiktoken
    import websockets
    from openai import AsyncOpenAI
    from openai.types.live import (
        DataChannelConfigParam,
        DelegationCreatedEvent,
        ErrorEvent,
        InputTranscriptDeltaEvent,
        OutputAudioDeltaEvent,
        OutputTranscriptDeltaEvent,
        ResponseEvent,
        SessionClosedEvent,
        SessionStartedEvent,
        SessionUsageUpdatedEvent,
    )
    from openai.types.live.media_session_config_param import MediaSessionConfigParam
    from openai.types.responses import (
        Response,
        ResponseCompletedEvent,
        ResponseErrorEvent,
        ResponseFailedEvent,
        ResponseFunctionToolCall,
        ResponseFunctionWebSearch,
        ResponseIncompleteEvent,
        ResponseInputFileContentParam,
        ResponseInputImageContentParam,
        ResponseInputTextContentParam,
        ResponseOutputItemDoneEvent,
        ResponseReasoningItem,
        ResponseStreamEvent,
    )
    from openai.types.shared import ReasoningEffort
    from websockets.asyncio.client import ClientConnection
except ImportError as _import_error:  # pragma: no cover
    raise ImportError(
        'Please install `openai>=3.12` and `websockets` to use the OpenAI GPT-Live model, '
        'you can use the `openai-realtime` optional group — `pip install "pydantic-ai-slim[openai-realtime]"`'
    ) from _import_error

__all__ = (
    'OpenAILiveModel',
    'OpenAILiveConnection',
    'OpenAILiveModelSettings',
    'OpenAILiveResponsesDelegation',
    'LatestOpenAILiveModelNames',
    'OpenAILiveModelName',
)

LatestOpenAILiveModelNames = Literal['gpt-live-1']
"""Latest OpenAI GPT-Live model names."""

OpenAILiveModelName = str | LatestOpenAILiveModelNames
"""Possible OpenAI GPT-Live model names.

Since OpenAI supports a variety of date-stamped models, we explicitly list the latest models but
allow any name in the type hints.
"""

DEFAULT_TURN_SILENCE_MS = 2_000
"""How long the model must stay quiet before a turn is considered complete.

Matches the `assistant_silence_ms` default of OpenAI's own `TranscriptGrouper`, which solves the same
problem for display transcripts.
"""

AUTO_BACKEND_MODEL = 'gpt-6-sol'
"""What a backend model of `'auto'` resolves to: the Responses model Pydantic AI currently recommends.

Used when nothing names one: not `openai_live_delegation`, not the model name, and not the agent. It
moves with new OpenAI models, so pin a backend explicitly when its behavior needs to stay put.
"""

_LIVE_WEBSOCKET_PATH = 'live/sessions'
_SESSION_STARTED_EVENT = 'session.started'
#: The loudest 16-bit sample an output frame can hold and still count as the idle track (about
#: -54 dBFS). Live's idle track is not always exact zeros: every session opens with a frame or two of
#: dither peaking around 20, and treating that as speech would open a reply nobody is giving.
_VOICE_FLOOR = 64

#: How much quiet audio after the model's voice is still forwarded as a pause, in milliseconds of audio.
#: Live's track never stops, so past this the quiet is treated as the gap between chunks every other
#: provider leaves: otherwise each reply would end with the whole turn-silence wait of silence, and a
#: tool call's quiet wait would arrive as a spoken part with nothing in it.
_MAX_FORWARDED_PAUSE_MS = 500

#: The most tokens Live accepts in one `session.thinking.append`.
_CONTEXT_TOKEN_LIMIT = 500
#: The tokenizer Live counts that limit in. Checked live: 500 `o200k_base` tokens are accepted, 501 refused.
_CONTEXT_ENCODING = 'o200k_base'
#: How a user's typed turn is put to Live as silent context, while the backend gets it as the user's message.
_TYPED_TEXT_PREFIX = 'The user typed: '

#: The most history items and tokens a session can start with (checked live: 129 items, or 20 items of 422
#: tokens, are refused). Each item costs a few tokens beyond its text: 20 items of 402 text tokens start.
_SEED_ITEM_LIMIT = 128
_SEED_TOKEN_LIMIT = 8192
_SEED_ITEM_TOKEN_OVERHEAD = 8

#: The Responses model kinds whose `Model.system` is `'openai'`: the only agent models that can be a backend.
_OPENAI_MODEL_KINDS = frozenset({'openai', 'openai-chat', 'openai-responses'})

#: How Live's top-level errors that end a delegated handoff begin (`Responses handoff incomplete.`, recorded
#: live). The frame names no delegation, so this is what says delegated work ended.
_HANDOFF_FAILURE_PREFIX = 'Responses handoff'

_ActedOnEvent = Annotated[
    OutputAudioDeltaEvent
    | OutputTranscriptDeltaEvent
    | InputTranscriptDeltaEvent
    | DelegationCreatedEvent
    | ResponseEvent
    | SessionUsageUpdatedEvent
    | SessionClosedEvent
    | ErrorEvent,
    Field(discriminator='type'),
]
#: The Live server events the connection acts on. Every other type, including ones this version of the SDK
#: doesn't know, is a notice or an acknowledgement that changes nothing the session has said or heard.
_ACTED_ON_EVENT_TYPES = frozenset(
    {
        'session.output_audio.delta',
        'session.output_transcript.delta',
        'session.input_transcript.delta',
        'session.delegation.created',
        'response.event',
        'session.usage.updated',
        'session.closed',
        'error',
    }
)
_acted_on_event_adapter: TypeAdapter[_ActedOnEvent] = TypeAdapter(_ActedOnEvent)
_json_object_adapter: TypeAdapter[dict[str, Any]] = TypeAdapter(dict[str, Any])


class _LiveErrorDetails(TypedDict):
    message: str
    code: str | None


class _LiveErrorFrame(TypedDict):
    type: Literal['error']
    error: _LiveErrorDetails


# OpenAI's guide says to expect `error` frames whose `code` is null, but the SDK's `Error.code` is a
# required `str`, so those fail `ServerEvent` validation. This narrower shape still parses them.
_live_error_adapter: TypeAdapter[_LiveErrorFrame] = TypeAdapter(_LiveErrorFrame)


class _LiveSessionClosedFrame(TypedDict):
    reason: str


class _LiveSessionUsage(TypedDict):
    seconds: float


# The two fields of `session.closed` the connection reads, each validated on its own, so a frame whose
# other fields have drifted from the SDK's shape still says why the session ended and, while its usage
# still parses, records the final usage.
_live_session_closed_adapter: TypeAdapter[_LiveSessionClosedFrame] = TypeAdapter(_LiveSessionClosedFrame)
_live_session_usage_adapter: TypeAdapter[_LiveSessionUsage] = TypeAdapter(_LiveSessionUsage)

#: Why a session ends as an ordinary end of the call. Any other reason, `expired`, `content` and
#: `connection_lost` or one this version doesn't know, means it ended without anyone asking.
_NORMAL_CLOSE_REASONS = frozenset({'close_requested', 'remote_hangup'})

#: How long `send_audio()` must be quiet before the connection streams silence in its place, in seconds.
_IDLE_AUDIO_GAP = 0.3
#: How much silence each idle frame carries, in seconds: the 100 ms frames a microphone would send.
_IDLE_AUDIO_FRAME = 0.1

#: The ones a reconnect policy recovers from. A session the safety filter ended stays ended.
_RECONNECTABLE_CLOSE_REASONS = frozenset({'expired', 'connection_lost'})

#: What a WebRTC browser may do over its data channel unless `openai_live_data_channel` says otherwise:
#: nothing, since the sideband runs the session.
_CLOSED_DATA_CHANNEL: DataChannelConfigParam = {'allowed_client_events': [], 'allowed_server_events': []}

#: The PCM16 sample rates Live accepts. (It also takes 8 kHz G.711, which isn't PCM16.)
_LIVE_PCM_RATES = frozenset({16000, 24000})
_response_stream_event_adapter: TypeAdapter[ResponseStreamEvent] = TypeAdapter(ResponseStreamEvent)
#: Nested events the codec acts on. One of these that doesn't parse is a malformed frame, reported as
#: recoverable; any other nested type that doesn't parse is one this SDK doesn't know yet, and ignored.
_ACTED_ON_DELEGATED_RESPONSE_EVENTS = frozenset(
    {'response.completed', 'response.failed', 'response.incomplete', 'response.output_item.done'}
)


class OpenAILiveResponsesDelegation(TypedDict, total=False):
    """Settings for the Responses backend a Live session delegates work to.

    The Live model runs the conversation; the backend model does the reasoning and calls the agent's
    tools. OpenAI's prompting guide asks for the two prompts to stay separate, and Pydantic AI keeps
    them separate by construction: the agent's instructions become the *backend* prompt, because they
    describe the work, while `live_instructions` describes how to speak.
    """

    model: str
    """The Responses model that handles delegated work.

    When unset, the backend is, first match wins: the model named after a `+` in the Live model name
    (`'gpt-live-1+gpt-5.6-sol'`); the agent's own model, when it is an OpenAI model reached the same way
    as the Live model (directly, or through the same gateway route); then `'auto'`, which resolves to
    [`AUTO_BACKEND_MODEL`][pydantic_ai.realtime.openai_live.AUTO_BACKEND_MODEL]. There is always a
    backend, so nothing raises for want of one.
    """
    instructions: str
    """Extra backend instructions, appended after the agent's own instructions."""
    max_output_tokens: int
    """Maximum output tokens per delegated response."""
    parallel_tool_calls: bool
    """Whether the backend may request several tool calls in one response.

    Defaults to the shared [`parallel_tool_calls`][pydantic_ai.realtime.RealtimeModelSettings.parallel_tool_calls]
    setting, since the backend is what calls the tools."""
    reasoning_effort: Literal['none', 'minimal', 'low', 'medium', 'high', 'xhigh']
    """Reasoning effort for the backend model.

    Takes precedence over the shared [`thinking`][pydantic_ai.realtime.RealtimeModelSettings.thinking]
    setting, which otherwise sets the backend's effort the way it would on a direct Responses request to
    that model."""
    reasoning_summary: Literal['detailed', 'concise', 'auto']
    """A summary of the backend model's reasoning, as
    [`openai_reasoning_summary`][pydantic_ai.models.openai.OpenAIResponsesModelSettings.openai_reasoning_summary]
    requests on a direct Responses request.

    The reasoning recorded ahead of a web search the backend runs then carries the summary, where the
    backend wrote one, as its [`ThinkingPart`][pydantic_ai.messages.ThinkingPart] content. Check the
    [OpenAI Reasoning documentation](https://platform.openai.com/docs/guides/reasoning?api-mode=responses#reasoning-summaries)
    for more details."""
    verbosity: Literal['low', 'medium', 'high']
    """How much detail the backend generates. Does not affect the Live model's spoken delivery."""
    service_tier: Literal['auto', 'default', 'flex', 'priority']
    """Service tier for delegated Responses requests."""


class OpenAILiveModelSettings(RealtimeModelSettings, total=False):
    """Settings for OpenAI GPT-Live sessions.

    See [`RealtimeModelSettings`][pydantic_ai.realtime.RealtimeModelSettings] for the shared settings.
    Live has no turn-detection, truncation, token-limit, or temperature controls: it owns turn-taking
    entirely, and voice, audio format and instructions are immutable once the session has started.
    """

    openai_voice: str
    """The voice used for Live speech, e.g. `marin` (the provider default). Immutable after startup."""

    openai_live_instructions: str
    """Instructions for the Live model's *spoken* behavior: voice, pacing, interruptions, and when to
    delegate.

    The agent's own instructions describe the work and become the backend prompt, so this is where
    conversational style belongs. Defaults to a short prompt that tells the model to delegate
    anything it can't answer from the conversation itself."""

    openai_live_delegation: OpenAILiveResponsesDelegation
    """Configuration for the Responses backend the Live session delegates work to."""

    openai_live_turn_silence_ms: int
    """How long the model must stay quiet, in milliseconds, before the session reports the turn
    complete. Defaults to 2000.

    Live has no end-of-turn frame, so this threshold *is* the turn boundary. Lower it for snappier
    turn-taking at the risk of ending a turn during a dramatic pause; raise it when replies contain
    long silences."""

    openai_live_store: bool
    """Whether OpenAI stores the session so it can later be forked or downloaded. Defaults to `False`.

    With a [`reconnect`][pydantic_ai.realtime.RealtimeModelSettings.reconnect] policy, a stored session
    that drops is forked, so the new one has the whole conversation. An unstored one is replaced by a new
    session seeded with the text of the history so far."""

    openai_live_idle_audio: bool
    """Whether to stream silence to Live while the application sends no audio. Defaults to `False`.

    Live only speaks while its timeline advances, which takes audio: without it, a typed turn still runs the
    backend (and its tools), but nothing is said until audio flows again. With this on, the session streams silence in real time
    whenever `send_audio()` has been quiet for a moment, and stops as soon as the application sends
    audio again, so a text-only session works. Live bills the audio it receives by the second, silence
    included, so this bills the whole time the session is open."""

    openai_live_data_channel: DataChannelConfigParam
    """Which Live events the browser on a [WebRTC call](https://pydantic.dev/docs/ai/realtime/openai#browser-webrtc)
    may send and receive over its data channel.

    Defaults to none either way. The browser holds only the media: the server's sideband runs the session,
    and an open channel would let the browser change the conversation (by appending instructions or
    context) and read what the sideband sees, starting with the backend's instructions and tool
    definitions in `session.started`. Allow specific events, such as `session.output_transcript.delta` for
    live captions, when the browser needs them. The sideband is never restricted, and a WebSocket
    session has no data channel, so this applies only to
    [`answer_webrtc_offer`][pydantic_ai.realtime.openai_live.OpenAILiveModel.answer_webrtc_offer]."""


DEFAULT_LIVE_INSTRUCTIONS = (
    'You are a voice assistant. Keep replies short and conversational. '
    'When the user asks for something you cannot answer from this conversation alone, delegate the '
    'task and tell them you are looking it up.'
)


def tool_def_to_live(tool: ToolDefinition) -> dict[str, Any]:
    """Convert a [`ToolDefinition`][pydantic_ai.tools.ToolDefinition] to a Live backend function tool."""
    result: dict[str, Any] = {
        'type': 'function',
        'name': tool.name,
        'parameters': tool.parameters_json_schema,
    }
    if tool.description:
        result['description'] = tool.description
    if tool.strict is not None:
        result['strict'] = tool.strict
    return result


_SeedRole = Literal['user', 'assistant']


def _seed_item(role: _SeedRole, text: str) -> dict[str, Any] | None:
    """One Live history item, or `None` when there is no text worth seeding."""
    if not (text := text.strip()):
        return None
    content_type = 'output_text' if role == 'assistant' else 'input_text'
    return {'role': role, 'content': [{'type': content_type, 'text': text}]}


def _seed_request_part(part: ModelRequestPart, *, provider_name: str) -> tuple[_SeedRole, str] | None:
    """The role and text a request part seeds as, or `None` when it carries nothing replayable.

    The standing system prompt is routed through `instructions` instead, exactly as on the Realtime
    protocol, and `seed_input_items` has already turned a later one into `<system>`-tagged user text.
    A tool result becomes user-level text because Live has nowhere to put a function part in seeded
    history, and not a developer note: its content comes from whatever the tool read, which must not
    be replayed with more authority than it had as a tool result.
    """
    # TODO(v3): remove `RetryPromptPart`. Translated ahead of the branches rather than inside one of
    # them, so a tool-bound legacy retry seeds through the `ToolReturnPart` branch below and reads
    # exactly like the retried return the framework emits for the same failure.
    if isinstance(part, RetryPromptPart):  # pyright: ignore[reportDeprecated]
        part = _translate_legacy_retry_part(part)
    if isinstance(part, UserPromptPart):
        return 'user', _prompt_text(part, provider_name=provider_name)
    if isinstance(part, SpeechPart):
        return 'user', part.transcript or ''
    if isinstance(part, ToolReturnPart):
        # A retried call's content is wrapped in an `{"error": ...}` object, so without it the
        # `ToolCallPart` before it would not read as a round that failed.
        return 'user', f'Result of `{part.tool_name}`: {part.model_response_str()}'
    if isinstance(part, RetryFeedbackPart):
        return 'user', seed_retry_feedback_text(part)
    return None


def _seed_response_part(message: ModelResponse, index: int) -> tuple[_SeedRole, str] | None:
    """The role and text the part at `index` of `message` seeds as, or `None` when it carries nothing replayable.

    Thinking is bound to the session that produced it: its text is replayable, its signature is not. Speech is
    its transcript, marked where a barge-in cut it off.
    """
    part = message.parts[index]
    if isinstance(part, TextPart):
        return 'assistant', part.content
    if isinstance(part, SpeechPart):
        return 'assistant', assistant_speech_text(message, index) if part.transcript else ''
    if isinstance(part, ThinkingPart):
        return 'assistant', part.content
    if isinstance(part, ToolCallPart):
        return 'assistant', f'Called `{part.tool_name}` with {part.args_as_json_str()}.'
    return None


def seed_input_items(messages: Sequence[ModelMessage], *, provider_name: str) -> list[dict[str, Any]]:
    """Map prior history to Live's startup `input` list.

    Live seeds from text only: user and assistant messages with one text part each. Tool
    rounds are rendered as readable text because the protocol has no place to put function parts in
    seeded history. Audio, images, and other media
    cannot be seeded at all, and the profile says so, which is what makes the session reject them
    before we get here.
    """
    items: list[dict[str, Any]] = []
    for message in wrap_seeded_system_prompts(messages):
        if isinstance(message, ModelRequest):
            seeded_parts = [_seed_request_part(part, provider_name=provider_name) for part in message.parts]
        else:
            seeded_parts = [_seed_response_part(message, index) for index in range(len(message.parts))]
        for seeded in seeded_parts:
            if seeded is not None and (item := _seed_item(*seeded)) is not None:
                items.append(item)
    return items


def _prompt_text(part: UserPromptPart, *, provider_name: str) -> str:
    """Extract the seedable text of a user prompt, refusing media Live cannot carry."""
    if isinstance(part.content, str):
        return part.content
    texts: list[str] = []
    for item in part.content:
        if isinstance(item, str):
            texts.append(item)
        elif isinstance(item, TextContent):
            texts.append(item.content)
        else:
            raise UserError(
                f'{provider_name} GPT-Live sessions can only be seeded with text: '
                f'{type(item).__name__} cannot be replayed into a Live session. '
                'Strip non-text content from `message_history`, or summarize it as text.'
            )
    return '\n'.join(texts)


async def replay_input_items(messages: Sequence[ModelMessage], *, provider_name: str) -> list[dict[str, Any]]:
    """Map a session's own history to the `input` of the Live session that replaces it after a drop.

    Unlike seeding a new session, nothing here is the caller's to fix, so nothing raises: media is left
    out, and a long call is cut to its most recent end within Live's seeding caps rather than refused.
    """
    replayable = [replayable for message in messages if (replayable := without_media(message)) is not None]
    items = seed_input_items(replayable, provider_name=provider_name)
    if not items:
        # Nothing to cut to the caps: the redial needn't wait for the tokenizer to load (seconds, on first use).
        return []
    encoding = await _utils.run_in_executor(tiktoken.get_encoding, _CONTEXT_ENCODING)
    kept: list[dict[str, Any]] = []
    tokens = 0
    for item in reversed(items):
        text = item['content'][0]['text']
        cost = len(encoding.encode(text, allowed_special='all')) + _SEED_ITEM_TOKEN_OVERHEAD
        if cost > _SEED_TOKEN_LIMIT:
            # One message too long to seed on its own shouldn't cost the rest of the call.
            continue
        if tokens + cost > _SEED_TOKEN_LIMIT:
            break
        tokens += cost
        kept.append(item)
        if len(kept) == _SEED_ITEM_LIMIT:
            break
    return kept[::-1]


_LiveDial = Callable[[str | None, list[dict[str, Any]]], Awaitable[tuple['ClientConnection', str | None]]]
"""Open a replacement Live session: fork the stored session with this id, or else start one seeded with these items.

Returns the new socket and the new session's id.
"""


@dataclass
class _SessionEnd:
    """How far Live's session has ended, kept in one place so a replacement session starts from a fresh one."""

    ended: bool = False
    """Whether `session.closed` arrived, or the socket closed cleanly: there is nothing left to ask Live for."""

    unclaimed: list[SessionUsage] = field(default_factory=list[SessionUsage])
    """The final usage `session.closed` reported, until it has been yielded, so a session that stops reading in
    between still gets it from `_end_session()`."""


@dataclass
class _Delegation:
    """A unit of work the Live model handed to the Responses backend."""

    id: str
    pending_tool_calls: set[str] = field(default_factory=set[str])
    response_in_flight: bool = True
    """Whether a backend response is running: the one that opened the delegation, or a continuation.

    Only that response's terminal event says every call it will make has been asked for. With parallel
    tool calls a result can come back before the next call does, so answering every call seen so far
    is not yet a reason to continue.
    """
    continuation_due: bool = False
    """Every call seen so far is answered, but the response that asked for them is still running.

    The continuation waits for its terminal, then goes out from the receive loop.
    """
    stalled: bool = False
    """A call it asked for settled without a result (a usage limit stopped it), so it can never be continued.

    The backend resumes only from every output of its round, so it is given up as one that failed would be,
    at once or, while a response is still running, at that response's terminal.
    """


class _LiveLifecycle(InferredLifecycle):
    """GPT-Live's inferred lifecycle.

    Live transcribes the user as they speak, so words over a reply are reported while it goes on, and its output is
    a continuous audio track, silent between replies: the connection says where the model takes the turn instead
    (`turn_taken`).

    A text turn runs the backend, and Live takes it up as it opens the delegation that answers it
    (`session.delegation.created`), in the speech under way, if any, rather than in a reply of its own: text taken up
    while a reply goes on is answered by that reply once it says anything more (`AnswersRevised.claimed`), and by the
    next reply otherwise.

    The tool calls a delegated backend response asks for are the reply's, but the reply doesn't end with them: Live
    goes on speaking while the backend waits for their results ("Okay, checking the forecast ... now."), and only the
    backend's answer is what it says with them in hand. So a reply that called tools goes on until a delegation
    settles (`delegation_settled()`), with what Live says meanwhile, or until the backend calls more tools in a
    continuation, which are a response of their own, after the results it was continued with, as in a standard run.
    Any delegation settling ends it, not only the one that asked for its calls: what Live says next is that
    delegation's outcome, which is a reply of its own.
    """

    transcripts_lag_replies = False
    audio_starts_response = False

    def __init__(self) -> None:
        super().__init__()
        self.turn_taken = False
        """The provider message being mapped has the model take the turn (see `_open_response()`)."""
        self._taken_up_text: list[InputId] = []
        """Text Live took up while the reply under way goes on, which its next output answers."""
        self._round_reported = False
        """The backend response that asked for the open response's tool calls reported its usage: it is over, and a
        call that comes now is a continuation's."""
        self._settles = False
        """The provider message being mapped settles a delegation, whichever one the open response's calls came from."""

    def takes_turn(self, codec: Sequence[RealtimeCodecEvent]) -> bool:
        took_turn, self.turn_taken = self.turn_taken, False
        return took_turn

    def frame_for(self, codec: Sequence[RealtimeCodecEvent]) -> RealtimeFrame:
        try:
            return super().frame_for(codec)
        finally:
            self._settles = False

    def delegation_settled(self) -> None:
        """The provider message being mapped settles a delegation: it owes nothing more.

        Its backend usage report ends the open response, if that called tools (of this delegation or another one still
        owed its results): what Live says next is the settled delegation's outcome, a reply of its own.
        """
        self._settles = True

    def _event(
        self, event: RealtimeCodecEvent, *, takes_turn: bool = False
    ) -> tuple[list[LifecycleEvent], list[LifecycleEvent]]:
        if not (isinstance(event, SessionUsage) and event.response_scoped and self._calls_awaiting_usage):
            return super()._event(event, takes_turn=takes_turn)
        # A delegated backend response is over. The reply that called the tools goes on, unless this settles them.
        before: list[LifecycleEvent] = []
        after: list[LifecycleEvent] = []
        if not self._settles:
            self._round_reported = True
            return before, after
        self._settles = False
        ended = self._open
        # The usage is the reply's if the backend response it reports asked for the reply's calls, and otherwise
        # the answer's (which it then waits for, as usage between responses does).
        self._end(before if self._round_reported else after, status='completed', finish_reason='tool_call')
        self._ended_by_usage = ended
        return before, after

    def calls_abandoned(self, call_ids: Sequence[str]) -> None:
        """The delegated backend that asked for these calls gave up: no reply will answer their results."""
        self._pending.append(ToolCallsAbandoned(tool_call_ids=tuple(call_ids)))

    def text_taken_up(self, input_id: InputId) -> None:
        """Live took up a text input, opening the delegation that answers it where the conversation now is."""
        if self._open is not None and input_id in self._unanswered:
            self._taken_up_text.append(input_id)

    def _output(self, event: RealtimeCodecEvent, before: list[LifecycleEvent], after: list[LifecycleEvent]) -> None:
        if isinstance(event, ToolCall) and self._round_reported and self._open is not None:
            # A continuation's call, made with the results of the open response's: a response of its own.
            self._end(before, status='completed', finish_reason='tool_call')
        super()._output(event, before, after)
        if (response_id := self._open) is not None and (claimed := tuple(self._taken_up_text)):
            # The reply goes on past the text: Live speaks to it here, not in a reply of its own.
            self._taken_up_text.clear()
            self._unanswered = [input_id for input_id in self._unanswered if input_id not in claimed]
            before.append(AnswersRevised(response_id=response_id, claimed=claimed))

    def _end(
        self,
        events: list[LifecycleEvent],
        *,
        status: ResponseStatus,
        finish_reason: FinishReason | None = None,
        provider_details: dict[str, Any] | None = None,
    ) -> None:
        # Text the reply never spoke past is the next reply's to answer.
        self._taken_up_text.clear()
        self._round_reported = False
        super()._end(events, status=status, finish_reason=finish_reason, provider_details=provider_details)


class OpenAILiveConnection(RealtimeConnection):
    """A live WebSocket connection to the OpenAI GPT-Live API.

    Translates Live's session-timeline events into the shared codec vocabulary, including the two
    boundaries Live itself never sends: the end of the user's turn and the end of the model's reply.

    Live streams output audio as a continuous telephony-style track — ten 100 ms frames a second for
    as long as the session is open, digitally silent when the model isn't speaking. So a frame
    arriving means nothing about whether anyone is talking, and *voice* (a transcript fragment or a
    non-silent audio frame) is what drives the turn clock.
    """

    transport_errors: ClassVar[tuple[type[Exception], ...]] = (websockets.WebSocketException, OSError)

    def __init__(
        self,
        ws: ClientConnection,
        *,
        model_name: str | None = None,
        backend_model: str | None = None,
        turn_silence_ms: int = DEFAULT_TURN_SILENCE_MS,
        audio_rate: int = 24000,
        provider_name: str = 'openai',
        provider_url: str = '',
        idle_audio: bool = False,
        forwards_output_audio: bool = True,
        session_id: str | None = None,
        dial: _LiveDial | None = None,
        reconnect: ReconnectPolicy | None = None,
        forks: bool = False,
    ) -> None:
        self._ws = ws
        self._idle_audio = idle_audio
        # Re-opening the session after a drop: by forking it, which Live can only do for a stored
        # session, or else by starting a new one seeded with the history so far.
        self._session_id = session_id
        self._dial = dial
        self._reconnect = reconnect
        self._forks = forks
        self._message_history: Callable[[], Sequence[ModelMessage]] | None = None
        self._reconnects_used = 0
        self._gave_up = False
        # Live said the session is ending (expired, or lost on its side): the clean close that follows is a drop.
        self._redial_on_close = False
        # Whether the last reconnect carried the conversation over: by fork, or by replaying the history.
        self._restored = False
        # A WebRTC sideband sees the call's output audio too, but the browser is what plays it, so it
        # only drives the turn clock here.
        self._forwards_output_audio = forwards_output_audio
        self._model_name = model_name
        self._backend_model = backend_model
        self._provider_name = provider_name
        self._provider_url = provider_url
        self._turn_silence = turn_silence_ms / 1000
        self._audio_bytes_per_ms = audio_rate * 2 / 1000
        self._recv_task: asyncio.Task[str | bytes] | None = None
        self._closed = False
        self._response_open = False
        self._input_open = False
        self._last_voice = 0.0
        # Quiet audio since the model's voice last sounded in this reply, measured by its length rather
        # than when it arrived, or `None` when there is no reply for a pause to continue.
        self._pause_ms: float | None = None
        # The last transcript fragment in each direction, for the space Live leaves out between segments.
        self._last_fragment: dict[Literal['input', 'output'], str] = {'input': '', 'output': ''}
        # Where on the session timeline the user's transcript last ended.
        self._last_input_end_ms: int | None = None
        self._delegations: dict[str, _Delegation] = {}
        self._call_delegations: dict[str, str] = {}
        # Calls a delegation asked for before its backend gave up. The session still runs them and
        # sends their results; those must go nowhere, not restart a response the backend abandoned.
        self._abandoned_calls: set[str] = set()
        # Delegations whose results all came back before the response that asked for them ended. Their
        # continuations go out from the receive loop, which is where that terminal is seen.
        self._continuations_due: list[_Delegation] = []
        # Calls asked for and not answered yet, which a replacement session wouldn't know.
        self._open_calls: set[str] = set()
        self._reported_seconds = 0.0
        # The idle-audio pump, and where the application's audio ends on the pump's clock: audio sent in a
        # burst plays on Live's timeline for as long as it lasts, however quickly it was sent.
        self._idle_audio_task: asyncio.Task[None] | None = None
        self._input_audio_end = 0.0
        # Where all the audio sent so far, idle frames included, ends on the pump's clock. Application audio
        # sent right after an idle frame plays once that frame has.
        self._audio_end = 0.0
        self._next_idle_frame = 0.0
        # Counts the application's audio sends. Held with the lock around every audio send, it is how the
        # pump tells that the application spoke between its wait ending and its frame going out.
        self._input_audio_sends = 0
        self._audio_send_lock = anyio.Lock()
        self._session_end = _SessionEnd()
        # Numbers the native tool parts this connection reports; the session maps them to its own indexes.
        self._native_part_index = 0
        # The backend's reasoning since its last other output item, per delegation. A search replays into
        # the Responses API only with the reasoning item that led to it, so that is recorded with it.
        self._pending_reasoning: dict[str | None, list[ResponseReasoningItem]] = {}
        # Which response, user turn, and input each frame is about (see `frames()`). Live always
        # transcribes, and closes the user's turn as the model's reply starts.
        self._lifecycle = _LiveLifecycle()
        # The text turns Live hasn't opened a delegation for yet, by the `event_id` of the `response.create` that asked.
        self._unacknowledged_text: dict[str, InputId] = {}

    @property
    def model_name(self) -> str | None:
        return self._model_name

    @property
    def input_transcription_enabled(self) -> bool:
        """Live always transcribes both directions; there is no way to turn it off."""
        return True

    @property
    def reconnect_restores_in_flight_state(self) -> bool:
        """Neither way of re-opening a Live session carries on what was in flight.

        A fork has the conversation, but not the reply or the delegated work the drop cut off: it has no
        record of the tool calls that work asked for (checked live). A replacement session has only the
        history it was seeded with.
        """
        return False

    @property
    def _answers_tool_calls_per_response(self) -> bool:
        # The delegated backend resumes from all of a round's results together, with one `response.create`.
        return True

    @property
    def _sends_failed_tool_results(self) -> bool:
        # A round missing an output never continues, and Live can't cancel the delegation it is in: left so, Live
        # delegates nothing more for the rest of the session (checked live).
        return True

    @property
    def _transcribes_all_output(self) -> bool:
        # Live always transcribes its speech, but the transcript runs ahead of or behind the audio, so a delegated call
        # arriving between the two splits a piece of audio from its words (checked live).
        return True

    def _tool_call_unanswered(self, tool_call_id: str) -> None:
        self._open_calls.discard(tool_call_id)
        delegation_id = self._call_delegations.pop(tool_call_id, None)
        if (delegation := self._delegations.get(delegation_id) if delegation_id is not None else None) is None:
            return
        delegation.pending_tool_calls.discard(tool_call_id)
        delegation.stalled = True
        if not delegation.response_in_flight:
            # Settled outside any provider message, so no backend usage report follows to end the reply that called
            # the tools: the turn clock, which the delegation no longer holds, ends it.
            self._settle_delegation(delegation, gave_up=True, in_frame=False)

    def set_message_history(self, message_history: Callable[[], Sequence[ModelMessage]]) -> None:
        self._message_history = message_history

    @property
    def _can_reconnect(self) -> bool:
        return (
            not self._gave_up
            and self._dial is not None
            and self._reconnect is not None
            and self._reconnects_used < self._reconnect.get('max_reconnects', DEFAULT_MAX_RECONNECTS)
        )

    # --- sending ----------------------------------------------------------------------------------

    async def send(self, content: RealtimeInput) -> Sequence[LifecycleEvent]:
        with self._lifecycle.sending(content) as input_index:
            delivered = await self._send_input(content, input_index)
        if not delivered:
            # A tool result whose backend gave up on the call: nothing will reply to it.
            self._lifecycle.input_unanswerable(input_index)
        # Live acknowledges nothing: where the input joined the conversation, and that a result goes nowhere, are
        # known now.
        return self._lifecycle.take_pending()

    async def _send_input(self, content: RealtimeInput, input_index: InputId) -> bool:
        """Send one input; `False` if it goes nowhere."""
        if isinstance(content, str):
            # A user turn. Live has no user-message event of its own, so the text goes to the backend as the
            # user's message and the backend is run on it, the way Live takes typed input. Live itself hears what
            # was asked as silent context: without it, it often leaves a terse answer unsaid, not knowing the
            # question (checked live: a bare "20" was spoken in none of six runs without it, and all six with it).
            # The backend takes text of any length, so text too long for that context goes without it.
            # System-prompt text is the operator's, not the user's: Live hears it as it is (`<system>`-tagged), and
            # the backend as a developer message. Framed as typed, Live took it for something the caller had said
            # (checked live: asked to list what they had said, 5 of 5 runs included it, and none of 5 this way).
            operator = isinstance(content, SystemPromptText)
            thinking = content if operator else _TYPED_TEXT_PREFIX + content
            tells_live = await _context_tokens_over_cap(thinking) is None
            # Live opens the delegation that answers it under this id (`session.delegation.created`).
            event_id = f'pydantic_ai.text.{input_index}'
            self._unacknowledged_text[event_id] = input_index
            try:
                if tells_live:
                    await self._send_event(
                        {'type': 'session.thinking.append', 'delegation_id': None, 'content': thinking}
                    )
                await self._send_event(
                    {
                        'type': 'response.item.create',
                        'item': {
                            'type': 'message',
                            'role': 'developer' if operator else 'user',
                            'content': [_text_part(content)],
                        },
                    }
                )
                await self._send_event({'type': 'response.create', 'event_id': event_id})
            except BaseException:
                del self._unacknowledged_text[event_id]
                raise
            return True
        if isinstance(content, TextContext):
            # Context that `thinking` carries without prompting speech itself. The model may still
            # choose to mention it.
            await _check_context_length(content.text)
            await self._send_event({'type': 'session.thinking.append', 'delegation_id': None, 'content': content.text})
            return True
        if isinstance(content, ToolResult):
            return await self._send_tool_result(content)
        if isinstance(content, CreateResponse):
            # Reaches the connection only right after an image: the profile's
            # `image_input_requires_response` is what lets the session send one, and `create_response()`
            # itself still needs manual turn control. Running the backend on the queued image is the
            # response: Live opens a delegation for it and speaks the result.
            await self._send_event({'type': 'response.create'})
            return True
        if isinstance(content, (CommitAudio, ClearAudio, CancelResponse, TruncateOutput)):
            raise UserError(
                'OpenAI GPT-Live drives turn-taking itself: manual turn control, cancellation, and '
                'output truncation are not available.'
            )
        if isinstance(content, BinaryImage):
            # The voice model sees no images; the delegated backend does, as ordinary Responses input.
            await self._send_event(
                {
                    'type': 'response.item.create',
                    'item': {
                        'type': 'message',
                        'role': 'user',
                        'content': [{'type': 'input_image', 'image_url': content.data_uri}],
                    },
                }
            )
            return True
        async with self._audio_send_lock:
            self._input_audio_sends += 1
            booked = self._input_audio_end, self._audio_end
            self._input_audio_end = self._audio_end = (
                max(_pump_clock(), self._audio_end) + len(content.data) / self._audio_bytes_per_ms / 1000
            )
            try:
                await self._send_event({'type': 'session.input_audio.append', 'audio': _b64(content.data)})
            except asyncio.CancelledError:
                # Audio that never went out doesn't hold the idle frames back.
                self._input_audio_end, self._audio_end = booked
                raise
        return True

    def _start_idle_audio(self) -> None:
        """Stream silence whenever the application sends no audio, until the connection closes.

        Live's timeline only advances while audio arrives, so without this, text sent to a session whose
        microphone isn't streaming waits for audio that never comes.
        """
        if self._idle_audio_task is not None:
            return
        # Audio sent before the pump started still plays out first.
        self._input_audio_end = max(self._input_audio_end, _pump_clock())
        self._idle_audio_task = asyncio.create_task(self._pump_idle_audio(), name='openai-live-idle-audio')

    async def _pump_idle_audio(self) -> None:
        frame = _b64(bytes(int(self._audio_bytes_per_ms * _IDLE_AUDIO_FRAME * 1000) // 2 * 2))
        while True:
            sends = self._input_audio_sends
            await self._wait_for_idle_frame()
            async with self._audio_send_lock:
                if self._input_audio_sends != sends:
                    # The application sent audio after the wait ended: wait out a fresh quiet gap.
                    continue
                try:
                    await self._send_event({'type': 'session.input_audio.append', 'audio': frame})
                    self._audio_end = max(_pump_clock(), self._audio_end) + _IDLE_AUDIO_FRAME
                except self.transport_errors:
                    # The read loop reports the drop. While it can redial, the frames that follow go to
                    # the replacement socket; once it can't, there is nothing left to keep going.
                    if self._closed or self._gave_up or self._reconnect is None or self._dial is None:
                        return

    async def _wait_for_idle_frame(self) -> None:
        """Wait until the next frame of silence is due.

        Frames go out at a microphone's pace, and none until the application's own audio has been quiet
        for `_IDLE_AUDIO_GAP`: application audio arriving meanwhile pushes the next frame back.
        """
        while (delay := self._idle_frame_due() - _pump_clock()) > 0:
            # In short steps, so a schedule a redial cuts short (see `_forget_session_state`) takes effect.
            await asyncio.sleep(min(delay, _IDLE_AUDIO_FRAME))
        # Booked from now rather than from when it was due, so a stalled loop doesn't catch up with a
        # burst of frames that would run Live's timeline ahead of the clock.
        self._next_idle_frame = max(self._idle_frame_due(), _pump_clock()) + _IDLE_AUDIO_FRAME

    def _idle_frame_due(self) -> float:
        return max(self._next_idle_frame, self._input_audio_end + _IDLE_AUDIO_GAP)

    async def _send_tool_result(self, result: ToolResult) -> bool:
        """Return a tool result to the delegated Responses backend and let it continue; `False` if it goes nowhere."""
        # Mapped first: downloading media can wait, and the backend can give up on the call meanwhile,
        # which only the checks below, made after it, can see.
        follow_up = await _tool_result_follow_up(result, provider_name=self._provider_name)
        self._open_calls.discard(result.tool_call_id)
        delegation_id = self._call_delegations.pop(result.tool_call_id, None)
        if result.tool_call_id in self._abandoned_calls:
            # The backend that asked for this call gave up before it was answered. Sending the output
            # would attach it to nothing, and `response.create` would start a turn nobody asked for.
            self._abandoned_calls.discard(result.tool_call_id)
            return False
        delegation = self._delegations.get(delegation_id) if delegation_id is not None else None
        if delegation is not None:
            delegation.pending_tool_calls.discard(result.tool_call_id)
        await self._send_event(
            {
                'type': 'response.item.create',
                'item': {'type': 'function_call_output', 'call_id': result.tool_call_id, 'output': result.output},
            }
        )
        if follow_up is not None:
            await self._send_event({'type': 'response.item.create', 'item': follow_up})
        if delegation is None:
            # A call we can't correlate to a delegation has no response we can wait on, so continue now.
            await self._send_event({'type': 'response.create'})
            return True
        if delegation.pending_tool_calls:
            # With `parallel_tool_calls` the backend resumes from all of its calls' outputs together.
            return True
        if delegation.response_in_flight:
            # The response that asked for these calls may still ask for more: continue at its terminal.
            delegation.continuation_due = True
            return True
        await self._continue(delegation)
        return True

    async def _send_due_continuations(self) -> None:
        """Continue each delegation whose asking response just ended with every result already in."""
        while self._continuations_due:
            await self._continue(self._continuations_due.pop(0))

    async def _continue(self, delegation: _Delegation) -> None:
        """Resume a delegated response that has every tool result it asked for.

        A delegated response waiting on tool results does not resume on its own. The continuation is a
        response in flight like the first, which keeps the turn clock suspended until it lands.
        """
        delegation.response_in_flight = True
        delegation.continuation_due = False
        await self._send_event({'type': 'response.create'})

    async def _send_event(self, event: dict[str, Any]) -> None:
        await self._ws.send(to_json(event).decode())

    async def _end_session(self) -> AsyncIterator[SessionUsage]:
        """Send `session.close`, and read on until `session.closed` reports the session's final usage.

        Live reports its billed seconds only periodically while a session runs, so without this the seconds
        since the last report, all of them on a short call, would never be recorded. Called once the session
        has stopped iterating: the read left in flight then is picked up here, so no frame is lost.

        A backend response still finishing meanwhile has no reply left to land on: its report is yielded as
        it is, counted in the session's total (with the request it was) and attributed to no response.
        """
        if self._closed:
            return
        if self._session_end.ended:
            # Live already ended the session; its final usage is yielded unless the session already took it.
            unclaimed, self._session_end.unclaimed = self._session_end.unclaimed, []
            for report in unclaimed:
                yield report
            return
        if self._idle_audio_task is not None:
            # Silence after `session.close` would only be billed: Live answers it without audio flowing.
            await _utils.cancel_and_drain(self._idle_audio_task)
        await self._send_event({'type': 'session.close'})
        while not self._session_end.ended:
            read = self._recv_task if self._recv_task is not None else self._start_read()
            self._recv_task = None
            try:
                raw = await read
            except websockets.ConnectionClosedOK:
                self._session_end.ended = True
                break
            for event in self._map_frame(raw):
                if isinstance(event, SessionUsage):
                    yield event
            # Any final usage `session.closed` held back was just yielded.
            self._session_end.unclaimed = []

    async def aclose(self) -> None:
        """Cancel the read in flight so closing the socket doesn't strand its exception."""
        self._closed = True
        task = self._recv_task
        self._cancel_read()
        if self._idle_audio_task is not None:
            await _utils.cancel_and_drain(self._idle_audio_task)
        if task is not None:
            with suppress(asyncio.CancelledError, websockets.WebSocketException):
                await task

    # --- receiving --------------------------------------------------------------------------------

    def _frame(self, codec: list[RealtimeCodecEvent]) -> RealtimeFrame:
        """One frame's codec events, with the lifecycle events around them."""
        return self._lifecycle.frame_for(codec)

    async def frames(self) -> AsyncIterator[RealtimeFrame]:  # noqa: C901
        # One read is always in flight: the next one starts before this frame is handled, so nothing
        # arrives while the consumer is busy and no frame is dropped between iterations.
        if self._idle_audio:
            self._start_idle_audio()
        pending = self._start_read()
        while True:
            # Never cancel the pending `recv()`: a cancelled read can drop the frame it already holds,
            # so the turn clock is a timeout on the wait rather than on the read.
            # A pump that failed before this wait would be left out of it.
            self._raise_if_idle_audio_failed()
            waiting: set[asyncio.Task[Any]] = {pending}
            if (pump := self._idle_audio_task) is not None and not pump.done():
                # A pump that fails wakes this wait, so its failure surfaces now rather than at the next frame.
                waiting.add(pump)
            done, _ = await asyncio.wait(waiting, timeout=self._silence_timeout(), return_when=asyncio.FIRST_COMPLETED)
            if self._closed:
                # `aclose()` cancelled the read while we were waiting on it.
                return
            self._raise_if_idle_audio_failed()
            if pending in done:
                finished, pending = pending, self._start_read()
                dropped: Exception | None = None
                try:
                    raw = finished.result()
                # A cancelled read is not caught here: `aclose()` sets `_closed` before cancelling,
                # so that path returns above rather than reaching this call.
                except websockets.ConnectionClosedOK as e:
                    if not self._redial_on_close:
                        # The read started above can no longer complete, and nothing will await it.
                        self._cancel_read()
                        # The session is over, so there is nothing left for `_end_session()` to ask Live for.
                        self._session_end.ended = True
                        # A graceful close ends whatever was in flight. Live never says a turn is over,
                        # so without this the last reply would be settled as interrupted even though the
                        # model had finished speaking and the session closed normally.
                        settled = self._frame(self._settle_open_turns())
                        yield [*settled, *self._lifecycle.connection_lost()]
                        return
                    dropped = e
                except self.transport_errors as e:
                    dropped = e
                else:
                    frame = self._frame(self._map_frame(raw))
                    for event in frame:
                        if isinstance(event, SessionUsage):
                            self._hand_over(event)
                    yield frame
                    try:
                        await self._send_due_continuations()
                    except self.transport_errors as e:
                        dropped = e
                if dropped is not None:
                    # Nothing under way on the dropped connection will finish, whether or not it is re-dialed.
                    lost: RealtimeFrame = [*self._lifecycle.connection_lost()]
                    if self._reconnect is None or self._dial is None:
                        # No reconnect policy: a dropped connection is fatal. Surface it as a non-recoverable
                        # error and end the stream, as the other providers do, rather than raising the
                        # `websockets` exception. The read started above is on the dead socket.
                        self._cancel_read()
                        error = RealtimeSessionErrorEvent(
                            message=f'OpenAI GPT-Live connection closed: {dropped}', recoverable=False
                        )
                        yield [*lost, error]
                        return
                    # The read started above is on the dead socket.
                    self._cancel_read()
                    reconnected = await self._try_reconnect()
                    lost += self._lifecycle.take_pending()
                    if not reconnected:
                        self._gave_up = True
                        error = RealtimeSessionErrorEvent(
                            message=f'OpenAI GPT-Live connection dropped; reconnect failed: {dropped}',
                            recoverable=False,
                        )
                        yield [*lost, error]
                        return
                    yield [*lost, RealtimeSessionReconnectEvent(state_restored=self._restored)]
                    pending = self._start_read()
                    continue
            # Checked after every frame, not just when the socket goes quiet: the idle audio track
            # keeps frames arriving, so a wait that returns is no evidence that anyone spoke.
            if expired := self._expire_quiet_turn():
                yield self._frame(expired)

    def _raise_if_idle_audio_failed(self) -> None:
        """Re-raise what stopped the idle-audio pump, rather than let the session go quietly deaf to text.

        A transport error isn't one: the read loop reports the drop, and the pump carries on past it to the
        replacement socket, or stops if there won't be one.
        """
        task = self._idle_audio_task
        if task is not None and task.done() and not task.cancelled() and (error := task.exception()) is not None:
            raise error

    async def _try_reconnect(self) -> bool:
        """Re-open the session with exponential backoff; return whether a replacement is connected."""
        assert self._reconnect is not None
        if not await reconnect_with_backoff(
            self._reconnect, self._attempt_reconnect, reconnects_used=self._reconnects_used
        ):
            return False
        self._reconnects_used += 1
        return True

    async def _attempt_reconnect(self) -> bool:
        assert self._dial is not None
        try:
            forked = False
            if self._forks and self._session_id is not None:
                try:
                    ws, session_id = await self._dial(self._session_id, [])
                    forked = True
                except RealtimeHandshakeError:
                    # Live refused to fork the session: carry the call on by replaying it instead.
                    ws, session_id = await self._dial(None, await self._replay_seed())
            else:
                ws, session_id = await self._dial(None, await self._replay_seed())
        except (websockets.WebSocketException, OSError, TimeoutError, RealtimeHandshakeError):
            # A failed dial, or a start Live refused: a later attempt may still succeed.
            return False
        self._ws = ws
        self._session_id = session_id
        # Like the gpt-realtime replay, a replay restores the call once a session has offered its history.
        self._restored = forked or self._message_history is not None
        self._redial_on_close = False
        self._forget_session_state()
        return True

    async def _replay_seed(self) -> list[dict[str, Any]]:
        history: Sequence[ModelMessage] = self._message_history() if self._message_history is not None else ()
        return await replay_input_items(history, provider_name=self._provider_name)

    def _forget_session_state(self) -> None:
        """Drop what only the lost session knew; the `RealtimeSession` settles the turn it cut off.

        The calls it asked for can't be answered on the new session, so their results go nowhere, and Live
        restarts its usage count and its timeline with each session.
        """
        self._response_open = False
        self._input_open = False
        self._pause_ms = None
        self._last_fragment = {'input': '', 'output': ''}
        self._last_input_end_ms = None
        self._abandoned_calls.update(self._open_calls)
        self._open_calls.clear()
        # (The connection's own drop handling settles the replies they asked for.)
        self._unacknowledged_text.clear()
        self._delegations.clear()
        self._call_delegations.clear()
        self._continuations_due.clear()
        self._reported_seconds = 0.0
        # Audio still booked to play on the lost session never will, so idle frames may start right away.
        self._input_audio_end = min(self._input_audio_end, _pump_clock())
        self._audio_end = min(self._audio_end, _pump_clock())
        self._next_idle_frame = 0.0
        # The new session hasn't ended: closing asks it to, and records the usage it reports then.
        self._session_end = _SessionEnd()

    def _hand_over(self, event: RealtimeCodecEvent) -> None:
        """Note that the session is being handed final usage `_end_session()` would otherwise yield.

        Handed over as it is yielded: a session that takes it records it before it can stop reading.
        """
        if isinstance(event, SessionUsage) and (unclaimed := self._session_end.unclaimed):
            self._session_end.unclaimed = [report for report in unclaimed if report is not event]

    def _start_read(self) -> asyncio.Task[str | bytes]:
        """Begin the next read, remembering it so it can be cancelled on the way out."""
        self._recv_task = asyncio.create_task(_recv(self._ws))
        return self._recv_task

    def _cancel_read(self) -> None:
        """Cancel the read in flight, if any, so it never completes unobserved."""
        if (task := self._recv_task) is not None:
            self._recv_task = None
            task.cancel()

    def _silence_timeout(self) -> float | None:
        """How long until the current turn could end, or `None` when nothing is pending.

        Delegated work suspends the clock: the model goes quiet while the backend thinks, and ending
        the turn there would finalize a reply that is still coming.
        """
        if self._delegations or not (self._response_open or self._input_open):
            return None
        return max(0.0, self._last_voice + self._turn_silence - _now())

    def _expire_quiet_turn(self) -> list[RealtimeCodecEvent]:
        """Close whichever turn is open once the session has been quiet long enough."""
        if (timeout := self._silence_timeout()) is None or timeout > 0:
            return []
        return self._settle_open_turns()

    def _settle_open_turns(self, *, interrupted: bool = False) -> list[RealtimeCodecEvent]:
        """Finalize whichever turns are open, in either direction."""
        events = self._close_input_turn()
        if self._response_open:
            self._response_open = False
            self._pause_ms = None
            self._last_fragment['output'] = ''
            events.append(ResponseDone(interrupted=interrupted))
        return events

    def _close_input_turn(self) -> list[RealtimeCodecEvent]:
        """Finalize the user's turn, which Live also never marks as done."""
        if not self._input_open:
            return []
        self._input_open = False
        self._last_fragment['input'] = ''
        return [InputTranscript('', is_final=True)]

    def _heard_voice(self) -> None:
        self._last_voice = _now()

    def _open_response(self) -> list[RealtimeCodecEvent]:
        """Note that the model is speaking, closing the user turn it is replying to."""
        self._heard_voice()
        events = self._close_input_turn()
        self._response_open = True
        # Its reply starts here, even with nothing of it to report: work it delegated, or speech a WebRTC
        # sideband doesn't forward.
        self._lifecycle.turn_taken = True
        return events

    def _map_frame(self, raw: str | bytes) -> list[RealtimeCodecEvent]:
        """Translate one frame, dispatching on its `type` before validating it, as the Realtime connection does.

        A frame the connection acts on that no longer matches the SDK's shape is reported as a recoverable
        error rather than dropped: dropping a drifted `session.closed` would lose the final usage and why
        the session ended, and a drifted `response.event` the delegated work. Any other type is ignored,
        known or not, so an event this version of the SDK doesn't know is not a reason to end the session.
        """
        if not isinstance(raw, str):
            # Live sends only text frames; skip anything else, as the Realtime connection does.
            return []
        try:
            data = _json_object_adapter.validate_json(raw)
            event_type = data.get('type')
            if not isinstance(event_type, str) or event_type not in _ACTED_ON_EVENT_TYPES:
                return []
            try:
                event = _acted_on_event_adapter.validate_python(data)
            except ValidationError as e:
                return self._map_drifted_event(event_type, data, e)
            return self._map_event(event)
        except ValueError as e:
            # Text that isn't a JSON object, or a well-formed event with a payload we can't decode (bad
            # base64 audio, say), costs that frame, not the call: report it as recoverable and keep
            # reading, as the Realtime connection does.
            return [RealtimeSessionErrorEvent(message=f'Failed to parse OpenAI GPT-Live event: {e}', recoverable=True)]

    def _map_drifted_event(
        self, event_type: str, data: dict[str, Any], error: ValidationError
    ) -> list[RealtimeCodecEvent]:
        """Salvage what the connection reads from an event that no longer matches the SDK's shape.

        OpenAI's guide says to expect `error` frames whose `code` is null, which the SDK's `Error.code`
        refuses. A `session.closed` is read for its reason and usage only, so it still ends the session
        the way its reason says, and is reported as well only if its usage is what drifted. Anything else
        that fails to validate is reported as a recoverable error naming its type.
        """
        parse_error = RealtimeSessionErrorEvent(
            message=f'Failed to parse OpenAI GPT-Live event: `{event_type}` {error}', recoverable=True
        )
        with suppress(ValidationError):
            if event_type == 'error':
                details = _live_error_adapter.validate_python(data)['error']
                return self._map_error(details['message'], code=details['code'])
            if event_type == 'session.closed':
                reason = _live_session_closed_adapter.validate_python(data)['reason']
                try:
                    seconds = _live_session_usage_adapter.validate_python(data.get('usage'))['seconds']
                except ValidationError:
                    return [parse_error, *self._map_session_closed(None, reason=reason)]
                return self._map_session_closed(seconds, reason=reason)
        return [parse_error]

    def _map_event(self, event: _ActedOnEvent) -> list[RealtimeCodecEvent]:
        """Translate one Live server event the connection acts on.

        Dispatch is on the parsed SDK types rather than the `type` string so each branch narrows to
        the payload it reads.
        """
        if isinstance(event, OutputAudioDeltaEvent):
            return self._map_output_audio(_b64decode(event.delta))
        if isinstance(event, OutputTranscriptDeltaEvent):
            return [*self._open_response(), OutputTranscript(self._fragment('output', event.delta))]
        if isinstance(event, InputTranscriptDeltaEvent):
            continues_closed_turn = (
                self._response_open
                and not self._input_open
                and self._last_input_end_ms is not None
                and event.start_ms <= self._last_input_end_ms
            )
            self._last_input_end_ms = event.end_ms
            if continues_closed_turn and not any(char.isalnum() for char in event.delta):
                # The tail of the user turn the reply already closed, picking up on the timeline where
                # that turn's transcript ended: Live transcribes the user's closing punctuation after the
                # model has started answering over it. That turn is already recorded, so there is
                # nothing to add it to, and opening a new one for a lone `'.'` would record it as a
                # request of its own.
                return []
            self._input_open = True
            self._heard_voice()
            return [InputTranscript(self._fragment('input', event.delta))]
        if isinstance(event, DelegationCreatedEvent):
            return self._map_delegation(event)
        if isinstance(event, ResponseEvent):
            return self._map_response_event(cast('dict[str, Any]', event.event), delegation_id=event.delegation_id)
        if isinstance(event, SessionUsageUpdatedEvent):
            context_window = event.context_window
            return self._map_usage(
                event.usage.seconds, context_window_used=context_window.usage_ratio if context_window else None
            )
        if isinstance(event, SessionClosedEvent):
            return self._map_session_closed(event.usage.seconds, reason=event.reason)
        if isinstance(event, ErrorEvent):
            return self._map_error(event.error.message, code=event.error.code)
        assert_never(event)

    def _fragment(self, direction: Literal['input', 'output'], delta: str) -> str:
        """One transcript fragment, with the space Live leaves out where a new segment starts.

        Fragments normally carry their own leading space, but the first one of a new segment doesn't,
        so a sentence that ends one segment runs into the next (`'up.'` then `"It's"`). Only a sentence
        end followed by a capital is taken as that boundary, which a word can't be split across.
        """
        previous, self._last_fragment[direction] = self._last_fragment[direction], delta
        if previous[-1:] in ('.', '!', '?') and delta[:1].isupper():
            return f' {delta}'
        return delta

    def _map_error(self, message: str, *, code: str | None) -> list[RealtimeCodecEvent]:
        """Report a top-level `error` frame, and settle whatever delegated work it ended.

        Live reports some backend failures only this way, with no nested terminal for the delegation:
        a backend that runs out of output tokens mid-handoff arrives as `Responses handoff incomplete.`,
        and a backend model that can't be used as one saying the model does not exist. The frame
        names no delegation, so a handoff failure is taken to have ended every backend response still in
        flight: leaving one open would suspend the turn clock for the rest of the session. Any other
        error is only reported, since nothing ties it to delegated work that may still complete.
        """
        if self._backend_model is not None and f'`{self._backend_model}`' in message:
            # Every delegation would fail the same way, so the session can't do the work it was set up
            # for: end it with a reason rather than let each request fail on its own.
            return [
                RealtimeSessionErrorEvent(
                    message=(
                        f'The OpenAI GPT-Live session cannot delegate to its backend model '
                        f'{self._backend_model!r}: {message} Name a Responses model this account can use '
                        "in `openai_live_delegation={'model': ...}`."
                    ),
                    code='live_backend_model_unavailable',
                    recoverable=False,
                )
            ]
        in_flight = [delegation for delegation in self._delegations.values() if delegation.response_in_flight]
        if not in_flight or not message.startswith(_HANDOFF_FAILURE_PREFIX):
            return [RealtimeSessionErrorEvent(message=message, code=code)]
        events: list[RealtimeCodecEvent] = []
        for delegation in in_flight:
            events.extend(self._response_ended_without_usage(unmeasured_requests=1))
            self._settle_delegation(delegation, gave_up=True)
        events.append(
            RealtimeSessionErrorEvent(
                message=f'The delegated OpenAI Responses backend did not finish ({code}: {message}).',
                code='live_delegation_failed',
            )
        )
        return events

    def _map_session_closed(self, cumulative_seconds: float | None, *, reason: str) -> list[RealtimeCodecEvent]:
        """Record the final usage, and say so when the session ended without anyone asking.

        The WebSocket close that follows is clean either way, so without this a reply cut off by the
        safety filter or the duration limit would be settled as though the model had finished it.
        """
        events: list[RealtimeCodecEvent] = [] if cumulative_seconds is None else self._map_usage(cumulative_seconds)
        self._session_end = _SessionEnd(
            ended=True, unclaimed=[report for report in events if isinstance(report, SessionUsage)]
        )
        if reason in _NORMAL_CLOSE_REASONS:
            return events
        events.extend(self._settle_open_turns(interrupted=True))
        if reason in _RECONNECTABLE_CLOSE_REASONS and self._can_reconnect:
            # Not the end of the call: the reconnect policy re-opens the session once the socket closes.
            self._redial_on_close = True
            return events
        events.append(
            RealtimeSessionErrorEvent(
                message=f'The OpenAI GPT-Live session ended: {reason}.',
                code=f'live_session_{reason}',
                recoverable=False,
            )
        )
        return events

    def _map_output_audio(self, pcm: bytes) -> list[RealtimeCodecEvent]:
        """Forward model audio, ignoring the idle track between replies.

        Only a frame louder than the idle floor is evidence that the model is speaking. Quieter frames
        shortly after it are still forwarded, which keeps a pause mid-sentence from arriving as a gap in
        playback — but not while the user is talking, because an assistant frame marks the end of the
        user's turn, and the idle track between their words would cut one utterance into many. A longer
        quiet stretch is not forwarded: it is most likely the end of the reply, or a wait on delegated
        work, and forwarding it would end every reply with seconds of silence.

        On a WebRTC sideband the browser plays the audio, so nothing is forwarded and voice only drives
        the turn clock.
        """
        if _is_voiced(pcm):
            self._pause_ms = 0.0
            events = self._open_response()
            return [*events, AudioDelta(data=pcm)] if self._forwards_output_audio else events
        if self._pause_ms is None or not self._forwards_output_audio:
            return []
        # A chunk that crosses the allowance is cut at it, on a sample boundary, so the pause forwarded
        # doesn't depend on how Live happened to chunk the track.
        allowed = max(0, int((_MAX_FORWARDED_PAUSE_MS - self._pause_ms) * self._audio_bytes_per_ms) // 2 * 2)
        self._pause_ms += len(pcm) / self._audio_bytes_per_ms
        if not self._response_open or self._input_open or not allowed:
            return []
        return [AudioDelta(data=pcm[:allowed])]

    def _map_delegation(self, event: DelegationCreatedEvent) -> list[RealtimeCodecEvent]:
        delegation = event.delegation
        if delegation.target == 'client':
            # This adapter configures Responses delegation; say so rather than stalling silently
            # while the model waits for an answer that will never come.
            return [
                RealtimeSessionErrorEvent(
                    message=(
                        'The Live session delegated work to the client, but Pydantic AI configures '
                        'Responses delegation. The request will go unanswered.'
                    ),
                    code='live_client_delegation',
                )
            ]
        self._delegations[delegation.id] = _Delegation(id=delegation.id)
        if (
            event.client_event_id is not None
            and (input_index := self._unacknowledged_text.pop(event.client_event_id, None)) is not None
        ):
            # The delegation a text turn's `response.create` asked for: Live speaks to the text from here on.
            self._lifecycle.text_taken_up(input_index)
        return self._open_response()

    def _map_response_event(self, nested: dict[str, Any], *, delegation_id: str | None) -> list[RealtimeCodecEvent]:
        """Map one nested Responses streaming event from the delegated backend."""
        try:
            event = _response_stream_event_adapter.validate_python(nested)
        except ValidationError:
            if nested.get('type') in _ACTED_ON_DELEGATED_RESPONSE_EVENTS:
                raise  # a malformed frame, which `_map_frame` reports as recoverable
            return []  # a nested event type this version of the SDK doesn't know
        if isinstance(event, ResponseErrorEvent):
            # Recoverable: the Live session carries on, and a failed response still sends its terminal.
            return [
                RealtimeSessionErrorEvent(
                    message=f'The delegated OpenAI Responses backend reported an error: {event.message}',
                    code=event.code,
                )
            ]
        delegation = self._delegations.get(delegation_id) if delegation_id is not None else None
        if isinstance(event, (ResponseCompletedEvent, ResponseFailedEvent, ResponseIncompleteEvent)):
            self._pending_reasoning.pop(delegation_id, None)
            events: list[RealtimeCodecEvent] = self._map_backend_usage(event.response)
            if delegation is not None:
                if not events:
                    events = self._response_ended_without_usage(unmeasured_requests=int(event.response.usage is None))
                self._settle_delegation(delegation, gave_up=not isinstance(event, ResponseCompletedEvent))
            if not isinstance(event, ResponseCompletedEvent):
                events.append(_delegation_stopped(event))
            return events
        if not isinstance(event, ResponseOutputItemDoneEvent):
            return []
        if isinstance(event.item, ResponseReasoningItem):
            self._pending_reasoning.setdefault(delegation_id, []).append(event.item)
            return []
        reasoning = self._pending_reasoning.pop(delegation_id, [])
        if isinstance(event.item, ResponseFunctionWebSearch):
            return self._map_web_search(event.item, reasoning)
        if not isinstance(event.item, ResponseFunctionToolCall):
            return []
        call = event.item
        self._open_calls.add(call.call_id)
        if delegation is not None:
            delegation.pending_tool_calls.add(call.call_id)
            self._call_delegations[call.call_id] = delegation.id
        events = self._open_response()
        # The call ends the spoken part before it: a quiet stretch after it is a wait, not a pause.
        self._pause_ms = None
        return [
            *events,
            ToolCall(
                call.call_id,
                tool_name=call.name,
                args=call.arguments or '{}',
                # The backend response that asked for the call reports its tokens on its terminal event,
                # after the call. Without this the call's `ModelResponse` is finalized empty and those
                # tokens land on the spoken reply that follows. A call we can't correlate to a
                # delegation has no terminal we will see, so nothing follows it.
                response_usage_follows=delegation is not None,
            ),
        ]

    def _map_web_search(
        self, item: ResponseFunctionWebSearch, reasoning: list[ResponseReasoningItem]
    ) -> list[RealtimeCodecEvent]:
        """Record a search the backend ran with the native `web_search` tool, as a standard run would.

        The call and its result arrive together, once the search is done, so both parts start and end
        here. The session folds them into the response they belong to, ahead of what is spoken. The
        reasoning that led to the search goes first, as `ThinkingPart`s: OpenAI refuses to replay a search
        without it, so without them this history couldn't be continued by an `OpenAIResponsesModel` agent.
        """
        parts: list[ModelResponsePart] = [
            thinking
            for reasoning_item in reasoning
            for thinking in map_reasoning_item(reasoning_item, self._provider_name)
        ]
        parts.extend(map_web_search_tool_call(item, self._provider_name))
        events: list[RealtimeCodecEvent] = []
        for part in parts:
            index = self._native_part_index
            self._native_part_index += 1
            events.extend((PartStartEvent(index=index, part=part), PartEndEvent(index=index, part=part)))
        return events

    @staticmethod
    def _response_ended_without_usage(*, unmeasured_requests: int = 0) -> list[RealtimeCodecEvent]:
        """The usage report a backend response that ended without mapped usage still makes.

        Every backend response is reported exactly once, usage or not: it is a request the backend made
        (see `responses_are_requests` on the profile), and the calls it asked for are reported as
        `response_usage_follows`, so their `ModelResponse` stays open until it arrives.

        Args:
            unmeasured_requests: Number of responses whose terminal omitted usage information.
        """
        return [SessionUsage(RequestUsage(unmeasured_requests=unmeasured_requests))]

    def _settle_delegation(self, delegation: _Delegation, *, gave_up: bool, in_frame: bool = True) -> None:
        """Account for one finished backend response, closing the delegation once it owes nothing.

        A delegation suspends the turn clock, so leaving a dead one in the map would keep the session
        from ever reporting another turn boundary: a backend that fails or stops short has to close
        it just as a completed one does.

        `in_frame` says it is settled by the provider message being mapped, whose backend usage report then ends the
        reply that called the tools (see `_LiveLifecycle.delegation_settled()`).
        """
        delegation.response_in_flight = False
        if gave_up or delegation.stalled:
            # Nothing further is coming for this delegation — no continuation, and no answer to any
            # call it had asked for — so it must not hold the clock open waiting for one.
            self._abandoned_calls.update(delegation.pending_tool_calls)
            if delegation.pending_tool_calls:
                self._lifecycle.calls_abandoned(sorted(delegation.pending_tool_calls))
            delegation.pending_tool_calls.clear()
            delegation.continuation_due = False
        if delegation.pending_tool_calls:
            return  # the last result to come back continues it
        if delegation.continuation_due:
            self._continuations_due.append(delegation)
            return
        self._delegations.pop(delegation.id, None)
        if in_frame:
            self._lifecycle.delegation_settled()
        self._heard_voice()

    def _map_backend_usage(self, response: Response) -> list[RealtimeCodecEvent]:
        """Accumulate the delegated backend's token usage, priced as the backend.

        Live meters its own audio by the second and reports no tokens for it, but the Responses
        backend it delegates to is billed per token like any other model — and that is where most of
        a call's token cost is. The nested lifecycle snapshot carries the same `usage` object a direct
        Responses call would, so it is mapped by the same code, keeping cache and reasoning
        breakdowns (and genai-prices' view of them) identical either way.

        The price is resolved here, against the backend's own model, because this is the only place
        that model name is known. The `ModelResponse` these tokens land on is the Live model's spoken
        turn and carries Live's name, so anything that prices it from `model_name` downstream would
        charge one model's tokens at another's rate. A cost that is already set is never recalculated
        there, so resolving it now is also what stops that from happening.
        """
        mapped = map_openai_usage(response, self._provider_name, self._provider_url, response.model)
        if not mapped.has_values():
            return []
        if (
            price := best_effort_price(
                mapped,
                model_name=response.model,
                provider_api_url=self._provider_url,
                provider_name=self._provider_name,
                price_context={'service_tier': response.service_tier} if response.service_tier else None,
            )
        ) is not None:
            mapped.cost = price.total_price
        # Response-scoped, so the backend's request is what a per-request input-token limit is
        # measured against: it is the only thing in a Live session that spends input tokens.
        # The response carries Live's name, so it records the backend model as well: without it the
        # tokens on `usage` could not be re-priced later, or even attributed to the model that spent them.
        # Its id goes next to it rather than into `provider_response_id`, which is the id of the response
        # the Live model spoke, and Live assigns none.
        return [
            SessionUsage(
                mapped, provider_details={'delegated_model': response.model, 'delegated_response_id': response.id}
            )
        ]

    def _map_usage(
        self, cumulative_seconds: float, *, context_window_used: float | None = None
    ) -> list[RealtimeCodecEvent]:
        """Emit the audio seconds billed since the last report, priced as the Live model.

        Live reports a running total and says explicitly not to sum successive values, while
        `RunUsage` accumulates what it is given — so the connection does the subtraction. The context
        window fraction is a snapshot, so it is passed on as is, even when no more seconds were billed.

        The price is resolved here because this usage belongs to no `ModelResponse`, and so is never
        priced at a response boundary: without it, the session's cost would leave out the call itself.
        """
        increment = cumulative_seconds - self._reported_seconds
        if increment <= 0:
            if context_window_used is None:
                return []
            return [SessionUsage(RequestUsage(), response_scoped=False, context_window_used=context_window_used)]
        self._reported_seconds = cumulative_seconds
        usage = RequestUsage(audio_seconds=increment)
        if (
            price := best_effort_price(
                usage,
                model_name=self._model_name,
                provider_api_url=self._provider_url,
                provider_name=self._provider_name,
            )
        ) is not None:
            usage.cost = price.total_price
        # Live bills the session, not a response: this belongs to the run, not to any one `ModelResponse`.
        return [SessionUsage(usage, response_scoped=False, context_window_used=context_window_used)]


def _now() -> float:
    """The turn clock. Monotonic rather than the loop's own, so it needs no running loop."""
    return time.monotonic()


def _pump_clock() -> float:
    """The idle-audio pump's clock, kept apart from the turn clock, which replayed recordings move."""
    return time.monotonic()


async def _recv(ws: ClientConnection) -> str | bytes:
    return await ws.recv()


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode()


_UserContentPart = ResponseInputTextContentParam | ResponseInputImageContentParam | ResponseInputFileContentParam


async def _tool_result_follow_up(result: ToolResult, *, provider_name: str) -> dict[str, Any] | None:
    """The backend input message carrying a tool result's `content`, sent after its output.

    As on the Realtime API, what a tool returns beyond its text output (a `ToolReturn`'s `content`, and
    the files it returned) follows the output as a user message: text as `input_text`, images as
    `input_image`, and documents as `input_file`, each mapped as `OpenAIResponsesModel` maps it.

    Mapped before anything is sent, so a result that can't be carried in full fails with nothing on the
    wire rather than reaching the backend without the material that explains it.
    """
    items = [item for item in result.content or [] if not isinstance(item, CachePoint)]
    if not items:
        return None
    content: list[_UserContentPart] = []
    for item in items:
        if isinstance(item, (str, TextContent)):
            content.append(_text_part(item))
        else:
            content.append(await _tool_result_media(item, provider_name=provider_name))
    return {'type': 'message', 'role': 'user', 'content': content}


def _text_part(text: str | TextContent) -> ResponseInputTextContentParam:
    return {'type': 'input_text', 'text': text if isinstance(text, str) else text.content}


async def _tool_result_media(
    item: MultiModalContent, *, provider_name: str
) -> ResponseInputImageContentParam | ResponseInputFileContentParam:
    """One media item of a tool result as a Responses content part, mapped as `OpenAIResponsesModel` maps it.

    Only images and documents are carried: a Responses input message has no part for audio or video.
    """
    if isinstance(item, (AudioUrl, VideoUrl)):
        kind = f'`{type(item).__name__}` content'
    elif isinstance(item, UploadedFile) and item.media_type.startswith(('audio/', 'video/')):
        kind = f'an uploaded `{item.media_type}` file'
    elif isinstance(item, BinaryContent) and not (item.is_image or item.is_document):
        kind = f'`{item.media_type}` content'
    elif isinstance(item, DocumentUrl) and _is_audio_or_video_url(item):
        kind = f'a `{item.media_type}` `DocumentUrl`'
    elif isinstance(item, UploadedFile):
        # An opaque Files-API id reports `application/octet-stream` and goes as `input_file`, as it does on
        # `OpenAIResponsesModel`: the backend reads what the id actually holds.
        _utils.validate_uploaded_file_provider(item, system=provider_name, model_type_name='OpenAILiveModel')
        return _uploaded_file_to_response_content(item)
    else:
        return await OpenAIResponsesModel._map_file_to_response_content(item, 'tool returns')  # pyright: ignore[reportPrivateUsage]
    raise UserError(
        f'OpenAI GPT-Live cannot send {kind} in a tool result to its delegated backend, which takes only text, '
        'images, and documents. Describe it in text instead.'
    )


def _is_audio_or_video_url(item: DocumentUrl) -> bool:
    """Whether a document URL names audio or video, which the backend can't read as a file.

    A URL whose type can't be inferred is left to the mapper, which fetches it or refuses it as it would on
    `OpenAIResponsesModel`.
    """
    try:
        media_type = item.media_type
    except ValueError:
        return False
    return media_type.startswith(('audio/', 'video/'))


async def _context_tokens_over_cap(text: str) -> int | None:
    """How many tokens context text is, in the tokenizer Live counts with, if that is over Live's cap; else `None`.

    A token spans at least one byte, so text that short can't be over and skips loading the tokenizer.
    """
    if len(text.encode()) <= _CONTEXT_TOKEN_LIMIT:
        return None
    # Loading an encoding can download it on first use, so it stays off the event loop. tiktoken caches
    # the loaded encoding under a lock, so concurrent first sends load it once.
    encoding = await _utils.run_in_executor(tiktoken.get_encoding, _CONTEXT_ENCODING)
    # Special-token text such as `<|endoftext|>` is counted as the one token it is, as Live counts it
    # (checked live), rather than refused as tiktoken does by default.
    tokens = len(encoding.encode(text, allowed_special='all'))
    return tokens if tokens > _CONTEXT_TOKEN_LIMIT else None


async def _check_context_length(text: str) -> None:
    """Refuse context text over Live's cap before it is sent, rather than after Live rejects it.

    A rejected append arrives as a recoverable error well after `send()` has returned and the text has
    been recorded as sent, so it is checked here.
    """
    if (tokens := await _context_tokens_over_cap(text)) is not None:
        raise UserError(
            f'OpenAI GPT-Live accepts at most {_CONTEXT_TOKEN_LIMIT} tokens of context per `send(..., respond=False)`, '
            f'and this is {tokens}. Send it in shorter pieces, send it as a typed turn for the backend, or give longer '
            'material to the agent as a tool result.'
        )


def _delegation_stopped(event: ResponseFailedEvent | ResponseIncompleteEvent) -> RealtimeSessionErrorEvent:
    """Report a delegated backend that failed or stopped short.

    The turn itself still ends — Live keeps talking and the silence clock closes it — so without this
    the caller would see an ordinary turn boundary and no sign that the delegated work never finished.
    Recoverable, because the session is fine: only this one piece of delegated work was lost.
    """
    response = event.response
    if response.error is not None:
        reason = f'{response.error.code}: {response.error.message}'
    elif response.incomplete_details is not None:
        reason = f'incomplete: {response.incomplete_details.reason}'
    else:
        reason = event.type
    return RealtimeSessionErrorEvent(
        message=f'The delegated OpenAI Responses backend did not finish ({reason}).',
        code='live_delegation_failed' if isinstance(event, ResponseFailedEvent) else 'live_delegation_incomplete',
    )


def _is_voiced(pcm: bytes) -> bool:
    """Whether a little-endian PCM16 frame is louder than the idle track."""
    samples = array.array('h', pcm[: len(pcm) - len(pcm) % 2])
    if sys.byteorder == 'big':  # pragma: no cover
        samples.byteswap()
    return any(abs(sample) > _VOICE_FLOOR for sample in samples)


def _check_seeded_history(expected: list[dict[str, Any]], started: SessionStartedEvent) -> None:
    """Refuse to attach a sideband whose history isn't the history the Live session started with.

    Live takes history only when a session starts, which on a WebRTC call is the offer. A sideband opened
    with other history would record a conversation the model never saw, so it raises rather than attach.
    """
    # Compared with whitespace collapsed: what matters is that it is the same conversation, and a false
    # mismatch would leave the call running with nothing to run its tools.
    seeded = [
        (item.role, [' '.join(part.text.split()) for part in item.content]) for item in started.session.input or []
    ]
    wanted = [(item['role'], [' '.join(part['text'].split()) for part in item['content']]) for item in expected]
    if seeded == wanted:
        return
    raise UserError(
        'An OpenAI GPT-Live session takes its history when it starts, which on a WebRTC call is when '
        '`answer_webrtc_offer()` starts it, so the sideband must be opened with the same `message_history`. '
        'Bind the history once with `agent.realtime(model, message_history=...)` and use that for both the '
        'offer and the session, or pass the same history to `answer_webrtc_offer()` and `connect_webrtc()`.'
    )


def _backend_reasoning_effort(
    delegation_settings: OpenAILiveResponsesDelegation, settings: OpenAILiveModelSettings, backend_model: str
) -> ReasoningEffort:
    """The backend's reasoning effort: the delegation's own, else the shared `thinking` setting.

    The backend is the model that reasons, so `thinking` is resolved against *its* profile, exactly as a
    direct Responses request to it would be: a backend that doesn't reason ignores it, `thinking=False`
    leaves a backend that always reasons at its default, and `'minimal'` becomes `'low'` where the
    backend has no minimal effort. `'max'` becomes `'xhigh'`: the delegation's effort levels stop at `'xhigh'`.
    """
    if (effort := delegation_settings.get('reasoning_effort')) is not None:
        return effort
    if (thinking := settings.get('thinking')) is None:
        return None
    # `openai_model_profile` builds an `OpenAIModelProfile`; its declared return type is the base one.
    profile = cast(OpenAIModelProfile, openai_model_profile(backend_model))
    thinking_always_enabled = profile.get('thinking_always_enabled', False)
    if not (profile.get('supports_thinking', False) or thinking_always_enabled):
        return None
    if thinking is False and thinking_always_enabled:
        return None
    return _resolve_openai_thinking_effort(thinking, profile, supports_max=False)


def _resolve_openai_model(model_id: str) -> Model | None:
    """Resolve an agent's model name as its run would, when it names an OpenAI model at all.

    Anything else can't be a backend, so it isn't resolved: that would build another provider's client
    (and need its package and key) only to find it doesn't qualify. A name that can't be resolved (its
    key isn't set, say) isn't one this session can use either.
    """
    provider_name, _ = parse_model_id(model_id)
    if provider_name is None or normalize_gateway_provider(provider_name) not in _OPENAI_MODEL_KINDS:
        return None
    try:
        return infer_model(model_id)
    except UserError:
        return None


def _b64decode(data: str) -> bytes:
    return base64.b64decode(data)


@dataclass(init=False)
class OpenAILiveModel(RealtimeModel):
    """OpenAI GPT-Live model.

    GPT-Live runs the spoken conversation and delegates the thinking to a Responses backend that
    Pydantic AI configures with the agent's instructions and tools, so tools, dependencies,
    validation, and message history stay on the Pydantic AI side. Reach it through
    [`Agent.realtime`][pydantic_ai.agent.Agent.realtime] as `'openai:gpt-live-1'`, or construct it
    directly for model-level configuration.

    Live differs from the [Realtime API][pydantic_ai.realtime.openai.OpenAIRealtimeModel] in ways that
    change what a session can do — no text input, an inferred turn boundary, no manual turn control or
    interruption, and duration-based usage. See
    [the Live docs](https://pydantic.dev/docs/ai/realtime/openai#gpt-live-models).

    Args:
        model: The model name, e.g. `gpt-live-1`.
        provider: The provider to use for authentication and the base URL. Defaults to `'openai'`.
        settings: [Model settings][pydantic_ai.realtime.RealtimeModelSettings] used as defaults for
            realtime sessions.
        profile: Optional override for the [realtime model profile][pydantic_ai.realtime.RealtimeModelProfile].
    """

    model: OpenAILiveModelName
    _: KW_ONLY
    settings: RealtimeModelSettings | None = None
    _provider: Provider[AsyncOpenAI] = field(init=False, repr=False)

    def __init__(
        self,
        model: OpenAILiveModelName,
        *,
        provider: Provider[AsyncOpenAI] | str = 'openai',
        settings: RealtimeModelSettings | None = None,
        profile: RealtimeModelProfileSpec | None = None,
    ) -> None:
        super().__init__(settings=settings, profile=profile)
        # `'gpt-live-1+gpt-5.6-sol'` names the voice model and the backend it delegates to.
        live_model, _, backend_model = model.partition('+')
        self.model = live_model
        self._backend_model = backend_model or None
        if isinstance(provider, str):
            provider = cast('Provider[AsyncOpenAI]', infer_provider(provider))
        if provider.name == 'azure':
            raise UserError(
                'Azure OpenAI does not serve GPT-Live. Use `AzureRealtimeModel` (or the `azure:` prefix) '
                'for Azure OpenAI realtime models.'
            )
        self._provider = provider

    @classmethod
    def supported_native_tools(cls) -> frozenset[type[AbstractNativeTool]]:
        """Web search, which the delegated backend runs: the only native tool Live lets it have."""
        return frozenset({WebSearchTool})

    def unsupported_native_tool_settings(self, native_tool: AbstractNativeTool) -> frozenset[str]:
        """Return `native_tool`'s restricting settings that the Responses `web_search` tool doesn't take: `max_uses`."""
        # `WebSearchTool` is the only native tool Live supports.
        return native_tool.restricting_settings - {'allowed_domains', 'blocked_domains', 'external_web_access'}

    @property
    def client(self) -> AsyncOpenAI:
        """The underlying [`AsyncOpenAI`](https://github.com/openai/openai-python) client from the provider."""
        return self._provider.client

    def _agent_model_name(self) -> str | None:
        """The agent's own model, as the backend to delegate to, when it is reached the same way as this one.

        The backend runs the agent's instructions and calls its tools, so it is the agent doing its work,
        and an agent built on an OpenAI model has already said which model that should be. It has to be
        an OpenAI model at this model's base URL, so both go to OpenAI directly or both through the same
        gateway route; anything else can't serve as this session's backend.

        Read from the current run context: a session opened with
        [`Agent.realtime`][pydantic_ai.agent.Agent.realtime] is an agent run, so its run context is
        current while connecting, as it is around a standard run's model request. A connection
        opened any other way has no agent to consult. An agent whose model is still a name (with
        `defer_model_check=True`) is resolved the way its own run would resolve it.
        """
        run_context = get_current_run_context()
        agent_model = run_context.agent.model if run_context is not None and run_context.agent is not None else None
        if isinstance(agent_model, str):
            agent_model = _resolve_openai_model(agent_model)
        if isinstance(agent_model, Model) and agent_model.system == 'openai' and agent_model.base_url == self.base_url:
            return agent_model.model_name
        return None

    def _resolve_backend_model(self, settings: OpenAILiveModelSettings) -> str:
        """The Responses model this session delegates to, from the first source that names one."""
        delegation_settings = settings.get('openai_live_delegation', OpenAILiveResponsesDelegation())
        backend_model = delegation_settings.get('model') or self._backend_model or self._agent_model_name() or 'auto'
        return AUTO_BACKEND_MODEL if backend_model == 'auto' else backend_model

    @property
    def model_name(self) -> OpenAILiveModelName:
        return self.model

    @property
    def system(self) -> str:
        return self._provider.name

    def _session_config(
        self,
        *,
        instructions: str,
        tools: list[ToolDefinition] | None,
        messages: Sequence[ModelMessage],
        settings: OpenAILiveModelSettings,
        native_tools: Sequence[AbstractNativeTool],
        audio_format: bool = True,
    ) -> dict[str, Any]:
        """The configuration Live starts the session with.

        `audio_format=False` leaves out the audio format, which WebRTC negotiates on the media transport
        (Live rejects one set there), so the profile's sample rates aren't consulted at all.
        """
        delegation_settings = settings.get('openai_live_delegation', OpenAILiveResponsesDelegation())
        backend_instructions = '\n\n'.join(
            text for text in (instructions, delegation_settings.get('instructions')) if text
        )
        responses: dict[str, Any] = {'model': self._resolve_backend_model(settings)}
        if backend_instructions:
            responses['instructions'] = backend_instructions
        advertised_tools, tool_choice = resolve_advertised_tools(tools, settings.get('tool_choice'))
        if tool_choice == 'required' or (isinstance(tool_choice, tuple) and tool_choice[0] == 'required'):
            # The backend applies the choice to every response of a delegation, including the one meant
            # to answer after the tools have run, so a forced call never lets a delegation finish: it
            # looped on tool calls (seven in ten seconds, live) until a limit ended the session.
            raise UserError(
                f'OpenAI GPT-Live cannot force a tool call, so `tool_choice={settings.get("tool_choice")!r}` cannot '
                'be set: the backend would apply it to every response, including the one after the tool '
                "results, and never answer. Use `'auto'`, `'none'`, or `ToolOrOutput` to limit the tools instead."
            )
        # The backend runs native tools too, so they go to it rather than to the Live model. Web search
        # takes the same options as on a direct Responses call, and Live passes them through unchecked.
        backend_tools = [tool_def_to_live(tool) for tool in advertised_tools]
        backend_tools += [map_web_search_tool_param(tool) for tool in native_tools if isinstance(tool, WebSearchTool)]
        if backend_tools:
            responses['tools'] = backend_tools
        if tool_choice is not None:
            # The backend takes the same forms as the Realtime API. A restriction is applied by trimming
            # the advertised tools above, leaving its mode to send.
            responses['tool_choice'] = tool_choice_config(tool_choice)
        for setting, key in (
            ('max_output_tokens', 'max_output_tokens'),
            ('service_tier', 'service_tier'),
        ):
            if (value := delegation_settings.get(setting)) is not None:
                responses[key] = value
        # The backend is what calls the tools, so the shared setting applies to it.
        parallel_tool_calls = delegation_settings.get('parallel_tool_calls', settings.get('parallel_tool_calls'))
        if parallel_tool_calls is not None:
            responses['parallel_tool_calls'] = parallel_tool_calls
        reasoning: dict[str, str] = {}
        if (effort := _backend_reasoning_effort(delegation_settings, settings, responses['model'])) is not None:
            reasoning['effort'] = effort
        if (summary := delegation_settings.get('reasoning_summary')) is not None:
            reasoning['summary'] = summary
        if reasoning:
            responses['reasoning'] = reasoning
        if (verbosity := delegation_settings.get('verbosity')) is not None:
            responses['text'] = {'verbosity': verbosity}

        audio = self._audio_config(settings, audio_format=audio_format)
        config: dict[str, Any] = {
            'model': self.model,
            'instructions': settings.get('openai_live_instructions', DEFAULT_LIVE_INSTRUCTIONS),
            **({'audio': audio} if audio else {}),
            'delegation': {'type': 'responses', 'responses': responses},
        }
        if settings.get('openai_live_store'):
            config['store'] = True
        if seed := seed_input_items(messages, provider_name=self.system):
            config['input'] = seed
        return config

    def _audio_config(self, settings: OpenAILiveModelSettings, *, audio_format: bool) -> dict[str, Any]:
        audio: dict[str, Any] = {}
        if audio_format:
            audio['format'] = {'type': 'audio/pcm', 'rate': self._audio_rate()}
        if voice := settings.get('openai_voice'):
            audio['output'] = {'voice': voice}
        return audio

    def _audio_rate(self) -> int:
        """The PCM16 sample rate to run the session at, from the profile's audio rates.

        Live takes one audio format for both directions, at 16 or 24 kHz, while the profile has a rate
        for each; set both through `profile=` to choose 16 kHz. Checked before connecting, since a
        mismatch would have the session resample one direction to a rate Live isn't using.
        """
        input_rate = self.profile.get('audio_input_sample_rate', 24000)
        output_rate = self.profile.get('audio_output_sample_rate', 24000)
        if input_rate != output_rate or input_rate not in _LIVE_PCM_RATES:
            raise UserError(
                'OpenAI GPT-Live uses one PCM16 audio format for both directions, at 16000 or 24000 Hz, so '
                '`audio_input_sample_rate` and `audio_output_sample_rate` must be equal and one of those; '
                f'got {input_rate} and {output_rate}.'
            )
        return input_rate

    def _reject_unsupported(self, settings: OpenAILiveModelSettings) -> None:
        """Refuse settings Live cannot honor, rather than silently ignoring a stated requirement."""
        for setting, feature in (
            ('turn_detection', 'turn detection: Live owns turn-taking and exposes no VAD configuration'),
            ('max_tokens', 'a token limit on the spoken conversation'),
        ):
            if settings.get(setting) is not None:
                raise UserError(f'OpenAI GPT-Live does not support {feature}, so `{setting}` cannot be set.')
        # Live always transcribes with its own model, which is what the `'auto'` default asks for.
        if (transcription_model := settings.get('input_transcription_model')) not in (AUTO_TRANSCRIPTION_MODEL, None):
            raise UserError(
                'OpenAI GPT-Live does not support choosing a transcription model, so `input_transcription_model` '
                f"can only be `'auto'`; got {transcription_model!r}."
            )

    def _live_url(self) -> str:
        return realtime_websocket_url(self._provider.base_url, path=_LIVE_WEBSOCKET_PATH)

    def _fork_url(self, session_id: str) -> str:
        """The WebSocket that starts a new session from a stored one, with its conversation."""
        return realtime_websocket_url(
            self._provider.base_url, path=f'{_LIVE_WEBSOCKET_PATH}/{quote(session_id, safe="")}/fork'
        )

    def _sideband_url(self, session_id: str) -> str:
        """The WebSocket a trusted server attaches to an existing Live session's control plane with."""
        return realtime_websocket_url(
            self._provider.base_url, path=f'{_LIVE_WEBSOCKET_PATH}/{quote(session_id, safe="")}/attach'
        )

    async def create_client_secret(
        self,
        *,
        instructions: str | None = None,
        tools: Sequence[ToolDefinition] | None = None,
        model_settings: RealtimeModelSettings | None = None,
        expires_after_seconds: int | None = None,
    ) -> RealtimeClientSecret:
        """GPT-Live has no ephemeral client secrets, so this always raises.

        Negotiate the call from your server with
        [`answer_webrtc_offer`][pydantic_ai.realtime.openai_live.OpenAILiveModel.answer_webrtc_offer] instead,
        so the browser never needs a token.
        """
        raise UserError(
            'OpenAI GPT-Live has no ephemeral client secrets, so `create_client_secret()` is unavailable. '
            "Relay the browser's SDP offer from your server with `answer_webrtc_offer()` instead."
        )

    async def answer_webrtc_offer(
        self,
        sdp_offer: str,
        *,
        instructions: str | None = None,
        tools: Sequence[ToolDefinition] | None = None,
        model_settings: RealtimeModelSettings | None = None,
        message_history: Sequence[ModelMessage] | None = None,
    ) -> WebRTCAnswer:
        """Start a Live session for a browser's WebRTC offer, and return the SDP answer and the session to attach to.

        Live's configuration is fixed when the session starts, so everything is set here: the voice and
        instructions, the delegated backend with the agent's instructions and tools, and the
        `message_history` the call continues, seeded as on a WebSocket session. The browser's
        data channel is closed unless `openai_live_data_channel` opens it. The audio format is negotiated
        by WebRTC, so the profile's sample rates don't apply.
        """
        settings = cast('OpenAILiveModelSettings', self._merge_model_settings(model_settings) or {})
        self._reject_unsupported(settings)
        # `RealtimeModel.answer_webrtc_offer` carries no native tools, so a browser call has no web search yet.
        session_config = self._session_config(
            instructions=instructions or '',
            tools=list(tools) if tools else None,
            native_tools=[],
            messages=message_history or [],
            settings=settings,
            audio_format=False,
        )
        session_config['client'] = {'data_channel': settings.get('openai_live_data_channel', _CLOSED_DATA_CHANNEL)}
        with map_openai_api_errors(self.model_name):
            created = await self.client.live.create(
                session=cast(MediaSessionConfigParam, session_config),
                transport={'type': 'webrtc', 'sdp': sdp_offer},
            )
        return WebRTCAnswer(
            sdp=created.transport.sdp,
            session=WebRTCSession(provider_name=self.system, session_id=created.session.id),
        )

    def _check_hang_up(self, session: RealtimeProviderSession) -> None:
        self._check_webrtc_session_provider(session)

    async def hang_up(self, session: RealtimeProviderSession) -> None:
        self._check_hang_up(session)
        client = self.client.with_options(timeout=HANG_UP_TIMEOUT, max_retries=HANG_UP_MAX_RETRIES)
        with ignore_ended_call('session_id_not_found'), map_openai_api_errors(self.model_name):
            await client.live.sessions.hangup(session.session_id)

    @asynccontextmanager
    async def connect_webrtc(
        self,
        session: RealtimeProviderSession,
        *,
        messages: Sequence[ModelMessage],
        model_settings: RealtimeModelSettings | None,
        model_request_parameters: ModelRequestParameters,
    ) -> AsyncGenerator[OpenAILiveConnection]:
        """Attach a sideband to a Live session started by [`answer_webrtc_offer`][pydantic_ai.realtime.openai_live.OpenAILiveModel.answer_webrtc_offer].

        The session was fully configured when it started, and Live can't reconfigure it, so the sideband
        only runs it: it executes the backend's tool calls and records the conversation, while the browser
        holds the audio. For the same reason it seeds nothing: the history it is opened with has to be the
        history the offer seeded, which it checks against the session Live replays.
        """
        self._check_webrtc_session_provider(session)
        settings = cast('OpenAILiveModelSettings', self._merge_model_settings(model_settings) or {})
        self._reject_unsupported(settings)
        if settings.get('openai_live_idle_audio'):
            raise UserError(
                "A WebRTC sideband does not carry the call's audio, the browser does, so `openai_live_idle_audio` "
                "cannot be set on one. The browser keeps Live's timeline moving as long as the call is up."
            )
        handshake_timeout = settings.get('handshake_timeout', 30.0)

        cm: AbstractAsyncContextManager[ClientConnection] | None = None
        connection: OpenAILiveConnection | None = None
        try:
            with map_connect_errors(self.model):
                headers = await openai_websocket_auth_headers(self.client)
                inject_trace_context(headers)
                opening = websockets.connect(self._sideband_url(session.session_id), additional_headers=headers)
                ws = await opening.__aenter__()
                cm = opening
                # Live replays `session.started` to every connection that attaches, with the configuration
                # the session started with.
                started_frame = await expect_event(ws, _SESSION_STARTED_EVENT, timeout=handshake_timeout)
                try:
                    started = SessionStartedEvent.model_validate(started_frame)
                except ValidationError as e:
                    raise RealtimeHandshakeError(f'Malformed `{_SESSION_STARTED_EVENT}` event: {e}') from e
            _check_seeded_history(seed_input_items(messages, provider_name=self.system), started)
            delegation = started.session.delegation
            connection = OpenAILiveConnection(
                ws,
                model_name=started.session.model,
                backend_model=delegation.responses.model if delegation and delegation.type == 'responses' else None,
                turn_silence_ms=settings.get('openai_live_turn_silence_ms', DEFAULT_TURN_SILENCE_MS),
                provider_name=self.system,
                provider_url=self._provider.base_url,
                forwards_output_audio=False,
            )
            yield connection
        finally:
            if connection is not None:
                await connection.aclose()
            if cm is not None:  # pragma: no branch
                await cm.__aexit__(None, None, None)

    @asynccontextmanager
    async def connect(
        self,
        *,
        messages: Sequence[ModelMessage],
        model_settings: RealtimeModelSettings | None,
        model_request_parameters: ModelRequestParameters,
    ) -> AsyncGenerator[OpenAILiveConnection]:
        settings = cast('OpenAILiveModelSettings', self._merge_model_settings(model_settings) or {})
        self._reject_unsupported(settings)
        handshake_timeout = settings.get('handshake_timeout', 30.0)
        instructions = session_instructions(messages, model_request_parameters)
        session_config = self._session_config(
            instructions=instructions,
            tools=model_request_parameters.function_tools,
            messages=messages,
            settings=settings,
            native_tools=model_request_parameters.native_tools,
        )

        cm: AbstractAsyncContextManager[ClientConnection] | None = None
        connection: OpenAILiveConnection | None = None

        async def open_session(url: str, session: dict[str, Any]) -> tuple[ClientConnection, dict[str, Any]]:
            nonlocal cm
            if cm is not None:
                previous, cm = cm, None
                await previous.__aexit__(None, None, None)
            # The raw WebSocket bypasses the provider's `httpx` client, so the handshake carries freshly
            # resolved authentication and the current trace context itself.
            headers = await openai_websocket_auth_headers(self.client)
            inject_trace_context(headers)
            opening = websockets.connect(url, additional_headers=headers)
            ws = await opening.__aenter__()
            cm = opening
            await ws.send(to_json({'type': 'session.start', 'session': session}).decode())
            return ws, await expect_event(ws, _SESSION_STARTED_EVENT, timeout=handshake_timeout)

        async def dial(fork_from: str | None, seed: list[dict[str, Any]]) -> tuple[ClientConnection, str | None]:
            if fork_from is not None:
                # A fork keeps the stored session's configuration, so it starts with none of its own.
                ws, started = await open_session(self._fork_url(fork_from), {})
            else:
                replacement = {key: value for key, value in session_config.items() if key != 'input'}
                if seed:
                    replacement['input'] = seed
                ws, started = await open_session(self._live_url(), replacement)
            return ws, started.get('session', {}).get('id')

        try:
            with map_connect_errors(self.model):
                ws, started = await open_session(self._live_url(), session_config)
            connection = OpenAILiveConnection(
                ws,
                model_name=started.get('session', {}).get('model'),
                backend_model=session_config['delegation']['responses']['model'],
                audio_rate=session_config['audio']['format']['rate'],
                turn_silence_ms=settings.get('openai_live_turn_silence_ms', DEFAULT_TURN_SILENCE_MS),
                provider_name=self.system,
                provider_url=self._provider.base_url,
                idle_audio=settings.get('openai_live_idle_audio', False),
                session_id=started.get('session', {}).get('id'),
                dial=dial,
                reconnect=settings.get('reconnect'),
                # Only a stored session can be forked. Storing it is the user's call, never made for them.
                forks=bool(settings.get('openai_live_store')),
            )
            yield connection
        finally:
            if connection is not None:
                await connection.aclose()
            if cm is not None:  # pragma: no branch
                await cm.__aexit__(None, None, None)
