# Copyright 2026 Marimo. All rights reserved.
from __future__ import annotations

from typing import Literal

import msgspec

from marimo._runtime.packages.package_manager import PackageDescription
from marimo._utils.uv_tree import DependencyTreeNode


class AddPackageRequest(msgspec.Struct, rename="camel"):
    """
    This can be a remove package or a local package.

    Supported formats:

    httpx
    httpx==0.27.0
    httpx>=0.27.0
    git+https://github.com/encode/httpx
    https://files.pythonhosted.org/packages/5c/2d/3da5bdf4408b8b2800061c339f240c1802f2e82d55e50bd39c5a881f47f0/httpx-0.27.0.tar.gz
    /example/foo-0.1.0-py3-none-any.whl
    """

    package: str
    upgrade: bool | None = False
    group: str | None = None


class RemovePackageRequest(msgspec.Struct, rename="camel"):
    package: str
    group: str | None = None


class SandboxRequest(msgspec.Struct, rename="camel"):
    file_key: str | None = None


class UpdateManifestRequest(msgspec.Struct, rename="camel"):
    contents: str
    previous: str
    file_key: str | None = None


class SandboxResponse(msgspec.Struct, rename="camel"):
    backend: Literal["uv", "pixi"] | None
    manifest: str | None
    filename: str | None


class SandboxPackageContext(
    msgspec.Struct,
    frozen=True,
    tag="sandbox",
    tag_field="kind",
    rename="camel",
):
    backend: Literal["uv", "pixi"]


class PackageManagerContext(
    msgspec.Struct,
    frozen=True,
    tag="package-manager",
    tag_field="kind",
    rename="camel",
):
    name: str


PackageInstallationContext = SandboxPackageContext | PackageManagerContext


class ListPackagesResponse(msgspec.Struct, rename="camel"):
    packages: list[PackageDescription]


class DependencyTreeResponse(msgspec.Struct, rename="camel"):
    tree: DependencyTreeNode | None
    context: PackageInstallationContext


class PackageOperationResponse(msgspec.Struct, rename="camel"):
    success: bool
    error: str | None = None
    restart_required: bool = False

    @staticmethod
    def of_success() -> PackageOperationResponse:
        return PackageOperationResponse(success=True, error=None)

    @staticmethod
    def of_failure(error: str) -> PackageOperationResponse:
        return PackageOperationResponse(success=False, error=error)


class SyncSandboxResponse(PackageOperationResponse, rename="camel"):
    reconnect: bool = False
