# Copyright 2026 Marimo. All rights reserved.
from __future__ import annotations

import os
import sys
from dataclasses import dataclass

from marimo._config.packages import infer_package_manager
from marimo._config.utils import deep_copy

if sys.version_info >= (3, 11):
    from typing import NotRequired
else:
    from typing_extensions import NotRequired

from typing import (
    TYPE_CHECKING,
    Any,
    Literal,
    TypedDict,
    cast,
)

from marimo._output.rich_help import mddoc
from marimo._utils.deep_merge import deep_merge


@mddoc
@dataclass
class CompletionConfig(TypedDict):
    """Configuration for code completion.

    A dict with key/value pairs configuring code completion in the marimo
    editor.

    **Keys.**

    - `activate_on_typing`: if `False`, completion won't activate
    until the completion hotkey is entered
    - `signature_hint_on_typing`: if `False`, signature hint won't be shown when typing
    - `copilot`: one of `"github"`, `"codeium"`, or `"custom"`
    - `codeium_api_key`: the Codeium API key
    - `auto_close_pairs`: if `False`, typing an opening bracket, parenthesis,
    or quote will not automatically insert the closing character
    """

    activate_on_typing: bool
    signature_hint_on_typing: bool
    copilot: bool | Literal["github", "codeium", "custom"]
    auto_close_pairs: NotRequired[bool]

    # Codeium
    codeium_api_key: NotRequired[str | None]

    # @deprecated: use `ai.models.autocomplete_model` instead
    api_key: NotRequired[str | None]
    model: NotRequired[str | None]
    base_url: NotRequired[str | None]


@mddoc
@dataclass
class SaveConfig(TypedDict):
    """Configuration for saving.

    **Keys.**

    - `autosave`: one of `"off"` or `"after_delay"`
    - `delay`: number of milliseconds to wait before autosaving
    - `format_on_save`: if `True`, format the code on save
    """

    autosave: Literal["off", "after_delay"]
    autosave_delay: int
    format_on_save: bool


@mddoc
@dataclass
class KeymapConfig(TypedDict):
    """Configuration for keymaps.

    **Keys.**

    - `preset`: one of `"default"` or `"vim"`
    - `overrides`: a dict of keymap actions to their keymap override
    - `vimrc`: path to a vimrc file to load keymaps from
    - `destructive_delete`: if `True`, allows deleting cells with content.
    """

    preset: Literal["default", "vim"]
    overrides: NotRequired[dict[str, str]]
    vimrc: NotRequired[str | None]
    destructive_delete: NotRequired[bool]


OnCellChangeType = Literal["lazy", "autorun"]
ExecutionType = Literal["relaxed", "strict"]


@mddoc
@dataclass
class VenvConfig(TypedDict, total=False):
    """Configuration for an external Python environment in edit mode.

    Launches the notebook kernel in an existing virtualenv. Applies to
    single notebooks and directories when editing without `--sandbox`.

    **Keys.**

    - `path`: path to a virtualenv directory (absolute or relative to
      pyproject.toml)
    - `writable`: if true, marimo will manage script metadata (inline
      dependencies). Defaults to false.
    """

    path: str
    writable: bool


# TODO(akshayka): remove normal, migrate to compact
# normal == compact
WidthType = Literal["normal", "compact", "medium", "full", "columns"]
Theme = Literal["light", "dark", "system"]
ExportType = Literal["html", "markdown", "ipynb"]
SqlOutputType = Literal["polars", "lazy-polars", "pandas", "native", "auto"]
StoreKey = Literal["file", "redis", "rest", "tiered"]


@mddoc
@dataclass
class RuntimeConfig(TypedDict):
    """Configuration for runtime.

    **Keys.**

    - `auto_instantiate`: if `False`, cells won't automatically
        run on startup. This only applies when editing a notebook,
        and not when running as an application.
        The default is `True`.
    - `auto_reload`: if `lazy`, cells importing modified modules will marked
      as stale; if `autorun`, affected cells will be automatically run. similar
      to IPython's %autoreload extension but with more code intelligence.
    - `reactive_tests`: if `True`, marimo will automatically run pytest on cells containing only test functions and test classes.
      execution.
    - `on_cell_change`: if `lazy`, cells will be marked stale when their
      ancestors run but won't autorun; if `autorun`, cells will automatically
      run when their ancestors run.
    - `execution_type`: if `relaxed`, marimo will not clone cell declarations;
      if `strict` marimo will clone cell declarations by default, avoiding
      hidden potential state build up.
    - `watcher_on_save`: how to handle file changes when saving. `"lazy"` marks
        affected cells as stale, `"autorun"` automatically runs affected cells.
    - `output_max_bytes`: the maximum size in bytes of cell outputs; larger
        values may affect frontend performance
    - `serve_cached_sessions_in_apps`: if `True`, initialize applications with session cache.
        The default is `False`.
    - `std_stream_max_bytes`: the maximum size in bytes of console outputs;
      larger values may affect frontend performance
    - `pythonpath`: a list of directories to add to the Python search path.
        Directories will be added to the head of sys.path. Similar to the
        `PYTHONPATH` environment variable, the directories will be included in
        where Python will look for imported modules.
    - `dotenv`: a list of paths to `.env` files to load.
        If the file does not exist, it will be silently ignored. Relative
        paths resolve against the directory holding the `pyproject.toml`,
        or the notebook's directory when there is none. The default is
        `[".env"]`.
    - `default_sql_output`: the default output format for SQL queries. Can be one of:
        `"auto"`, `"native"`, `"polars"`, `"lazy-polars"`, or `"pandas"`.
        The default is `"auto"`.
    - `default_auto_download`: an Optional list of export types to automatically snapshot your notebook as:
       `html`, `markdown`, `ipynb`.
       The default is None.
    - `default_csv_encoding`: the default encoding for CSV exports.
        The default is `"utf-8"`.
    - `show_tracebacks`: if `True`, show detailed error tracebacks in run mode.
        When enabled, exceptions will display a clickable toast that opens a modal with the full traceback.
        The default is `False`.
    """

    auto_instantiate: bool
    auto_reload: Literal["off", "lazy", "autorun"]
    reactive_tests: bool
    on_cell_change: OnCellChangeType
    watcher_on_save: Literal["lazy", "autorun"]
    output_max_bytes: int
    serve_cached_sessions_in_apps: NotRequired[bool]
    std_stream_max_bytes: int
    pythonpath: NotRequired[list[str]]
    dotenv: NotRequired[list[str]]
    default_sql_output: SqlOutputType
    default_auto_download: NotRequired[list[ExportType]]
    default_csv_encoding: NotRequired[str]
    show_tracebacks: NotRequired[bool]


@mddoc
@dataclass
class DisplayConfig(TypedDict):
    """Configuration for display.

    **Keys.**

    - `theme`: `"light"`, `"dark"`, or `"system"`
    - `code_editor_font_size`: font size for the code editor
    - `cell_output`: `"above"` or `"below"`
    - `dataframes`: `"rich"` or `"plain"`
    - `custom_css`: list of paths to custom CSS files
    - `default_table_page_size`: default number of rows to display in tables
    - `default_table_max_columns`: default maximum number of columns to display in tables
    - `reference_highlighting`: if `True`, highlight reactive variable references
    - `code_lens`: if `True`, show inline icons in cell editors linking
      datasources, storage buckets, and caches to their panels
    - `locale`: locale for date formatting and internationalization (e.g., "en-US", "en-GB", "de-DE")
    """

    theme: Theme
    code_editor_font_size: int
    cell_output: Literal["above", "below"]
    default_width: WidthType
    dataframes: Literal["rich", "plain"]
    custom_css: NotRequired[list[str]]
    default_table_page_size: int
    default_table_max_columns: int
    reference_highlighting: NotRequired[bool]
    code_lens: NotRequired[bool]
    locale: NotRequired[str | None]


@mddoc
@dataclass
class FormattingConfig(TypedDict):
    """Configuration for code formatting.

    **Keys.**

    - `line_length`: max line length
    """

    line_length: int


@dataclass
class ServerConfig(TypedDict):
    """Configuration for the server.

    **Keys.**

    - `browser`: the web browser to use. `"default"` or a browser registered
        with Python's webbrowser module (eg, `"firefox"` or `"chrome"`)
    - `follow_symlink`: if true, the server will follow symlinks it finds
        inside its static assets directory.
    - `disable_file_downloads`: if true, the file download button will be
        hidden in the file explorer.
    - `transport`: experimental. The transport used to stream kernel
        messages to the frontend, typically set with the
        `MARIMO_SERVER_TRANSPORT` environment variable. `"websocket"`
        (default) uses the `/ws` WebSocket endpoint; `"sse"` uses
        server-sent events over HTTP, for deployments behind proxies or
        services that do not support WebSockets. Terminal, LSP, and
        real-time collaboration still require WebSockets; RTC is disabled
        when using `"sse"`.
    """

    browser: Literal["default"] | str
    follow_symlink: bool
    disable_file_downloads: NotRequired[bool]
    transport: NotRequired[Literal["websocket", "sse"]]


@dataclass
class PackageManagementConfig(TypedDict):
    """Configuration options for package management.

    **Keys.**

    - `manager`: the package manager to use
    """

    manager: Literal["pip", "rye", "uv", "poetry", "pixi"]


CopilotMode = Literal["ask", "manual", "agent", "code_mode"]


@mddoc
@dataclass
class AiModelConfig(TypedDict):
    """Configuration options for an AI model.

    **Keys.**

    - `chat_model`: the model to use for chat completions
    - `edit_model`: the model to use for edit completions
    - `autocomplete_model`: the model to use for code completion/autocomplete
    - `displayed_models`: a list of models to display in the UI
    - `custom_models`: a list of custom models to use that are not from the default list
    """

    chat_model: NotRequired[str]
    edit_model: NotRequired[str]
    autocomplete_model: NotRequired[str]

    displayed_models: list[str]
    custom_models: list[str]


@dataclass
class AiConfig(TypedDict, total=False):
    """Configuration options for AI.

    **Keys.**

    - `enabled`: if `False`, hide AI actions and panels in the marimo UI
    - `rules`: custom rules to include in all AI completion prompts
    - `max_tokens`: the maximum number of tokens to use in AI completions
    - `mode`: the mode to use for AI completions. Can be one of: `"ask"` or `"manual"`
    - `inline_tooltip`: if `True`, enable inline AI tooltip suggestions
    - `allow_provider_config`: if `False`, lock provider setup in the settings UI, making them read-only. Users cannot bring their own credentials or add custom providers. Default `True`.
    - `models`: the models to use for AI completions
    - `open_ai`: the OpenAI config
    - `anthropic`: the Anthropic config
    - `google`: the Google AI config
    - `bedrock`: the Bedrock config
    - `azure`: the Azure config
    - `ollama`: the Ollama config
    - `github`: the GitHub Copilot config
    - `openrouter`: the OpenRouter config
    - `wandb`: the Weights & Biases config
    - `opencode_go`: the OpenCode Go config
    - `custom_providers`: a dict of custom OpenAI-compatible providers
    - `open_ai_compatible`: the OpenAI-compatible config (deprecated, use custom_providers)
    """

    enabled: NotRequired[bool]
    rules: NotRequired[str]
    max_tokens: NotRequired[int]
    mode: NotRequired[CopilotMode]
    inline_tooltip: NotRequired[bool]
    allow_provider_config: NotRequired[bool]
    models: AiModelConfig
    # providers
    open_ai: OpenAiConfig
    anthropic: AnthropicConfig
    google: GoogleAiConfig
    bedrock: BedrockConfig
    azure: OpenAiConfig
    ollama: OpenAiConfig
    github: GitHubConfig
    openrouter: OpenAiConfig
    wandb: OpenAiConfig
    opencode_go: OpenAiConfig
    custom_providers: NotRequired[dict[str, OpenAiConfig]]
    # @deprecated: use `custom_providers` instead
    open_ai_compatible: OpenAiConfig


@dataclass
class OpenAiConfig(TypedDict, total=False):
    """Configuration options for OpenAI or OpenAI-compatible services.

    **Keys.**

    - `api_key`: the OpenAI API key or an `env:` reference
    - `base_url`: the base URL for the API
    - `project`: the project ID for the OpenAI API
    - `ssl_verify` : Boolean argument for httpx passed to open ai client. httpx defaults to true, but some use cases to let users override to False in some testing scenarios
    - `ca_bundle_path`: custom ca bundle to be used for verifying SSL certificates. Used to create custom SSL context for httpx client
    - `client_pem` : custom path of a client .pem cert used for verifying identity of client server
    - `extra_headers`: extra headers to be passed to the OpenAI client
    """

    api_key: str
    base_url: NotRequired[str]
    project: NotRequired[str]
    ssl_verify: NotRequired[bool]
    ca_bundle_path: NotRequired[str]
    client_pem: NotRequired[str]
    extra_headers: NotRequired[dict[str, str]]

    # @deprecated: use `ai.models.chat_model` instead
    model: NotRequired[str]


@dataclass
class AnthropicConfig(TypedDict, total=False):
    """Configuration options for Anthropic.

    **Keys.**

    - `api_key`: the Anthropic API key or an `env:` reference
    """

    api_key: str


@dataclass
class GoogleAiConfig(TypedDict, total=False):
    """Configuration options for Google AI.

    **Keys.**

    - `api_key`: the Google AI API key or an `env:` reference
    """

    api_key: str


@dataclass
class BedrockConfig(TypedDict, total=False):
    """Configuration options for Bedrock.

    **Keys.**

    - `profile_name`: the AWS profile to use
    - `region_name`: the AWS region to use
    - `aws_access_key_id`: the AWS access key ID
    - `aws_secret_access_key`: the AWS secret access key
    """

    profile_name: NotRequired[str]
    region_name: NotRequired[str]
    aws_access_key_id: NotRequired[str]
    aws_secret_access_key: NotRequired[str]


@dataclass
class GitHubConfig(TypedDict, total=False):
    """Configuration options for GitHub Copilot.

    **Keys.**

    - `api_key`: a GitHub Copilot token or an `env:` reference
    - `base_url`: the base URL for the GitHub Copilot API
    - `copilot_settings`: configuration settings for GitHub Copilot LSP.
        Supports settings like `http` (proxy configuration), `telemetry`,
        and `github-enterprise` (enterprise URI).
    """

    api_key: NotRequired[str]
    base_url: NotRequired[str]
    copilot_settings: NotRequired[dict[str, Any]]


@dataclass
class PythonLanguageServerConfig(TypedDict, total=False):
    """
    Configuration options for Python Language Server.

    pylsp handles completion, hover, go-to-definition, and diagnostics.
    """

    enabled: bool
    enable_mypy: bool
    enable_ruff: bool
    enable_flake8: bool
    enable_pydocstyle: bool
    enable_pylint: bool
    enable_pyflakes: bool


@dataclass
class BasedpyrightServerConfig(TypedDict, total=False):
    """
    Configuration options for basedpyright Language Server.

    basedpyright handles completion, hover, go-to-definition, and diagnostics,
    but we only use it for diagnostics.
    """

    enabled: bool


@dataclass
class TyLanguageServerConfig(TypedDict, total=False):
    """
    Configuration options for Ty Language Server.

    ty handles completion, hover, go-to-definition, and diagnostics,
    but we only use it for diagnostics.
    """

    enabled: bool


@dataclass
class PyreflyLanguageServerConfig(TypedDict, total=False):
    """
    Configuration options for Pyrefly Language Server.

    Pyrefly handles completion, hover, go-to-definition, and diagnostics.
    """

    enabled: bool


@dataclass
class LanguageServersConfig(TypedDict, total=False):
    """Configuration options for language servers.

    **Keys.**

    - `pylsp`: the pylsp config
    - `basedpyright`: the basedpyright config
    - `ty`: the ty config
    - `pyrefly`: the pyrefly config
    """

    pylsp: PythonLanguageServerConfig
    basedpyright: BasedpyrightServerConfig
    ty: TyLanguageServerConfig
    pyrefly: PyreflyLanguageServerConfig


@dataclass
class DiagnosticsConfig(TypedDict, total=False):
    """Configuration options for diagnostics.

    **Keys.**

    - `enabled`: if `True`, diagnostics will be shown in the editor
    - `sql_linter`: if `True`, SQL cells will have linting enabled
    """

    enabled: bool
    sql_linter: bool


@dataclass
class LintConfig(TypedDict, total=False):
    """Configuration for lint rule selection.

    Follows ruff-inspired semantics for selecting which rules to run
    during `marimo check`.

    **Keys.**

    - `select`: list of rule code prefixes that replaces the default
      enabled set. Use `"ALL"` to select all rules.
      Example: `["MB", "MR001"]`
    - `ignore`: list of rule code prefixes to remove from the
      enabled set.
    """

    select: list[str]
    ignore: list[str]


@dataclass
class SnippetsConfig(TypedDict):
    """Configuration for snippets.

    **Keys.**

    - `custom_path`: the path to the custom snippets directory
    """

    custom_paths: NotRequired[list[str]]
    include_default_snippets: NotRequired[bool]


@dataclass
class DatasourcesConfig(TypedDict):
    """Configuration for datasources panel.

    **Keys.**

    - `auto_discover_schemas`: if `True`, include schemas in the datasource
    - `auto_discover_tables`: if `True`, include tables in the datasource
    - `auto_discover_columns`: if `True`, include columns & table metadata in the datasource
    """

    auto_discover_schemas: NotRequired[bool | Literal["auto"]]
    auto_discover_tables: NotRequired[bool | Literal["auto"]]
    auto_discover_columns: NotRequired[bool | Literal["auto"]]


@dataclass
class FolderConfig(TypedDict):
    """Configuration for an additional file browser root.

    **Keys.**

    - `path`: the absolute path to the folder
    - `name`: an optional display name for the folder
    """

    path: str
    name: NotRequired[str]


@dataclass
class FileBrowserConfig(TypedDict):
    """Configuration for the file browser panel.

    **Keys.**

    - `folders`: additional absolute folders to show in the file browser
    """

    folders: NotRequired[list[FolderConfig]]


@mddoc
@dataclass
class SharingConfig(TypedDict):
    """Configuration for sharing features.

    **Keys.**

    - `html`: if `False`, HTML sharing options will be hidden from the UI
    - `wasm`: if `False`, WebAssembly sharing options will be hidden from the UI
    - `molab`: if `False`, molab sharing options will be hidden from the UI
    """

    html: NotRequired[bool]
    wasm: NotRequired[bool]
    molab: NotRequired[bool]


@dataclass
class StoreConfig(TypedDict, total=False):
    """Configuration for a single cache store."""

    type: StoreKey
    args: dict[str, Any]


# One store, or a list composed into a TieredStore.
CacheStoreConfig = list[StoreConfig] | StoreConfig

CacheVerification = Literal["off", "on", "strict"]


class CacheConfig(TypedDict, total=False):
    """Configuration for caching.

    `verification` is the signature-checking posture; `store` is the backing
    store, or a list of stores composed into a `TieredStore`.
    """

    verification: CacheVerification
    store: CacheStoreConfig


class SigningConfig(TypedDict, total=False):
    """Cache-signing trust and identity.

    `trusted_signers` maps a key fingerprint (`"SHA256:<base64>"`) to an
    advisory label. Trusting a key allows arbitrary code execution from its
    holder on this machine — a cache restore is `pickle.loads` — so there is no
    lesser cache-only grant. `private_key_path` is this machine's signing
    identity; it is never serialized to the frontend.
    """

    trusted_signers: dict[str, str]
    private_key_path: str


class ExperimentalConfig(TypedDict, total=False):
    """
    Configuration for experimental features.

    Features exposed on the frontend must match the frontend config.
    """

    markdown: bool  # Used in playground (community cloud)
    wasm_layouts: bool  # Used in playground (community cloud)
    rtc_v2: bool
    isolate_apps: bool
    debugger: bool  # Live frame-watching debugger (gutter breakpoints + pdb)
    line_timing: bool  # Active-line highlight + per-line timer (sys.settrace)

    # Internal features
    execution_type: ExecutionType


# Prefer to accept any dict since feature flags can change frequently
# But maintain type safety for known flags
ExperimentalConfigType = dict[str, Any]


@mddoc
@dataclass
class MarimoConfig(TypedDict):
    """Configuration for the marimo editor"""

    completion: CompletionConfig
    display: DisplayConfig
    formatting: FormattingConfig
    keymap: KeymapConfig
    runtime: RuntimeConfig
    save: SaveConfig
    server: ServerConfig
    package_management: PackageManagementConfig
    ai: NotRequired[AiConfig]
    language_servers: NotRequired[LanguageServersConfig]
    diagnostics: NotRequired[DiagnosticsConfig]
    lint: NotRequired[LintConfig]
    experimental: NotRequired[ExperimentalConfigType]
    snippets: NotRequired[SnippetsConfig]
    datasources: NotRequired[DatasourcesConfig]
    file_browser: NotRequired[FileBrowserConfig]
    sharing: NotRequired[SharingConfig]
    mcp: NotRequired[MCPConfig]
    venv: NotRequired[VenvConfig]
    cache: NotRequired[CacheConfig]
    signing: NotRequired[SigningConfig]


@mddoc
@dataclass
class MCPServerStdioConfig(TypedDict):
    """Configuration for STDIO transport MCP servers"""

    command: str
    args: NotRequired[list[str] | None]
    env: NotRequired[dict[str, str] | None]
    disabled: NotRequired[bool | None]


@mddoc
@dataclass
class MCPServerStreamableHttpConfig(TypedDict):
    """Configuration for Streamable HTTP transport MCP servers"""

    url: str
    headers: NotRequired[dict[str, str] | None]
    timeout: NotRequired[float | None]
    env: NotRequired[dict[str, str] | None]
    disabled: NotRequired[bool | None]


if TYPE_CHECKING:
    MCPServerConfig = MCPServerStdioConfig | MCPServerStreamableHttpConfig
else:
    MCPServerConfig = dict[str, Any]


@mddoc
@dataclass
class MCPConfig(TypedDict):
    """
    Configuration for MCP servers

    Note: the field name `mcpServers` is camelCased to match MCP server
    config conventions used by popular AI applications (e.g. Cursor, Claude Desktop, etc.)
    """

    mcpServers: dict[str, MCPServerConfig]
    presets: NotRequired[list[Literal["marimo", "context7"]]]


@mddoc
@dataclass
class PartialMarimoConfig(TypedDict, total=False):
    """Partial configuration for the marimo editor"""

    completion: CompletionConfig
    display: DisplayConfig
    formatting: FormattingConfig
    keymap: KeymapConfig
    runtime: RuntimeConfig
    save: SaveConfig
    server: ServerConfig
    package_management: PackageManagementConfig
    ai: NotRequired[AiConfig]
    language_servers: NotRequired[LanguageServersConfig]
    diagnostics: NotRequired[DiagnosticsConfig]
    lint: NotRequired[LintConfig]
    experimental: NotRequired[ExperimentalConfigType]
    snippets: SnippetsConfig
    datasources: NotRequired[DatasourcesConfig]
    file_browser: NotRequired[FileBrowserConfig]
    sharing: NotRequired[SharingConfig]
    venv: NotRequired[VenvConfig]
    cache: NotRequired[CacheConfig]
    signing: NotRequired[SigningConfig]


DEFAULT_CONFIG: MarimoConfig = {
    "completion": {
        "activate_on_typing": True,
        "signature_hint_on_typing": False,
        "copilot": False,
        "auto_close_pairs": True,
    },
    "display": {
        "theme": "light",
        "code_editor_font_size": 14,
        "cell_output": "below",
        "default_width": "medium",
        "dataframes": "rich",
        "default_table_page_size": 10,
        "default_table_max_columns": 50,
        "reference_highlighting": True,
        "code_lens": True,
    },
    "formatting": {"line_length": 79},
    "keymap": {"preset": "default", "overrides": {}},
    # dotenv's default value is set at runtime, since it resolves relative to
    # the pyproject.toml or the notebook's directory.
    "runtime": {
        "auto_instantiate": False,
        "auto_reload": "off",
        "reactive_tests": True,
        "on_cell_change": "autorun",
        "watcher_on_save": "lazy",
        "output_max_bytes": int(
            os.getenv("MARIMO_OUTPUT_MAX_BYTES", "8000000")
        ),
        "std_stream_max_bytes": int(
            os.getenv("MARIMO_STD_STREAM_MAX_BYTES", "1000000")
        ),
        "default_sql_output": "auto",
        "default_csv_encoding": "utf-8",
        "show_tracebacks": False,
    },
    "save": {
        "autosave": "after_delay",
        "autosave_delay": 1000,
        "format_on_save": False,
    },
    "package_management": {"manager": infer_package_manager()},
    "server": {
        "browser": "default",
        "follow_symlink": False,
    },
    "language_servers": {
        "pylsp": {
            "enabled": False,
            "enable_mypy": True,
            "enable_ruff": True,
            "enable_flake8": False,
            "enable_pydocstyle": False,
            "enable_pylint": False,
            "enable_pyflakes": False,
        }
    },
    "ai": {
        "enabled": True,
        "allow_provider_config": True,
        "models": {
            "displayed_models": [],
            "custom_models": [],
        },
        "custom_providers": {},
    },
    "snippets": {
        "custom_paths": [],
        "include_default_snippets": True,
    },
    "mcp": {
        "mcpServers": {},
        "presets": [],
    },
    "diagnostics": {
        "sql_linter": True,
    },
}


def merge_default_config(
    config: PartialMarimoConfig | MarimoConfig,
) -> MarimoConfig:
    """Merge a user configuration with the default configuration."""
    return merge_config(DEFAULT_CONFIG, config)


def merge_config(
    config: MarimoConfig,
    new_config: PartialMarimoConfig | MarimoConfig,
) -> MarimoConfig:
    """Merge a user configuration with a new configuration. The new config
    will take precedence over the default config.

    Args:
        config: The default configuration.
        new_config: The new configuration to merge with the default config.

    Returns:
        A merged configuration.
    """
    # Remove the keymap overrides from the incoming config,
    # so that they don't get merged into the new config
    if new_config.get("keymap", {}).get("overrides") is not None:
        # Clone config to avoid modifying the original
        config = deep_copy(config)
        config.get("keymap", {}).pop("overrides", {})

    # Fields that should be replaced instead of merged.
    # These are "record" types where keys can be added/removed,
    # as opposed to config objects where you only set specific fields.
    # NB. `signing.trusted_signers` is replaced, not deep-merged. A deep merge
    # unions the fingerprints from every layer. Then no layer can remove a
    # signer that a lower-priority one anchored.
    replace_paths = frozenset(
        {"ai.custom_providers", "signing.trusted_signers"}
    )

    merged = cast(
        MarimoConfig,
        deep_merge(
            cast(dict[Any, Any], config),
            cast(dict[Any, Any], new_config),
            replace_paths=replace_paths,
        ),
    )

    # Patches for backward compatibility
    if "runtime" in merged:
        if (
            merged["runtime"].get("auto_reload") is False  # type:ignore[comparison-overlap]
        ):
            merged["runtime"]["auto_reload"] = "off"
        elif (
            merged["runtime"].get("auto_reload") is True  # type:ignore[comparison-overlap]
        ) or (
            merged["runtime"].get("auto_reload") == "detect"  # type:ignore[comparison-overlap]
        ):
            merged["runtime"]["auto_reload"] = "lazy"

    return merged
