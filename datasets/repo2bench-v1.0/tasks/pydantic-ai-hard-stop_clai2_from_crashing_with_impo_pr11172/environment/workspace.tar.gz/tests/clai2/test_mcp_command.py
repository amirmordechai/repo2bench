"""The `/mcp` command surface: the add/edit server form, trust, help, and completion."""

import hashlib
import io
import json
import os
import sys
from pathlib import Path

import pytest
from pydantic import HttpUrl
from rich.console import Console
from termflow.tui.menu import MenuResult
from termflow.tui.textinput import TextInputResult

from pydantic_clai2.commands import Commands
from pydantic_clai2.mcp import (
    CLAUDE_MCP_FILE,
    EXAMPLES,
    HELP,
    PROJECT_MCP_FILE,
    HTTPServer,
    MCPCommand,
    MCPPlugin,
    MCPServers,
    MCPSettings,
    MCPStore,
    ServerForm,
    SSEServer,
    StdioServer,
    edit_in_editor,
    run_form,
)
from pydantic_clai2.plugins import PluginHost, collect
from pydantic_clai2.ui.menus.dialogs import TerminalDialogs
from tests.clai2.dialog_script import Back, Pick, ScriptedDialogs, Type
from tests.clai2.menu_script import Script, pick, typed

ESC = MenuResult(cancelled=True)


def make(
    tmp_path: Path, script: Script | None = None, edits: list[str | None] | None = None
) -> tuple[MCPCommand, MCPStore]:
    store = MCPStore(tmp_path / 'config', workspace=tmp_path / 'repo')
    (tmp_path / 'repo' / '.git').mkdir(parents=True, exist_ok=True)
    pending = iter(edits or [])
    command = MCPCommand(servers=MCPServers(store), editor=lambda _: next(pending))
    if script is not None:
        command.runners = script.runners
    return command, store


def stdio(command: str = 'python', *args: str) -> StdioServer:
    return StdioServer(type='stdio', command=command, args=list(args))


async def test_help_errors_and_usage(tmp_path: Path) -> None:
    command, _ = make(tmp_path)
    assert await command(['help']) == HELP
    for sub in ('install', 'start', 'stop', 'restart', 'status', 'logs', 'edit', 'remove', 'trust', 'start-all'):
        assert f'/mcp {sub}' in HELP
    assert 'search' not in HELP and 'catalog' not in HELP
    with pytest.raises(ValueError, match='Unknown MCP subcommand: nope'):
        await command(['nope'])
    with pytest.raises(ValueError, match='Usage: /mcp install'):
        await command(['install', 'github'])
    with pytest.raises(ValueError, match='Usage: /mcp start NAME'):
        await command(['start'])
    with pytest.raises(ValueError, match=r'Unknown MCP server: ghost. Known: none'):
        await command(['status', 'ghost'])
    assert await command(['status']) == await command([])
    assert await command(['start-all']) == 'No MCP servers to start.'
    assert await command(['stop-all']) == 'No MCP servers to stop.'


async def test_install_stdio_through_the_form(tmp_path: Path) -> None:
    config = json.dumps({'command': 'uvx', 'args': ['my-server'], 'env': {'TOKEN': '$MY_TOKEN'}})
    script = Script(lists=[], choices=[pick('name'), pick('json'), pick('save')], texts=[typed(' files ')])
    command, store = make(tmp_path, script, edits=[config])
    message = await command(['install'])
    assert message.startswith('Added files. The agent can use it on your next prompt')
    assert 'Set MY_TOKEN' in message
    assert store.load().servers['files'] == StdioServer(
        type='stdio', command='uvx', args=['my-server'], env={'TOKEN': '$MY_TOKEN'}
    )
    assert '! files' in await command([]), 'MY_TOKEN is not set'


async def test_install_remote_with_type_swap_and_oauth(tmp_path: Path) -> None:
    dialogs = ScriptedDialogs(
        [
            Pick(value='type'),
            Pick(value='http'),
            Pick(value='target'),
            Type(text='https://mcp.example.com/mcp'),
            Pick(value='oauth'),
            Pick(value='name'),
            Type(text='docs'),
            Pick(value='save'),
        ]
    )
    command, store = make(tmp_path)
    assert (await command.run(['install'], dialogs=dialogs, editor=None)).startswith('Added docs.')
    form, *_ = dialogs.asked
    assert form.title == 'Add Custom MCP Server' and form.description.startswith('Name   (not set)')
    assert dialogs.asked[1].current == 'stdio', 'the type picker marks the current type'
    saved = store.load().servers['docs']
    assert isinstance(saved, HTTPServer)
    assert str(saved.url) == 'https://mcp.example.com/mcp'
    assert saved.auth == 'oauth' and saved.timeout == 330, 'OAuth allows time for the browser sign-in'
    assert saved.headers is None, 'switching on OAuth drops the Authorization header'


async def test_form_saves_only_valid_servers(tmp_path: Path) -> None:
    store = MCPStore(tmp_path / 'config')
    store.put('taken', stdio())
    form = ServerForm(store)
    assert not form.save() and form.status == 'Save failed: Server name is required'
    form.name = 'taken'
    assert not form.save() and 'taken already exists' in (form.status or '')
    form.name = 'bad_name'
    assert form.name_problem(form.name) is not None
    form.name = 'fresh-one'
    form.config = '{not json'
    assert not form.save() and 'Invalid JSON' in (form.status or '')
    assert 'JSON Configuration (INVALID)' in [option.label for option in form.options()]
    form.config = '{}'
    assert form.problem() == 'command: Field required'
    form.config = '{"command": "x", "typo": 1}'
    assert form.problem() == 'typo: Extra inputs are not permitted'
    form.select_type('http')
    form.config = '{"url": "https://example.com/mcp", "auth": "oauth", "headers": {"Authorization": "x"}}'
    assert 'Authorization' in (form.problem() or '')
    form.config = '{"type": "stdio", "url": "https://example.com/mcp"}'
    assert form.problem() is None, 'the Server Type row wins over a stale "type" key'
    assert form.save() and isinstance(store.load().servers['fresh-one'], HTTPServer)


def test_form_rows_preview_and_examples(tmp_path: Path) -> None:
    form = ServerForm(MCPStore(tmp_path / 'config'))
    labels = [option.label for option in form.options()]
    assert labels == [
        'Server Name: (not set)',
        'Server Type: stdio',
        'Command: npx -y @modelcontextprotocol/server-filesystem /path/to/dir',
        'JSON Configuration (valid)',
        'Load example for stdio',
        'Save & Install',
        'Cancel',
    ]
    assert form.title == 'Add Custom MCP Server' and 'Configuration is valid' in form.preview()
    assert 'OAuth' not in form.preview()
    form.select_type('sse')
    assert form.config == EXAMPLES['sse'], 'an untouched example follows the type'
    assert 'OAuth sign-in: off' in [option.label for option in form.options()]
    assert '/mcp auth NAME signs in' in form.preview()
    form.config = '{"url": "https://example.com/sse"}'
    form.select_type('http')
    assert form.config == '{"url": "https://example.com/sse"}', 'edited configuration is kept'
    form.toggle_oauth()
    assert form.oauth and 'OAuth sign-in: on' in [option.label for option in form.options()]
    form.toggle_oauth()
    assert not form.oauth and json.loads(form.config) == {'url': 'https://example.com/sse'}
    form.config = '{"url": "https://example.com/sse", "auth": "oauth", "timeout": 60}'
    form.toggle_oauth()
    assert json.loads(form.config) == {'url': 'https://example.com/sse', 'timeout': 60}, 'a chosen timeout stays'
    form.config = json.dumps({'url': 'https://example.com/mcp', 'headers': {'authorization': 'x', 'X-Team': 'a'}})
    form.toggle_oauth()
    assert json.loads(form.config)['headers'] == {'X-Team': 'a'} and 'Removed the Authorization' in (form.status or '')
    form.config = 'broken'
    form.toggle_oauth()
    assert form.status == 'Fix the JSON before switching OAuth' and not form.oauth
    assert 'Fix the JSON' in form.preview() and 'Invalid: Invalid JSON' in form.preview()
    form.load_example()
    assert form.config == EXAMPLES['http'] and form.status is None


async def test_json_fallback_when_no_editor_runs(tmp_path: Path) -> None:
    """The terminal's one-line input when its editor cannot run; empty text or backing out keeps the JSON."""
    store = MCPStore(tmp_path / 'config')
    script = Script(
        lists=[],
        choices=[pick('json'), pick('json'), pick('json'), pick('cancel')],
        texts=[typed('{"command": "uvx"}'), TextInputResult(cancelled=True), typed('  ')],
    )
    form = ServerForm(store)
    form.config = 'not json yet'
    assert not await run_form(form, TerminalDialogs(script.runners), editor=lambda _: None)
    assert json.loads(form.config) == {'command': 'uvx'}
    assert script.opened == ['choice', 'text', 'choice', 'text', 'choice', 'text', 'choice']


async def test_without_an_editor_the_dialog_edits_the_indented_json(tmp_path: Path) -> None:
    """As the web UI asks: the JSON as it is, which its dialog edits over several lines."""
    form = ServerForm(MCPStore(tmp_path / 'config'))
    dialogs = ScriptedDialogs([Pick(value='json'), Type(text='{"command": "uvx"}'), Back()])
    assert not await run_form(form, dialogs)
    assert dialogs.asked[1].initial == EXAMPLES['stdio'] and '\n' in dialogs.asked[1].initial
    assert json.loads(form.config) == {'command': 'uvx'}


async def test_form_cancel_paths(tmp_path: Path) -> None:
    store = MCPStore(tmp_path / 'config')
    form = ServerForm(store)
    dialogs = ScriptedDialogs(
        [
            Pick(value='name'),
            Back(),
            Pick(value='type'),
            Back(),
            Pick(value='target'),
            Back(),
            Pick(value='example'),
            Pick(value='save'),
            Back(),
        ]
    )
    assert not await run_form(form, dialogs)
    assert form.status == 'Save failed: Server name is required'
    assert form.type == 'stdio' and form.name == ''


async def test_an_empty_name_keeps_the_name(tmp_path: Path) -> None:
    form = ServerForm(MCPStore(tmp_path / 'config'), name='local', server=stdio())
    assert not await run_form(form, ScriptedDialogs([Pick(value='name'), Type(text=''), Back()]))
    assert form.name == 'local'


async def test_install_cancelled(tmp_path: Path) -> None:
    command, store = make(tmp_path, Script(lists=[], choices=[pick('cancel'), pick('cancel')], texts=[]))
    assert await command(['install']) == 'Exited custom server form.'
    assert await command(['INSTALL']) == 'Exited custom server form.', 'subcommands ignore case'
    assert store.load().servers == {}


async def test_missing_program_is_reported(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv('PATH', str(tmp_path / 'empty'))
    script = Script(lists=[], choices=[pick('name'), pick('save')], texts=[typed('fs')])
    command, _ = make(tmp_path, script)
    assert 'npx is not on PATH' in await command(['install'])


async def test_edit_prefills_renames_and_cancels(tmp_path: Path) -> None:
    script = Script(lists=[], choices=[pick('name'), pick('json'), pick('save'), ESC], texts=[typed('renamed')])
    command, store = make(tmp_path, script, edits=[json.dumps({'command': 'uvx', 'args': ['new'], 'timeout': 5})])
    store.put('local', StdioServer(type='stdio', command='python', env={'A': 'b'}))
    form = ServerForm(store, name='local', server=store.load().servers['local'])
    assert json.loads(form.config) == {'type': 'stdio', 'command': 'python', 'env': {'A': 'b'}}
    assert form.title == 'Edit MCP Server' and 'Save changes' in [option.label for option in form.options()]
    assert form.name_problem('local') is None, 'keeping the name is not a clash'
    assert (await command(['edit', 'local'])).startswith('Updated renamed.')
    assert list(store.load().servers) == ['renamed']
    assert store.load().servers['renamed'] == StdioServer(type='stdio', command='uvx', args=['new'], timeout=5)
    assert await command(['edit', 'renamed']) == 'No changes.'


@pytest.mark.subprocess(reason='starts a real stdio MCP server written in Python')
async def test_edit_restarts_a_running_server(tmp_path: Path) -> None:
    server = tmp_path / 'server.py'
    server.write_text(
        'from mcp.server.fastmcp import FastMCP\nserver = FastMCP("t")\n'
        '@server.tool()\ndef ping() -> str:\n    return "pong"\nserver.run()\n'
    )
    config = json.dumps({'command': sys.executable, 'args': [str(server)], 'cwd': str(tmp_path)})
    command, store = make(tmp_path, Script(lists=[], choices=[pick('json'), pick('save')], texts=[]), edits=[config])
    store.put('local', stdio(sys.executable, str(server)))
    await command(['start', 'local'])
    lines = (await command(['edit', 'local'])).splitlines()
    assert lines[0].startswith('Updated local.')
    assert lines[-1] == 'Started local with 1 tools. The agent can use them on your next prompt.'
    await command.servers.close()


async def test_edit_refuses_servers_mcp_does_not_own(tmp_path: Path) -> None:
    store = MCPStore(tmp_path / 'config', workspace=tmp_path)
    command = MCPCommand(servers=MCPServers(store, {'legacy': stdio()}))
    with pytest.raises(ValueError, match='/plugins'):
        await command(['edit', 'legacy'])


@pytest.mark.subprocess(reason='runs Python scripts as the `$VISUAL`/`$EDITOR` commands')
def test_editor_round_trip(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    edit = tmp_path / 'edit.py'
    edit.write_text('import sys, pathlib\npathlib.Path(sys.argv[1]).write_text("{\\"command\\": \\"edited\\"}")\n')
    monkeypatch.setenv('VISUAL', f'{sys.executable} {edit}')
    assert edit_in_editor('{}') == '{"command": "edited"}'
    monkeypatch.setenv('VISUAL', f'{sys.executable} -c "raise SystemExit(1)"')
    assert edit_in_editor('{}') is None
    monkeypatch.setenv('VISUAL', str(tmp_path / 'no-such-editor'))
    assert edit_in_editor('{}') is None
    monkeypatch.setenv('VISUAL', 'vim "unclosed')
    assert edit_in_editor('{}') is None, 'an unparsable editor falls back to the one-line input'


async def test_project_file_trust(tmp_path: Path) -> None:
    command, store = make(tmp_path)
    assert 'No .clai/mcp_servers.json' in await command(['trust'])
    project = tmp_path / 'repo' / PROJECT_MCP_FILE
    project.parent.mkdir()
    project.write_text('{"servers": {"team": {"type": "stdio", "command": "team-server"}}}')

    dashboard = await command([])
    assert 'not trusted, so its servers are not loaded' in dashboard and 'team' not in dashboard.split('\n\n')[0]
    assert (await command(['trust'])).endswith('untrusted')
    assert 'Servers loaded: team' in await command(['trust', 'accept'])
    assert 'project' in await command([])
    assert 'team' in await command(['status', 'team'])
    with pytest.raises(ValueError, match='change that file instead'):
        await command(['edit', 'team'])
    with pytest.raises(ValueError, match='change that file instead'):
        await command(['remove', 'team'])
    assert 'Stopped team' in await command(['stop', 'team'])
    assert '- team' in await command([]), 'project servers stop for the session only'
    assert 'team-server' in project.read_text()

    project.write_text('{"servers": {"team": {"type": "stdio", "command": "other"}}}')
    assert 'changed since you trusted it' in await command([])
    assert (await command(['trust', 'status'])).endswith('changed')
    assert 'Revoked trust' in await command(['trust', 'revoke'])
    assert 'Not trusted:' in await command(['trust', 'revoke'])
    with pytest.raises(ValueError, match='Usage: /mcp trust'):
        await command(['trust', 'maybe'])

    project.write_text('{"servers": {"bad_name": {}}}')
    store.trust(project)
    with pytest.raises(ValueError, match=r'mcp_servers.json'):
        await command([])
    project.unlink()
    project.mkdir()
    assert store.trust_state(project) == 'changed', 'an unreadable file fails closed'
    assert store.project_servers() == {}


CLAUDE_CONFIG = {
    'mcpServers': {
        'claude-local': {'command': 'npx', 'args': ['-y', 'some-server'], 'env': {'TOKEN': '${TOKEN}'}},
        'claude-remote': {'type': 'http', 'url': 'https://example.com/mcp', 'headers': {'X-Key': '$KEY'}},
        'claude-sse': {'type': 'sse', 'url': 'https://example.com/sse'},
    }
}


async def test_claude_code_mcp_json(tmp_path: Path) -> None:
    make(tmp_path)
    claude = tmp_path / 'repo' / CLAUDE_MCP_FILE
    claude.write_text(json.dumps(CLAUDE_CONFIG))
    nested = tmp_path / 'repo' / 'src' / 'pkg'
    nested.mkdir(parents=True)
    store = MCPStore(tmp_path / 'config', workspace=nested)
    command = MCPCommand(servers=MCPServers(store))
    assert store.project_files() == [claude.resolve()], 'found from a subdirectory, up to the git root'

    assert f'{claude.resolve()} is not trusted' in await command([])
    assert store.project_servers() == {}
    assert 'Servers loaded: claude-local, claude-remote, claude-sse' in await command(['trust', 'accept'])
    local, remote, sse = command.servers.entries()
    assert isinstance(local.server, StdioServer) and local.server.args == ['-y', 'some-server']
    assert isinstance(remote.server, HTTPServer) and isinstance(sse.server, SSEServer)
    assert local.source == 'project' and local.path == claude.resolve()
    assert f'project ({claude.resolve()})' in await command(['status', 'claude-local'])
    assert 'TOKEN' in await command(['status', 'claude-local'])
    with pytest.raises(ValueError, match=r'\.mcp\.json; change that file instead'):
        await command(['edit', 'claude-remote'])

    claude.write_text(json.dumps({'servers': CLAUDE_CONFIG['mcpServers']}))
    store.trust(claude.resolve())
    with pytest.raises(ValueError, match=r'(?s)\.mcp\.json: .*servers\s+Extra inputs'):
        store.project_servers()


async def test_both_project_files_load_with_clai_first(tmp_path: Path) -> None:
    command, store = make(tmp_path)
    clai = tmp_path / 'repo' / PROJECT_MCP_FILE
    clai.parent.mkdir()
    clai.write_text('{"servers": {"shared": {"type": "stdio", "command": "from-clai"}}}')
    claude = tmp_path / 'repo' / CLAUDE_MCP_FILE
    claude.write_text('{"mcpServers": {"shared": {"command": "from-claude"}, "extra": {"command": "x"}}}')
    clai, claude = clai.resolve(), claude.resolve()

    dashboard = await command([])
    assert f'{clai} is not trusted' in dashboard and f'{claude} is not trusted' in dashboard
    assert (await command(['trust'])).splitlines() == [f'{clai}: untrusted', f'{claude}: untrusted']
    assert f'Trusted {clai}, {claude}. Servers loaded: shared, shared, extra' in await command(['trust', 'accept'])
    shared, extra = command.servers.entries()
    assert isinstance(shared.server, StdioServer) and shared.server.command == 'from-clai'
    assert shared.path == clai and extra.path == claude

    assert 'Stopped shared' in await command(['stop', 'shared'])
    clai.write_text('{"servers": {}}')
    store.trust(clai)
    [fallback, _] = command.servers.entries()
    assert fallback.path == claude and command.servers.state(fallback) == 'ready', (
        "a session stop belongs to the definition, not to another file's server of the same name"
    )

    clai.write_text('{"servers": {"mine": {"type": "stdio", "command": "from-clai"}}}')
    store.trust(clai)
    claude.write_text('{"mcpServers": {}}')
    assert f'{claude} is changed since you trusted it' in await command([])
    assert [entry.name for entry in command.servers.entries()] == ['mine'], 'the unchanged file stays loaded'
    assert await command(['trust', 'revoke']) == f'Revoked trust in {clai}, {claude}.'
    assert store.project_servers() == {}


def test_trust_is_all_or_nothing_when_one_file_is_a_symlink(tmp_path: Path) -> None:
    _, store = make(tmp_path)
    clai = tmp_path / 'repo' / PROJECT_MCP_FILE
    clai.parent.mkdir()
    clai.write_text('{"servers": {}}')
    elsewhere = tmp_path / 'elsewhere.json'
    elsewhere.write_text('{"mcpServers": {}}')
    claude = tmp_path / 'repo' / CLAUDE_MCP_FILE
    claude.symlink_to(elsewhere)
    with pytest.raises(ValueError, match=r'\.mcp\.json: a symlink'):
        store.trust(*store.project_files())
    assert store.load().trusted_projects == {}


def test_a_symlink_swapped_in_after_the_check_is_not_read(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _, store = make(tmp_path)
    elsewhere = tmp_path / 'elsewhere.json'
    elsewhere.write_text('{"mcpServers": {"evil": {"command": "evil"}}}')
    claude = tmp_path / 'repo' / CLAUDE_MCP_FILE
    claude.symlink_to(elsewhere)
    data = store.load()
    digest = hashlib.sha256(elsewhere.read_bytes()).hexdigest()
    store.save(data.model_copy(update={'trusted_projects': {str(claude.absolute()): digest}}))

    def checked_before_the_swap(self: Path) -> bool:
        return False

    monkeypatch.setattr(Path, 'is_symlink', checked_before_the_swap)
    with pytest.raises(ValueError, match='Cannot trust a project MCP file'):
        store.trust(claude)
    assert store.trust_state(claude) == 'changed'
    assert store.project_servers() == {}


@pytest.mark.skipif(not hasattr(os, 'mkfifo'), reason='FIFOs are POSIX-only')
async def test_a_fifo_project_file_does_not_block(tmp_path: Path) -> None:
    command, store = make(tmp_path)
    fifo = tmp_path / 'repo' / CLAUDE_MCP_FILE
    os.mkfifo(fifo)
    with pytest.raises(ValueError, match='not a regular file'):
        await command(['trust', 'accept'])
    data = store.load()
    store.save(data.model_copy(update={'trusted_projects': {str(fifo.resolve()): 'x'}}))
    assert store.trust_state(fifo.resolve()) == 'changed' and store.project_servers() == {}


def test_user_servers_shadow_project_servers(tmp_path: Path) -> None:
    command, store = make(tmp_path)
    project = tmp_path / 'repo' / PROJECT_MCP_FILE
    project.parent.mkdir()
    project.write_text('{"servers": {"shared": {"type": "stdio", "command": "project"}}}')
    store.trust(project)
    store.put('shared', stdio('mine'))
    [only] = command.servers.entries()
    assert only.source == 'user' and isinstance(only.server, StdioServer) and only.server.command == 'mine'


async def test_dashboard_lists_every_type(tmp_path: Path) -> None:
    command, store = make(tmp_path)
    store.put('local', stdio())
    store.put('docs', HTTPServer(type='http', url=HttpUrl('https://example.com/mcp')))
    store.put('old', SSEServer(type='sse', url=HttpUrl('https://example.com/sse')))
    dashboard = await command([])
    assert 'stdio' in dashboard and 'http' in dashboard and 'sse' in dashboard
    assert '0/3 running, 3 available to the agent' in dashboard
    assert await command(['remove', 'local']) == 'Removed local.'


async def test_completion(tmp_path: Path) -> None:
    command, store = make(tmp_path)
    store.put('local', stdio())
    assert 'install' in command.complete([]) and 'start-all' in command.complete([''])
    assert 'search' not in command.complete([])
    assert list(command.complete(['start', ''])) == ['local']
    assert tuple(command.complete(['install', ''])) == ()
    assert tuple(command.complete(['trust', ''])) == ('status', 'accept', 'revoke')
    store.path.write_text('not json')
    assert tuple(command.complete(['start', ''])) == ()


async def test_registered_completion_through_the_command_registry(tmp_path: Path) -> None:
    host: PluginHost[None] = PluginHost(name='mcp', console=Console(file=io.StringIO()), settings={})
    store = MCPStore(tmp_path / 'config', workspace=tmp_path)
    loaded = collect(MCPPlugin(host, MCPSettings(), store=store))
    registry = Commands()
    registry.register_many(loaded.commands)
    store.put('local', stdio())
    [mcp] = list(registry)
    assert 'local' in mcp.complete(['logs', ''])


def test_url_and_command_rows(tmp_path: Path) -> None:
    form = ServerForm(MCPStore(tmp_path / 'config'))
    assert form.target_label == 'Command'
    assert form.target_problem('uvx "unclosed') == 'No closing quotation'
    assert form.target_problem('  ') == 'Enter the program to run, then its arguments'
    assert form.target_problem('uvx my-server') is None
    form.set_target('uvx my-server --flag "a b"')
    assert json.loads(form.config)['args'] == ['my-server', '--flag', 'a b']
    assert form.target() == "uvx my-server --flag 'a b'"
    form.set_target('my-server')
    assert 'args' not in json.loads(form.config)
    form.config = '{"command": 3, "args": "x"}'
    assert form.target() == ''
    form.config = '{"command": "x", "args": "x"}'
    assert form.target() == 'x'
    form.select_type('sse')
    assert form.target_label == 'URL' and form.target() == ''
    assert form.target_problem('ftp://example.com') == 'Enter an http:// or https:// URL'
    form.set_target(' https://example.com/sse ')
    assert form.target() == 'https://example.com/sse'
    assert 'URL: https://example.com/sse' in [option.label for option in form.options()]
    form.config = 'broken'
    assert form.target() == ''
    form.set_target('https://example.com/sse')
    assert form.status == 'Fix the JSON before editing the URL'


async def test_surplus_arguments_are_rejected(tmp_path: Path) -> None:
    command, store = make(tmp_path)
    store.put('local', stdio())
    for args in (['remove', 'local', 'oops'], ['start', 'local', 'x'], ['start-all', 'typo'], ['stop-all', 'x']):
        with pytest.raises(ValueError, match='unexpected'):
            await command(args)
    with pytest.raises(ValueError, match='Usage: /mcp trust'):
        await command(['trust', 'accept', 'junk'])
    assert 'local' in store.load().servers


async def test_symlinked_project_file_is_never_trusted(tmp_path: Path) -> None:
    command, store = make(tmp_path)
    elsewhere = tmp_path / 'trusted.json'
    elsewhere.write_text('{"servers": {"team": {"type": "stdio", "command": "team-server"}}}')
    project = tmp_path / 'repo' / PROJECT_MCP_FILE
    project.parent.mkdir()
    project.symlink_to(elsewhere)
    with pytest.raises(ValueError, match='symlink'):
        await command(['trust', 'accept'])
    data = store.load()
    store.save(data.model_copy(update={'trusted_projects': {str(project.absolute()): 'x'}}))
    assert store.trust_state(project) == 'untrusted' and store.project_servers() == {}


@pytest.mark.subprocess(reason='starts a real stdio MCP server written in Python')
async def test_revoke_disconnects_project_servers(tmp_path: Path) -> None:
    server = tmp_path / 'server.py'
    server.write_text('from mcp.server.fastmcp import FastMCP\nFastMCP("t").run()\n')
    command, _ = make(tmp_path)
    project = tmp_path / 'repo' / PROJECT_MCP_FILE
    project.parent.mkdir()
    project.write_text(
        json.dumps({'servers': {'team': {'type': 'stdio', 'command': sys.executable, 'args': [str(server)]}}})
    )
    await command(['trust', 'accept'])
    assert 'Started team' in await command(['start', 'team'])
    assert 'Revoked' in await command(['trust', 'revoke'])
    assert command.servers._connections == {}  # pyright: ignore[reportPrivateUsage]


def test_oauth_toggle_restores_a_short_timeout(tmp_path: Path) -> None:
    form = ServerForm(MCPStore(tmp_path / 'config'))
    form.select_type('http')
    form.config = '{"url": "https://example.com/mcp", "timeout": 30}'
    form.toggle_oauth()
    assert json.loads(form.config)['timeout'] == 330
    form.toggle_oauth()
    assert json.loads(form.config) == {'url': 'https://example.com/mcp', 'timeout': 30}
    form.config = '{"url": "https://example.com/mcp", "timeout": 330}'
    form.toggle_oauth()
    form.toggle_oauth()
    assert json.loads(form.config)['timeout'] == 330, 'a timeout the user chose is kept'
