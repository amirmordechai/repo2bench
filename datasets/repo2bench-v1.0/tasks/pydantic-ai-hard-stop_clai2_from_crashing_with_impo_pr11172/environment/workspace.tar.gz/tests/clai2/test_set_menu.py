"""The `/set` menu, driven headless with scripted key presses."""

from pathlib import Path

import pytest
from termflow.tui import MenuItem
from termflow.tui.menu import MenuResult
from termflow.tui.textinput import TextInputResult

from pydantic_clai2.config.project_settings import ProjectSettings
from pydantic_clai2.plugins.menus import FieldRow
from pydantic_clai2.ui.menus import field_menu
from pydantic_clai2.ui.menus.field_menu import (
    SAVE_AND_CLOSE,
    FieldMenu,
    is_save_and_close,
    run_flow,
    run_flow_async,
    save_and_close_item,
)
from pydantic_clai2.ui.menus.set_menu import SettingsSource, open_settings_menu
from tests.clai2.menu_script import Script, make_context, pick, typed


def test_rows_details_and_validation(tmp_path: Path) -> None:
    context, _ = make_context(tmp_path)
    menu = FieldMenu(SettingsSource(context))
    keys = [row.key for row in menu.rows]
    assert keys[:3] == ['model', 'run.request_limit', 'display.thinking']
    assert 'run.instructions' not in keys, '/system_prompt edits them, keeping their line breaks'
    items = menu.items()
    assert items[0].label.startswith('model') and 'openai-codex:gpt-6-astra' in items[0].label
    thinking = next(row for row in menu.rows if row.key == 'display.thinking')
    model = menu.rows[0]
    assert thinking.choices == ('true', 'false')
    assert len(model.choices) > 8
    assert 'choices  true, false' in menu.details(items[2])
    assert 'options; Enter opens a searchable list' in menu.details(items[0])
    assert 'current  true (default)' in menu.details(items[2])
    assert 'choices' not in menu.details(items[1])
    assert menu.details(MenuItem('stray', value='nope')) == ''
    assert menu.initial(model) == '', 'a value at its default opens empty'
    context.settings = context.settings.model_copy(update={'model': None})
    assert 'current  (not set)' in menu.details(items[0])
    assert menu.initial(model) == '', 'a value that is not set opens empty'
    limit = menu.rows[1]
    source = SettingsSource(context)
    assert source.problem(limit, '50') is None
    assert source.problem(limit, '-1') is not None
    assert 'JSON' in (source.problem(limit, 'not json') or '')
    assert menu.build(99) is not None
    assert menu.build_choices(thinking) is not None
    assert menu.build_choices(model) is not None
    assert menu.build_editor(limit) is not None
    assert menu.reset_marker(object(), items[1]).item is not None


def test_flow_edits_resets_and_reports(tmp_path: Path) -> None:
    context, applied = make_context(tmp_path)
    menu = FieldMenu(SettingsSource(context))
    script = Script(
        lists=[
            pick('display.thinking'),
            pick('run.request_limit'),
            pick('run.request_limit'),
            menu.reset_marker(object(), MenuItem('run.request_limit', value='run.request_limit')),
            menu.reset_marker(object(), MenuItem('ghost', value='ghost')),
            pick('model'),
            pick('model'),
            pick('display.splash'),
            pick('display.splash'),
            pick('unknown-key'),
        ],
        choices=[
            pick('false'),
            pick('Type a value...'),
            pick('Type a value...'),
            pick('Keep current'),
            MenuResult(cancelled=True),
        ],
        texts=[typed('50'), typed('bad'), typed('test'), typed('')],
    )
    messages = run_flow(menu, script.runners)
    assert messages == [
        'Saved display.thinking. Applied.',
        'Saved run.request_limit. Applied.',
        'run.request_limit: Invalid JSON: expected value at line 1 column 1',
        'Reset run.request_limit. Applied.',
        'Saved model. Applied.',
        'Reset model. Applied.',
    ]
    assert not context.settings.thinking
    assert context.settings.request_limit == 10000
    assert context.settings.model == 'openai-codex:gpt-6-astra'
    assert context.store.overrides() == {'display.thinking': False}
    assert applied == ['display.thinking', 'run.request_limit', 'run.request_limit', 'model', 'model']
    assert script.opened.count('choice') == 5


def test_flow_stops_on_cancel(tmp_path: Path) -> None:
    context, _ = make_context(tmp_path)
    script = Script(lists=[MenuResult(cancelled=True)], choices=[], texts=[])
    assert run_flow(FieldMenu(SettingsSource(context)), script.runners) == []
    script = Script(
        lists=[pick('run.request_limit'), MenuResult(item=None)], choices=[], texts=[TextInputResult(cancelled=True)]
    )
    assert run_flow(FieldMenu(SettingsSource(context)), script.runners) == []


def test_save_and_close_is_the_last_row_and_leaves_with_edits_saved(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    context, _ = make_context(tmp_path)
    menu = FieldMenu(SettingsSource(context))
    first, *_, last = menu.items()
    assert last.label == SAVE_AND_CLOSE and is_save_and_close(last) and not is_save_and_close(first)
    assert menu.details(last) == 'Leave this menu. Each change was saved as you made it.'
    pressed = iter(['end', 'R', 'enter', 'R'])
    monkeypatch.setattr(field_menu, 'menu_key', lambda: next(pressed))
    left = menu.build().run()
    assert left.item is not None and is_save_and_close(left.item), 'R on Save & close resets nothing'
    assert menu.build().run() == menu.reset_marker(object(), first)
    script = Script(
        lists=[pick('display.thinking'), MenuResult(item=save_and_close_item())], choices=[pick('false')], texts=[]
    )
    assert run_flow(menu, script.runners) == ['Saved display.thinking. Applied.']
    assert context.store.overrides() == {'display.thinking': False}
    assert script.opened == ['list', 'choice', 'list']


async def test_async_flow_matches_the_sync_one_without_submenus(tmp_path: Path) -> None:
    context, _ = make_context(tmp_path)
    script = Script(
        lists=[pick('run.request_limit'), MenuResult(item=None)], choices=[], texts=[TextInputResult(cancelled=True)]
    )
    assert await run_flow_async(FieldMenu(SettingsSource(context)), script.runners) == []
    assert script.opened == ['list', 'text', 'list']


async def test_open_menu_runs_in_a_thread(tmp_path: Path) -> None:
    context, _ = make_context(tmp_path)
    assert await open_settings_menu(context, run=lambda menu: []) == 'No changes.'
    assert await open_settings_menu(context, run=lambda menu: [menu.apply(menu.rows[1], '7')]) == (
        'Saved run.request_limit. Applied.'
    )
    assert context.settings.request_limit == 7
    assert await open_settings_menu(context, run=lambda menu: [menu.apply(menu.rows[1], '  ')]) == (
        'Reset run.request_limit. Applied.'
    )


def test_project_overrides_are_marked_on_the_row(tmp_path: Path) -> None:
    context, _ = make_context(tmp_path)
    context.project = ProjectSettings(path=tmp_path / '.clai' / 'settings.json', overrides={'display.thinking': False})
    menu = FieldMenu(SettingsSource(context))
    items = {item.value: item for item in menu.items()}
    assert items['display.thinking'].description.endswith('project')
    assert items['display.thinking'].description.startswith('\x1b[')
    assert items['model'].description == ''
    assert 'origin   project' in menu.details(items['display.thinking'])
    assert 'origin' not in menu.details(items['model'])
    assert context.reset_setting('display.thinking').endswith('sets it again at next start.')


class _Stored:
    """A one-row source whose saved value the test sets."""

    title = 'Stored'

    def __init__(self, value: str) -> None:
        self.value = value

    def rows(self) -> list[FieldRow]:
        return [FieldRow(key='root', description='', default='')]

    def current(self, row: FieldRow) -> str:
        return self.value

    def problem(self, row: FieldRow, text: str) -> str | None:
        raise NotImplementedError

    def apply(self, row: FieldRow, raw: str) -> str:
        raise NotImplementedError

    def reset(self, row: FieldRow) -> str:
        raise NotImplementedError


@pytest.mark.parametrize(('value', 'initial'), [('src', 'src'), ('', ''), ('evil\x1b[2J', '')])
def test_editor_opens_holding_a_printable_value(value: str, initial: str) -> None:
    menu = FieldMenu(_Stored(value))
    editor = menu.build_editor(menu.rows[0])
    assert (editor.text, editor._placeholder) == (initial, 'empty resets to (empty)')  # pyright: ignore[reportPrivateUsage]
