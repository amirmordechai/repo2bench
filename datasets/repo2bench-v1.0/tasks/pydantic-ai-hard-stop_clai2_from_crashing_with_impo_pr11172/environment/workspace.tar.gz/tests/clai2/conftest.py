"""Isolate settings and provider access for every CLAI test."""

import sys
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path

import keyring
import pytest
from keyring.errors import PasswordDeleteError

from pydantic_ai import models
from pydantic_clai2.config import Settings, credential_store
from tests.clai2.cli_runner import CliRunner


@pytest.fixture
def blockbuster_enabled() -> bool:
    """Not yet: the suite predates the detector. https://github.com/pydantic/pydantic-ai/issues/8821"""
    return False


@pytest.fixture
def anyio_backend() -> str:
    """CLAI's terminal and cancellation primitives require asyncio."""
    return 'asyncio'


@dataclass
class FakeGh:
    """The fake `gh`'s state: tokens per host, the next `auth login` outcome, and opened URLs."""

    state: Path
    opened: list[str] = field(default_factory=list[str])

    def sign_in(self, host: str = 'github.com', token: str = 'gho_saved') -> None:
        (self.state / host).write_text(token)

    def next_login(self, mode: str) -> None:
        """`ok`, `fail`, `hang` (after the code), `silent` (before it), `early`, `no-token`, or `stall-token` (then `auth token` hangs)."""
        (self.state / 'login').write_text(mode)

    def hang_on_token(self) -> None:
        (self.state / 'token-hang').write_text('')

    def calls(self) -> list[str]:
        path = self.state / 'calls'
        return path.read_text().splitlines() if path.exists() else []


@pytest.fixture(autouse=True)
def fake_gh(tmp_path_factory: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch) -> FakeGh:
    """Never run the real GitHub CLI or open a browser: either would touch the developer's own login."""
    fake = FakeGh(state=tmp_path_factory.mktemp('fake-gh'))
    monkeypatch.setenv('FAKE_GH_STATE', str(fake.state))
    script = Path(__file__).with_name('fake_gh_cli.py')
    monkeypatch.setattr('pydantic_clai2.gh_cli.gh_command', lambda: [sys.executable, str(script)])

    def open_browser(url: str) -> bool:
        fake.opened.append(url)
        return True

    monkeypatch.setattr('pydantic_clai2.builtin_plugins.github.OPEN_BROWSER', open_browser)
    return fake


@pytest.fixture(autouse=True)
def no_native_clipboard(monkeypatch: pytest.MonkeyPatch) -> None:
    """Copy out through OSC 52 only: the local clipboard command would replace the developer's clipboard."""
    monkeypatch.setattr('pydantic_clai2.ui.prompt.text_clipboard.copy_command', lambda: None)


@pytest.fixture(autouse=True)
def isolated_environment(
    tmp_path: Path, tmp_path_factory: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Redirect default databases, including subprocesses, away from user data."""
    monkeypatch.setenv('XDG_CONFIG_HOME', str(tmp_path / 'config'))
    monkeypatch.setenv('HOME', str(tmp_path / 'home'))
    # State such as the web UI's orchestrator chat, which `XDG_STATE_HOME` would otherwise keep outside `HOME`.
    monkeypatch.setenv('XDG_STATE_HOME', str(tmp_path / 'state'))
    # Away from this repository's own files, such as the Agent Skills the `coder` plugin would load.
    monkeypatch.chdir(tmp_path_factory.mktemp('work'))
    monkeypatch.delenv('CLAI_MODEL', raising=False)
    # Claude Code and Codex sessions are read from the isolated home, never the developer's own.
    monkeypatch.delenv('CLAUDE_CONFIG_DIR', raising=False)
    monkeypatch.delenv('CODEX_HOME', raising=False)
    for name in (
        'LOGFIRE_TOKEN',
        'LOGFIRE_API_KEY',
        'OTEL_EXPORTER_OTLP_ENDPOINT',
        'OTEL_EXPORTER_OTLP_TRACES_ENDPOINT',
        'OTEL_EXPORTER_OTLP_METRICS_ENDPOINT',
        'OTEL_EXPORTER_OTLP_LOGS_ENDPOINT',
    ):
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv('LOGFIRE_CREDENTIALS_DIR', str(tmp_path / 'logfire'))
    monkeypatch.setattr(models, 'ALLOW_MODEL_REQUESTS', False)
    credentials: dict[tuple[str, str], str] = {}

    def get_password(service: str, account: str) -> str | None:
        return credentials.get((service, account))

    def set_password(service: str, account: str, value: str) -> None:
        credentials[service, account] = value

    def delete_password(service: str, account: str) -> None:
        if credentials.pop((service, account), None) is None:
            raise PasswordDeleteError(account)

    monkeypatch.setattr(keyring, 'get_password', get_password)
    monkeypatch.setattr(keyring, 'set_password', set_password)
    monkeypatch.setattr(keyring, 'delete_password', delete_password)
    monkeypatch.setenv('PYTHON_KEYRING_BACKEND', 'keyring.backends.null.Keyring')
    # The encryption key is read once per process; each test gets a fresh keyring, so a fresh read.
    credential_store._stored_key.cache_clear()  # pyright: ignore[reportPrivateUsage]
    credential_store._NO_OLDER_ENTRY.clear()  # pyright: ignore[reportPrivateUsage]


@pytest.fixture(autouse=True)
def native_tools() -> Iterator[None]:
    """Default code mode to off, so shells run native tools unless a test turns it on.

    CLAI turns code mode on by default, folding tools into `run_code`, but most shell tests script
    native tool calls with `TestModel`. Override this fixture to test the real default.
    """
    setting = Settings.model_fields['code_mode']
    shipped = setting.default
    setting.default = False
    Settings.model_rebuild(force=True)
    try:
        yield
    finally:
        setting.default = shipped
        Settings.model_rebuild(force=True)


def stored_accounts() -> set[str]:
    """Accounts with a saved credential: each is an encrypted file, while the keyring only holds their key."""
    directory = credential_store.credentials_path().parent
    return {path.stem.removeprefix('credentials-') for path in directory.glob('credentials-*.enc')}


@pytest.fixture
def vault(monkeypatch: pytest.MonkeyPatch) -> dict[tuple[str, str], str]:
    """A keyring that also deletes, for tests that sign out."""
    entries: dict[tuple[str, str], str] = {}

    def get(service: str, account: str) -> str | None:
        return entries.get((service, account))

    def set_value(service: str, account: str, value: str) -> None:
        entries[service, account] = value

    def delete(service: str, account: str) -> None:
        if (service, account) not in entries:
            raise PasswordDeleteError('Not found')  # pragma: no cover
        del entries[service, account]

    monkeypatch.setattr(keyring, 'get_password', get)
    monkeypatch.setattr(keyring, 'set_password', set_value)
    monkeypatch.setattr(keyring, 'delete_password', delete)
    return entries


@pytest.fixture
def run_cli(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]) -> CliRunner:
    """Run `clai2` in this process; see `CliRunner`."""
    return CliRunner(monkeypatch=monkeypatch, capsys=capsys)
