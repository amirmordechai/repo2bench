"""One command registry for execution, help, and Termflow completion."""

import json
import re
import shlex
from collections.abc import Awaitable, Callable, Iterable, Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from pydantic import JsonValue, TypeAdapter
from termflow.tui.completion import (
    CompleteEvent,
    Completer,
    Completion,
    Document,
)

from pydantic_ai.exceptions import UserError
from pydantic_ai.models import known_model_names
from pydantic_clai2.config import (
    SETTING_FIELDS,
    STRING_SETTINGS,
    TOOL_CALL_DISPLAYS,
    UPDATE_CHANNELS,
    PluginSettings,
)
from pydantic_clai2.config.builtins import STOCK_PLUGINS
from pydantic_clai2.config.features import CAPABILITY_REQUIREMENTS
from pydantic_clai2.config.settings_store import SettingsStore, canonical_plugin_id
from pydantic_clai2.ui import telemetry
from pydantic_clai2.ui.rendering.spinners import BUILTIN_SPINNERS
from pydantic_clai2.ui.rendering.theme import names as theme_names

if TYPE_CHECKING:
    # Only for the annotation: `pydantic_clai2.plugins` imports this module.
    from pydantic_clai2.plugins.menus import SettingsMenu

_COMMAND_NAME = re.compile(r'\w[\w-]*')
"""Letters, digits, underscores, and hyphens, not starting with a hyphen: what a skill such as `code-review` is called."""


def is_command_input(text: str) -> bool:
    """Recognize slash commands without routing path-like prefixes to the registry.

    A slash, dot, or backslash in the first token after `/` denotes a path, not a command
    name. This is lexical: it neither reads local files nor parses prompt text
    as shell arguments. Unknown command-shaped names still reach the registry.
    """
    if not text.startswith('/'):
        return False
    name = text.split(maxsplit=1)[0][1:]
    return not any(marker in name for marker in ('/', '.', '\\'))


def is_silent(result: str) -> bool:
    """Whether a command result is not worth printing: blank, or a one-line no-op such as `API key unchanged.`.

    A menu that closed without changes has nothing to report, and neither blank lines
    nor 'settings unchanged' chatter should land in the transcript.
    """
    text = result.strip()
    return not text or (text.endswith(' unchanged.') and len(text.splitlines()) == 1)


def expand_bare_command(text: str) -> str:
    """Map bare `clear` to `/clear`, as Code Puppy does, so every input path dispatches it as a command."""
    return '/clear' if text.strip().lower() == 'clear' else text


@dataclass(frozen=True, kw_only=True)
class Command:
    """A command available to both dispatch and autocomplete."""

    name: str
    description: str
    handler: Callable[[list[str]], str | Awaitable[str]]
    complete: Callable[[list[str]], Iterable[str]] = lambda _: ()
    available: Callable[[], bool] = lambda: True
    """Whether dispatch, help, and completion expose this command in the current session."""
    raw: bool = False
    """Pass the argument text unparsed, as one element, so free-form prompts keep quotes and apostrophes."""
    during_turn: bool = False
    """Open the bare command's menu as soon as it is entered, even while a turn streams.

    Only for menus whose changes the running turn cannot observe, such as settings that
    take effect on the next turn. The run's output is held while the menu owns the screen.
    With arguments the command still queues, keeping its order among queued follow-ups,
    unless the only argument is one of `during_turn_subcommands` or `args_during_turn` is set.
    """
    args_during_turn: bool = False
    """Also run the command with any arguments as soon as it is entered mid-turn, instead of queueing it.

    For commands whose every form applies as soon as it is safe, such as `/plugins`. The command
    then runs ahead of queued follow-ups instead of in order among them.
    """
    during_turn_subcommands: tuple[str, ...] = ()
    """Subcommands, like `add` in `/model add`, whose bare form also opens its menu mid-turn."""
    live: bool = False
    """Keep the editor live while the handler runs, as it is during a turn.

    The working spinner shows, Esc or Ctrl-C cancels, and Enter queues a follow-up. Only for
    handlers that may take a while and only print through the console: one that reads keys or
    opens a menu needs the suspended editor every other command gets.
    """
    overridable: bool = False
    """Give way to another command with the same name, whichever registers first, instead of clashing.

    For commands named after something the user names, such as a skill, which may collide with a
    built-in like `/model`. The hidden command is reported, not dropped silently.
    """
    menu: 'Callable[[], SettingsMenu] | None' = None
    """A settings menu over what the bare command changes, for surfaces that cannot show the terminal's own.

    The terminal still runs `handler`, whose menu may offer more, such as `/spinner`'s speed keys; the
    web UI shows this one in the page instead, so its edits must save and apply as the command's do.
    Built each time it is shown.
    """


class Commands(Completer):
    """Instance-owned registry, based on Code Puppy's registry/completer pattern."""

    def __init__(self, *, workspace: Callable[[], Path] = Path.cwd) -> None:
        """Create an empty registry and filesystem completer; relative `@` paths complete in `workspace()`."""
        self._commands: dict[str, Command] = {}
        self._workspace = workspace

    def register(self, command: Command) -> None:
        """Register one command, rejecting ambiguous duplicate names."""
        self.register_many((command,))

    def register_many(self, commands: Iterable[Command]) -> list[Command]:
        """Validate a provider's declarations atomically, including collisions.

        Returns the `overridable` commands hidden by another of the same name: new ones that found
        their name taken, and registered ones that a new command took it from.
        """
        pending: dict[str, Command] = {}
        hidden: list[Command] = []
        for command in commands:
            if not _COMMAND_NAME.fullmatch(command.name):
                raise ValueError(f'Invalid or duplicate command: {command.name}')
            existing = pending.get(command.name) or self._commands.get(command.name)
            if existing is not None and command.overridable:
                hidden.append(command)
                continue
            if existing is not None and not existing.overridable:
                raise ValueError(f'Invalid or duplicate command: {command.name}')
            if existing is not None:
                hidden.append(existing)
            pending[command.name] = command
        self._commands.update(pending)
        return hidden

    def unregister(self, commands: Iterable[str | Command]) -> None:
        """Remove commands a plugin registered; unknown names are ignored.

        A name removes the command registered under it. A `Command` is removed only while it is the
        one registered, so a command that took the name of a hidden `overridable` one stays.
        """
        for command in commands:
            if isinstance(command, str):
                self._commands.pop(command, None)
            elif self._commands.get(command.name) is command:
                del self._commands[command.name]

    def __contains__(self, name: object) -> bool:
        """Whether a command called `name` (without its slash) is registered."""
        return name in self._commands

    def __iter__(self) -> Iterator[Command]:
        """Iterate a snapshot, so callers may register or unregister while looping."""
        return iter(list(self._commands.values()))

    def get(self, name: str) -> Command | None:
        """The command called `name` (without its slash), or `None` when there is none or it is not available now."""
        command = self._commands.get(name)
        return command if command is not None and command.available() else None

    def execute(self, text: str) -> str | Awaitable[str]:
        """Parse shell-style arguments and dispatch without invoking a shell."""
        parts = text.removeprefix('/').split(maxsplit=1)
        if not parts:
            return self.help([])
        name, rest = parts[0], parts[1] if len(parts) > 1 else ''
        command = self._commands.get(name)
        if command is None or not command.available():
            raise ValueError(f'Unknown command /{name}. Use /help.')
        if command.raw:
            return command.handler([rest] if rest else [])
        return command.handler(shlex.split(rest))

    def runs_during_turn(self, text: str) -> bool:
        """Whether `text` runs mid-turn: a `during_turn` bare command or subcommand, or any `args_during_turn` use."""
        if not is_command_input(text):
            return False
        words = text.split()
        command = self._commands.get(words[0][1:])
        if command is None or not command.available():
            return False
        if len(words) == 1:
            return command.during_turn
        return command.args_during_turn or (len(words) == 2 and words[1] in command.during_turn_subcommands)

    def runs_live(self, text: str) -> bool:
        """Whether `text` names an available command that keeps the editor live while it runs."""
        parts = text.removeprefix('/').split(maxsplit=1)
        command = self._commands.get(parts[0]) if parts else None
        return command is not None and command.live and command.available()

    async def execute_async(self, text: str) -> str:
        """Await asynchronous plugin commands without blocking the event loop.

        The UI telemetry span names a registered command and counts its arguments; the arguments, and any
        unregistered name, which is just typed text, stay out.

        The shell shows a failure instead of raising it, so one that is not a usage error (`ValueError`,
        `UserError`) is also recorded here as a handled error, under the command's span.
        """
        name, *arguments = text.removeprefix('/').split() or ['help']
        command = name if name in self else 'unknown'
        with telemetry.span('command /{command}', command=command, arguments=len(arguments)):
            try:
                result = self.execute(text)
                return result if isinstance(result, str) else await result
            except Exception as error:
                if not isinstance(error, ValueError | UserError):
                    telemetry.handled_error('command /{command} failed', error, command=command)
                raise

    def get_completions(self, document: Document, complete_event: CompleteEvent) -> Iterator[Completion]:
        """Complete slash commands, contextual arguments, and @file paths."""
        text = document.text_before_cursor
        if not is_command_input(text):
            word = document.get_word_before_cursor(WORD=True)
            if word.startswith('@'):
                path = Path(word[1:]).expanduser()
                directory = path if word.endswith('/') else path.parent
                prefix = '' if word.endswith('/') else path.name
                try:
                    for child in sorted((self._workspace() / directory).iterdir()):
                        if prefix in child.name:
                            yield Completion(child.name + ('/' if child.is_dir() else ''), start_position=-len(prefix))
                except OSError:
                    return
            return
        words = text[1:].split()
        if len(words) <= 1 and not text.endswith(' '):
            prefix = text[1:]
            # Best match first: the exact name, then names starting with the fragment, then the rest.
            matches = sorted(
                (command for command in list(self._commands.values()) if prefix in command.name),
                key=lambda command: (command.name != prefix, not command.name.startswith(prefix)),
            )
            for command in matches:
                if command.available():
                    yield Completion(
                        command.name,
                        start_position=-len(prefix),
                        display='/' + command.name,
                        display_meta=command.description,
                    )
            return
        if not words:
            return
        command = self._commands.get(words[0])
        if command is None or not command.available():
            return
        args = words[1:]
        if text.endswith(' '):
            args.append('')
        prefix = args[-1] if args else ''
        for candidate in command.complete(args):
            if prefix in candidate:
                yield Completion(candidate, start_position=-len(prefix))

    def help(self, _: list[str]) -> str:
        """Generate help from the same registry used for completion."""
        return '\n'.join(
            f'/{command.name}: {command.description}' for command in self._commands.values() if command.available()
        )


def config_command(store: SettingsStore, args: list[str]) -> str:
    """Share settings commands between the terminal and CLI."""
    if args == ['show'] or not args:
        return store.load().model_dump_json(indent=2)
    if len(args) == 2 and args[0] == 'get':
        field = SETTING_FIELDS.get(args[1])
        if field is None:
            raise ValueError(f'Unknown setting: {args[1]}')
        return json.dumps(store.load().model_dump()[field])
    if len(args) == 2 and args[0] == 'reset':
        store.reset(args[1])
    elif len(args) == 3 and args[0] == 'set':
        adapter: TypeAdapter[JsonValue] = TypeAdapter(JsonValue)
        value: JsonValue = args[2] if args[1] in STRING_SETTINGS else adapter.validate_json(args[2])
        store.set(args[1], value)
    else:
        raise ValueError('Usage: config show|get KEY|set KEY VALUE|reset KEY')
    return 'Saved. Applies when you restart CLAI.'


def set_completions(args: list[str], *, plugin_models: Iterable[str] = ()) -> Iterable[str]:
    """Complete setting names and values without network calls or credentials.

    `plugin_models` are `PREFIX:NAME` models that loaded plugins offer, completed beside the built-in ones.
    """
    if len(args) <= 1:
        return (*SETTING_FIELDS, 'api_key')
    if len(args) == 2 and args[0] == 'display.theme':
        return theme_names()
    if len(args) == 2 and args[0] == 'display.spinner':
        return tuple(BUILTIN_SPINNERS)
    if len(args) == 2 and args[0] == 'model':
        from pydantic_clai2.models.model_catalog import CODEX_MODELS

        names = (*plugin_models, *known_model_names())
        providers = sorted({name.partition(':')[0] + ':' for name in names} | {'openai-codex:'})
        return tuple(dict.fromkeys((*providers, *CODEX_MODELS, *names)))
    if len(args) == 2 and args[0] in ('display.thinking', 'display.splash'):
        return ('true', 'false')
    if len(args) == 2 and args[0] == 'display.tool_calls':
        return TOOL_CALL_DISPLAYS
    if len(args) == 2 and args[0] == 'updates.channel':
        return UPDATE_CHANNELS
    return ()


def config_completions(args: list[str]) -> Iterable[str]:
    """Suggest operations, setting names, and boolean values."""
    if len(args) <= 1:
        return ('show', 'get', 'set', 'reset')
    if len(args) == 2 and args[0] in ('get', 'set', 'reset'):
        return SETTING_FIELDS
    if len(args) == 3 and args[0] == 'set':
        return set_completions(args[1:])
    return ()


PLUGINS_USAGE = (
    'Usage: plugins list|add ID MODULE[:ATTR] [JSON]|enable ID|disable ID|remove ID'
    '\nGit repositories can be installed only inside a CLAI session: /plugins add GIT_URL'
)


def added_plugin(args: list[str]) -> PluginSettings:
    """The declaration `plugins add ID MODULE[:ATTR] [JSON]` describes, without saving it."""
    if len(args) not in (3, 4) or args[0] != 'add':
        raise ValueError(PLUGINS_USAGE)
    settings = TypeAdapter(dict[str, JsonValue]).validate_json(args[3]) if len(args) == 4 else {}
    return PluginSettings(id=args[1], factory=args[2], settings=settings)


def plugins_command(store: SettingsStore, args: list[str]) -> str:
    """Manage explicit plugin declarations without importing plugins."""
    if len(args) > 1:
        args = [args[0], canonical_plugin_id(args[1]), *args[2:]]
    declarations = store.plugins()
    if not args or args == ['list']:
        return (
            '\n'.join(f'{p.id}: {p.factory} ({"enabled" if p.enabled else "disabled"})' for p in declarations)
            or 'No plugins.'
        )
    if args[0] == 'add':
        added = added_plugin(args)
        # Without importing, only a capability class's tags are known; a plugin's own come when it saves.
        store.save_plugin(added, requires=CAPABILITY_REQUIREMENTS.get(added.factory))
    elif len(args) == 2 and args[0] in ('enable', 'disable'):
        # A saved declaration overrides the built-in, as in the shell; the CLI owns its agent, so the stock ones.
        builtin = {p.id: p for p in STOCK_PLUGINS}
        plugin = next((p for p in declarations if p.id == args[1]), builtin.get(args[1]))
        if plugin is None:
            raise ValueError(f'Unknown plugin: {args[1]}')
        store.save_plugin(plugin.model_copy(update={'enabled': args[0] == 'enable'}))
    elif len(args) == 2 and args[0] == 'remove':
        store.delete_plugin(args[1])
    else:
        raise ValueError(PLUGINS_USAGE)
    return 'Saved. Plugin code is trusted and loads on next startup.'
