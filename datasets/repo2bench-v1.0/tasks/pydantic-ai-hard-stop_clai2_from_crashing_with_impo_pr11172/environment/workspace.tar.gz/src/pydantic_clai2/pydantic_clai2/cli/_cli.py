"""CLI settings resolution and interactive application startup."""

import argparse
import asyncio
import os
import re
import sys
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

from pydantic_clai2.runtime.launch import launch_session_id
from pydantic_clai2.ui.rendering.splash import Splash
from pydantic_clai2.ui.stderr_relay import relay_stderr

if TYPE_CHECKING:
    from collections.abc import Callable

    from pydantic_clai2.cli.self_update import WebHandoff
    from pydantic_clai2.config import Settings
    from pydantic_clai2.config.project_settings import ProjectSettings
    from pydantic_clai2.config.settings_store import SettingsStore
    from pydantic_clai2.runtime.worktrees import Worktree

_RELAUNCH_WORKTREE = 'CLAI_RELAUNCH_WORKTREE'
"""Carries a removable checkout's launch `HEAD` across `/update`; an environment variable, so older builds ignore it."""
_RELAUNCH_WEB = 'CLAI_RELAUNCH_WEB'
"""Carries the web UI's port and token across `/update`, so its open pages reconnect.

In the environment, which only you can read, rather than on the command line `ps` shows every user.
"""


def run(*, splash: Splash | None = None) -> None:
    """Parse explicit overrides without replacing persisted preferences."""
    parser = argparse.ArgumentParser(description='CLAI 2.0: streaming Pydantic AI terminal')
    _add_resume_flags(parser)
    parser.add_argument(
        '--session-id',
        metavar='UUID',
        help='Start the new session under this ID, or with --fork-session, save the copy under it',
    )
    parser.add_argument(
        '--fork-session',
        action='store_true',
        help='With --resume, continue in a copy of the session under a new ID, leaving the original as it was',
    )
    parser.add_argument(
        '--worktree',
        '-w',
        nargs='?',
        const='',
        metavar='NAME',
        help='Start in a Git worktree, reopening NAME if it exists; omit NAME to generate one',
    )
    parser.add_argument(
        '-a',
        '--agent',
        metavar='MODULE:ATTR',
        help=(
            'Chat with an existing Pydantic AI Agent instance, e.g. pydantic_ai.main:my_cool_agent; '
            "loads no plugins for this session and keeps the agent's model unless -m is given"
        ),
    )
    parser.add_argument('-m', '--model', help='Provider-qualified model name')
    parser.add_argument(
        '-p', '--prompt', metavar='TEXT', help='Run one prompt without interaction and print only the answer'
    )
    parser.add_argument(
        '--web',
        action='store_true',
        help='Drive CLAI from a local web UI instead of the terminal prompt; prints the address and opens it',
    )
    parser.add_argument(
        '--port',
        type=int,
        metavar='PORT',
        help='With --web, listen on PORT for this launch instead of the saved port; 0 picks a free one',
    )
    parser.add_argument(
        '--token-file',
        type=Path,
        metavar='PATH',
        help=(
            "With --web, read this launch's access token from PATH, a file only you can read, instead of making one; "
            'the address printed leaves it out and no browser opens'
        ),
    )
    parser.add_argument('--request-limit', type=int)
    parser.add_argument('--database', type=Path, help='Settings database location')
    parser.add_argument('command', nargs='?', choices=('config', 'plugins'))
    parser.add_argument('arguments', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    _resume_source(args)
    _validate_args(args, parser)
    if args.database is not None:
        # Before `--worktree` changes directory, so a restart after `/update` reopens the same database.
        args.database = args.database.resolve()
    if args.token_file is not None:
        args.token_file = args.token_file.resolve()  # Also before `--worktree` changes directory.
    try:
        from pydantic_ai.usage import UsageLimits
        from pydantic_clai2._app import DEFAULT_PLUGINS, STOCK_PLUGINS, chat, create_stock_agent as create_agent
        from pydantic_clai2.cli.agent_import import import_agent
        from pydantic_clai2.cli.self_update import Relaunch
        from pydantic_clai2.commands import config_command, plugins_command
        from pydantic_clai2.config.project_settings import load_project_settings
        from pydantic_clai2.config.settings_store import SettingsStore
        from pydantic_clai2.runtime.worktrees import offer_worktree_cleanup
    finally:
        if splash is not None:
            splash.stop()
    relaunched = os.environ.pop(_RELAUNCH_WORKTREE, None)  # Popped so tools and later launches never see it.
    served = _web_handoff(os.environ.pop(_RELAUNCH_WEB, None))  # Likewise, and the model never reads the token.
    worktree = launched = None
    try:
        store = SettingsStore(args.database)
        store.path = store.path.resolve()
        if args.command:
            handler = config_command if args.command == 'config' else plugins_command
            print(handler(store, args.arguments))
            return
        agent = import_agent(args.agent) if args.agent is not None else None
        if args.worktree is not None:
            worktree = _enter_worktree(name=args.worktree, headless=args.prompt is not None or args.web)
        project = load_project_settings(Path.cwd())
        model = args.model or os.getenv('CLAI_MODEL')
        settings_for = _settings_for(
            store,
            model=model,
            request_limit=args.request_limit,
            # Keep the agent's own model over saved, project, and default ones; only -m or CLAI_MODEL replaces it.
            agent_model=agent is not None and agent.model is not None and not model,
        )
        settings = settings_for(project)
        if args.prompt is not None:
            from pydantic_clai2.cli.headless import run_headless

            raise SystemExit(
                asyncio.run(
                    run_headless(
                        text=args.prompt,
                        settings=settings,
                        store=store,
                        project=project,
                        resume=args.resume,
                        resume_from=args.resume_from,
                        agent=agent,
                        session_id=args.session_id,
                        fork_session=args.fork_session,
                    )
                )
            )
        if args.web:
            from rich.console import Console

            from pydantic_clai2.cli.web import run_web

            asyncio.run(
                run_web(
                    settings_for=settings_for,
                    store=store,
                    project=project,
                    console=Console(force_terminal=False, highlight=False),
                    resume=args.resume,
                    resume_from=args.resume_from,
                    session_id=args.session_id,
                    fork_session=args.fork_session,
                    port=args.port,
                    token=None if args.token_file is None else read_token(args.token_file),
                    restart=served,
                )
            )
            return
        # `chat` relays stderr itself; this also covers the `git` calls around it.
        with relay_stderr():
            # Before the session, so commits made during it count as changes on exit.
            launched = worktree or _launched_worktree(relaunched=relaunched)
            asyncio.run(
                chat(
                    create_agent() if agent is None else agent,
                    deps=None,
                    usage_limits=UsageLimits(request_limit=settings.request_limit),
                    settings=settings,
                    store=store,
                    builtin_plugins=DEFAULT_PLUGINS if args.agent else STOCK_PLUGINS,
                    project=project,
                    resume=args.resume,
                    resume_from=args.resume_from,
                    load_plugins=agent is None,
                    session_id=args.session_id,
                    fork_session=args.fork_session,
                    worktree=worktree,
                    web=served,
                    settings_for=settings_for,
                )
            )
            offer_worktree_cleanup(worktree=launched)
    except Relaunch as relaunch:
        # Replace this process with the new build; the working directory, a worktree included, carries over.
        argv = relaunch_argv(
            args,
            executable=relaunch.executable,
            session_id=relaunch.session_id,
            new_session_id=relaunch.new_session_id,
        )
        _remember_worktree(launched)
        if relaunch.web is not None:
            os.environ[_RELAUNCH_WEB] = f'{relaunch.web.port} {relaunch.web.token}'
        sys.stdout.flush()
        os.execv(relaunch.executable, argv)
    except (ValueError, TypeError, ImportError, AttributeError, LookupError, OSError) as exc:
        if worktree is not None:
            # A startup error can come before the banner, so name the checkout this launch leaves behind.
            print(f'Worktree kept at {worktree.path} (branch: {worktree.branch}).', file=sys.stderr)
        parser.error(str(exc))
    except KeyboardInterrupt:
        if args.prompt is not None or args.web:
            raise SystemExit(130) from None


def _settings_for(
    store: 'SettingsStore', *, model: str | None, request_limit: int | None, agent_model: bool = False
) -> 'Callable[[ProjectSettings], Settings]':
    """The settings CLAI starts with beside a project file: saved ones, then the project's, then the launch flags.

    With `agent_model`, no model: the `--agent` agent's own one is used.
    """
    from pydantic_clai2.config import resolve_settings

    def settings_for(project: 'ProjectSettings') -> 'Settings':
        overrides = store.overrides() | project.overrides
        if model:
            overrides['model'] = model
        if request_limit is not None:
            overrides['run.request_limit'] = request_limit
        settings = resolve_settings(overrides)
        return settings.model_copy(update={'model': None}) if agent_model else settings

    return settings_for


def _enter_worktree(*, name: str, headless: bool) -> 'Worktree':
    """Open the `--worktree` checkout and change into it, marking it for exit cleanup when that will run."""
    from pydantic_clai2.runtime.worktrees import open_worktree

    worktree = open_worktree(name=name)
    if headless:
        # Headless stdout carries only the answer; the shell shows the notice under its banner instead.
        print(worktree.notice, file=sys.stderr)
    else:
        # Exit cleanup needs a terminal; piped input keeps even an unchanged checkout.
        worktree = replace(worktree, remove_if_unchanged=worktree.created and sys.stdin.isatty())
    os.chdir(worktree.path)
    return worktree


def _launched_worktree(*, relaunched: str | None) -> 'Worktree | None':
    """The linked checkout CLAI starts inside, restoring the first launch's snapshot after `/update`."""
    from pydantic_clai2.runtime.worktrees import current_worktree

    worktree = current_worktree()
    if worktree is None or relaunched is None:
        return worktree
    head, _, new_branch = relaunched.partition(' ')
    return replace(
        worktree, head=head, created=True, new_branch=new_branch == 'new-branch', remove_if_unchanged=sys.stdin.isatty()
    )


def _remember_worktree(worktree: 'Worktree | None') -> None:
    """Hand a checkout exit would remove to the relaunched build, which starts without `--worktree`."""
    if worktree is not None and worktree.remove_if_unchanged:
        os.environ[_RELAUNCH_WORKTREE] = f'{worktree.head} new-branch' if worktree.new_branch else worktree.head


def relaunch_argv(
    args: argparse.Namespace, *, executable: str, session_id: str | None, new_session_id: str | None = None
) -> list[str]:
    """The launch options to restart with after `/update`, resuming `session_id` instead of any `--resume`.

    An unsaved conversation started with `--session-id` restarts under `new_session_id`. The token
    `--token-file` names stays in its file.
    """
    argv = [executable]
    if args.web:
        argv.append('--web')
        if args.port is not None:
            argv += ['--port', str(args.port)]
        if args.token_file is not None:
            argv += ['--token-file', str(args.token_file)]
    if args.agent is not None:
        argv += ['--agent', args.agent]
    if args.model is not None:
        argv += ['--model', args.model]
    if args.request_limit is not None:
        argv += ['--request-limit', str(args.request_limit)]
    if args.database is not None:
        argv += ['--database', str(args.database)]
    if session_id is not None:
        argv += ['--resume', session_id]
    elif new_session_id is not None:
        argv += ['--session-id', new_session_id]
    return argv


_TOKEN = re.compile(r'[A-Za-z0-9_-]{32,256}')


def _web_handoff(value: str | None) -> 'WebHandoff | None':
    """The web UI `/update` handed over as `PORT TOKEN`; `None` when there is none, or it is malformed."""
    from pydantic_clai2.cli.self_update import WebHandoff

    port, _, token = (value or '').partition(' ')
    if not port.isdigit() or int(port) > 65535 or not _TOKEN.fullmatch(token):
        return None
    return WebHandoff(port=int(port), token=token)


def read_token(path: Path) -> str:
    """The access token in `path`; `ValueError` unless only this user can read the file and it holds a long random token."""
    info = path.stat()
    if sys.platform != 'win32' and (info.st_mode & 0o077 or info.st_uid != os.geteuid()):
        raise ValueError(f'{path} must belong to you and be readable by you alone (mode 0600).')
    token = path.read_text(encoding='utf-8').strip()
    if not _TOKEN.fullmatch(token):
        raise ValueError(f'{path} must hold one URL-safe token of at least 32 characters.')
    return token


def _add_resume_flags(parser: argparse.ArgumentParser) -> None:
    """`--resume` and its Claude Code and Codex counterparts, of which one may be given."""
    flags = parser.add_mutually_exclusive_group()
    flags.add_argument(
        '--resume', nargs='?', const='', metavar='SESSION-ID', help='Restore a saved session; no ID opens the browser'
    )
    for flag, name in (('--resume-claude', 'Claude Code'), ('--resume-codex', 'Codex')):
        flags.add_argument(
            flag,
            nargs='?',
            const='',
            metavar='SESSION-ID',
            help=f'Import and restore a {name} session; no ID browses {name} sessions',
        )


def _resume_source(args: argparse.Namespace) -> None:
    """Fold `--resume-claude` and `--resume-codex` into `resume`, so the same rules check all three."""
    args.resume_from = None
    for source, session_id in (('claude', args.resume_claude), ('codex', args.resume_codex)):
        if session_id is not None:
            args.resume_from, args.resume = source, session_id


def _validate_args(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.command and (
        args.resume is not None
        or args.worktree is not None
        or args.agent is not None
        or args.session_id is not None
        or args.fork_session
    ):
        parser.error(
            '--resume, --session-id, --fork-session, --worktree, and --agent cannot be combined with config or plugins'
        )
    try:
        args.session_id = launch_session_id(resume=args.resume, session_id=args.session_id, fork=args.fork_session)
    except ValueError as exc:
        parser.error(str(exc))
    if args.worktree is not None and args.resume is not None:
        parser.error('--worktree cannot be combined with --resume; resume from an existing worktree directory')
    if args.web:
        if args.command or args.prompt is not None or args.agent is not None:
            parser.error('--web cannot be combined with config, plugins, --prompt, or --agent')
        if args.resume == '':
            parser.error('--web requires an explicit --resume SESSION-ID')
    elif args.port is not None or args.token_file is not None:
        parser.error('--port and --token-file need --web')
    if args.port is not None and not 0 <= args.port < 65536:
        parser.error('--port must be between 0 and 65535')
    if args.prompt is not None:
        if args.command:
            parser.error('--prompt cannot be combined with config or plugins')
        if not args.prompt.strip():
            parser.error('--prompt requires non-empty text')
        if args.resume == '':
            parser.error('--prompt requires an explicit --resume SESSION-ID')
