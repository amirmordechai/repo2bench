"""The invariants every simulated session is checked against.

Each check reports a violation with a stable `code` and some context, which is what known findings are
matched on (see `_findings.py`). A violation that matches a known finding is recorded and tolerated
(unless `REALTIME_SIMULATION_STRICT` is set, or the simulation was built with `strict=True`); any other
raises `InvariantViolation`, carrying the trace that reproduces it.

The checks are black-box wherever the public API allows: history comes from `all_messages()`, usage
from `session.usage`, and waits are real `wait_for_reply()` calls whose return is judged against the
server's ground truth. The one internal hook is observational: the codec events a connection yields are
recorded on their way into the session, for the lifecycle contract.

Checked after every step:

- `history.mutated`: a message object that appeared in a snapshot changed afterwards;
- `history.removed`: a message disappeared, other than a refused input taken back or the request of a
  send that failed. A response the user barged in on after it was recorded is the one message that can be
  replaced, by a copy cut off where the listener stopped (`is_cut_off_copy`): that counts as the same message;
- `history.reordered` / `history.inserted`: recorded messages changed order, or a message appeared
  anywhere but the end, other than a tool return placed after its call (every snapshot should be a
  prefix of the next);
- `response.duplicated`: one server response is recorded as two `ModelResponse`s;
- `response.mixed`: one `ModelResponse` holds what two server responses said;
- `wait.early`: a `wait_for_reply()` returned while a reply it was owed was still coming: only the response that
  answers an input, as the server saw it, settles it (not one already under way when it arrived);
- `obligation.misattributed`: the session settled an input's reply with a response the server started before it had
  the input (where the server names both, by the client's index and the response's id);
- `turn_complete.while_owed`: the session streamed a `RealtimeTurnCompleteEvent` while a reply it was owed was still
  coming, judged as `wait.early` judges a wait that returned there;
- `codec.*`: the connection broke the lifecycle contract (`_conformance.py`);
- `lifecycle.*`: a connection on version 2 of the contract broke a rule its lifecycle events promise
  (`_conformance.py`), checked on its lifecycle stream;
- `api.unexpected_error`: a client call, or iterating the session, raised something other than the
  documented errors;
- `simulator.malformed_frame`: the simulated server sent something the real connection can't parse (a
  bug in the simulator, not the session).

Checked at rest (`settle()`):

- `wait.hang`: a `wait_for_reply()` is still waiting, or a new one doesn't return, with nothing left
  to wait for;
- `history.tool_pairing`: a tool call without exactly one return, a return without its call, or a
  return not directly after its call's response;
- `history.order`: a user input and a response recorded in the opposite order to the one the server
  saw them in, or two responses out of order. History follows the provider's conversation order; with
  history also append-only, a session can only satisfy both by holding a reply back until the user turn
  before it is final, never by inserting the turn afterwards;
- `history.tool_round_order`: something the model said in a response before the first of its tool
  calls' results reached the server is recorded after those results (asynchronous tool calls, where
  the model keeps talking after the call);
- `history.rejected_kept`: an input the provider refused is still in history;
- `history.turn_missing`: fewer spoken user turns are recorded than the provider committed, as the client read
  or committed with `commit_audio()` (whether or not it read the provider's acknowledgement); for a session that
  ended on its own, once it closes;
- `history.not_restored`: a re-dialed provider conversation started a response without something history
  records and an earlier conversation held, other than the turn the drop cut off (which is settled instead);
- `history.replayed_as_heard`: a re-dialed provider conversation holds the plain transcript of a reply an earlier
  one truncated, as though the user had heard all of it;
- `prune.unanswered` / `prune.dropped_from_history`: the session deleted a tool call's items from the server
  conversation before the model answered its result, or history lost what it deleted (history keeps everything);
- `response.missing` / `response.truncated`: a response the server completed is missing from history,
  or recorded without all of what it said;
- `usage.total`: `session.usage` tokens differ from what the server billed in the reports the client read;
- `usage.attribution`: a response's recorded usage isn't what the server billed for it;
- `usage.requests`: `usage.requests` differs from the number of responses recorded (or, for a model
  that reports its requests with usage, the number it reported);
- `playback.cut_beyond_audio` / `playback.bad_truncate`: a reply is marked cut past the audio it had,
  or the provider had to refuse a truncation the session sent;
- `playback.cut_not_recorded`: the provider truncated a reply's item, but history records the reply as heard
  further than that (or as not interrupted at all), whether or not it had finished generating;
- `wire.duplicate` / `wire.order`: the server got a send twice, or one caller's sends out of order;
- `send.failed_across_reconnect`: a send failed on a dropped connection the session went on to replace;
- `history.roundtrip` / `history.handoff`: history doesn't survive serialization, or a standard
  `Agent.run(message_history=...)` refuses it.
"""

from __future__ import annotations as _annotations

import asyncio
import os
from collections import Counter
from collections.abc import Callable, Iterable
from dataclasses import replace
from typing import TYPE_CHECKING, Any

from pydantic_ai.exceptions import UnexpectedModelBehavior, UsageLimitExceeded, UserError
from pydantic_ai.messages import (
    ModelMessage,
    ModelMessagesTypeAdapter,
    ModelRequest,
    ModelResponse,
    RealtimeSessionErrorEvent,
    RealtimeTurnCompleteEvent,
    SpeechPart,
    TextPart,
    ToolCallPart,
    ToolReturnPart,
    UserPromptPart,
)
from pydantic_ai.models._speech import assistant_speech_text
from pydantic_ai.realtime import RealtimeError, RealtimeSession
from pydantic_ai.realtime._lifecycle import LifecycleEvent
from pydantic_ai.realtime.codec import RealtimeCodecEvent

from ._conformance import ConformanceIssue, LifecycleChecker
from ._truth import TruthInput, TruthResponse, response_numbers

if TYPE_CHECKING:
    from ._simulation import Simulation, Waiter

Violation = tuple[str, dict[str, Any]]
"""A violation's detail, and the context a known finding is recognized by."""


class SimulatedToolError(RuntimeError):
    """What a gated tool raises for `outcome='error'`: an unhandled tool failure, which ends the session."""


_EXPECTED_CLIENT_ERRORS = (RealtimeError, UserError, UsageLimitExceeded, SimulatedToolError, asyncio.CancelledError)
"""What a client call may raise: a lost connection, a misuse, an exceeded limit, or (from the next outbound
call, or iteration) the tool failure that ended the session."""

_SEND_FAILED = 'Realtime connection failed while sending'


def _expected_error(error: BaseException) -> bool:
    # A tool that keeps asking for retries ends the session as it ends a standard run.
    return isinstance(error, _EXPECTED_CLIENT_ERRORS) or (
        isinstance(error, UnexpectedModelBehavior) and 'exceeded max retries' in str(error)
    )


def strict_from_environment() -> bool:
    """Whether known findings fail too (`REALTIME_SIMULATION_STRICT=1`), as when hunting for new ones."""
    return os.environ.get('REALTIME_SIMULATION_STRICT', '') not in ('', '0')


def response_text(message: ModelResponse) -> str:
    texts = [part.transcript for part in message.parts if isinstance(part, SpeechPart) and part.transcript]
    texts += [part.content for part in message.parts if isinstance(part, TextPart)]
    # Whitespace is not what these checks are about: a part can keep the space its first fragment led with.
    return ' '.join(' '.join(texts).split())


def request_keys(message: ModelRequest) -> list[str]:
    """Ground-truth keys of the user inputs and tool outputs a request carries."""
    keys: list[str] = []
    for part in message.parts:
        if isinstance(part, UserPromptPart):
            # Text is its own key; an image (the only other content the simulation sends) the tail of its data.
            contents = [part.content] if isinstance(part.content, str) else part.content
            keys += [item if isinstance(item, str) else getattr(item, 'base64', '')[-12:] for item in contents]
        elif isinstance(part, SpeechPart) and part.transcript:
            keys.append(part.transcript)
        elif isinstance(part, ToolReturnPart):
            keys.append(part.tool_call_id)
    return keys


def is_tool_return_request(message: ModelMessage) -> bool:
    """A request carrying tool returns (and the content that follows them), which is placed after its call."""
    return isinstance(message, ModelRequest) and isinstance(message.parts[0], ToolReturnPart)


def conversation_fingerprints(messages: list[ModelMessage]) -> set[str]:
    """What recorded history replays into a provider conversation, keyed as the server's `conversation_fingerprint`."""
    fingerprints: set[str] = set()
    for message in messages:
        for part in message.parts:
            if isinstance(part, UserPromptPart):
                # The server keys a user message by its first part, when that is text.
                first = part.content if isinstance(part.content, str) else next(iter(part.content), None)
                if isinstance(first, str):
                    fingerprints.add(f'user:{" ".join(first.split())}')
            elif isinstance(part, ToolReturnPart):
                fingerprints.add(f'function_call_output:{part.tool_call_id}')
            elif isinstance(part, ToolCallPart):
                fingerprints.add(f'function_call:{part.tool_call_id}')
        said = [part.content for part in message.parts if isinstance(part, TextPart)]
        said += [part.transcript for part in message.parts if isinstance(part, SpeechPart) and part.speaker != 'user']
        fingerprints |= {f'assistant:{" ".join(text.split())}' for text in said if text}
    return fingerprints


def cut_off_replays(messages: list[ModelMessage]) -> dict[str, str]:
    """How history replays each reply it records as cut off: its marked text, keyed by the plain transcript's fingerprint.

    A reply the listener cut off is replayed with a marker (see `assistant_speech_text`), whether or not the provider
    applied the truncation (a truncation whose send failed may not have reached it).
    """
    return {
        f'assistant:{" ".join(part.transcript.split())}': f'assistant:{" ".join(replayed.split())}'
        for message in messages
        if isinstance(message, ModelResponse)
        for index, part in enumerate(message.parts)
        if isinstance(part, SpeechPart)
        and part.speaker != 'user'
        and part.transcript
        and (replayed := assistant_speech_text(message, index)) != part.transcript
    }


def is_cut_off_copy(old: ModelMessage, new: ModelMessage) -> bool:
    """Whether `new` is `old` recorded as cut off by a barge-in: the same response, marked interrupted, and nothing else changed.

    A cut can only move back: a part already cut keeps its cut or an earlier one.
    """
    if not isinstance(old, ModelResponse) or not isinstance(new, ModelResponse) or new.state != 'interrupted':
        return False
    if any(
        isinstance(before, SpeechPart)
        and isinstance(after, SpeechPart)
        and before.interrupted_at_ms is not None
        and (after.interrupted_at_ms is None or after.interrupted_at_ms > before.interrupted_at_ms)
        for before, after in zip(old.parts, new.parts)
    ):
        return False

    def uncut(message: ModelResponse) -> bytes:
        parts = [
            replace(part, interrupted_at_ms=None) if isinstance(part, SpeechPart) else part for part in message.parts
        ]
        return ModelMessagesTypeAdapter.dump_json([replace(message, parts=parts, state='complete')])

    return uncut(old) == uncut(new)


def is_user_speech_request(message: ModelMessage) -> bool:
    return isinstance(message, ModelRequest) and any(
        isinstance(part, SpeechPart) and part.speaker == 'user' for part in message.parts
    )


class Checker:
    """Keeps the observations the invariants need across steps, and runs them."""

    def __init__(self, sim: Simulation, *, strict: bool, enforce: frozenset[str] = frozenset()) -> None:
        self.sim = sim
        self.strict = strict
        self.enforce = enforce
        """Ids of known findings that raise anyway: the one a pinned scenario is about."""
        self.lifecycle = LifecycleChecker()
        self.lifecycle_stream: LifecycleChecker | None = None
        """The version 2 lifecycle contract, checked on the connection's lifecycle stream when it has one."""
        self.codec_events: list[RealtimeCodecEvent] = []
        self.known_hits: list[tuple[str, str]] = []
        """`(finding id, invariant code)` for every tolerated violation, in order."""
        self._seen: dict[int, tuple[ModelMessage, bytes]] = {}
        self._previous: list[int] = []
        self._judged_waiters: set[int] = set()
        self._judged_turn_completes = 0
        self._judged_attributions: set[tuple[int, str]] = set()
        self._judged_operations: set[int] = set()
        """`id()`s of the finished operations already judged (they can finish in any order)."""
        self._judged_events = 0
        self._judged_truncations = 0
        self._judged_consumer_errors = 0
        self._codec_issues: list[ConformanceIssue] = []

    def attach(self, session: RealtimeSession) -> None:
        """Observe the codec events the connection yields, on their way into the session."""
        handle = session._handle_pump_event  # pyright: ignore[reportPrivateUsage]

        async def observed(event: RealtimeCodecEvent) -> bool:
            self.codec_events.append(event)
            self._codec_issues += self.lifecycle.feed(event)
            self.sim.observe_codec_event(event)
            return await handle(event)

        session._handle_pump_event = observed  # pyright: ignore[reportPrivateUsage]
        queue_put = session._queue_put  # pyright: ignore[reportPrivateUsage]

        def queued(item: object) -> None:
            if isinstance(item, RealtimeTurnCompleteEvent):
                from ._simulation import Waiter

                # Nothing the session owed was still to come: what a wait taken now would return at once for.
                sim = self.sim
                now = sim.truth.clock
                done = frozenset(
                    operation.key
                    for operation in sim.operations
                    if operation.done and operation.key is not None and operation.error is None
                )
                sim.turn_completes.append(
                    Waiter(index=len(sim.turn_completes), started=now, returned=now, snapshot=done)
                )
            queue_put(item)

        session._queue_put = queued  # pyright: ignore[reportPrivateUsage]

    def observe_lifecycle_stream(
        self, inputs_sent: Callable[[], int]
    ) -> Callable[[RealtimeCodecEvent | LifecycleEvent | None], None]:
        """Check a version 2 connection's lifecycle stream: feed the returned callback each event, and `None` at its end."""
        checker = self.lifecycle_stream = LifecycleChecker(lifecycle=True, inputs_sent=inputs_sent)
        self.lifecycle.brackets_responses = True

        def observe(event: RealtimeCodecEvent | LifecycleEvent | None) -> None:
            self._codec_issues += checker.finish() if event is None else checker.feed(event)

        return observe

    def report(self, code: str, violations: Iterable[Violation]) -> None:
        """Report each violation: tolerated if it is a known finding (and not strict), raised otherwise."""
        from ._findings import matching_findings
        from ._simulation import FindingReproduced, InvariantViolation

        for detail, context in violations:
            violation = InvariantViolation(code, detail, self.sim.trace, context)
            findings = [finding.id for finding in matching_findings(self.sim, violation)]
            violation.findings = findings
            if self.enforce.intersection(findings):
                raise FindingReproduced(code, detail, self.sim.trace, context, findings=findings)
            if self.strict or not findings:
                raise violation
            self.known_hits.append((findings[0], code))

    # --- every step -------------------------------------------------------------------------------

    def check_step(self) -> None:
        session = self.sim.session
        assert session is not None
        issues, self._codec_issues = self._codec_issues, []
        for code in dict.fromkeys(issue.code for issue in issues):
            self.report(
                code,
                [(f'{issue.detail} (codec event #{issue.position})', {}) for issue in issues if issue.code == code],
            )
        self._check_errors()
        self._check_simulator_frames()
        messages = session.all_messages()
        self._check_history_stability(messages)
        self._check_response_identity(messages)
        self._check_attribution(session)
        waiters = [w for w in self.sim.waiters if w.returned is not None and w.index not in self._judged_waiters]
        self._judged_waiters.update(waiter.index for waiter in waiters)
        self.report('wait.early', [violation for waiter in waiters for violation in self._early_return(waiter)])
        completes, self._judged_turn_completes = (
            self.sim.turn_completes[self._judged_turn_completes :],
            len(self.sim.turn_completes),
        )
        self.report(
            'turn_complete.while_owed',
            [
                (detail.replace('wait_for_reply()', 'turn complete'), context)
                for complete in completes
                for detail, context in self._early_return(complete)
            ],
        )

    def _check_attribution(self, session: RealtimeSession) -> None:
        """Whether the session settles an input's reply with a response the server started before it had the input.

        Judged where the server names its inputs by the client's index and its responses by the ids the session
        records (the OpenAI protocol): such a response never saw the input, so it can't be the input's answer.
        """
        truth = self.sim.truth
        inputs = {input_.client_index: input_ for input_ in truth.inputs if input_.client_index is not None}
        answered_by = session._core._answered_by  # pyright: ignore[reportPrivateUsage]
        violations: list[Violation] = []
        for input_id, response_id in answered_by.items():
            if (input_id, response_id) in self._judged_attributions:
                continue
            self._judged_attributions.add((input_id, response_id))
            input_ = inputs.get(input_id)
            response = truth.responses.get(response_id)
            if (
                input_ is not None
                and response is not None
                and input_.answered_by != response.key
                and response.seq_start < input_.seq
            ):
                violations.append(
                    (
                        f'{input_.key!r} is settled by {response.key}, which the server started before it had the input',
                        {'input': input_.key, 'response': response.key},
                    )
                )
        self.report('obligation.misattributed', violations)

    def _check_simulator_frames(self) -> None:
        """The simulated server must only send frames the real connection can parse; anything else is a harness bug."""
        events, self._judged_events = self.sim.events[self._judged_events :], len(self.sim.events)
        self.report(
            'simulator.malformed_frame',
            [
                (event.message, {})
                for event in events
                if isinstance(event, RealtimeSessionErrorEvent) and 'Failed to parse' in event.message
            ],
        )

    def _check_errors(self) -> None:
        sim = self.sim
        judged = [
            operation for operation in sim.operations if operation.done and id(operation) not in self._judged_operations
        ]
        self._judged_operations.update(id(operation) for operation in judged)
        unexpected = [
            (f'{operation.name} raised {operation.error!r}', {'operation': operation.name})
            for operation in judged
            if operation.error is not None and not _expected_error(operation.error)
        ]
        errors = sim.consumer_errors[self._judged_consumer_errors :]
        self._judged_consumer_errors = len(sim.consumer_errors)
        unexpected += [
            (f'iterating the session raised {error!r}', {'operation': 'iterate'})
            for error in errors
            if not _expected_error(error)
        ]
        self.report('api.unexpected_error', unexpected)

    def _removal_allowed(self, message: ModelMessage) -> bool:  # pragma: lax no cover (the session core never removes)
        """A refused input taken back, or the request of a send that failed."""
        truth = self.sim.truth
        failed_sends = {operation.key for operation in self.sim.operations if operation.error is not None}
        keys = request_keys(message) if isinstance(message, ModelRequest) else []
        return bool(keys) and all(
            key in failed_sends or ((input_ := truth.input(key)) is not None and input_.rejected) for key in keys
        )

    def _check_history_stability(self, messages: list[ModelMessage]) -> None:
        actual = [id(message) for message in messages]
        # A response replaced by its cut-off copy is judged as the response it replaced.
        previous_set, actual_set = set(self._previous), set(actual)
        replaced = [self._seen[message_id][0] for message_id in self._previous if message_id not in actual_set]
        copies: dict[int, int] = {}
        for message in messages:
            if id(message) not in previous_set and isinstance(message, ModelResponse):
                old = next(
                    (old for old in replaced if is_cut_off_copy(old, message) and id(old) not in copies.values()), None
                )
                if old is not None:
                    copies[id(message)] = id(old)
        current = [copies.get(message_id, message_id) for message_id in actual]
        mutated: list[Violation] = []
        for message in messages:
            dumped = ModelMessagesTypeAdapter.dump_json([message])
            before = self._seen.get(id(message), (message, dumped))[1]
            self._seen[id(message)] = (message, dumped)
            if before != dumped:  # pragma: lax no cover (only when the session breaks the invariant)
                changed = f'before: {before.decode()}\n  after:  {dumped.decode()}'
                mutated.append((f'a recorded {type(message).__name__} changed:\n  {changed}', {'message': message}))
        self.report('history.mutated', mutated)

        current_set, previous_set = set(current), set(self._previous)
        removed = [self._seen[message_id][0] for message_id in self._previous if message_id not in current_set]
        self.report(
            'history.removed',
            [
                (f'a recorded message disappeared: {self._describe(message)}', {'message': message})
                for message in removed
                if not self._removal_allowed(message)
            ],
        )
        survivors = [message_id for message_id in current if message_id in previous_set]
        kept = [message_id for message_id in self._previous if message_id in current_set]
        self.report('history.reordered', [('recorded messages changed order', {})] if survivors != kept else [])
        # New messages must all come after the last surviving one: the documented exception is a tool's
        # return, placed directly after its call.
        last_old = current.index(survivors[-1]) if survivors else 0
        self.report(
            'history.inserted',
            [
                (
                    f'{self._describe(messages[position])} was inserted at position {position} of {len(current)}, '
                    'before messages already recorded',
                    {'message': messages[position]},
                )
                for position in range(last_old)
                if current[position] not in previous_set and not is_tool_return_request(messages[position])
            ],
        )
        self._previous = actual

    def _describe(self, message: ModelMessage) -> str:
        # Only for a violation's message: which of these a run reaches depends on what it finds.
        if isinstance(message, ModelRequest):  # pragma: lax no cover
            return f'request {request_keys(message) or [part.part_kind for part in message.parts]}'
        return f'response {message.provider_response_id} {response_text(message)!r}'  # pragma: lax no cover

    def response_numbers(self, message: ModelResponse) -> set[int]:
        """The server responses a recorded `ModelResponse` holds content (or the id) of."""
        truth = self.sim.truth
        numbers = response_numbers(response_text(message))
        if (known := truth.responses.get(message.provider_response_id or '')) is not None:
            numbers.add(known.number)
        calls = [part.tool_call_id for part in message.parts if isinstance(part, ToolCallPart)]
        numbers.update(truth.responses[truth.tool_calls[call_id].response].number for call_id in calls)
        return numbers

    def _check_response_identity(self, messages: list[ModelMessage]) -> None:
        recorded = [
            (position, self.response_numbers(message))
            for position, message in enumerate(messages)
            if isinstance(message, ModelResponse)
        ]
        self.report(
            'response.mixed',
            [
                (
                    f'the response at {position} holds what server responses {sorted(numbers)} said: '
                    f'{self._describe(messages[position])}',
                    {'responses': sorted(numbers)},
                )
                for position, numbers in recorded
                if len(numbers) > 1
            ],
        )
        owners: dict[int, list[int]] = {}
        for position, numbers in recorded:
            for number in numbers:
                owners.setdefault(number, []).append(position)
        self.report(
            'response.duplicated',
            [
                (f'server response r{number} is recorded at {positions}', {'response': number})
                for number, positions in owners.items()
                if len(positions) > 1
            ],
        )

    # --- waits ------------------------------------------------------------------------------------

    def _exchange_resolved(self, response: TruthResponse, by: int, seen: set[str]) -> bool:
        """Whether `response` and everything its tool calls led to had ended, as far as the client could see, by `by`."""
        if response.key in seen or response.lost:  # pragma: lax no cover
            # A response lost with its connection is settled by the reconnect, not by a terminal.
            return True
        seen.add(response.key)
        if response.terminal_read is None or response.terminal_read > by:
            return False
        truth = self.sim.truth
        # A call the client never saw, or one from a response that was cancelled or failed, leads nowhere; nor
        # does one the provider cancelled. Any other has to be answered, and its answer spoken.
        calls = [
            call
            for call in map(truth.tool_calls.__getitem__, response.tool_calls)
            if call.read and response.status == 'completed' and not call.cancelled_by_server
        ]
        outputs = [truth.input(call.call_id) for call in calls]
        return all(
            self._input_resolved(output, by, seen) if output is not None else self._round_cut_by_drop(response, by)
            for output in outputs
        )

    def _round_cut_by_drop(self, response: TruthResponse, by: int) -> bool:
        """Whether a drop after `response` started had settled its tool calls still running, by `by`.

        Where a reconnect doesn't restore what was in flight, it interrupts the calls still running: their results
        never go out, and nothing more is owed for them.
        """
        session = self.sim.session
        assert session is not None
        settled_by_drop = not session._connection.reconnect_restores_in_flight_state  # pyright: ignore[reportPrivateUsage]
        return settled_by_drop and any(response.seq_start < loss <= by for loss in self.sim.truth.connection_losses)

    def _input_resolved(self, input_: TruthInput, by: int, seen: set[str]) -> bool:
        if (input_.refused_read is not None and input_.refused_read <= by) or input_.answer_lost:
            return True  # pragma: lax no cover
        if input_.refused_at is not None and any(
            input_.refused_at < loss <= by for loss in self.sim.truth.connection_losses
        ):  # pragma: lax no cover (a refusal lost with its connection: no reply is coming)
            return True
        # The response that answers it, and only that one: a response already under way when it arrived, which
        # neither saw it nor spoke to it, doesn't. One the server names no answer for (a request the connection
        # folded into another, a merged or superseded `response.create`) is answered by whichever came next.
        return any(
            self._exchange_resolved(response, by, set(seen))
            for response in self.sim.truth.responses.values()
            if response.key == input_.answered_by or (input_.answered_by is None and response.seq_start > input_.seq)
        )

    def _early_return(self, waiter: Waiter) -> list[Violation]:
        """What a returned `wait_for_reply()` should still have been waiting for, if anything."""
        sim = self.sim
        returned = waiter.returned
        assert returned is not None
        truth = sim.truth
        if (
            waiter.error is not None
            or sim.close_requested is not None
            or any(loss >= waiter.started for loss in truth.connection_losses)
            # Every connection was lost and none replaced (GPT-Live doesn't reconnect): the session is over.
            or len(truth.connection_losses) >= truth.connections
            or sim.receive_ended
        ):
            # The session ended or lost state to a drop: returning is right. (A failure that ended only an exchange is
            # judged per exchange, below.)
            return []
        context = {'waiter': waiter.index, 'started': waiter.started}

        def ended_by_failure(since: int) -> bool:
            """Whether a failure the session parked ended an exchange begun at `since` before the wait returned.

            A tool that raised, a usage limit a tool's result would pass, or a tool result that failed to send ends the
            exchange in progress, though the session goes on receiving. (Not a tool failure whose result went out
            anyway, as on GPT-Live: the model answers it, so the exchange goes on.)
            """
            return any(since < at <= returned for at in sim.exchanges_abandoned_at)

        # A reply to a turn it had asked for, by the time the wait began, before the provider saw it...
        soliciting = [
            operation.key
            for operation in sim.operations
            if operation.key in waiter.snapshot and operation.name in ('send_text', 'send_image_respond')
        ]
        inputs = [(key, truth.input(key)) for key in soliciting]
        violations: list[Violation] = [
            (f'wait_for_reply() #{waiter.index} returned before the reply to {key!r} ended', {**context, 'input': key})
            for key, input_ in inputs
            if input_ is None or not (self._input_resolved(input_, returned, set()) or ended_by_failure(input_.seq))
        ]
        # ...or a response it could see was under way when the wait began (unless the client cut it off).
        interrupted = [operation.issued for operation in sim.operations if operation.name.startswith('interrupt_')]
        # Where a reconnect doesn't restore what was in flight, it settles the exchanges the drop cut into: nothing
        # more is owed for them, even before the reconnect has run.
        session = sim.session
        assert session is not None
        settled_by_drop = not session._connection.reconnect_restores_in_flight_state  # pyright: ignore[reportPrivateUsage]
        violations += [
            (
                f'wait_for_reply() #{waiter.index} returned while {response.key} '
                '(already under way when the wait began) was still in progress',
                {**context, 'response': response.key},
            )
            for response in truth.responses.values()
            if response.started_read is not None
            and response.started_read < waiter.started
            and not any(issued > response.seq_start for issued in interrupted)
            and not (settled_by_drop and any(loss > response.seq_start for loss in truth.connection_losses))
            and not self._exchange_resolved(response, waiter.started, set())
            and not self._exchange_resolved(response, returned, set())
            and not ended_by_failure(response.seq_start)
        ]
        return violations

    # --- at rest ----------------------------------------------------------------------------------

    def check_at_rest(self) -> None:
        sim = self.sim
        self.check_step()
        session = sim.session
        assert session is not None
        messages = session.all_messages()
        self._check_tool_pairing(messages)
        self._check_tool_round_order(messages)
        self._check_order(messages)
        self._check_completeness(messages)
        self._check_spoken_turns(messages)
        self._check_restored(messages)
        self._check_pruned(messages)
        self._check_usage(messages)
        self._check_playback(messages)
        roundtrip = ModelMessagesTypeAdapter.validate_json(ModelMessagesTypeAdapter.dump_json(messages))
        self.report(
            'history.roundtrip',
            [('history did not survive a serialization round trip', {})] if roundtrip != messages else [],
        )
        self._check_transcripts(messages)
        self._check_wire()
        if not session.closed:
            # Also once the event stream has ended: `wait_for_reply()` must never outlive the session's ability to reply.
            self._check_sends_survived()
            self._check_wait_liveness()

    def _check_transcripts(self, messages: list[ModelMessage]) -> None:
        """A spoken turn's transcript the session read before it was asked to close is in history, and history has
        no spoken turn the provider never had."""
        sim = self.sim
        truth = sim.truth
        if truth.models_every_spoken_turn:
            spoken = sum(input_.kind == 'speech' for input_ in truth.inputs)
            if sim.close_requested is not None:
                # Closing records what the user was still saying, though the provider never committed it.
                inputs = {input_.key for input_ in truth.inputs}
                spoken += sum(
                    key not in inputs  # (xAI adds the turn at speech start: it's counted above.)
                    and key not in truth.speech_committed
                    and key not in truth.speech_stopped_uncommitted
                    # A clear the session never heard back about (its send failed) leaves the turn as it was.
                    and (key not in truth.speech_cleared or key not in truth.speech_cleared_read)
                    for key in truth.speech_started
                )
            recorded_turns = sum(is_user_speech_request(message) for message in messages)
            self.report(
                'history.phantom_turn',
                [
                    (
                        f'history has {recorded_turns} spoken turns, but the provider had {spoken}',
                        {'extra': recorded_turns - spoken},
                    )
                ]
                if recorded_turns > spoken
                else [],
            )
        if sim.receive_ended and sim.close_requested is None:
            # The session ended on its own: what it holds back for a response it will never read the end of is
            # recorded when it closes.
            return
        recorded = {key for message in messages if isinstance(message, ModelRequest) for key in request_keys(message)}
        self.report(
            'history.transcript_lost',
            [
                (f"the transcript of spoken turn {key!r} was read but isn't in history", {'input': key})
                for key, read in sim.truth.transcripts_read.items()
                if key not in recorded and (sim.close_requested is None or read < sim.close_requested)
            ],
        )

    def _check_tool_round_order(self, messages: list[ModelMessage]) -> None:
        truth = self.sim.truth
        first_return: dict[str, int] = {}
        first_arrival: dict[str, int] = {}
        for position, message in enumerate(messages):
            if not isinstance(message, ModelRequest):
                continue
            for part in message.parts:
                call = truth.tool_calls.get(part.tool_call_id) if isinstance(part, ToolReturnPart) else None
                output = truth.input(call.call_id) if call is not None else None
                if call is None or output is None or output.kind != 'tool_output':
                    continue
                first_return.setdefault(call.response, position)
                first_arrival[call.response] = min(first_arrival.get(call.response, output.seq), output.seq)
        violations: list[Violation] = [
            (
                f"{word!r} was said before the first result for {key}'s tool calls reached the server, "
                f'but is recorded after it ({position} > {first_return[key]})',
                {'response': key},
            )
            for position, message in enumerate(messages)
            if isinstance(message, ModelResponse)
            for key in first_return
            if position > first_return[key]
            for word in response_text(message).split()
            if word in truth.responses[key].words and truth.word_seq[word] < first_arrival[key]
        ]
        self.report('history.tool_round_order', violations)

    def _check_tool_pairing(self, messages: list[ModelMessage]) -> None:
        calls = {
            part.tool_call_id: position
            for position, message in enumerate(messages)
            if isinstance(message, ModelResponse)
            for part in message.parts
            if isinstance(part, ToolCallPart)
        }
        returns = [
            (part.tool_call_id, position)
            for position, message in enumerate(messages)
            if isinstance(message, ModelRequest)
            for part in message.parts
            if isinstance(part, ToolReturnPart)
        ]
        violations: list[Violation] = [
            (f'a return for {call_id!r}, which no recorded response called', {'call': call_id})
            for call_id, _ in returns
            if call_id not in calls
        ]
        violations += [
            (
                f'the return for {call_id!r} is at {position}, not directly after its call at {calls[call_id]}',
                {'call': call_id},
            )
            for call_id, position in returns
            if call_id in calls
            and not (
                calls[call_id] < position
                and all(is_tool_return_request(message) for message in messages[calls[call_id] + 1 : position])
            )
        ]
        # Every call has exactly one return, once no tool is still running.
        counts = Counter(call_id for call_id, _ in returns)
        violations += [
            (f'tool call {call_id!r} has {counts[call_id]} returns', {'call': call_id})
            for call_id in calls
            if counts[call_id] != 1 and not self.sim.tools.pending()
        ]
        self.report('history.tool_pairing', violations)

    def _check_order(self, messages: list[ModelMessage]) -> None:
        truth = self.sim.truth
        positions: dict[str, int] = {}
        responses: dict[str, int] = {}
        for position, message in enumerate(messages):
            if isinstance(message, ModelRequest):
                for key in request_keys(message):
                    positions.setdefault(key, position)
            else:
                for number in self.response_numbers(message):
                    responses.setdefault(truth.responses_by_number[number].key, position)
        self.report(
            'history.rejected_kept',
            [
                (f'{input_.key!r} was refused by the provider but is still in history', {'input': input_.key})
                for input_ in truth.inputs
                if input_.rejected and input_.refused_read is not None and input_.key in positions
            ],
        )
        # User turns (not tool returns, which are pinned after their call) against the responses around them.
        pairs = [
            (input_, positions[input_.key], truth.responses[key], position)
            for input_ in truth.inputs
            if not input_.rejected and input_.key in positions and input_.kind not in ('tool_output', 'create')
            for key, position in responses.items()
        ]
        violations: list[Violation] = [
            (
                f'{input_.key!r} reached the server before {response.key} started, but is recorded after it '
                f'({input_position} > {response_position})',
                {'input': input_.key, 'response': response.key},
            )
            for input_, input_position, response, response_position in pairs
            if input_.seq < response.seq_start and input_position > response_position
        ]
        violations += [
            (
                f'{input_.key!r} reached the server after {response.key} ended, but is recorded before it '
                f'({input_position} < {response_position})',
                {'input': input_.key, 'response': response.key},
            )
            for input_, input_position, response, response_position in pairs
            if response.seq_end is not None and input_.seq > response.seq_end and input_position < response_position
        ]
        ordered = [truth.responses[key] for key, _ in sorted(responses.items(), key=lambda item: item[1])]
        violations += [
            (f'{second.key} ended before {first.key} started but is recorded after it', {'response': second.key})
            for first, second in zip(ordered, ordered[1:])
            if second.seq_end is not None and second.seq_end < first.seq_start
        ]
        self.report('history.order', violations)

    def _check_spoken_turns(self, messages: list[ModelMessage]) -> None:
        if self.sim.receive_ended and self.sim.close_requested is None:
            # The session ended on its own: a turn it holds back for a response it will never read the end of is
            # recorded when it closes, and checked then.
            return
        # By count: a turn recorded without its transcript can't be told apart from another.
        committed = [
            input_.key
            for input_ in self.sim.truth.inputs
            if input_.kind == 'speech'
            and (input_.committed_read is not None or input_.committed_by_client)
            and not input_.rejected
            # A commit whose send raised, though the provider had it, is one the client was told failed.
            and input_.key not in self.sim.truth.ambiguous_inputs
        ]
        recorded = sum(1 for message in messages if is_user_speech_request(message))
        self.report(
            'history.turn_missing',
            [(f'{len(committed)} spoken turns committed ({committed}), but {recorded} recorded', {'inputs': committed})]
            if recorded < len(committed)
            else [],
        )

    def _check_pruned(self, messages: list[ModelMessage]) -> None:
        """Tool rounds deleted from the server conversation were answered, and history still holds them."""
        truth = self.sim.truth
        self.report(
            'prune.unanswered',
            [
                (f'{call} was deleted before the model answered its result', {'call': call})
                for call in truth.pruned_unanswered
            ],
        )
        recorded = conversation_fingerprints(messages)
        self.report(
            'prune.dropped_from_history',
            [
                (f'{fingerprint} was deleted from the server conversation and from history', {'item': fingerprint})
                for fingerprint in truth.pruned
                if fingerprint not in recorded
            ],
        )

    def _check_restored(self, messages: list[ModelMessage]) -> None:
        """A re-dialed conversation must hold what history records and the one before held (a local replay's promise).

        The turn a drop cut off is settled instead (a reconnect reports `state_restored=False` for it): that turn is
        over, so what it said and called before the drop need not reach the new conversation.
        """
        sim = self.sim
        recorded = conversation_fingerprints(messages)
        settled: set[str] = set()
        for response in sim.truth.responses.values():
            if response.lost:
                # (Each message item it spoke: a tool call ends one and starts the next, so any run of its words.)
                words = response.words
                settled |= {
                    f'assistant:{" ".join(words[start:end])}'
                    for start in range(len(words))
                    for end in range(start + 1, len(words) + 1)
                }
                settled |= {
                    f'{kind}:{call}'
                    for call in response.tool_calls
                    for kind in ('function_call', 'function_call_output')
                }
        cut_off = cut_off_replays(messages)
        missing = [
            (
                restoration,
                sorted(
                    fingerprint
                    for fingerprint in (restoration.before & recorded) - restoration.held - settled
                    # (Restored as cut off, which is how history records it.)
                    if cut_off.get(fingerprint) not in restoration.held
                ),
            )
            for restoration in sim.truth.restorations
        ]
        truncated = {
            f'assistant:{" ".join(response.items[item_id])}': (item_id, response)
            for item_id, _ in sim.truth.truncations
            if (response := sim.truth.item_responses.get(item_id)) is not None and response.items[item_id]
        }
        self.report(
            'history.replayed_as_heard',
            [
                (
                    f'connection {restoration.connection} holds {fingerprint!r} as heard, '
                    f'but {response.key} was truncated at {item_id}',
                    {'response': response.key},
                )
                for restoration in sim.truth.restorations
                for fingerprint, (item_id, response) in truncated.items()
                if response.connection < restoration.connection and fingerprint in restoration.held
            ],
        )
        self.report(
            'history.not_restored',
            [
                (
                    f'connection {restoration.connection} started {restoration.response} without {lost}, '
                    'which history records and an earlier connection held',
                    {'response': restoration.response, 'missing': lost},
                )
                for restoration, lost in missing
                if lost
            ],
        )

    def _check_completeness(self, messages: list[ModelMessage]) -> None:
        truth = self.sim.truth
        recorded: dict[int, list[str]] = {}
        for message in messages:
            if isinstance(message, ModelResponse):
                for number in self.response_numbers(message):
                    # A response recorded in pieces is `response.duplicated`'s business; here, only what it said.
                    recorded.setdefault(number, []).append(response_text(message))
        completed = [
            (response, ' '.join(filter(None, recorded.get(response.number, []))) or None)
            for response in truth.responses.values()
            if response.words and response.terminal_read is not None and response.status == 'completed'
        ]
        self.report(
            'response.missing',
            [
                (
                    f'{response.key} ({" ".join(response.words)!r}) completed but is not in history',
                    {'response': response.key},
                )
                for response, _ in completed
                if response.number not in recorded
            ],
        )
        self.report(
            'response.truncated',
            [
                (
                    f'{response.key} said {" ".join(response.words)!r} but is recorded as {text!r}',
                    {'response': response.key},
                )
                for response, text in completed
                if response.number in recorded and text != ' '.join(response.words)
            ],
        )

    def _check_usage(self, messages: list[ModelMessage]) -> None:
        sim = self.sim
        session = sim.session
        assert session is not None
        ended = sim.receive_ended_at
        if ended is not None and (sim.close_requested is None or ended < sim.close_requested):
            # The session ended on its own (an exceeded usage limit, a lost connection), before any close: whatever
            # the connection read after that point, closing included, was never going to be accounted.
            return
        truth = sim.truth
        billed = (
            sum(tokens[0] for tokens in truth.usage_read.values()),
            sum(tokens[1] for tokens in truth.usage_read.values()),
        )
        usage = session.usage
        recorded = (usage.input_tokens, usage.output_tokens)
        # Closing stops the session mid-frame: a report the connection had read ahead may go unaccounted, but
        # nothing may ever be counted twice.
        over = any(count > limit for count, limit in zip(recorded, billed))
        wrong = recorded != billed if sim.close_requested is None else over
        self.report(
            'usage.total',
            [(f'session.usage has {recorded} tokens (in, out), but the server billed {billed} in the reports read', {})]
            if wrong
            else [],
        )
        # A response the server identified is recorded with exactly the usage reported under its id: none, if the client
        # read no report for it, rather than another response's.
        billed_by_id = {
            message.provider_response_id: truth.usage_read.get(message.provider_response_id, (0, 0))
            for message in messages
            if isinstance(message, ModelResponse)
            and message.provider_response_id is not None
            and (message.provider_response_id in truth.usage_read or message.provider_response_id in truth.responses)
        }
        self.report(
            'usage.attribution',
            [
                (
                    f'{message.provider_response_id} is recorded with {message.usage.input_tokens} / '
                    f'{message.usage.output_tokens} tokens, but was billed {billed_by_id[message.provider_response_id]}',
                    {'response': message.provider_response_id},
                )
                for message in messages
                if isinstance(message, ModelResponse)
                and message.provider_response_id in billed_by_id
                and (message.usage.input_tokens, message.usage.output_tokens)
                != billed_by_id[message.provider_response_id]
            ],
        )
        # A model that reports its requests with usage (GPT-Live's delegated backend) counts those instead.
        expected = sim.expected_requests()
        if expected is None:
            expected = sum(isinstance(message, ModelResponse) for message in session.new_messages())
        self.report(
            'usage.requests',
            [(f'usage.requests is {usage.requests}, but {expected} were made', {})]
            if usage.requests != expected
            else [],
        )

    def _check_playback(self, messages: list[ModelMessage]) -> None:
        """A cut lands inside the audio of the reply it cuts, and the provider can apply every truncation sent."""
        truth = self.sim.truth
        refused, self._judged_truncations = (
            truth.refused_truncations[self._judged_truncations :],
            len(truth.refused_truncations),
        )
        self.report(
            'playback.bad_truncate', [(f'the provider refused a truncation: {reason}', {}) for reason in refused]
        )
        cuts = [
            (message, part.interrupted_at_ms, self.response_numbers(message))
            for message in messages
            if isinstance(message, ModelResponse)
            for part in message.parts
            if isinstance(part, SpeechPart) and part.interrupted_at_ms is not None
        ]
        generated = {
            id(message): sum(truth.responses_by_number[number].audio_bytes for number in numbers)
            // self.sim.output_bytes_per_ms
            for message, _, numbers in cuts
        }
        self.report(
            'playback.cut_beyond_audio',
            [
                (
                    f'{self._describe(message)} is cut at {at_ms} ms, but only {generated[id(message)]} ms of it was generated',
                    {'responses': sorted(numbers)},
                )
                for message, at_ms, numbers in cuts
                if at_ms > generated[id(message)]
            ],
        )
        heard: dict[str, int] = {}
        for item_id, audio_end_ms in truth.truncations:
            heard[item_id] = min(audio_end_ms, heard.get(item_id, audio_end_ms))
        spoken = {
            (number, part.transcript): (message, part)
            for message in messages
            if isinstance(message, ModelResponse)
            for number in self.response_numbers(message)
            for part in message.parts
            if isinstance(part, SpeechPart) and part.transcript
        }
        not_recorded: list[Violation] = []
        for item_id, heard_ms in heard.items():
            response = truth.item_responses.get(item_id)
            recorded = (
                spoken.get((response.number, ' '.join(response.items[item_id]))) if response is not None else None
            )
            if response is None or recorded is None:  # pragma: lax no cover (depends on what exploration reaches)
                # Not recorded as the provider said it (lost with its connection, say): other invariants judge that.
                continue
            message, part = recorded
            cut = part.interrupted_at_ms
            if message.state != 'interrupted' or cut is None or cut > heard_ms:  # pragma: lax no cover (a violation)
                not_recorded.append(
                    (
                        f'{response.key} was truncated at {heard_ms} ms, but history records it as '
                        f'{message.state} with a cut at {cut}',
                        {'response': response.key},
                    )
                )
        self.report('playback.cut_not_recorded', not_recorded)

    def _check_wire(self) -> None:
        """Each caller's sends reach the server once each, in the order they were made."""
        sim = self.sim
        arrivals: dict[str, list[int]] = {}
        for input_ in sim.truth.inputs:
            if input_.kind in ('text', 'context', 'image'):
                arrivals.setdefault(input_.key, []).append(input_.seq)
        # A send that failed after the frame went out is sent again: the client can't know it arrived.
        self.report(
            'wire.duplicate',
            [
                (f'the server received {key!r} {len(seqs)} times', {'input': key})
                for key, seqs in arrivals.items()
                # An ambiguous send may be sent once more, not again after that.
                if len(seqs) > (2 if key in sim.truth.ambiguous_inputs else 1)
            ],
        )
        callers: dict[str, list[tuple[int, int, str]]] = {}
        for operation in sim.operations:
            if operation.key in arrivals:
                callers.setdefault(operation.caller, []).append(
                    (operation.issued, arrivals[operation.key][0], operation.key)
                )
        orders = [
            (caller, [key for *_, key in sorted(sends)], [key for *_, key in sorted(sends, key=lambda send: send[1])])
            for caller, sends in callers.items()
        ]
        self.report(
            'wire.order',
            [
                (f'the {caller} caller sent {issued}, but the server received {arrived}', {'caller': caller})
                for caller, issued, arrived in orders
                if issued != arrived
            ],
        )

    def _check_sends_survived(self) -> None:
        """A send must not fail on a connection the session went on to replace: only a session that ended may refuse one."""
        if self.sim.receive_ended:
            return
        self.report(
            'send.failed_across_reconnect',
            [
                (
                    f'{operation.name} failed ({operation.error}), though the session reconnected and went on',
                    {'operation': operation.name},
                )
                for operation in self.sim.operations
                if isinstance(operation.error, RealtimeError) and operation.error.message.startswith(_SEND_FAILED)
            ],
        )

    def _check_wait_liveness(self) -> None:
        sim = self.sim
        stuck = [waiter.index for waiter in sim.waiters if waiter.returned is None]
        session = sim.session
        assert session is not None
        probe = sim.loop.create_task(session.wait_for_reply())
        sim.loop.run_until_idle()
        hung = not probe.done()
        probe.cancel()
        sim.loop.run_until_idle()
        if hung:
            stuck.append(len(sim.waiters))
        self.report(
            'wait.hang',
            [(f'wait_for_reply() {stuck} still waiting with nothing left to wait for', {'waiters': stuck})]
            if stuck
            else [],
        )
