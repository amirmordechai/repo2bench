"""Network-free GPT-Live tests: profile, session configuration, and codec translation.

The cassette tests in `test_openai_live_ws.py` cover a real conversation. These pin the parts a recording
can't: the guards that fire before a socket is opened, the pieces of Live's protocol our own frames
have to get right (a cassette matcher can match a recording even after the payload drifts), and the
translation rules that only show up under conditions a recorded call doesn't reliably produce.
"""

from __future__ import annotations as _annotations

import asyncio
import base64
import itertools
import json
import re
import warnings
from contextlib import contextmanager, nullcontext
from dataclasses import replace
from datetime import UTC
from decimal import Decimal
from typing import Any

import anyio
import pytest
from genai_prices import calc_price
from genai_prices.data_snapshot import DataSnapshot, get_snapshot, set_custom_snapshot
from genai_prices.types import ClauseEquals, ModelInfo, ModelPrice
from inline_snapshot import snapshot

from pydantic_ai import Agent, UsageLimitUnavailableWarning
from pydantic_ai.capabilities import NativeTool
from pydantic_ai.exceptions import ModelHTTPError, UsageLimitExceeded, UserError
from pydantic_ai.messages import (
    AudioUrl,
    BinaryAudio,
    BinaryContent,
    BinaryImage,
    CachePoint,
    DocumentUrl,
    FilePart,
    FunctionToolResultEvent,
    ImageUrl,
    ModelMessage,
    ModelRequest,
    ModelResponse,
    NativeToolCallPart,
    NativeToolReturnPart,
    PartEndEvent,
    PartStartEvent,
    RealtimeSessionErrorEvent,
    RetryFeedbackPart,
    RetryInfo,
    SpeechPart,
    SystemPromptPart,
    TextContent,
    TextPart,
    ThinkingPart,
    ToolCallPart,
    ToolReturnPart,
    UploadedFile,
    UserContent,
    UserPromptPart,
    VideoUrl,
)
from pydantic_ai.models import ModelRequestParameters
from pydantic_ai.native_tools import WebSearchTool
from pydantic_ai.realtime import (
    RealtimeError,
    RealtimeModelProfile,
    RealtimeModelProfileSpec,
    RealtimeSession,
    RealtimeSessionReconnectEvent,
    RealtimeTurnCompleteEvent,
    WebRTCSession,
    infer_realtime_model,
)
from pydantic_ai.realtime.codec import (
    AudioDelta,
    CancelResponse,
    ClearAudio,
    CommitAudio,
    CreateResponse,
    InputTranscript,
    OutputTranscript,
    ResponseDone,
    SessionUsage,
    TextContext,
    ToolCall,
    ToolResult,
    TruncateOutput,
)
from pydantic_ai.settings import ThinkingLevel, ToolOrOutput
from pydantic_ai.tools import ToolDefinition
from pydantic_ai.usage import RequestUsage, UsageLimits

from ..conftest import IsNow, legacy_retry_prompt_part, try_import

with try_import() as imports_successful:
    import httpx2
    import websockets
    from openai import AsyncOpenAI
    from openai.types.live import SessionConfig
    from openai.types.shared import ReasoningEffort
    from pydantic import TypeAdapter
    from websockets.frames import Close

    from pydantic_ai.models.openai import OpenAIChatModel, OpenAIResponsesModel
    from pydantic_ai.providers import Provider
    from pydantic_ai.providers.azure import AzureProvider
    from pydantic_ai.providers.gateway import gateway_provider
    from pydantic_ai.providers.openai import OpenAIProvider
    from pydantic_ai.realtime import openai_live as live_module
    from pydantic_ai.realtime.openai import OpenAIRealtimeModel
    from pydantic_ai.realtime.openai_live import (
        AUTO_BACKEND_MODEL,
        OpenAILiveConnection,
        OpenAILiveModel,
        OpenAILiveModelSettings,
        OpenAILiveResponsesDelegation,
        _ActedOnEvent,  # pyright: ignore[reportPrivateUsage]
        seed_input_items,
    )

pytestmark = [
    pytest.mark.skipif(not imports_successful(), reason='realtime provider dependencies not installed'),
]


@pytest.fixture
def model() -> OpenAILiveModel:
    return OpenAILiveModel('gpt-live-1', provider='openai')


def _config(model: OpenAILiveModel, **kwargs: Any) -> dict[str, Any]:
    kwargs.setdefault('instructions', '')
    kwargs.setdefault('tools', [])
    kwargs.setdefault('native_tools', [])
    kwargs.setdefault('messages', [])
    kwargs.setdefault('settings', OpenAILiveModelSettings())
    return model._session_config(**kwargs)  # pyright: ignore[reportPrivateUsage]


def _connection(**kwargs: Any) -> OpenAILiveConnection:
    """A connection with no socket: every test here drives `_map_event` directly."""
    return OpenAILiveConnection(object(), **kwargs)  # pyright: ignore[reportArgumentType]


_acted_on_events: TypeAdapter[_ActedOnEvent] = TypeAdapter(_ActedOnEvent)


def _event(payload: dict[str, Any]) -> _ActedOnEvent:
    """Parse a raw Live frame the way the connection does, so tests drive real SDK event objects."""
    return _acted_on_events.validate_python(payload)


def test_live_model_names_route_to_the_live_protocol(env: Any) -> None:
    """`gpt-live-*` is served by a different endpoint than the Realtime API, on the same provider."""
    env.set('OPENAI_API_KEY', 'test-key')
    assert isinstance(infer_realtime_model('openai:gpt-live-1'), OpenAILiveModel)
    assert isinstance(infer_realtime_model('openai:gpt-realtime'), OpenAIRealtimeModel)


def test_profile(model: OpenAILiveModel) -> None:
    """Live is far more constrained than the Realtime API, and the profile is what says so."""
    assert model.profile == RealtimeModelProfile(
        supports_image_input=True,
        image_input_requires_response=True,
        supports_manual_turn_control=False,
        supports_interruption=False,
        supports_output_truncation=False,
        supports_text_output=False,
        supports_session_seeding=True,
        supports_seeding_images=False,
        supports_seeding_audio=False,
        # A server relays the offer and attaches a sideband; there are no client secrets.
        supports_webrtc=True,
        async_tool_call_mode='always',
        supports_async_tool_calls=True,  # deprecated, derived from `async_tool_call_mode`
        # `thinking` sets the delegated backend's reasoning effort.
        supports_thinking=True,
        supports_tool_return_schema=False,
        emits_input_speech_events=False,
        # The one model in the repo that infers its turn boundary rather than reading it off the wire.
        synthesizes_turn_boundary=True,
        # Its spoken replies are inferred turns; the requests that spend tokens are the backend's.
        responses_are_requests=False,
        # Live reports its own context usage; the tokens it reports are the delegated backend's.
        response_usage_covers_context=False,
        # The delegated backend runs web search; Live refuses every other native Responses tool.
        supported_native_tools=frozenset({WebSearchTool}),
        audio_input_sample_rate=24000,
        audio_output_sample_rate=24000,
        context_window=128_000,
    )


def test_websocket_url_is_the_live_endpoint(model: OpenAILiveModel) -> None:
    """Live is a different path on the same host, and carries no model query parameter."""
    assert model._live_url() == snapshot('wss://api.openai.com/v1/live/sessions')  # pyright: ignore[reportPrivateUsage]


def test_azure_is_rejected() -> None:
    """Azure does not serve GPT-Live, so pointing at it fails with a pointer to what does."""
    provider = AzureProvider(azure_endpoint='https://example.openai.azure.com', api_key='k', api_version='v')
    with pytest.raises(UserError, match='Azure OpenAI does not serve GPT-Live'):
        OpenAILiveModel('gpt-live-1', provider=provider)


def test_agent_instructions_and_tools_configure_the_backend(model: OpenAILiveModel) -> None:
    """The agent describes the work, so it configures the backend, not the spoken conversation.

    A cassette would match this recording even if the payload drifted, so the split is pinned here.
    """
    tool = ToolDefinition(name='lookup', description='Look something up.', parameters_json_schema={'type': 'object'})
    config = _config(model, instructions='You look things up.', tools=[tool])

    assert config['delegation'] == snapshot(
        {
            'type': 'responses',
            'responses': {
                'model': AUTO_BACKEND_MODEL,
                'instructions': 'You look things up.',
                'tools': [
                    {
                        'type': 'function',
                        'name': 'lookup',
                        'parameters': {'type': 'object'},
                        'description': 'Look something up.',
                    }
                ],
            },
        }
    )
    # The spoken prompt is separate, and defaults rather than inheriting the agent's.
    assert 'You look things up.' not in config['instructions']


def test_delegation_settings_reach_the_backend(model: OpenAILiveModel) -> None:
    settings = OpenAILiveModelSettings(
        openai_live_delegation=OpenAILiveResponsesDelegation(
            model='gpt-5.6-luna',
            instructions='Prefer metric units.',
            max_output_tokens=256,
            parallel_tool_calls=False,
            reasoning_effort='low',
            reasoning_summary='auto',
            verbosity='low',
            service_tier='priority',
        ),
        openai_voice='cedar',
        openai_live_instructions='Speak slowly.',
        openai_live_store=True,
    )
    config = _config(model, instructions='Be accurate.', settings=settings)

    assert config['delegation']['responses'] == snapshot(
        {
            'model': 'gpt-5.6-luna',
            # The agent's instructions come first; the setting appends to them.
            'instructions': 'Be accurate.\n\nPrefer metric units.',
            'max_output_tokens': 256,
            'parallel_tool_calls': False,
            'service_tier': 'priority',
            'reasoning': {'effort': 'low', 'summary': 'auto'},
            'text': {'verbosity': 'low'},
        }
    )
    assert config['instructions'] == 'Speak slowly.'
    assert config['audio']['output'] == {'voice': 'cedar'}
    assert config['store'] is True


@pytest.mark.parametrize(
    'backend,thinking,expected',
    [
        pytest.param('gpt-5.6-sol', True, 'medium', id='on'),
        pytest.param('gpt-5.6-sol', 'high', 'high', id='level'),
        pytest.param('gpt-5.6-sol', False, 'none', id='off'),
        # Resolved against the backend's profile, as a direct Responses request to it would be.
        pytest.param('gpt-5.6-sol', 'minimal', 'low', id='no-minimal-effort'),
        pytest.param('gpt-5', 'minimal', 'minimal', id='minimal-effort'),
        # The delegation's efforts stop at `xhigh`, even for a backend whose Responses API takes `max`.
        pytest.param('gpt-6.1-sol', 'max', 'xhigh', id='max-effort'),
        # A backend that always reasons can't be turned off, so `False` sends its lowest effort.
        pytest.param('gpt-5', False, 'minimal', id='always-reasons'),
        pytest.param('gpt-6-astra', False, 'low', id='always-reasons-no-minimal-effort'),
        # A backend that doesn't reason is sent no effort at all.
        pytest.param('gpt-4.1', 'high', None, id='does-not-reason'),
    ],
)
def test_thinking_sets_the_backends_reasoning_effort(
    model: OpenAILiveModel, backend: str, thinking: ThinkingLevel, expected: ReasoningEffort
) -> None:
    """The backend does the reasoning, so the shared `thinking` setting is its effort."""
    settings = OpenAILiveModelSettings(thinking=thinking, openai_live_delegation={'model': backend})
    responses = _config(model, settings=settings)['delegation']['responses']

    assert responses.get('reasoning') == ({'effort': expected} if expected is not None else None)


def test_a_reasoning_summary_is_requested_without_an_effort(model: OpenAILiveModel) -> None:
    """A summary needs no effort of its own: the backend reasons at its default and summarizes that."""
    settings = OpenAILiveModelSettings(openai_live_delegation={'model': 'gpt-5.6-sol', 'reasoning_summary': 'detailed'})
    responses = _config(model, settings=settings)['delegation']['responses']

    assert responses['reasoning'] == {'summary': 'detailed'}


def test_delegation_settings_take_precedence_over_shared_ones(model: OpenAILiveModel) -> None:
    settings = OpenAILiveModelSettings(
        thinking='high',
        parallel_tool_calls=True,
        openai_live_delegation={'model': 'gpt-5.6-sol', 'reasoning_effort': 'low', 'parallel_tool_calls': False},
    )
    responses = _config(model, settings=settings)['delegation']['responses']

    assert responses['reasoning'] == {'effort': 'low'}
    assert responses['parallel_tool_calls'] is False


def test_shared_parallel_tool_calls_reaches_the_backend(model: OpenAILiveModel) -> None:
    """The backend is what calls the tools, so the shared setting applies to it."""
    responses = _config(model, settings=OpenAILiveModelSettings(parallel_tool_calls=False))['delegation']['responses']

    assert responses['parallel_tool_calls'] is False


@pytest.mark.parametrize(
    'setting,value',
    [
        ('turn_detection', False),
        ('max_tokens', 100),
        ('input_transcription_model', 'gpt-transcribe'),
    ],
)
async def test_unsupported_settings_raise_before_connecting(model: OpenAILiveModel, setting: str, value: Any) -> None:
    """A setting Live cannot honor is a stated requirement, so it fails rather than being ignored."""
    with pytest.raises(UserError, match='GPT-Live does not support'):
        async with model.connect(
            messages=[],
            model_settings={setting: value},  # pyright: ignore[reportArgumentType]
            model_request_parameters=ModelRequestParameters(),
        ):
            pass  # pragma: no cover


@pytest.mark.parametrize('verb', [CommitAudio(), ClearAudio(), CancelResponse(), TruncateOutput(audio_end_ms=10)])
async def test_turn_control_is_rejected(verb: Any) -> None:
    """Live owns turn-taking, so every manual turn verb fails rather than being dropped.

    `CreateResponse` is the exception: the session only sends one right after an image, and on Live it
    runs the delegated backend on that image.
    """
    with pytest.raises(UserError, match='drives turn-taking itself'):
        await _connection().send(verb)


async def test_an_image_goes_to_the_backend_that_runs_on_it() -> None:
    """The voice model sees no images; the delegated backend does, as ordinary Responses input."""
    sent: list[dict[str, Any]] = []

    class _Sink(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)

    connection = _Sink(object())  # pyright: ignore[reportArgumentType]
    await connection.send(BinaryImage(data=b'png', media_type='image/png'))
    await connection.send(CreateResponse())

    assert sent == snapshot(
        [
            {
                'type': 'response.item.create',
                'item': {
                    'type': 'message',
                    'role': 'user',
                    'content': [{'type': 'input_image', 'image_url': 'data:image/png;base64,cG5n'}],
                },
            },
            {'type': 'response.create'},
        ]
    )


async def test_an_image_needs_respond_true(model: OpenAILiveModel) -> None:
    """Queued as context alone, an image goes unseen: Live's voice model answers questions about it blind."""
    started = json.dumps({'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}})
    ws = _FakeWebSocket([started])
    image = BinaryImage(data=b'png', media_type='image/png')

    with _patched_connect(ws):
        async with Agent().realtime(model).session() as session:
            with pytest.raises(UserError, match='only takes an image to respond to it'):
                await session.send(image)
            # Without manual turn control, which Live doesn't have.
            await session.send(image, respond=True)

    assert [json.loads(frame)['type'] for frame in ws.sent[1:]] == [
        'response.item.create',
        'response.create',
        'session.close',
    ]


async def test_session_start_carries_seeded_system_prompts(model: OpenAILiveModel) -> None:
    """The standing system prompt opens the backend instructions; a later one is seeded in place as `<system>` text."""
    started = json.dumps({'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}})
    ws = _FakeWebSocket([started])
    history = [
        ModelRequest(parts=[SystemPromptPart(content='Standing prompt.'), UserPromptPart(content='hi')]),
        ModelResponse(parts=[TextPart(content='hello')]),
        ModelRequest(parts=[SystemPromptPart(content='Mid-conversation note.'), UserPromptPart(content='more')]),
        ModelResponse(parts=[TextPart(content='sure')]),
    ]

    with _patched_connect(ws):
        async with Agent(instructions='Agent instructions.').realtime(model, message_history=history).session():
            pass

    session = json.loads(ws.sent[0])['session']
    assert session['delegation']['responses']['instructions'] == 'Standing prompt.\n\nAgent instructions.'
    assert session['input'] == snapshot(
        [
            {'role': 'user', 'content': [{'type': 'input_text', 'text': 'hi'}]},
            {'role': 'assistant', 'content': [{'type': 'output_text', 'text': 'hello'}]},
            {'role': 'user', 'content': [{'type': 'input_text', 'text': '<system>Mid-conversation note.</system>'}]},
            {'role': 'user', 'content': [{'type': 'input_text', 'text': 'more'}]},
            {'role': 'assistant', 'content': [{'type': 'output_text', 'text': 'sure'}]},
        ]
    )


def test_seeding_projects_history_to_text() -> None:
    """Live seeds from text alone, so tool rounds are rendered as readable user/assistant text."""
    messages = [
        ModelRequest(parts=[SystemPromptPart(content='ignored, goes to instructions')]),
        ModelRequest(parts=[UserPromptPart(content='What is the weather?')]),
        ModelResponse(parts=[ThinkingPart(content='They want a forecast.'), ToolCallPart('forecast', {'city': 'A'})]),
        ModelRequest(parts=[ToolReturnPart(tool_name='forecast', content='14C', tool_call_id='1')]),
        ModelResponse(parts=[TextPart(content='Fourteen degrees.')]),
        ModelRequest(parts=[SpeechPart(speaker='user', transcript='Thanks!')]),
        ModelResponse(parts=[SpeechPart(speaker='assistant', transcript='Any time.')]),
    ]

    assert seed_input_items(messages, provider_name='openai') == snapshot(
        [
            {'role': 'user', 'content': [{'type': 'input_text', 'text': 'What is the weather?'}]},
            {'role': 'assistant', 'content': [{'type': 'output_text', 'text': 'They want a forecast.'}]},
            {'role': 'assistant', 'content': [{'type': 'output_text', 'text': 'Called `forecast` with {"city":"A"}.'}]},
            {'role': 'user', 'content': [{'type': 'input_text', 'text': 'Result of `forecast`: 14C'}]},
            {'role': 'assistant', 'content': [{'type': 'output_text', 'text': 'Fourteen degrees.'}]},
            {'role': 'user', 'content': [{'type': 'input_text', 'text': 'Thanks!'}]},
            {'role': 'assistant', 'content': [{'type': 'output_text', 'text': 'Any time.'}]},
        ]
    )


def test_seeding_marks_interrupted_speech() -> None:
    """Interrupted assistant speech carries the same marker a text handoff gets, so the model doesn't take it as heard."""
    history = [
        ModelRequest(parts=[UserPromptPart(content='Book me a flight.')]),
        # Cut off where the listener stopped hearing it.
        ModelResponse(
            parts=[SpeechPart(speaker='assistant', transcript='Sure, the morning flight', interrupted_at_ms=640)]
        ),
        # Interrupted with no offset reported: the last speech part is marked.
        ModelResponse(
            parts=[
                SpeechPart(speaker='assistant', transcript='Let me check.'),
                SpeechPart(speaker='assistant', transcript='It leaves at'),
            ],
            state='interrupted',
        ),
        # Nothing was transcribed, so there is still nothing to seed.
        ModelResponse(parts=[SpeechPart(speaker='assistant', interrupted_at_ms=0)], state='interrupted'),
    ]

    assert seed_input_items(history, provider_name='openai') == snapshot(
        [
            {'role': 'user', 'content': [{'type': 'input_text', 'text': 'Book me a flight.'}]},
            {
                'role': 'assistant',
                'content': [{'type': 'output_text', 'text': 'Sure, the morning flight\n[Interrupted after 640 ms]'}],
            },
            {'role': 'assistant', 'content': [{'type': 'output_text', 'text': 'Let me check.'}]},
            {'role': 'assistant', 'content': [{'type': 'output_text', 'text': 'It leaves at\n[Interrupted]'}]},
        ]
    )


def test_seeding_refuses_media(image_content: Any) -> None:
    """Unsupported content raises rather than being silently dropped from the seeded conversation."""
    messages = [ModelRequest(parts=[UserPromptPart(content=[image_content])])]
    with pytest.raises(UserError, match='can only be seeded with text'):
        seed_input_items(messages, provider_name='openai')


def test_idle_output_audio_is_dropped_but_speech_passes() -> None:
    """Live streams a continuous audio track; only what carries sound is a reply.

    A recorded call can't pin this: the idle frames and the spoken ones are the same event type, so
    the rule only shows as a difference when the two are fed in deliberately.
    """
    connection = _connection()
    silence = {'type': 'session.output_audio.delta', 'delta': 'AAAAAAAAAAA='}
    voice = {'type': 'session.output_audio.delta', 'delta': 'f39/f39/f38='}

    assert connection._map_event(_event(silence)) == []  # pyright: ignore[reportPrivateUsage]
    assert [type(e).__name__ for e in connection._map_event(_event(voice))] == ['AudioDelta']  # pyright: ignore[reportPrivateUsage]
    # Once the model is speaking, a silent frame mid-utterance is a pause, not the end of the track.
    assert [type(e).__name__ for e in connection._map_event(_event(silence))] == ['AudioDelta']  # pyright: ignore[reportPrivateUsage]


def test_start_of_stream_dither_is_not_speech() -> None:
    """Every Live session opens with a frame or two of dither peaking around 20.

    Counting any non-zero sample as speech opened a reply before the user had said anything, and
    every idle frame after it then reached the session as assistant audio.
    """
    connection = _connection()
    dither = {'type': 'session.output_audio.delta', 'delta': 'EwD0/wcAAAD9/wEAAAAAAA=='}

    assert connection._map_event(_event(dither)) == []  # pyright: ignore[reportPrivateUsage]
    assert not connection._response_open  # pyright: ignore[reportPrivateUsage]


def test_idle_audio_is_held_back_while_the_user_speaks() -> None:
    """An assistant frame ends the user's turn, so the idle track must not reach it mid-utterance.

    Otherwise each gap between the user's words arrives as model audio and one sentence is recorded
    as a turn per word.
    """
    connection = _connection()
    silence = {'type': 'session.output_audio.delta', 'delta': 'AAAAAAAAAAA='}
    voice = {'type': 'session.output_audio.delta', 'delta': 'f39/f39/f38='}
    words = {'type': 'session.input_transcript.delta', 'delta': 'and', 'start_ms': 0, 'end_ms': 1, 'event_id': 'e1'}

    connection._map_event(_event(voice))  # pyright: ignore[reportPrivateUsage]
    connection._map_event(_event(words))  # pyright: ignore[reportPrivateUsage]
    assert connection._map_event(_event(silence)) == []  # pyright: ignore[reportPrivateUsage]


def test_an_undecodable_audio_frame_is_a_recoverable_error() -> None:
    """Bad base64 in one frame must not take down the receive loop and, with it, the call."""
    connection = _connection()
    events = connection._map_frame(  # pyright: ignore[reportPrivateUsage]
        json.dumps({'type': 'session.output_audio.delta', 'delta': 'A', 'event_id': 'e'})
    )

    assert len(events) == 1
    error = events[0]
    assert isinstance(error, RealtimeSessionErrorEvent)
    assert error.recoverable is True
    assert error.message.startswith('Failed to parse OpenAI GPT-Live event:')


def test_output_transcript_closes_the_user_turn() -> None:
    """Live marks neither turn as finished, so the model replying is what ends the user's."""
    connection = _connection()
    assert connection._map_event(  # pyright: ignore[reportPrivateUsage]
        _event(
            {'type': 'session.input_transcript.delta', 'delta': 'hello', 'start_ms': 0, 'end_ms': 1, 'event_id': 'e1'}
        )
    ) == [InputTranscript('hello')]

    events = connection._map_event(  # pyright: ignore[reportPrivateUsage]
        _event({'type': 'session.output_transcript.delta', 'delta': 'hi', 'start_ms': 1, 'end_ms': 2, 'event_id': 'e2'})
    )
    assert events == [InputTranscript('', is_final=True), OutputTranscript('hi')]


def test_client_delegation_surfaces_a_recoverable_error() -> None:
    """A session in client-delegation mode would stall silently; say so instead."""
    connection = _connection()
    events = connection._map_event(  # pyright: ignore[reportPrivateUsage]
        _event(
            {
                'type': 'session.delegation.created',
                'event_id': 'e1',
                'offset_ms': 10,
                'delegation': {'id': 'd1', 'type': 'delegation', 'target': 'client'},
            }
        )
    )
    assert len(events) == 1
    error = events[0]
    assert isinstance(error, RealtimeSessionErrorEvent)
    assert error.code == 'live_client_delegation'
    assert error.recoverable is True


def test_usage_is_reported_as_an_increment() -> None:
    """Live reports a cumulative total and says not to sum it; `RunUsage` adds what it is given."""
    connection = _connection()

    def usage(seconds: float) -> list[Any]:
        return connection._map_event(  # pyright: ignore[reportPrivateUsage]
            _event({'type': 'session.usage.updated', 'event_id': 'e', 'usage': {'seconds': seconds}})
        )

    assert usage(10.5) == [SessionUsage(_request_usage(10.5), response_scoped=False)]
    # The second report is a running total, so only the difference is new.
    assert usage(25.0) == [SessionUsage(_request_usage(14.5), response_scoped=False)]
    # A repeat of the same total adds nothing.
    assert usage(25.0) == []


def test_context_window_usage_ratio_is_passed_on_as_a_snapshot() -> None:
    """Live's `context_window.usage_ratio` is the fraction in use, reported as is rather than summed.

    It rides on the seconds report when there is one, and on its own when no more seconds were billed:
    it's a snapshot, which can go down once Live compacts, and a report without it says nothing.
    """
    connection = _connection()

    def usage(seconds: float, ratio: float | None) -> list[Any]:
        frame: dict[str, Any] = {'type': 'session.usage.updated', 'event_id': 'e', 'usage': {'seconds': seconds}}
        if ratio is not None:
            frame['context_window'] = {'usage_ratio': ratio}
        return connection._map_event(_event(frame))  # pyright: ignore[reportPrivateUsage]

    assert usage(10.0, 0.25) == [SessionUsage(_request_usage(10.0), response_scoped=False, context_window_used=0.25)]
    assert usage(10.0, 0.1) == [SessionUsage(RequestUsage(), response_scoped=False, context_window_used=0.1)]
    assert usage(12.0, None) == [SessionUsage(_request_usage(2.0), response_scoped=False)]


def _request_usage(seconds: float) -> Any:
    return RequestUsage(audio_seconds=seconds)


def test_audio_seconds_are_priced_as_the_live_model() -> None:
    """The seconds belong to no `ModelResponse`, so no response boundary prices them; the connection must.

    Without it `session.usage.cost` left out the call itself, and a `cost_limit` could never stop it.
    genai-prices ships `gpt-live-1` at $3 per audio hour; the snapshot here adds it in case the installed
    data predates it.
    """
    snapshot_data = get_snapshot()
    providers = [
        replace(
            provider,
            models=[
                ModelInfo(
                    id='gpt-live-1',
                    match=ClauseEquals(equals='gpt-live-1'),
                    name='GPT-Live 1',
                    prices=ModelPrice(audio_hours=Decimal('3')),
                ),
                *provider.models,
            ],
        )
        if provider.id == 'openai'
        else provider
        for provider in snapshot_data.providers
    ]
    set_custom_snapshot(DataSnapshot(providers=providers, from_auto_update=False))
    try:
        connection = _connection(model_name='gpt-live-1', provider_url='https://api.openai.com/v1')
        (reported,) = connection._map_event(  # pyright: ignore[reportPrivateUsage]
            _event({'type': 'session.usage.updated', 'event_id': 'e', 'usage': {'seconds': 36.0}})
        )
    finally:
        set_custom_snapshot(None)

    assert isinstance(reported, SessionUsage)
    assert reported.usage.audio_seconds == 36.0
    assert reported.usage.cost == snapshot(Decimal('0.03'))


async def test_text_turn_runs_the_backend_and_context_is_thinking() -> None:
    """Live has no user-message event: a text turn is the backend's user message, which it is run on, and Live hears
    what was asked as silent context; text sent as context alone is only that."""
    sent: list[dict[str, Any]] = []

    class _Recorder(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)

    connection = _Recorder(object())  # pyright: ignore[reportArgumentType]
    await connection.send('What is the weather in London?')
    await connection.send(TextContext('Know this quietly.'))

    assert sent == snapshot(
        [
            {
                'type': 'session.thinking.append',
                'delegation_id': None,
                'content': 'The user typed: What is the weather in London?',
            },
            {
                'type': 'response.item.create',
                'item': {
                    'type': 'message',
                    'role': 'user',
                    'content': [{'type': 'input_text', 'text': 'What is the weather in London?'}],
                },
            },
            {'type': 'response.create', 'event_id': 'pydantic_ai.text.0'},
            {'type': 'session.thinking.append', 'delegation_id': None, 'content': 'Know this quietly.'},
        ]
    )


async def test_tool_result_continues_the_delegated_response() -> None:
    """A delegated response waiting on tool output does not resume on its own."""
    sent: list[dict[str, Any]] = []

    class _Recorder(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)

    connection = _Recorder(object())  # pyright: ignore[reportArgumentType]
    await connection.send(ToolResult('call_1', output='14C'))

    assert sent == snapshot(
        [
            {
                'type': 'response.item.create',
                'item': {'type': 'function_call_output', 'call_id': 'call_1', 'output': '14C'},
            },
            {'type': 'response.create'},
        ]
    )


def _backend_response(**overrides: Any) -> dict[str, Any]:
    """A Responses object as the delegated backend's lifecycle events carry it."""
    return {
        'id': 'resp_1',
        'object': 'response',
        'created_at': 0,
        'status': 'completed',
        'model': 'gpt-5.6-sol',
        'output': [],
        'parallel_tool_calls': True,
        'tool_choice': 'auto',
        'tools': [],
        **overrides,
    }


def _backend_terminal(nested_type: str = 'response.completed', **response: Any) -> dict[str, Any]:
    """A backend response's terminal event: `response.completed`, `.failed`, or `.incomplete`."""
    return {'type': nested_type, 'sequence_number': 0, 'response': _backend_response(**response)}


def _backend_call(call_id: str, name: str = 'weather', arguments: str = '{}') -> dict[str, Any]:
    """The backend asking for a tool call."""
    return {
        'type': 'response.output_item.done',
        'output_index': 0,
        'sequence_number': 0,
        'item': {'type': 'function_call', 'call_id': call_id, 'name': name, 'arguments': arguments},
    }


def _open_delegation(connection: OpenAILiveConnection, *, call_ids: tuple[str, ...] = ()) -> None:
    """Open a Responses delegation and have the backend ask for `call_ids`."""
    connection._map_event(  # pyright: ignore[reportPrivateUsage]
        _event(
            {
                'type': 'session.delegation.created',
                'event_id': 'e1',
                'offset_ms': 0,
                'delegation': {'id': 'd1', 'type': 'delegation', 'target': 'responses'},
            }
        )
    )
    for call_id in call_ids:
        connection._map_response_event(_backend_call(call_id), delegation_id='d1')  # pyright: ignore[reportPrivateUsage]


@pytest.mark.parametrize('nested_type', ['response.failed', 'response.incomplete'])
def test_a_backend_that_gives_up_releases_the_turn_clock(nested_type: str) -> None:
    """A delegation suspends the clock, so a backend that stops short has to close it too.

    Only `response.completed` used to clear the delegation, so a failed one left the map non-empty
    for the rest of the session and no turn could ever be reported complete again.
    """
    connection = _connection()
    _open_delegation(connection, call_ids=('c1',))
    assert connection._silence_timeout() is None  # pyright: ignore[reportPrivateUsage]

    connection._map_response_event(_backend_terminal(nested_type), delegation_id='d1')  # pyright: ignore[reportPrivateUsage]

    assert not connection._delegations  # pyright: ignore[reportPrivateUsage]
    # The clock runs again, so this turn — and every later one — can still end.
    assert connection._silence_timeout() is not None  # pyright: ignore[reportPrivateUsage]


async def test_a_result_for_an_abandoned_call_is_not_sent() -> None:
    """A tool that finishes after its backend gave up must not restart the backend."""
    sent: list[dict[str, Any]] = []

    class _Recorder(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)  # pragma: no cover

    connection = _Recorder(object())  # pyright: ignore[reportArgumentType]
    _open_delegation(connection, call_ids=('c1',))
    connection._map_response_event(_backend_terminal('response.failed'), delegation_id='d1')  # pyright: ignore[reportPrivateUsage]

    await connection.send(ToolResult('c1', output='too late'))

    assert sent == []


async def test_a_call_abandoned_while_its_media_downloads_is_not_sent(monkeypatch: pytest.MonkeyPatch) -> None:
    """Mapping media can wait on a download, and a backend that gives up meanwhile must still be honored."""
    sent: list[dict[str, Any]] = []

    class _Recorder(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)  # pragma: no cover

    connection = _Recorder(object())  # pyright: ignore[reportArgumentType]
    _open_delegation(connection, call_ids=('c1',))
    map_items = live_module._tool_result_follow_up  # pyright: ignore[reportPrivateUsage]

    async def downloading(result: ToolResult, *, provider_name: str) -> Any:
        # The backend gives up while the download is in flight.
        connection._map_response_event(_backend_terminal('response.failed'), delegation_id='d1')  # pyright: ignore[reportPrivateUsage]
        return await map_items(result, provider_name=provider_name)

    monkeypatch.setattr(live_module, '_tool_result_follow_up', downloading)
    image = BinaryContent(data=b'png', media_type='image/png')
    await connection.send(ToolResult('c1', output='too late', content=[image]))

    assert sent == []


@pytest.mark.parametrize('nested_type', ['response.completed', 'response.failed'])
def test_a_tool_calls_usage_always_arrives(nested_type: str) -> None:
    """Delegated calls wait for their response's usage, so its terminal must always report some.

    A backend that fails, or reports no usage, would otherwise leave the call's `ModelResponse` open
    and hold back queued messages for the rest of the session.
    """
    connection = _connection()
    _open_delegation(connection, call_ids=('c1',))

    events = connection._map_response_event(_backend_terminal(nested_type), delegation_id='d1')  # pyright: ignore[reportPrivateUsage]

    assert events[0] == SessionUsage(RequestUsage(unmeasured_requests=1))
    # Every backend response is reported exactly once, calls or not: each is a request the backend made.
    # A backend that gave up closed its delegation, so a later terminal isn't one of its responses.
    later = connection._map_response_event(_backend_terminal(nested_type), delegation_id='d1')  # pyright: ignore[reportPrivateUsage]
    expected = [SessionUsage(RequestUsage(unmeasured_requests=1))] if nested_type == 'response.completed' else []
    assert [event for event in later if isinstance(event, SessionUsage)] == expected


@pytest.mark.parametrize(
    ('nested', 'code', 'reason'),
    [
        (
            _backend_terminal('response.failed', status='failed', error={'code': 'server_error', 'message': 'boom'}),
            'live_delegation_failed',
            'server_error: boom',
        ),
        (
            _backend_terminal(
                'response.incomplete', status='incomplete', incomplete_details={'reason': 'max_output_tokens'}
            ),
            'live_delegation_incomplete',
            'incomplete: max_output_tokens',
        ),
        (_backend_terminal('response.failed', status='failed'), 'live_delegation_failed', 'response.failed'),
    ],
)
def test_a_backend_that_gives_up_is_reported(nested: dict[str, Any], code: str, reason: str) -> None:
    """Live keeps talking and the turn still ends, so the failure has to be said out loud.

    Otherwise the caller sees an ordinary turn boundary and no sign the delegated work was lost.
    """
    connection = _connection()
    _open_delegation(connection)

    events = connection._map_response_event(nested, delegation_id='d1')  # pyright: ignore[reportPrivateUsage]

    assert events == [
        # The terminal proves a request occurred even when its token usage is missing.
        SessionUsage(RequestUsage(unmeasured_requests=1)),
        RealtimeSessionErrorEvent(
            message=f'The delegated OpenAI Responses backend did not finish ({reason}).', code=code
        ),
    ]
    error = events[1]
    assert isinstance(error, RealtimeSessionErrorEvent) and error.recoverable is True


class _Recorder(OpenAILiveConnection):
    """A connection with no socket that records what it would send."""

    def __init__(self) -> None:
        super().__init__(object())  # pyright: ignore[reportArgumentType]
        self.sent: list[str] = []

    async def _send_event(self, event: dict[str, Any]) -> None:
        self.sent.append(event['type'])

    async def terminal(self, nested_type: str = 'response.completed') -> None:
        """The backend response ends; as the receive loop does, send any continuation now due."""
        self._map_response_event(_backend_terminal(nested_type), delegation_id='d1')
        await self._send_due_continuations()

    def call(self, call_id: str) -> None:
        self._map_response_event(_backend_call(call_id), delegation_id='d1')


async def test_parallel_tool_calls_continue_once_every_result_is_in() -> None:
    """The backend resumes from all of its outputs together, so the first result is not the cue."""
    connection = _Recorder()
    _open_delegation(connection, call_ids=('c1', 'c2'))

    await connection.send(ToolResult('c1', output='14C'))
    await connection.send(ToolResult('c2', output='rainy'))
    # Every result is in, but the response that asked for them hasn't ended: it could ask for more.
    assert connection.sent == ['response.item.create', 'response.item.create']

    await connection.terminal()
    assert connection.sent == snapshot(['response.item.create', 'response.item.create', 'response.create'])


async def test_a_result_before_the_next_call_does_not_continue_early() -> None:
    """A fast tool can answer before the backend's next parallel call has even arrived.

    Continuing as soon as every call *seen so far* was answered sent `response.create` with the second
    call still to come, then a second `response.create` once it was answered.
    """
    connection = _Recorder()
    _open_delegation(connection, call_ids=('c1',))
    await connection.send(ToolResult('c1', output='14C'))
    connection.call('c2')
    await connection.terminal()
    # The response has ended, but `c2` is still unanswered.
    assert connection.sent == ['response.item.create']

    await connection.send(ToolResult('c2', output='rainy'))
    assert connection.sent == snapshot(['response.item.create', 'response.item.create', 'response.create'])


async def test_a_late_completion_does_not_end_a_delegation_mid_continuation() -> None:
    """Answering before the asking response completes must not hand the turn back early."""
    connection = _Recorder()
    _open_delegation(connection, call_ids=('c1',))
    await connection.send(ToolResult('c1', output='14C'))

    # The response that *asked* for the tool ends only now, which is what sends the continuation.
    await connection.terminal()
    assert connection.sent == ['response.item.create', 'response.create']
    assert connection._delegations  # pyright: ignore[reportPrivateUsage]
    assert connection._silence_timeout() is None  # pyright: ignore[reportPrivateUsage]

    # The continuation itself is what ends the delegation.
    await connection.terminal()
    assert not connection._delegations  # pyright: ignore[reportPrivateUsage]


async def test_a_call_that_raised_gives_up_its_round() -> None:
    """The backend resumes only from every output of its round, so a call whose tool raised leaves none to continue.

    The round is given up as a failed backend would be: no `response.create`, a sibling's result goes nowhere, and the
    delegation no longer suspends the turn clock.
    """
    connection = _Recorder()
    _open_delegation(connection, call_ids=('c1', 'c2'))
    await connection.terminal()

    connection._tool_call_unanswered('c1')  # pyright: ignore[reportPrivateUsage]
    assert not connection._delegations  # pyright: ignore[reportPrivateUsage]
    assert connection._silence_timeout() is not None  # pyright: ignore[reportPrivateUsage]
    # Settled outside any provider message: no usage report follows, so a later one can't be taken for its settling.
    assert not connection._lifecycle._settles  # pyright: ignore[reportPrivateUsage]
    await connection.send(ToolResult('c2', output='rainy'))
    assert connection.sent == []


async def test_a_call_that_raised_while_its_response_runs_gives_up_the_round_at_its_terminal() -> None:
    """The response that asked for the calls may still be running: the round is given up once it ends."""
    connection = _Recorder()
    _open_delegation(connection, call_ids=('c1', 'c2'))
    await connection.send(ToolResult('c2', output='rainy'))
    connection._tool_call_unanswered('c1')  # pyright: ignore[reportPrivateUsage]
    assert connection._delegations  # pyright: ignore[reportPrivateUsage]

    await connection.terminal()
    assert connection.sent == ['response.item.create']
    assert not connection._delegations  # pyright: ignore[reportPrivateUsage]


def test_a_call_from_no_delegation_left_unanswered_changes_nothing() -> None:
    connection = _connection()
    _open_delegation(connection, call_ids=('c1',))
    connection._tool_call_unanswered('unknown')  # pyright: ignore[reportPrivateUsage]
    assert connection._delegations['d1'].pending_tool_calls == {'c1'}  # pyright: ignore[reportPrivateUsage]


async def test_tool_result_text_content_reaches_the_backend() -> None:
    """A `ToolReturn`'s text `content` goes to the backend as a message after the call's output."""
    sent: list[dict[str, Any]] = []

    class _Sink(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)

    connection = _Sink(object())  # pyright: ignore[reportArgumentType]
    await connection.send(ToolResult('c1', output='ok', content=['The user is a returning guest.']))

    assert sent == snapshot(
        [
            {'type': 'response.item.create', 'item': {'type': 'function_call_output', 'call_id': 'c1', 'output': 'ok'}},
            {
                'type': 'response.item.create',
                'item': {
                    'type': 'message',
                    'role': 'user',
                    'content': [{'type': 'input_text', 'text': 'The user is a returning guest.'}],
                },
            },
            {'type': 'response.create'},
        ]
    )


async def test_tool_result_text_content_types_reach_the_backend_as_text() -> None:
    """Typed text rides with plain text in the follow-up message; a cache point has no meaning here."""
    sent: list[dict[str, Any]] = []

    class _Sink(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)

    connection = _Sink(object())  # pyright: ignore[reportArgumentType]
    await connection.send(
        ToolResult('c1', output='ok', content=[TextContent(content='Returning guest.'), CachePoint()])
    )

    assert sent[1] == snapshot(
        {
            'type': 'response.item.create',
            'item': {
                'type': 'message',
                'role': 'user',
                'content': [{'type': 'input_text', 'text': 'Returning guest.'}],
            },
        }
    )


async def test_tool_result_media_follows_the_output_as_a_user_message() -> None:
    """Files a tool returns follow its output as a user message, as they do on the Realtime API.

    Each item keeps its place among the text. The per-item mapping is `OpenAIResponsesModel`'s, so a pinned
    payload is what catches it drifting: a cassette would still match.
    """
    sent: list[dict[str, Any]] = []

    class _Sink(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)

    connection = _Sink(object(), provider_name='openai')  # pyright: ignore[reportArgumentType]
    content: list[UserContent] = [
        'The photo:',
        BinaryContent(data=b'png', media_type='image/png'),
        TextContent(content='The invoice:'),
        BinaryContent(data=b'pdf', media_type='application/pdf'),
        CachePoint(),
        ImageUrl(url='https://example.com/kiwi.jpg'),
        DocumentUrl(url='https://example.com/terms.pdf'),
        UploadedFile(file_id='file-abc', provider_name='openai', media_type='image/png'),
    ]
    await connection.send(ToolResult('c1', output='See the attachments.', content=content))

    assert sent == snapshot(
        [
            {
                'type': 'response.item.create',
                'item': {'type': 'function_call_output', 'call_id': 'c1', 'output': 'See the attachments.'},
            },
            {
                'type': 'response.item.create',
                'item': {
                    'type': 'message',
                    'role': 'user',
                    'content': [
                        {'type': 'input_text', 'text': 'The photo:'},
                        {'image_url': 'data:image/png;base64,cG5n', 'type': 'input_image', 'detail': 'auto'},
                        {'type': 'input_text', 'text': 'The invoice:'},
                        {
                            'type': 'input_file',
                            'file_data': 'data:application/pdf;base64,cGRm',
                            'filename': 'filename.pdf',
                        },
                        {'image_url': 'https://example.com/kiwi.jpg', 'type': 'input_image', 'detail': 'auto'},
                        {'type': 'input_file', 'file_url': 'https://example.com/terms.pdf'},
                        {'type': 'input_image', 'file_id': 'file-abc', 'detail': 'auto'},
                    ],
                },
            },
            {'type': 'response.create'},
        ]
    )


@pytest.mark.parametrize(
    'item,match',
    [
        (AudioUrl(url='https://example.com/clip'), 'cannot send `AudioUrl` content'),
        (VideoUrl(url='https://example.com/clip'), 'cannot send `VideoUrl` content'),
        (BinaryContent(data=b'x', media_type='audio/wav'), 'cannot send `audio/wav` content'),
        (BinaryContent(data=b'x', media_type='video/mp4'), 'cannot send `video/mp4` content'),
        (DocumentUrl(url='https://example.com/clip.mp3'), 'cannot send a `audio/mpeg` `DocumentUrl`'),
        (
            DocumentUrl(url='https://example.com/clip', media_type='video/mp4'),
            'cannot send a `video/mp4` `DocumentUrl`',
        ),
        (UploadedFile(file_id='f', provider_name='openai', media_type='audio/wav'), 'uploaded `audio/wav` file'),
        (UploadedFile(file_id='f', provider_name='openai', media_type='video/mp4'), 'uploaded `video/mp4` file'),
        (UploadedFile(file_id='f', provider_name='anthropic'), "provider_name='anthropic'"),
    ],
)
async def test_tool_result_media_the_backend_cannot_read_is_refused(item: UserContent, match: str) -> None:
    """The backend takes text, images, and documents only, so anything else fails with nothing sent."""
    sent: list[dict[str, Any]] = []

    class _Recorder(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)  # pragma: no cover

    connection = _Recorder(object(), provider_name='openai')  # pyright: ignore[reportArgumentType]
    result = ToolResult(
        'c1', output='see this', content=['Here:', BinaryContent(data=b'x', media_type='image/png'), item]
    )

    with pytest.raises(UserError, match=match):
        await connection.send(result)

    assert sent == []


def _session_closed(reason: str, seconds: float = 0) -> dict[str, Any]:
    return {
        'type': 'session.closed',
        'event_id': 'e',
        'reason': reason,
        'session': {'id': 's', 'expires_at': 0, 'model': 'gpt-live-1', 'status': 'active'},
        'usage': {'seconds': seconds},
    }


@pytest.mark.parametrize('reason', ['expired', 'content', 'connection_lost'])
def test_a_session_ended_by_the_provider_interrupts_the_reply(reason: str) -> None:
    """The WebSocket close that follows is clean, so the reason is the only sign the reply was cut off.

    Settled on that close, a reply stopped by the safety filter or the duration limit read as finished.
    """
    connection = _connection()
    connection._map_frame(json.dumps({'type': 'session.output_audio.delta', 'delta': 'f39/f39/f38='}))  # pyright: ignore[reportPrivateUsage]

    events = connection._map_frame(json.dumps(_session_closed(reason)))  # pyright: ignore[reportPrivateUsage]

    assert events == [
        ResponseDone(interrupted=True),
        RealtimeSessionErrorEvent(
            message=f'The OpenAI GPT-Live session ended: {reason}.', code=f'live_session_{reason}', recoverable=False
        ),
    ]


@pytest.mark.parametrize('reason', ['close_requested', 'remote_hangup'])
def test_an_ordinary_close_only_reports_final_usage(reason: str) -> None:
    connection = _connection()
    connection._map_frame(json.dumps({'type': 'session.output_audio.delta', 'delta': 'f39/f39/f38='}))  # pyright: ignore[reportPrivateUsage]

    events = connection._map_frame(json.dumps(_session_closed(reason, seconds=12)))  # pyright: ignore[reportPrivateUsage]

    assert events == [SessionUsage(_request_usage(12), response_scoped=False)]


def test_a_backend_error_event_is_reported() -> None:
    """A nested Responses `error` is the backend's diagnostic; dropping it hid why delegated work failed."""
    connection = _connection()
    error = {
        'type': 'error',
        'sequence_number': 0,
        'code': 'rate_limit_exceeded',
        'message': 'slow down',
        'param': None,
    }

    assert connection._map_response_event(error, delegation_id='d1') == [  # pyright: ignore[reportPrivateUsage]
        RealtimeSessionErrorEvent(
            message='The delegated OpenAI Responses backend reported an error: slow down', code='rate_limit_exceeded'
        )
    ]


def test_an_error_with_no_code_is_still_reported() -> None:
    """OpenAI documents `error` frames with a null `code`, which the SDK's `ServerEvent` rejects."""
    connection = _connection()
    frame = {'type': 'error', 'event_id': 'e', 'error': {'type': 'server_error', 'code': None, 'message': 'boom'}}

    assert connection._map_frame(json.dumps(frame)) == [RealtimeSessionErrorEvent(message='boom', code=None)]  # pyright: ignore[reportPrivateUsage]


def test_unknown_events_are_ignored() -> None:
    """A future event type is not a reason to end a call in progress."""
    assert _connection()._map_frame('{"type": "session.something.new"}') == []  # pyright: ignore[reportPrivateUsage]


def test_events_the_connection_does_not_act_on_are_ignored_even_if_malformed() -> None:
    """An acknowledgement or notice changes nothing the session has said or heard, whatever its shape."""
    assert _connection()._map_frame('{"type": "session.thinking.appended"}') == []  # pyright: ignore[reportPrivateUsage]
    # A `type` that isn't a string names no event at all.
    assert _connection()._map_frame('{"type": []}') == []  # pyright: ignore[reportPrivateUsage]


@pytest.mark.parametrize(
    'frame',
    [
        pytest.param({'type': 'session.usage.updated', 'event_id': 'e', 'usage': {'seconds': 'many'}}, id='usage'),
        pytest.param({'type': 'session.delegation.created', 'event_id': 'e'}, id='delegation'),
        pytest.param({'type': 'response.event', 'event_id': 'e'}, id='backend-event'),
        pytest.param({'type': 'error', 'event_id': 'e', 'error': 'boom'}, id='error'),
        pytest.param({'type': 'session.closed', 'event_id': 'e'}, id='closed-without-reason'),
    ],
)
def test_a_malformed_event_the_connection_acts_on_is_a_recoverable_error(frame: dict[str, Any]) -> None:
    """Dropping it silently could lose the final usage, why the session ended, or delegated work."""
    (event,) = _connection()._map_frame(json.dumps(frame))  # pyright: ignore[reportPrivateUsage]

    assert isinstance(event, RealtimeSessionErrorEvent)
    assert event.recoverable is True
    assert event.message.startswith('Failed to parse OpenAI GPT-Live event:')
    assert frame['type'] in event.message


def test_a_frame_that_is_not_a_json_object_is_a_recoverable_error() -> None:
    (event,) = _connection()._map_frame('[1, 2]')  # pyright: ignore[reportPrivateUsage]

    assert isinstance(event, RealtimeSessionErrorEvent) and event.recoverable is True


def test_a_binary_frame_is_skipped() -> None:
    """Live sends only text frames, so a binary one is skipped, as on the Realtime connection."""
    assert _connection()._map_frame(b'{"type": "session.closed"}') == []  # pyright: ignore[reportPrivateUsage]


def test_a_drifted_session_closed_still_records_usage_and_why_it_ended() -> None:
    """`session.closed` is read for its usage and reason, so a change to its other fields loses neither."""
    connection = _connection()
    frame = {**_session_closed('expired', seconds=12), 'session': {'id': 's', 'shape': 'changed'}}

    events = connection._map_frame(json.dumps(frame))  # pyright: ignore[reportPrivateUsage]

    assert [type(event).__name__ for event in events] == snapshot(['SessionUsage', 'RealtimeSessionErrorEvent'])
    usage, error = events
    assert isinstance(usage, SessionUsage) and usage.usage.audio_seconds == 12
    assert isinstance(error, RealtimeSessionErrorEvent) and error.code == 'live_session_expired'


@pytest.mark.parametrize(
    'usage', [pytest.param({}, id='missing'), pytest.param({'usage': {'seconds': 'many'}}, id='drifted')]
)
def test_a_session_closed_whose_usage_drifted_still_ends_the_session_as_its_reason_says(
    usage: dict[str, Any],
) -> None:
    """Losing the usage is reported, but must not also cost the reason the session ended."""
    frame = {'type': 'session.closed', 'event_id': 'e', 'reason': 'expired', **usage}

    parse_error, ended = _connection()._map_frame(json.dumps(frame))  # pyright: ignore[reportPrivateUsage]

    assert isinstance(parse_error, RealtimeSessionErrorEvent) and parse_error.recoverable is True
    assert 'session.closed' in parse_error.message
    assert isinstance(ended, RealtimeSessionErrorEvent) and ended.code == 'live_session_expired'
    assert ended.recoverable is False


def test_a_session_closed_with_an_unknown_reason_is_an_abnormal_end() -> None:
    """Only a close someone asked for is ordinary; a reason this version doesn't know is not assumed to be."""
    events = _connection()._map_frame(json.dumps(_session_closed('server_error', seconds=3)))  # pyright: ignore[reportPrivateUsage]

    assert [type(event).__name__ for event in events] == snapshot(['SessionUsage', 'RealtimeSessionErrorEvent'])
    error = events[-1]
    assert isinstance(error, RealtimeSessionErrorEvent)
    assert error.code == 'live_session_server_error' and error.recoverable is False


async def test_agent_rejects_text_output(model: OpenAILiveModel) -> None:
    """Live only speaks, so asking it for text fails before the session opens."""
    agent = Agent(instructions='hi')
    with pytest.raises(UserError):
        async with agent.realtime(model, model_settings={'output_modality': 'text'}).session():
            pass  # pragma: no cover


async def test_agent_rejects_web_search_max_uses(model: OpenAILiveModel) -> None:
    """The backend's `web_search` tool has no usage limit, so `max_uses` can't be applied and the session doesn't open."""
    agent = Agent(capabilities=[NativeTool(WebSearchTool(max_uses=1))])
    with pytest.raises(UserError, match=r'`WebSearchTool.max_uses` not supported by this model'):
        async with agent.realtime(model).session():
            pass  # pragma: no cover


class _FakeWebSocket:
    """A socket that yields queued frames and then goes quiet, so the turn clock can run out.

    Like Live, it answers `session.close` with `session.closed`, reporting `closed_seconds` of usage.
    """

    def __init__(self, frames: list[str], *, delay: float = 0.0, closed_seconds: float = 0) -> None:
        self._frames = list(frames)
        self._delay = delay
        self._closed_seconds = closed_seconds
        self._arrived = asyncio.Event()
        self.sent: list[str] = []
        self.closed = False

    async def recv(self) -> str:
        while not self._frames:
            self._arrived.clear()
            await self._arrived.wait()
        if self._delay:
            await anyio.sleep(self._delay)
        return self._frames.pop(0)

    async def send(self, data: str) -> None:
        self.sent.append(data)
        if json.loads(data)['type'] == 'session.close':
            self._frames.append(json.dumps(_session_closed('close_requested', seconds=self._closed_seconds)))
            self._arrived.set()


def _transcript_frame(delta: str, *, speaker: str = 'output') -> str:
    return json.dumps(
        {'type': f'session.{speaker}_transcript.delta', 'delta': delta, 'start_ms': 0, 'end_ms': 1, 'event_id': 'e'}
    )


async def test_quiet_stretch_ends_the_turn() -> None:
    """Live sends no end-of-turn frame, so going quiet is what finishes the reply."""
    ws = _FakeWebSocket([_transcript_frame('hello there')])
    connection = OpenAILiveConnection(ws, turn_silence_ms=10)  # pyright: ignore[reportArgumentType]

    events: list[Any] = []
    with anyio.fail_after(5):
        async for event in connection:  # pragma: no branch
            events.append(event)
            if isinstance(event, ResponseDone):
                break

    assert events == [OutputTranscript('hello there'), ResponseDone()]


async def test_delegated_work_holds_the_turn_open() -> None:
    """The model goes quiet while the backend thinks; ending the turn there would truncate the reply."""
    delegation = json.dumps(
        {
            'type': 'session.delegation.created',
            'event_id': 'e1',
            'offset_ms': 0,
            'delegation': {'id': 'd1', 'type': 'delegation', 'target': 'responses'},
        }
    )
    ws = _FakeWebSocket([delegation])
    connection = OpenAILiveConnection(ws, turn_silence_ms=10)  # pyright: ignore[reportArgumentType]

    response_done = anyio.Event()

    async def drain() -> None:
        async for event in connection:  # pragma: no branch
            if isinstance(event, ResponseDone):  # pragma: no cover
                response_done.set()  # pragma: no cover
                return  # pragma: no cover

    async with anyio.create_task_group() as tg:
        tg.start_soon(drain)
        with anyio.fail_after(5):
            while not connection._delegations:  # pyright: ignore[reportPrivateUsage]
                await anyio.sleep(0)
        with anyio.move_on_after(0.2) as scope:
            await response_done.wait()
        assert scope.cancelled_caught
        await connection.aclose()
        tg.cancel_scope.cancel()

    # Once the backend reports it is finished, the clock restarts and the turn can end.
    assert connection._delegations  # pyright: ignore[reportPrivateUsage]
    connection._map_response_event(_backend_terminal(), delegation_id='d1')  # pyright: ignore[reportPrivateUsage]
    assert not connection._delegations  # pyright: ignore[reportPrivateUsage]


async def test_response_completed_without_a_delegation_is_ignored() -> None:
    """A nested event we can't correlate is not an error; Live says it may be uncorrelated."""
    connection = _connection()
    assert connection._map_response_event(_backend_terminal(), delegation_id=None) == []  # pyright: ignore[reportPrivateUsage]
    # An output item that isn't a function call is nothing to map.
    message: dict[str, Any] = {
        **_backend_call('c'),
        'item': {'type': 'message', 'id': 'm', 'role': 'assistant', 'status': 'completed', 'content': []},
    }
    assert connection._map_response_event(message, delegation_id=None) == []  # pyright: ignore[reportPrivateUsage]
    assert connection._map_response_event(_backend_call('c', name='n', arguments=''), delegation_id='missing')[  # pyright: ignore[reportPrivateUsage]
        -1
    ] == ToolCall('c', tool_name='n', args='{}', response_usage_follows=False)


def test_a_malformed_backend_event_is_a_recoverable_error() -> None:
    """A tool call missing its `call_id` must not take down the receive loop.

    Read with dict indexing, it raised a `KeyError`, which isn't the `ValueError` `_map_frame` reports
    as recoverable. Parsed through the SDK's types, it is a `ValidationError`, which is.
    """
    connection = _connection()
    _open_delegation(connection)
    frame = {
        'type': 'response.event',
        'event_id': 'e2',
        'delegation_id': 'd1',
        'event': {**_backend_call('c1'), 'item': {'type': 'function_call', 'name': 'weather', 'arguments': '{}'}},
    }

    events = connection._map_frame(json.dumps(frame))  # pyright: ignore[reportPrivateUsage]

    assert len(events) == 1
    error = events[0]
    assert isinstance(error, RealtimeSessionErrorEvent) and error.recoverable is True
    assert error.message.startswith('Failed to parse OpenAI GPT-Live event:')


def test_an_unknown_backend_event_type_is_ignored() -> None:
    """A nested event type this SDK doesn't know is not a reason to report anything."""
    connection = _connection()
    assert connection._map_response_event({'type': 'response.something_new'}, delegation_id=None) == []  # pyright: ignore[reportPrivateUsage]


async def test_aclose_cancels_the_pending_read() -> None:
    """Closing must not strand the read in flight, or its exception surfaces with no owner."""
    ws = _FakeWebSocket([])
    connection = OpenAILiveConnection(ws, turn_silence_ms=10)  # pyright: ignore[reportArgumentType]

    async def drain() -> None:
        async for _ in connection:
            pass  # pragma: no cover

    async with anyio.create_task_group() as tg:
        tg.start_soon(drain)
        await anyio.sleep(0.05)
        await connection.aclose()
        tg.cancel_scope.cancel()
    # A second close is a no-op rather than an error.
    await connection.aclose()


def test_error_events_keep_the_session_usable() -> None:
    connection = _connection()
    events = connection._map_event(  # pyright: ignore[reportPrivateUsage]
        _event(
            {
                'type': 'error',
                'event_id': 'e1',
                'error': {'type': 'invalid_request_error', 'code': 'bad_thing', 'message': 'nope'},
            }
        )
    )
    error = events[0]
    assert isinstance(error, RealtimeSessionErrorEvent)
    assert error == RealtimeSessionErrorEvent(message='nope', code='bad_thing')
    assert error.recoverable is True


def test_reconnect_does_not_restore_state() -> None:
    """A redialed Live session starts empty, so the session replays local history instead."""
    assert _connection().reconnect_restores_in_flight_state is False
    assert _connection().input_transcription_enabled is True


@pytest.mark.parametrize('tool_choice', ['required', ['kept'], ['kept', 'also_kept']])
def test_a_forced_tool_choice_raises(model: OpenAILiveModel, tool_choice: Any) -> None:
    """The backend applies the choice to every response, including the one after the tool results.

    So a forced call never lets a delegation answer: `'required'` looped on tool calls (seven in ten
    seconds, live) until a limit ended the session.
    """
    tools = [
        ToolDefinition(name='kept', parameters_json_schema={'type': 'object'}),
        ToolDefinition(name='also_kept', parameters_json_schema={'type': 'object'}),
    ]
    with pytest.raises(UserError, match='GPT-Live cannot force a tool call'):
        _config(model, tools=tools, settings=OpenAILiveModelSettings(tool_choice=tool_choice))


def test_a_tool_choice_that_lets_the_backend_answer_is_forwarded(model: OpenAILiveModel) -> None:
    """`'auto'`, `'none'`, and limiting the tools can't loop, so they reach the backend as before."""
    tools = [
        ToolDefinition(name='kept', parameters_json_schema={'type': 'object'}),
        ToolDefinition(name='dropped', parameters_json_schema={'type': 'object'}),
    ]

    def responses(tool_choice: Any) -> dict[str, Any]:
        config = _config(model, tools=tools, settings=OpenAILiveModelSettings(tool_choice=tool_choice))
        TypeAdapter(SessionConfig).validate_python(config)
        return config['delegation']['responses']

    auto = responses('auto')
    assert (auto['tool_choice'], [tool['name'] for tool in auto['tools']]) == ('auto', ['kept', 'dropped'])
    assert 'tools' not in responses('none')
    limited = responses(ToolOrOutput(function_tools=['kept']))
    assert (limited['tool_choice'], [tool['name'] for tool in limited['tools']]) == ('auto', ['kept'])
    # `None` asks for nothing, as if it were unset.
    assert 'tool_choice' not in responses(None)


def test_strict_tools_reach_the_backend(model: OpenAILiveModel) -> None:
    tool = ToolDefinition(name='lookup', parameters_json_schema={'type': 'object'}, strict=True)
    responses = _config(model, tools=[tool])['delegation']['responses']

    assert responses['tools'] == snapshot(
        [{'type': 'function', 'name': 'lookup', 'parameters': {'type': 'object'}, 'strict': True}]
    )
    # No tool choice is ever sent: the backend picks its tools, and a forced one never lets it answer.
    assert 'tool_choice' not in responses
    # With no agent instructions there is no backend prompt to send.
    assert 'instructions' not in responses


def test_web_search_reaches_the_backend(model: OpenAILiveModel) -> None:
    """`WebSearchTool` is advertised to the backend next to the function tools, with every option.

    Live accepts any `web_search` shape at session start and hands it to the backend unchecked (an
    unknown key only fails the first delegation), so the options are pinned here, where a drift would
    otherwise go unseen until a search behaved differently.
    """
    tool = ToolDefinition(name='lookup', parameters_json_schema={'type': 'object'})
    web_search = WebSearchTool(
        search_context_size='high',
        user_location={'city': 'Amsterdam', 'country': 'NL'},
        allowed_domains=['wikipedia.org'],
        blocked_domains=['example.com'],
        external_web_access=False,
    )
    responses = _config(model, tools=[tool], native_tools=[web_search])['delegation']['responses']

    assert responses['tools'] == snapshot(
        [
            {'type': 'function', 'name': 'lookup', 'parameters': {'type': 'object'}},
            {
                'type': 'web_search',
                'search_context_size': 'high',
                'user_location': {'type': 'approximate', 'city': 'Amsterdam', 'country': 'NL'},
                'filters': {'allowed_domains': ['wikipedia.org'], 'blocked_domains': ['example.com']},
                'external_web_access': False,
            },
        ]
    )
    # With no function tools, web search is the backend's only tool.
    assert _config(model, native_tools=[WebSearchTool()])['delegation']['responses']['tools'] == snapshot(
        [{'type': 'web_search', 'search_context_size': 'medium'}]
    )


def test_a_backend_web_search_is_recorded_as_native_tool_parts() -> None:
    """A finished `web_search_call` becomes the call and return parts a standard Responses run records."""
    connection = _connection()
    search = {
        'type': 'response.event',
        'event_id': 'e',
        'delegation_id': 'd1',
        'event': {
            'type': 'response.output_item.done',
            'sequence_number': 3,
            'output_index': 1,
            'item': {
                'id': 'ws_1',
                'type': 'web_search_call',
                'status': 'completed',
                'action': {'type': 'search', 'query': 'Amsterdam population', 'queries': ['Amsterdam population']},
            },
        },
    }
    connection._map_event(_event(_delegation_created('d1')))  # pyright: ignore[reportPrivateUsage]

    first = connection._map_event(_event(search))  # pyright: ignore[reportPrivateUsage]
    call = NativeToolCallPart(
        tool_name='web_search',
        args={'type': 'search', 'query': 'Amsterdam population', 'queries': ['Amsterdam population']},
        tool_call_id='ws_1',
        id='ws_1',
        provider_name='openai',
    )
    result = NativeToolReturnPart(
        tool_name='web_search',
        content={'status': 'completed'},
        tool_call_id='ws_1',
        timestamp=IsNow(tz=UTC),
        provider_name='openai',
    )
    assert first == [
        PartStartEvent(index=0, part=call),
        PartEndEvent(index=0, part=call),
        PartStartEvent(index=1, part=result),
        PartEndEvent(index=1, part=result),
    ]
    # A second search is numbered after the first, so its parts never replace the first's.
    second = connection._map_event(_event(search))  # pyright: ignore[reportPrivateUsage]
    assert [event.index for event in second if isinstance(event, PartStartEvent)] == [2, 3]


def _output_item_done(item: dict[str, Any], *, delegation_id: str = 'd1') -> dict[str, Any]:
    return {
        'type': 'response.event',
        'event_id': 'e',
        'delegation_id': delegation_id,
        'event': {'type': 'response.output_item.done', 'sequence_number': 1, 'output_index': 0, 'item': item},
    }


def _reasoning(item_id: str) -> dict[str, Any]:
    return {'id': item_id, 'type': 'reasoning', 'summary': [], 'encrypted_content': f'enc-{item_id}'}


_SEARCH_ITEM = {'id': 'ws_1', 'type': 'web_search_call', 'status': 'completed', 'action': {'type': 'search'}}


def test_a_search_is_recorded_with_the_reasoning_that_led_to_it() -> None:
    """OpenAI replays a search only with its reasoning item, so that is recorded with it, as a Responses run does.

    Reasoning that leads to anything else (a function call, the answer) isn't recorded: nothing needs it.
    """
    connection = _connection()
    connection._map_event(_event(_delegation_created('d1')))  # pyright: ignore[reportPrivateUsage]
    connection._map_event(_event(_delegation_created('d2')))  # pyright: ignore[reportPrivateUsage]

    def parts(frame: dict[str, Any]) -> list[str]:
        events = connection._map_event(_event(frame))  # pyright: ignore[reportPrivateUsage]
        return [
            f'{type(e.part).__name__}:{getattr(e.part, "id", None)}' for e in events if isinstance(e, PartStartEvent)
        ]

    # Reasoning waits for what it leads to.
    assert parts(_output_item_done(_reasoning('rs_1'))) == []
    # Another delegation's reasoning is its own.
    assert parts(_output_item_done(_reasoning('rs_other'), delegation_id='d2')) == []
    assert parts(_output_item_done(_SEARCH_ITEM)) == [
        'ThinkingPart:rs_1',
        'NativeToolCallPart:ws_1',
        'NativeToolReturnPart:None',
    ]
    # Reasoning before a function call or the answer is dropped when that arrives.
    parts(_output_item_done(_reasoning('rs_2')))
    call: dict[str, Any] = {'id': 'fc_1', 'type': 'function_call', 'call_id': 'c1', 'name': 'lookup', 'arguments': '{}'}
    connection._map_event(_event(_output_item_done(call)))  # pyright: ignore[reportPrivateUsage]
    assert parts(_output_item_done(_SEARCH_ITEM)) == ['NativeToolCallPart:ws_1', 'NativeToolReturnPart:None']
    parts(_output_item_done(_reasoning('rs_2b')))
    message: dict[str, Any] = {
        'id': 'msg_1',
        'type': 'message',
        'role': 'assistant',
        'status': 'completed',
        'content': [],
    }
    assert parts(_output_item_done(message)) == []
    assert parts(_output_item_done(_SEARCH_ITEM)) == ['NativeToolCallPart:ws_1', 'NativeToolReturnPart:None']
    # And so is reasoning a response ends with.
    parts(_output_item_done(_reasoning('rs_3')))
    connection._map_response_event(_backend_terminal('response.completed'), delegation_id='d1')  # pyright: ignore[reportPrivateUsage]
    assert parts(_output_item_done(_SEARCH_ITEM, delegation_id='d2')) == [
        'ThinkingPart:rs_other',
        'NativeToolCallPart:ws_1',
        'NativeToolReturnPart:None',
    ]


def _backend(model: OpenAILiveModel, **settings: Any) -> str:
    return _config(model, settings=OpenAILiveModelSettings(**settings))['delegation']['responses']['model']


def test_the_backend_model_can_follow_a_plus_in_the_model_name() -> None:
    """`'gpt-live-1+gpt-6-luna'` reads as the composite it is: a voice model and the model it delegates to."""
    model = infer_realtime_model('openai:gpt-live-1+gpt-6-luna')

    assert isinstance(model, OpenAILiveModel)
    assert model.model_name == 'gpt-live-1'
    assert _backend(model) == 'gpt-6-luna'


async def _session_backend(agent: Agent[None, Any], model: OpenAILiveModel) -> str:
    """Open a session through `agent.realtime()` and read the backend its `session.start` names."""
    started = json.dumps({'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}})
    ws = _FakeWebSocket([started])
    with _patched_connect(ws):
        async with agent.realtime(model).session():
            pass
    return json.loads(ws.sent[0])['session']['delegation']['responses']['model']


@pytest.mark.parametrize(
    ('agent_model', 'backend'),
    [
        ('openai:gpt-6-luna', 'gpt-6-luna'),
        ('openai-responses:gpt-6-luna', 'gpt-6-luna'),
        (None, AUTO_BACKEND_MODEL),
    ],
)
async def test_the_backend_defaults_to_the_agents_own_model(
    model: OpenAILiveModel, agent_model: str | None, backend: str
) -> None:
    """The backend runs the agent's instructions and tools; an OpenAI agent model already names it."""
    assert await _session_backend(Agent(agent_model), model) == backend


@pytest.mark.parametrize(
    ('agent_route', 'live_route', 'backend'),
    [
        ('direct', 'direct', 'gpt-6-luna'),
        ('gateway', 'gateway', 'gpt-6-luna'),
        # Reached a different way, the agent's model isn't one this session can delegate to.
        ('gateway', 'direct', AUTO_BACKEND_MODEL),
        ('direct', 'gateway', AUTO_BACKEND_MODEL),
    ],
)
async def test_the_agents_model_is_used_when_reached_the_same_way(
    agent_route: str, live_route: str, backend: str
) -> None:
    """`gateway/openai:gpt-live-1` on an agent built on `gateway/openai:gpt-6-luna` delegates to it.

    Both have to go to OpenAI the same way, directly or through the same gateway route, which is what
    comparing their base URLs checks.
    """

    def provider(route: str) -> Provider[AsyncOpenAI]:
        return gateway_provider('openai', api_key='pylf_v1_us_x') if route == 'gateway' else OpenAIProvider(api_key='x')

    agent = Agent(OpenAIResponsesModel('gpt-6-luna', provider=provider(agent_route)))
    live = OpenAILiveModel('gpt-live-1', provider=provider(live_route))
    assert await _session_backend(agent, live) == backend


async def test_an_agent_model_not_at_openai_is_not_a_backend(model: OpenAILiveModel) -> None:
    """An OpenAI-compatible server speaks the protocol, but isn't where the Live session runs."""
    compatible = OpenAIChatModel('llama3', provider=OpenAIProvider(api_key='x', base_url='http://localhost:11434/v1'))
    assert await _session_backend(Agent(compatible), model) == AUTO_BACKEND_MODEL


@pytest.mark.parametrize(
    ('agent_model', 'backend'),
    [
        ('openai:gpt-6-luna', 'gpt-6-luna'),
        ('openai-chat:gpt-6-luna', 'gpt-6-luna'),
        # Reached through the gateway, it isn't where this directly connected session runs.
        ('gateway/openai:gpt-6-luna', AUTO_BACKEND_MODEL),
        # Not an OpenAI model, so it is never resolved: that would need Anthropic's package and key.
        ('anthropic:claude-sonnet-5', AUTO_BACKEND_MODEL),
        ('test', AUTO_BACKEND_MODEL),
    ],
)
async def test_an_agent_model_named_but_not_yet_resolved_is_resolved_as_its_run_would(
    env: Any, agent_model: str, backend: str
) -> None:
    """With `defer_model_check=True` the agent's model is still a name when the session connects.

    Left unresolved, `Agent('openai:gpt-5.6-sol', defer_model_check=True)` delegated to `'auto'` rather
    than to the model it names.
    """
    env.set('OPENAI_API_KEY', 'test-key')
    env.set('PYDANTIC_AI_GATEWAY_API_KEY', 'pylf_v1_us_x')
    agent = Agent(agent_model, defer_model_check=True)
    assert await _session_backend(agent, OpenAILiveModel('gpt-live-1', provider='openai')) == backend


async def test_an_agent_model_that_cannot_be_resolved_is_not_a_backend(env: Any) -> None:
    """Resolving it is what the agent's own run would do; a name that fails there can't be a backend."""
    env.set('OPENAI_API_KEY', 'test-key')
    live = OpenAILiveModel('gpt-live-1', provider='openai')
    env.remove('OPENAI_API_KEY')
    agent = Agent('openai:gpt-6-luna', defer_model_check=True)
    assert await _session_backend(agent, live) == AUTO_BACKEND_MODEL


async def test_a_named_backend_takes_precedence_over_the_agents_model() -> None:
    """An explicit setting beats the name's `+`, which beats the agent's model, which beats `'auto'`."""
    agent = Agent('openai:gpt-5.6-sol')
    assert await _session_backend(agent, OpenAILiveModel('gpt-live-1+gpt-6-luna', provider='openai')) == 'gpt-6-luna'

    def delegating_to(backend: str) -> OpenAILiveModel:
        delegation = OpenAILiveResponsesDelegation(model=backend)
        return OpenAILiveModel(
            'gpt-live-1', provider='openai', settings=OpenAILiveModelSettings(openai_live_delegation=delegation)
        )

    assert await _session_backend(agent, delegating_to('gpt-6-luna')) == 'gpt-6-luna'
    assert await _session_backend(agent, delegating_to('auto')) == AUTO_BACKEND_MODEL


def test_a_connection_opened_without_an_agent_uses_auto(model: OpenAILiveModel) -> None:
    """Outside `agent.realtime()` there is no run context, and so no agent to consult."""
    assert _backend(model) == AUTO_BACKEND_MODEL


def test_16khz_audio_is_chosen_through_the_profile() -> None:
    """Live runs at 16 or 24 kHz, set the way the Realtime providers set their rate: on the profile."""
    model = OpenAILiveModel(
        'gpt-live-1',
        provider='openai',
        profile={'audio_input_sample_rate': 16000, 'audio_output_sample_rate': 16000},
    )
    config = _config(model)

    assert config['audio']['format'] == {'type': 'audio/pcm', 'rate': 16000}
    TypeAdapter(SessionConfig).validate_python(config)


@pytest.mark.parametrize(
    ('input_rate', 'output_rate'),
    [(16000, 24000), (8000, 8000), (48000, 48000)],
)
def test_an_audio_rate_live_cannot_run_raises(input_rate: int, output_rate: int) -> None:
    """One format covers both directions, so the two rates must agree, and be one Live accepts."""
    model = OpenAILiveModel(
        'gpt-live-1',
        provider='openai',
        profile={'audio_input_sample_rate': input_rate, 'audio_output_sample_rate': output_rate},
    )
    with pytest.raises(UserError, match='one PCM16 audio format for both directions'):
        _config(model)


def test_user_prompt_text_parts_are_joined() -> None:
    messages = [ModelRequest(parts=[UserPromptPart(content=['first', TextContent(content='second')])])]
    assert seed_input_items(messages, provider_name='openai') == snapshot(
        [{'role': 'user', 'content': [{'type': 'input_text', 'text': 'first\nsecond'}]}]
    )


async def test_handshake_timeout_is_a_typed_error(model: OpenAILiveModel) -> None:
    """A session that never starts fails predictably instead of hanging."""
    with _patched_connect(_FakeWebSocket([])):
        with pytest.raises(RealtimeError, match='timed out waiting'):
            async with model.connect(
                messages=[],
                model_settings=OpenAILiveModelSettings(handshake_timeout=0.05),
                model_request_parameters=ModelRequestParameters(),
            ):
                pass  # pragma: no cover


async def test_handshake_error_is_a_typed_error(model: OpenAILiveModel) -> None:
    """A rejected configuration arrives over the open socket, so it maps like a provider error."""
    rejection = json.dumps({'type': 'error', 'error': {'type': 'invalid_request_error', 'message': 'bad model'}})
    with _patched_connect(_FakeWebSocket([rejection])):
        with pytest.raises(RealtimeError, match='bad model'):
            async with model.connect(
                messages=[], model_settings=None, model_request_parameters=ModelRequestParameters()
            ):
                pass  # pragma: no cover


@contextmanager
def _patched_connect(ws: _FakeWebSocket) -> Any:
    """Stand in for `websockets.connect`, which returns an async context manager yielding the socket."""

    class _Opening:
        async def __aenter__(self) -> _FakeWebSocket:
            return ws

        async def __aexit__(self, *args: Any) -> None:
            ws.closed = True

    original = live_module.websockets.connect

    def _connect(*args: Any, **kwargs: Any) -> _Opening:
        return _Opening()

    live_module.websockets.connect = _connect
    try:
        yield
    finally:
        live_module.websockets.connect = original


async def test_a_new_turn_starts_after_the_previous_one_ended() -> None:
    """The reply clock restarts per turn: a later frame opens a new response, not a resumed one."""
    # The gap between frames has to clear the turn clock by a wide margin, or a loaded machine
    # delivers the second frame before the first turn expires and the test silently stops testing it.
    ws = _FakeWebSocket([_transcript_frame('first'), _transcript_frame('second')], delay=0.3)
    connection = OpenAILiveConnection(ws, turn_silence_ms=10)  # pyright: ignore[reportArgumentType]

    events: list[Any] = []
    with anyio.fail_after(5):
        async for event in connection:  # pragma: no branch
            events.append(event)
            if len(events) == 4:
                break

    assert events == [
        OutputTranscript('first'),
        ResponseDone(),
        OutputTranscript('second'),
        ResponseDone(),
    ]


async def test_a_user_turn_alone_is_finalized_when_the_model_stays_silent() -> None:
    """A spoken turn the model never answers must still land in history rather than hang open."""
    ws = _FakeWebSocket([_transcript_frame('are you there', speaker='input')])
    connection = OpenAILiveConnection(ws, turn_silence_ms=10)  # pyright: ignore[reportArgumentType]

    events: list[Any] = []
    with anyio.fail_after(5):
        async for event in connection:  # pragma: no branch
            events.append(event)
            if len(events) == 2:
                break

    # No `ResponseDone`: the model never replied, so there is no reply to finalize.
    assert events == [InputTranscript('are you there'), InputTranscript('', is_final=True)]


def test_seeding_skips_content_it_cannot_carry() -> None:
    """Empty transcripts and parts with no text equivalent are dropped, not sent as blanks."""
    messages = [
        ModelRequest(parts=[SpeechPart(speaker='user', transcript=None)]),
        ModelResponse(parts=[SpeechPart(speaker='assistant', transcript='   ')]),
        ModelRequest(parts=[UserPromptPart(content='kept')]),
    ]

    assert seed_input_items(messages, provider_name='openai') == snapshot(
        [{'role': 'user', 'content': [{'type': 'input_text', 'text': 'kept'}]}]
    )
    assert seed_input_items([ModelResponse(parts=[FilePart(content=None)])], provider_name='openai') == []  # pyright: ignore[reportArgumentType]


def test_seeding_keeps_a_failed_tool_round() -> None:
    """A retry carries the outcome of the call before it.

    Dropping it seeds the `ToolCallPart` as a call that was never answered, so the backend reads a
    round that failed as one that succeeded and does not try again. A legacy `RetryPromptPart` a
    caller built by hand seeds exactly like the part it is translated into.
    """
    messages = [
        ModelResponse(parts=[ToolCallPart(tool_name='weather', args={'city': 'Utrecht'}, tool_call_id='1')]),
        ModelRequest(
            parts=[ToolReturnPart(tool_name='weather', content='unknown city', tool_call_id='1', outcome='retried')]
        ),
        # Feedback that answers no call is output validation rather than a tool round.
        ModelRequest(parts=[RetryFeedbackPart(content='not a number', retry=RetryInfo(cause='model_retry'))]),
        ModelRequest(parts=[RetryFeedbackPart(content='not an int', retry=RetryInfo(cause='validation_error'))]),
        ModelResponse(parts=[ToolCallPart(tool_name='weather', args={'city': 'Delft'}, tool_call_id='2')]),
        ModelRequest(parts=[legacy_retry_prompt_part('still unknown', tool_name='weather', tool_call_id='2')]),
        ModelRequest(parts=[legacy_retry_prompt_part('still not a number')]),
    ]

    assert seed_input_items(messages, provider_name='openai') == snapshot(
        [
            {
                'role': 'assistant',
                'content': [{'type': 'output_text', 'text': 'Called `weather` with {"city":"Utrecht"}.'}],
            },
            {
                'role': 'user',
                'content': [{'type': 'input_text', 'text': 'Result of `weather`: {"error":"unknown city"}'}],
            },
            {
                'role': 'user',
                'content': [
                    {
                        'type': 'input_text',
                        'text': """\
Your previous response failed the application's validation (this is automated feedback, not a message from the user):
<retry_feedback>
not a number
</retry_feedback>\
""",
                    }
                ],
            },
            {
                'role': 'user',
                'content': [
                    {
                        'type': 'input_text',
                        'text': """\
Your previous response failed the application's validation (this is automated feedback, not a message from the user):
<validation_errors>
not an int
</validation_errors>\
""",
                    }
                ],
            },
            {
                'role': 'assistant',
                'content': [{'type': 'output_text', 'text': 'Called `weather` with {"city":"Delft"}.'}],
            },
            {
                'role': 'user',
                'content': [{'type': 'input_text', 'text': 'Result of `weather`: {"error":"still unknown"}'}],
            },
            {
                'role': 'user',
                'content': [
                    {
                        'type': 'input_text',
                        'text': """\
Your previous response failed the application's validation (this is automated feedback, not a message from the user):
<retry_feedback>
still not a number
</retry_feedback>\
""",
                    }
                ],
            },
        ]
    )


async def test_unrelated_frames_during_the_handshake_are_skipped(model: OpenAILiveModel) -> None:
    """A notice that arrives before `session.started` is not a protocol violation."""
    notice = json.dumps({'type': 'info', 'code': 'x', 'message': 'hello', 'event_id': 'e'})
    started = json.dumps({'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}})
    with _patched_connect(_FakeWebSocket([notice, started])):
        async with model.connect(
            messages=[], model_settings=None, model_request_parameters=ModelRequestParameters()
        ) as connection:
            assert connection.model_name == 'gpt-live-1'


@pytest.mark.parametrize('frame', ['not json at all', '["a list, not an object"]'])
async def test_a_malformed_handshake_frame_raises_a_realtime_error(model: OpenAILiveModel, frame: str) -> None:
    """The handshake promises a `RealtimeError`; a bad frame must not escape as a bare `ValueError`.

    `map_connect_errors` translates `RealtimeHandshakeError`, not the `ValueError` that parsing a
    malformed frame raises, so this only holds while the shared `expect_event` helper does the
    reading.
    """
    with _patched_connect(_FakeWebSocket([frame])):
        with pytest.raises(RealtimeError):
            async with model.connect(
                messages=[], model_settings=None, model_request_parameters=ModelRequestParameters()
            ):
                pass  # pragma: no cover


def test_session_config_matches_the_provider_schema(model: OpenAILiveModel) -> None:
    """What we build is validated against the SDK's own session shape.

    A cassette matcher can keep matching a recording after our payload drifts, so the wire shape is
    pinned against the provider's schema rather than only against a recorded conversation.
    """
    settings = OpenAILiveModelSettings(
        openai_voice='marin',
        openai_live_store=True,
        openai_live_delegation=OpenAILiveResponsesDelegation(model='gpt-5.6-sol', reasoning_effort='high'),
    )
    tool = ToolDefinition(name='lookup', parameters_json_schema={'type': 'object'}, strict=True)
    config = _config(
        model,
        instructions='Answer carefully.',
        tools=[tool],
        messages=[ModelRequest(parts=[UserPromptPart(content='hi')])],
        settings=settings,
    )

    validated = TypeAdapter(SessionConfig).validate_python(config)
    assert validated.model == 'gpt-live-1'
    assert validated.delegation is not None and validated.delegation.type == 'responses'


def test_delegated_backend_token_usage_is_accumulated() -> None:
    """Live meters audio by the second, but the backend it delegates to is billed per token.

    Most of a call's token cost lives in the backend, so dropping this would under-report the run.
    """
    connection = _connection()
    completed: dict[str, Any] = {
        'type': 'response.event',
        'event_id': 'e1',
        'delegation_id': 'd1',
        'event': {
            'type': 'response.completed',
            'sequence_number': 0,
            'response': {
                'id': 'resp_1',
                'object': 'response',
                'created_at': 0,
                'status': 'completed',
                'model': 'gpt-5.6-sol',
                'output': [],
                'parallel_tool_calls': True,
                'tool_choice': 'auto',
                'tools': [],
                'usage': {
                    'input_tokens': 805,
                    'input_tokens_details': {'cache_write_tokens': 805, 'cached_tokens': 0},
                    'output_tokens': 19,
                    'output_tokens_details': {'reasoning_tokens': 3},
                    'total_tokens': 824,
                },
            },
        },
    }

    events = connection._map_event(_event(completed))  # pyright: ignore[reportPrivateUsage]
    assert len(events) == 1
    reported = events[0]
    assert isinstance(reported, SessionUsage)
    assert reported.usage.input_tokens == 805
    assert reported.usage.output_tokens == 19
    # The cache and reasoning breakdowns survive, so cost accounting matches a direct Responses call.
    assert reported.usage.cache_write_tokens == 805
    assert reported.usage.details['reasoning_tokens'] == 3
    # The backend's request is what a per-request input-token limit is measured against.
    assert reported.response_scoped is True
    # Priced here, against the backend's own model. The response these tokens land on carries Live's
    # name, so anything pricing it from `model_name` downstream would use the wrong rate — and a cost
    # that is already set is never recalculated.
    assert reported.usage.cost is not None and reported.usage.cost > 0


def test_delegated_backend_usage_is_priced_at_its_reported_service_tier() -> None:
    """A backend that reports it served the request at `priority` is priced at priority rates."""

    def cost(service_tier: str) -> Decimal | None:
        usage = {
            'input_tokens': 1000,
            'input_tokens_details': {'cache_write_tokens': 0, 'cached_tokens': 0},
            'output_tokens': 100,
            'output_tokens_details': {'reasoning_tokens': 0},
            'total_tokens': 1100,
        }
        event = _backend_terminal(service_tier=service_tier, usage=usage)
        completed = {'type': 'response.event', 'event_id': 'e1', 'delegation_id': 'd1', 'event': event}
        [reported] = _connection()._map_event(_event(completed))  # pyright: ignore[reportPrivateUsage]
        assert isinstance(reported, SessionUsage)
        return reported.usage.cost

    standard, priority = cost('default'), cost('priority')
    assert standard is not None and priority is not None
    assert priority > standard


def test_unpriceable_backend_usage_is_still_accumulated() -> None:
    """A model genai-prices doesn't know leaves the cost unset; the tokens still count.

    Pricing must never cost us the usage itself, so `cost=None` has to stay distinguishable from a
    genuine zero rather than dropping the event.
    """
    connection = _connection()
    completed: dict[str, Any] = {
        'type': 'response.event',
        'event_id': 'e1',
        'delegation_id': 'd1',
        'event': {
            'type': 'response.completed',
            'sequence_number': 0,
            'response': {
                'id': 'resp_1',
                'object': 'response',
                'created_at': 0,
                'status': 'completed',
                'model': 'a-model-that-is-not-priced',
                'output': [],
                'parallel_tool_calls': True,
                'tool_choice': 'auto',
                'tools': [],
                'usage': {
                    'input_tokens': 11,
                    'input_tokens_details': {'cache_write_tokens': 0, 'cached_tokens': 0},
                    'output_tokens': 2,
                    'output_tokens_details': {'reasoning_tokens': 0},
                    'total_tokens': 13,
                },
            },
        },
    }

    events = connection._map_event(_event(completed))  # pyright: ignore[reportPrivateUsage]
    assert len(events) == 1
    reported = events[0]
    assert isinstance(reported, SessionUsage)
    assert reported.usage.input_tokens == 11
    assert reported.usage.cost is None


async def test_a_clean_close_finalizes_the_reply() -> None:
    """A graceful close ends the turn in flight rather than leaving it to settle as interrupted."""

    class _ClosingWebSocket(_FakeWebSocket):
        async def recv(self) -> str:
            if self._frames:
                return self._frames.pop(0)
            raise websockets.ConnectionClosedOK(Close(1000, ''), Close(1000, ''), True)

    connection = OpenAILiveConnection(_ClosingWebSocket([_transcript_frame('all done')]), turn_silence_ms=10_000)  # pyright: ignore[reportArgumentType]

    # Iterated to exhaustion, not broken out of: the stream ends itself when the socket closes.
    events = [event async for event in connection]
    assert events == [OutputTranscript('all done'), ResponseDone()]


# Recorded live: a backend with `max_output_tokens=16` ran out mid-handoff, and Live reported it with this
# top-level frame and no nested terminal for the delegation.
_HANDOFF_INCOMPLETE = {
    'type': 'error',
    'event_id': 'event_ERogN762PZ7dWVocvq7N2',
    'error': {
        'type': 'invalid_request_error',
        'code': 'invalid_request_error',
        'message': 'Responses handoff incomplete.',
        'param': None,
    },
}


def test_a_top_level_error_ends_the_delegation_it_interrupted() -> None:
    """Live can end a delegation with a top-level `error` and no nested terminal.

    The delegation stayed open, the turn clock stayed suspended, and the session never reported another
    turn boundary, while the idle track kept arriving for the rest of the call.
    """
    connection = _connection()
    _open_delegation(connection, call_ids=('c1',))
    # The call was answered and its continuation is running when the handoff fails.
    connection._call_delegations.pop('c1')  # pyright: ignore[reportPrivateUsage]
    connection._delegations['d1'].pending_tool_calls.clear()  # pyright: ignore[reportPrivateUsage]

    events = connection._map_frame(json.dumps(_HANDOFF_INCOMPLETE))  # pyright: ignore[reportPrivateUsage]

    assert events == [
        # The call's response waits for usage from a terminal that will never come.
        SessionUsage(RequestUsage(unmeasured_requests=1)),
        RealtimeSessionErrorEvent(
            message=(
                'The delegated OpenAI Responses backend did not finish '
                '(invalid_request_error: Responses handoff incomplete.).'
            ),
            code='live_delegation_failed',
        ),
    ]
    assert not connection._delegations  # pyright: ignore[reportPrivateUsage]
    assert connection._silence_timeout() is not None  # pyright: ignore[reportPrivateUsage]


async def test_a_turn_completes_after_a_failed_handoff() -> None:
    """End to end over a socket: the reply that promised a lookup still ends, and so does the next one."""
    delegation = {
        'type': 'session.delegation.created',
        'event_id': 'e1',
        'offset_ms': 0,
        'delegation': {'id': 'd1', 'type': 'delegation', 'target': 'responses'},
    }
    ws = _FakeWebSocket(
        [json.dumps(delegation), _transcript_frame("I'll check that for you."), json.dumps(_HANDOFF_INCOMPLETE)]
    )
    connection = OpenAILiveConnection(ws, turn_silence_ms=10)  # pyright: ignore[reportArgumentType]

    events: list[Any] = []
    with anyio.fail_after(5):
        async for event in connection:  # pragma: no branch
            events.append(event)
            if isinstance(event, ResponseDone):
                break

    assert [type(event).__name__ for event in events] == snapshot(
        ['OutputTranscript', 'SessionUsage', 'RealtimeSessionErrorEvent', 'ResponseDone']
    )


def test_an_error_leaves_a_delegation_waiting_on_its_tools_alone() -> None:
    """A delegation whose backend is waiting on our tool results has no response for the error to end."""
    connection = _connection()
    _open_delegation(connection, call_ids=('c1',))
    connection._map_response_event(_backend_terminal(), delegation_id='d1')  # pyright: ignore[reportPrivateUsage]

    events = connection._map_frame(json.dumps(_HANDOFF_INCOMPLETE))  # pyright: ignore[reportPrivateUsage]

    assert events == [RealtimeSessionErrorEvent(message='Responses handoff incomplete.', code='invalid_request_error')]
    assert 'd1' in connection._delegations  # pyright: ignore[reportPrivateUsage]


def test_an_unusable_backend_model_ends_the_session() -> None:
    """Live accepts any backend name at startup and fails each delegation on it, so fail once, clearly."""
    connection = _connection(backend_model='gpt-nonexistent-9')
    # Recorded live, when the first question was delegated.
    frame = {
        'type': 'error',
        'event_id': 'event_ERofKUO3MvYbjfL96XoLB',
        'error': {
            'type': 'invalid_request_error',
            'code': 'invalid_request_error',
            'message': 'The model `gpt-nonexistent-9` does not exist or you do not have access to it.',
            'param': None,
        },
    }

    events = connection._map_frame(json.dumps(frame))  # pyright: ignore[reportPrivateUsage]

    assert events == snapshot(
        [
            RealtimeSessionErrorEvent(
                message="The OpenAI GPT-Live session cannot delegate to its backend model 'gpt-nonexistent-9': The model `gpt-nonexistent-9` does not exist or you do not have access to it. Name a Responses model this account can use in `openai_live_delegation={'model': ...}`.",
                code='live_backend_model_unavailable',
                recoverable=False,
            )
        ]
    )


def _text_of(tokens: int) -> str:
    """Text that is exactly `tokens` tokens long in the tokenizer Live counts its cap in."""
    return ' '.join(['hello'] * tokens)


async def test_context_text_over_the_cap_is_refused_before_sending() -> None:
    """Live rejects context over 500 tokens with an error that arrives after `send()` has returned.

    By then the text was recorded as sent.
    """
    started = json.dumps({'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}})
    ws = _FakeWebSocket([started])
    with _patched_connect(ws):
        async with Agent().realtime(OpenAILiveModel('gpt-live-1', provider='openai')).session() as session:
            with pytest.raises(
                UserError,
                match=re.escape('at most 500 tokens of context per `send(..., respond=False)`, and this is 501'),
            ):
                await session.send(_text_of(501), respond=False)
            assert session.all_messages() == []
            # 500 is within the cap, and goes out.
            await session.send(_text_of(500), respond=False)

    assert [json.loads(frame)['type'] for frame in ws.sent[1:]] == ['session.thinking.append', 'session.close']


async def test_enqueued_system_prompt_is_the_operators_not_the_users() -> None:
    """`enqueue(SystemPromptPart(...))` still runs the backend, but isn't framed as something the user typed.

    Framed that way, Live later told the caller they had said it (checked live). Live hears it as context as it
    is, `<system>`-tagged, and the backend as a developer message.
    """
    started = json.dumps({'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}})
    ws = _FakeWebSocket([started])
    with _patched_connect(ws):
        async with Agent().realtime(OpenAILiveModel('gpt-live-1', provider='openai')).session() as session:
            session.enqueue(SystemPromptPart(content='The caller was verified as Jamie. Greet them by name.'))
            with anyio.fail_after(5):
                while not any(json.loads(frame)['type'] == 'response.create' for frame in ws.sent):
                    await anyio.sleep(0.01)
            messages = session.all_messages()

    assert [json.loads(frame) for frame in ws.sent[1:-1]] == snapshot(
        [
            {
                'type': 'session.thinking.append',
                'delegation_id': None,
                'content': '<system>The caller was verified as Jamie. Greet them by name.</system>',
            },
            {
                'type': 'response.item.create',
                'item': {
                    'type': 'message',
                    'role': 'developer',
                    'content': [
                        {
                            'type': 'input_text',
                            'text': '<system>The caller was verified as Jamie. Greet them by name.</system>',
                        }
                    ],
                },
            },
            {'type': 'response.create', 'event_id': 'pydantic_ai.text.0'},
        ]
    )
    # History records the text the session delivered, as for any enqueued system prompt.
    assert [
        type(part.content) for message in messages for part in message.parts if isinstance(part, UserPromptPart)
    ] == [str]


async def test_typed_turn_too_long_to_tell_live_still_runs_the_backend() -> None:
    """The backend takes typed text of any length; only the note telling Live what was typed is capped.

    A typed turn whose note would be over Live's 500-token context cap goes to the backend without it.
    """
    sent: list[dict[str, Any]] = []

    class _Recorder(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)

    connection = _Recorder(object())  # pyright: ignore[reportArgumentType]
    # 496 tokens fit alongside the note that introduces them; 497 don't.
    await connection.send(_text_of(496))
    await connection.send(_text_of(497))

    assert [event['type'] for event in sent] == snapshot(
        [
            'session.thinking.append',
            'response.item.create',
            'response.create',
            'response.item.create',
            'response.create',
        ]
    )
    assert sent[3]['item']['content'] == [{'type': 'input_text', 'text': _text_of(497)}]


def test_a_new_transcript_segment_is_spaced_from_the_last() -> None:
    """A segment's first fragment carries no leading space, so sentences ran together (`'up.It's'`)."""
    connection = _connection()

    def fragment(delta: str, speaker: str = 'output') -> list[Any]:
        return connection._map_event(  # pyright: ignore[reportPrivateUsage]
            _event(
                {
                    'type': f'session.{speaker}_transcript.delta',
                    'delta': delta,
                    'start_ms': 0,
                    'end_ms': 1,
                    'event_id': 'e',
                }
            )
        )

    # Recorded live.
    assert fragment(' look it up.') == [OutputTranscript(' look it up.')]
    assert fragment("It's") == [OutputTranscript(" It's")]
    # A fragment that continues a word or a number is left alone.
    assert fragment('3.') == [OutputTranscript('3.')]
    assert fragment('5') == [OutputTranscript('5')]
    # Each direction has its own segments.
    assert fragment('Sorry', speaker='input')[-1] == InputTranscript('Sorry')


def _audio_frame(pcm: bytes) -> _ActedOnEvent:
    return _event({'type': 'session.output_audio.delta', 'delta': base64.b64encode(pcm).decode()})


def test_a_quiet_stretch_after_speech_is_forwarded_only_as_a_pause() -> None:
    """Live's track never stops, so forwarding every quiet frame of a reply ended each with seconds of silence.

    The pause is measured by how much audio it is, not by when it arrives: a stalled network delivers
    seconds of buffered quiet at once, and a stalled event loop reads a short pause late.
    """
    connection = _connection()
    voice = _audio_frame(b'\x00\x10' * 2400)
    quiet = _audio_frame(b'\x00' * 4800)  # 100 ms at 24 kHz

    connection._map_event(voice)  # pyright: ignore[reportPrivateUsage]
    forwarded = [bool(connection._map_event(quiet)) for _ in range(8)]  # pyright: ignore[reportPrivateUsage]
    assert forwarded == [True] * 5 + [False] * 3
    # Speech resuming is a pause after all, and the next one is measured from it.
    connection._map_event(voice)  # pyright: ignore[reportPrivateUsage]
    assert connection._map_event(quiet) != []  # pyright: ignore[reportPrivateUsage]
    # However the quiet is chunked, the same 500 ms of it is forwarded: a chunk crossing the allowance
    # is cut at it, rather than dropped whole.
    connection._map_event(voice)  # pyright: ignore[reportPrivateUsage]
    (cut,) = connection._map_event(_audio_frame(b'\x00' * 28_800))  # pyright: ignore[reportPrivateUsage]  # 600 ms
    assert isinstance(cut, AudioDelta) and len(cut.data) == 24_000  # 500 ms
    assert connection._map_event(quiet) == []  # pyright: ignore[reportPrivateUsage]


def test_the_wait_after_a_delegated_call_is_not_spoken() -> None:
    """The quiet track after a tool call reached the session as an empty assistant `SpeechPart`."""
    connection = _connection()
    silence = _event({'type': 'session.output_audio.delta', 'delta': 'AAAAAAAAAAA='})
    voice = _event({'type': 'session.output_audio.delta', 'delta': 'f39/f39/f38='})

    connection._map_event(voice)  # pyright: ignore[reportPrivateUsage]
    _open_delegation(connection, call_ids=('c1',))

    assert connection._map_event(silence) == []  # pyright: ignore[reportPrivateUsage]


def _live_frames(*frames: dict[str, Any]) -> list[str]:
    started = {'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}}
    return [json.dumps(frame) for frame in (started, *frames)]


def _backend_completion(
    delegation_id: str, *, usage: dict[str, Any] | None = None, include_usage: bool = True
) -> dict[str, Any]:
    if include_usage and usage is None:
        usage = {
            'input_tokens': 10,
            'input_tokens_details': {'cache_write_tokens': 0, 'cached_tokens': 0},
            'output_tokens': 2,
            'output_tokens_details': {'reasoning_tokens': 0},
            'total_tokens': 12,
        }
    terminal = _backend_terminal(usage=usage) if include_usage else _backend_terminal()
    return {
        'type': 'response.event',
        'event_id': 'e',
        'delegation_id': delegation_id,
        'event': terminal,
    }


def _delegation_created(delegation_id: str) -> dict[str, Any]:
    return {
        'type': 'session.delegation.created',
        'event_id': 'e',
        'offset_ms': 0,
        'delegation': {'id': delegation_id, 'type': 'delegation', 'target': 'responses'},
    }


async def test_requests_count_backend_responses_not_spoken_replies() -> None:
    """Live's spoken replies are turns the session infers; the requests that spend tokens are the backend's.

    Counting each recorded response made `request_limit` a cap on how many times the model spoke.
    """
    ws = _FakeWebSocket(
        _live_frames(
            {
                'type': 'session.output_transcript.delta',
                'delta': 'Hi there.',
                'start_ms': 0,
                'end_ms': 1,
                'event_id': 'e',
            },
            _delegation_created('d1'),
            _backend_completion('d1'),
            {'type': 'session.output_transcript.delta', 'delta': 'Sunny.', 'start_ms': 2, 'end_ms': 3, 'event_id': 'e'},
        ),
        delay=0.05,
    )
    model = OpenAILiveModel(
        'gpt-live-1', provider='openai', settings=OpenAILiveModelSettings(openai_live_turn_silence_ms=10)
    )
    with _patched_connect(ws):
        async with Agent().realtime(model, usage_limits=UsageLimits(request_limit=1)).session() as session:
            with anyio.fail_after(5):
                async for event in session:  # pragma: no branch
                    if isinstance(event, RealtimeTurnCompleteEvent) and len(session.all_messages()) >= 2:
                        break

    responses = [message for message in session.all_messages() if isinstance(message, ModelResponse)]
    assert len(responses) == 2
    assert session.usage.requests == 1


async def test_audio_a_delegated_call_splits_from_its_words_is_not_recorded_as_speech() -> None:
    """Live's transcript runs ahead of its audio, so the end of a sentence can be heard after the call that cut it.

    That audio got a speech part of its own, which history recorded as an empty assistant `SpeechPart`: its words
    are in the speech before the call.
    """
    voice = {'type': 'session.output_audio.delta', 'delta': 'f39/f39/f38='}
    ws = _FakeWebSocket(
        _live_frames(
            _delegation_created('d1'),
            {
                'type': 'session.output_transcript.delta',
                'delta': 'Checking on that.',
                'start_ms': 0,
                'end_ms': 1,
                'event_id': 'e',
            },
            voice,
            {'type': 'response.event', 'event_id': 'e', 'delegation_id': 'd1', 'event': _backend_call('c1')},
            voice,
            _backend_completion('d1'),
        ),
        delay=0.05,
    )
    agent = Agent()

    @agent.tool_plain
    async def weather() -> str:
        return 'Sunny.'

    model = OpenAILiveModel(
        'gpt-live-1', provider='openai', settings=OpenAILiveModelSettings(openai_live_turn_silence_ms=10)
    )
    streamed: list[SpeechPart] = []
    with _patched_connect(ws):
        async with agent.realtime(model).session() as session:
            # Once the split-off audio streamed and the call was answered, closing the session ends the reply.
            answered = False
            with anyio.fail_after(5):
                async for event in session:  # pragma: no branch
                    if isinstance(event, PartStartEvent) and isinstance(event.part, SpeechPart):
                        streamed.append(event.part)
                    answered = answered or isinstance(event, FunctionToolResultEvent)
                    if answered and len(streamed) == 2:
                        break

    # The audio was still streamed, for playback, as a part of its own.
    assert len(streamed) == 2
    calling, returned = session.all_messages()
    assert calling.parts == snapshot(
        [
            SpeechPart(speaker='assistant', transcript='Checking on that.'),
            ToolCallPart(tool_name='weather', args='{}', tool_call_id='c1'),
        ]
    )
    assert [type(part) for part in returned.parts] == [ToolReturnPart]


@pytest.mark.parametrize('reported_zero', [False, True], ids=['missing-usage', 'reported-zero'])
async def test_backend_missing_usage_survives_realtime_session(
    reported_zero: bool,
) -> None:
    """Only a terminal delegated response can report usage; omission must survive session accumulation."""
    zero_usage = {
        'input_tokens': 0,
        'input_tokens_details': {'cache_write_tokens': 0, 'cached_tokens': 0},
        'output_tokens': 0,
        'output_tokens_details': {'reasoning_tokens': 0},
        'total_tokens': 0,
    }
    intermediate = {
        'type': 'response.event',
        'event_id': 'e',
        'delegation_id': 'd1',
        'event': {
            'type': 'response.created',
            'sequence_number': 0,
            'response': _backend_response(status='in_progress'),
        },
    }
    ws = _FakeWebSocket(
        _live_frames(
            _delegation_created('d1'),
            intermediate,
            _backend_completion('d1', usage=zero_usage if reported_zero else None, include_usage=reported_zero),
            {'type': 'session.output_transcript.delta', 'delta': 'Done.', 'start_ms': 0, 'end_ms': 1, 'event_id': 'e'},
        )
    )
    realtime = Agent().realtime(
        OpenAILiveModel(
            'gpt-live-1',
            provider='openai',
            settings=OpenAILiveModelSettings(openai_live_turn_silence_ms=10),
        ),
        usage_limits=UsageLimits(input_tokens_limit=100, cost_limit=Decimal('1')),
    )

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('default', UsageLimitUnavailableWarning)
        with _patched_connect(ws):
            async with realtime.session() as session:
                with anyio.fail_after(5):
                    async for event in session:  # pragma: no branch
                        if isinstance(event, RealtimeTurnCompleteEvent):
                            break

    availability_warnings = [item for item in caught if issubclass(item.category, UsageLimitUnavailableWarning)]
    if reported_zero:
        assert availability_warnings == []
    else:
        assert len(availability_warnings) == 1
        assert all('Some responses omitted usage information' in str(item.message) for item in availability_warnings)
    assert session.usage.requests == 1
    assert session.usage.unmeasured_requests == int(not reported_zero)
    assert session.usage.input_tokens == 0
    assert session.usage.output_tokens == 0


@pytest.mark.parametrize(
    ('usage_limits', 'warning_expected'),
    [
        pytest.param(UsageLimits(input_tokens_limit=100), True, id='input-token-limit'),
        pytest.param(UsageLimits(cost_limit=Decimal('1')), True, id='cost-limit'),
        pytest.param(UsageLimits(request_limit=1), False, id='request-only-limit'),
    ],
)
async def test_failed_handoff_without_usage_is_unmeasured_in_realtime_session(
    usage_limits: UsageLimits, warning_expected: bool
) -> None:
    """An in-flight backend request that fails before usage arrives is counted as unmeasured."""
    ws = _FakeWebSocket(
        _live_frames(
            _delegation_created('d1'),
            {'type': 'session.output_transcript.delta', 'delta': 'Done.', 'start_ms': 0, 'end_ms': 1, 'event_id': 'e'},
            _HANDOFF_INCOMPLETE,
        )
    )
    realtime = Agent().realtime(
        OpenAILiveModel(
            'gpt-live-1',
            provider='openai',
            settings=OpenAILiveModelSettings(openai_live_turn_silence_ms=10),
        ),
        usage_limits=usage_limits,
    )

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('default', UsageLimitUnavailableWarning)
        with _patched_connect(ws):
            async with realtime.session() as session:
                with anyio.fail_after(5):
                    async for event in session:  # pragma: no branch
                        if isinstance(event, RealtimeTurnCompleteEvent):
                            break

    availability_warnings = [item for item in caught if issubclass(item.category, UsageLimitUnavailableWarning)]
    if warning_expected:
        assert len(availability_warnings) == 1
        assert all('Some responses omitted usage information' in str(item.message) for item in availability_warnings)
    else:
        assert availability_warnings == []
    responses = [message for message in session.all_messages() if isinstance(message, ModelResponse)]
    assert len(responses) == 1
    assert session.usage.requests == 1
    assert responses[0].usage.unmeasured_requests == 1
    assert session.usage.unmeasured_requests == 1
    assert session.usage.input_tokens == 0
    assert session.usage.output_tokens == 0


async def test_request_limit_is_checked_as_backend_responses_arrive() -> None:
    """The backend has already made a request by the time its usage arrives, so the one past the limit ends the session."""
    ws = _FakeWebSocket(
        _live_frames(
            _delegation_created('d1'),
            _backend_completion('d1'),
            _delegation_created('d2'),
            _backend_completion('d2'),
        )
    )
    realtime = Agent().realtime(
        OpenAILiveModel('gpt-live-1', provider='openai'), usage_limits=UsageLimits(request_limit=1)
    )
    sessions: list[RealtimeSession] = []
    with _patched_connect(ws):
        with pytest.raises(UsageLimitExceeded, match='request_limit of 1'):
            async with realtime.session() as session:
                sessions.append(session)
                with anyio.fail_after(5):
                    async for _ in session:
                        pass

    # The request past the limit had already run: it is recorded before the session ends, tokens and all.
    assert sessions[0].usage.requests == 2
    assert sessions[0].usage.input_tokens == 20
    # Priced too: the connection prices the backend's tokens as they arrive, so the cost includes both.
    one = RequestUsage(input_tokens=10, output_tokens=2)
    price = calc_price(one, 'gpt-5.6-sol', provider_id='openai').total_price
    assert sessions[0].usage.cost == 2 * price
    # And the response it landed on is settled into history carrying that cost when the session ends.
    responses = [message for message in sessions[0].all_messages() if isinstance(message, ModelResponse)]
    assert sum(response.usage.cost or 0 for response in responses) == 2 * price


async def test_a_backend_response_without_usage_is_still_a_request() -> None:
    """A backend response that fails before reporting usage was still a request the backend made."""
    failed = {
        'type': 'response.event',
        'event_id': 'e',
        'delegation_id': 'd1',
        'event': _backend_terminal('response.failed', status='failed'),
    }
    ws = _FakeWebSocket(_live_frames(_delegation_created('d1'), failed, _delegation_created('d2'), _HANDOFF_INCOMPLETE))
    with _patched_connect(ws):
        async with Agent().realtime(OpenAILiveModel('gpt-live-1', provider='openai')).session() as session:
            with anyio.fail_after(5):
                errors = 0
                async for event in session:  # pragma: no branch
                    errors += isinstance(event, RealtimeSessionErrorEvent)
                    if errors == 2:
                        break

    # One for the response that failed, one for the response the handoff error ended.
    assert session.usage.requests == 2


def test_closing_punctuation_after_the_reply_began_is_not_a_new_turn() -> None:
    """Live transcribes the user's closing punctuation after the model has started answering over it.

    Recorded live over an always-on microphone: `' Alice'` (ending at 2000 ms), then the reply's
    `' Hi Alice'`, then the user's `'.'` starting at 2000 ms. Opening a turn for it recorded a request
    holding nothing but the full stop.
    """
    connection = _connection()

    def fragment(delta: str, speaker: str, start_ms: int) -> list[Any]:
        return connection._map_event(  # pyright: ignore[reportPrivateUsage]
            _event(
                {
                    'type': f'session.{speaker}_transcript.delta',
                    'delta': delta,
                    'start_ms': start_ms,
                    'end_ms': start_ms + 200,
                    'event_id': 'e',
                }
            )
        )

    fragment(' Alice', 'input', 1800)
    assert fragment(' Hi Alice', 'output', 1800) == [
        InputTranscript('', is_final=True),
        OutputTranscript(' Hi Alice'),
    ]
    assert fragment('.', 'input', 2000) == []
    # Later on the timeline, a fragment of symbols is the user saying something new: a `'?'`, say.
    assert fragment('?', 'input', 4000) == [InputTranscript('?')]
    # Words while the model is talking are always the user's.
    fragment(' Sure', 'output', 4200)
    assert fragment(' Wait', 'input', 4200) == [InputTranscript(' Wait')]


def test_an_unrelated_error_leaves_delegated_work_running() -> None:
    """Only an error known to end a handoff settles the delegations in flight; the frame names none.

    Settling on any error abandoned work that went on to complete, and lost the calls it asked for.
    """
    connection = _connection()
    _open_delegation(connection)
    # Recorded live, for a context append over the cap.
    frame = {
        'type': 'error',
        'event_id': 'event_ERodY3WFXhnyRbzdG03oB',
        'error': {
            'type': 'invalid_request_error',
            'code': 'invalid_value',
            'message': 'Context append text must not exceed 500 tokens.',
            'param': 'content',
        },
    }

    events = connection._map_frame(json.dumps(frame))  # pyright: ignore[reportPrivateUsage]

    assert events == [
        RealtimeSessionErrorEvent(message='Context append text must not exceed 500 tokens.', code='invalid_value')
    ]
    assert 'd1' in connection._delegations  # pyright: ignore[reportPrivateUsage]


async def test_an_explicit_tool_choice_of_none_is_unset(model: OpenAILiveModel) -> None:
    """Settings shared across providers may say `tool_choice=None`, which asks for nothing."""
    started = json.dumps({'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}})
    with _patched_connect(_FakeWebSocket([started])):
        async with model.connect(
            messages=[],
            model_settings=OpenAILiveModelSettings(tool_choice=None),
            model_request_parameters=ModelRequestParameters(),
        ):
            pass


def test_transcript_spacing_does_not_carry_across_turns() -> None:
    """A segment boundary is only within a turn: the next reply or user turn starts as Live sent it."""
    connection = _connection()

    def fragment(delta: str, speaker: str) -> list[Any]:
        return connection._map_event(  # pyright: ignore[reportPrivateUsage]
            _event(
                {
                    'type': f'session.{speaker}_transcript.delta',
                    'delta': delta,
                    'start_ms': 0,
                    'end_ms': 1,
                    'event_id': 'e',
                }
            )
        )

    fragment('Done.', 'output')
    fragment('Is it?', 'input')
    connection._settle_open_turns()  # pyright: ignore[reportPrivateUsage]

    assert fragment('Hello', 'output') == [OutputTranscript('Hello')]
    connection._settle_open_turns()  # pyright: ignore[reportPrivateUsage]
    assert fragment('Yes', 'input') == [InputTranscript('Yes')]


async def test_special_token_text_is_counted_as_live_counts_it() -> None:
    """tiktoken refuses special-token text such as `<|endoftext|>` by default, which raised its own error.

    Live counts it as the single token it is (checked live: 499 words plus it are accepted, 500 refused).
    """
    sent: list[dict[str, Any]] = []

    class _Recorder(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)

    connection = _Recorder(object())  # pyright: ignore[reportArgumentType]
    await connection.send(TextContext(_text_of(499) + '<|endoftext|>'))
    with pytest.raises(UserError, match='and this is 501'):
        await connection.send(TextContext(_text_of(500) + '<|endoftext|>'))
    assert len(sent) == 1


# --- idle audio -------------------------------------------------------------------------------------

#: A generous bound on waiting for something the test has set in motion, so a loaded runner doesn't flake.
READINESS_WAIT_TIMEOUT = 10


class _AudioSink(OpenAILiveConnection):
    """A connection that records the events it sends, and says when the first frame of silence goes out."""

    def __init__(self) -> None:
        super().__init__(object())  # pyright: ignore[reportArgumentType]
        self.sent: list[dict[str, Any]] = []
        self.silence_sent = anyio.Event()

    async def _send_event(self, event: dict[str, Any]) -> None:
        self.sent.append(event)
        if event['type'] == 'session.input_audio.append' and not any(base64.b64decode(event['audio'])):
            self.silence_sent.set()


def test_idle_frames_follow_a_quiet_gap_at_a_microphones_pace(monkeypatch: pytest.MonkeyPatch) -> None:
    """The first frame of silence waits out the gap after the application's audio; the rest follow every 100 ms.

    The timing is pinned on a fixed clock: `test_the_idle_pump_streams_silence_until_closed` runs the real one.
    """
    clock = [10.0]
    monkeypatch.setattr(live_module, '_pump_clock', lambda: clock[0])
    connection = _connection()
    connection._input_audio_end = 10.0  # pyright: ignore[reportPrivateUsage]

    assert connection._idle_frame_due() == pytest.approx(10.3)  # pyright: ignore[reportPrivateUsage]
    connection._next_idle_frame = 10.3 + 0.1  # pyright: ignore[reportPrivateUsage]
    assert connection._idle_frame_due() == pytest.approx(10.4)  # pyright: ignore[reportPrivateUsage]


async def test_application_audio_pushes_the_next_idle_frame_back(monkeypatch: pytest.MonkeyPatch) -> None:
    """While the application streams audio, the pump stays quiet; it picks up again once that audio stops."""
    clock = [5.0]
    monkeypatch.setattr(live_module, '_pump_clock', lambda: clock[0])
    connection = _AudioSink()
    connection._next_idle_frame = 5.1  # pyright: ignore[reportPrivateUsage]

    await connection.send(BinaryAudio(data=b'\x01\x00' * 10, media_type='audio/pcm'))

    # The quiet gap starts where the application's audio ends on Live's timeline: 10 samples after now.
    assert connection._idle_frame_due() == pytest.approx(5.3 + 10 / 24000)  # pyright: ignore[reportPrivateUsage]
    # Due already, so the wait returns at once and books the next frame a microphone frame later.
    clock[0] = 5.3 + 10 / 24000
    await connection._wait_for_idle_frame()  # pyright: ignore[reportPrivateUsage]
    assert connection._idle_frame_due() == pytest.approx(5.4 + 10 / 24000)  # pyright: ignore[reportPrivateUsage]


async def test_audio_sent_in_a_burst_holds_the_pump_back_until_it_has_played(monkeypatch: pytest.MonkeyPatch) -> None:
    """A long chunk, or a whole clip sent at once, plays on Live's timeline for as long as it lasts.

    Timing the gap from the send would splice silence into the middle of the user's speech.
    """
    clock = [5.0]
    monkeypatch.setattr(live_module, '_pump_clock', lambda: clock[0])
    connection = _AudioSink()

    # Two 400 ms chunks sent back to back: 800 ms of speech, ending at 5.8.
    for _ in range(2):
        await connection.send(BinaryAudio(data=bytes(9600 * 2), media_type='audio/pcm'))
    assert connection._idle_frame_due() == pytest.approx(5.8 + 0.3)  # pyright: ignore[reportPrivateUsage]
    # A chunk sent after the previous audio has played starts from now, not from where that audio ended.
    clock[0] = 7.0
    await connection.send(BinaryAudio(data=bytes(4800), media_type='audio/pcm'))
    assert connection._idle_frame_due() == pytest.approx(7.1 + 0.3)  # pyright: ignore[reportPrivateUsage]


async def test_a_failed_idle_pump_ends_the_session_loudly(monkeypatch: pytest.MonkeyPatch) -> None:
    """A pump that died of anything but the socket going away would leave text deferred forever, so it raises.

    The socket here stays quiet, so it is the pump's failure itself that has to wake the read loop.
    """

    async def broken(self: OpenAILiveConnection) -> None:
        raise RuntimeError('pump broke')

    monkeypatch.setattr(OpenAILiveConnection, '_pump_idle_audio', broken)
    connection = OpenAILiveConnection(_FakeWebSocket([]), idle_audio=True)  # pyright: ignore[reportArgumentType]

    with anyio.fail_after(READINESS_WAIT_TIMEOUT), pytest.raises(RuntimeError, match='pump broke'):
        async for _ in connection:
            pass  # pragma: no cover
    await connection.aclose()


async def test_audio_sent_before_the_pump_starts_still_plays_out_first(monkeypatch: pytest.MonkeyPatch) -> None:
    clock = [5.0]
    monkeypatch.setattr(live_module, '_pump_clock', lambda: clock[0])
    connection = _AudioSink()
    await connection.send(BinaryAudio(data=bytes(48000), media_type='audio/pcm'))  # one second

    connection._start_idle_audio()  # pyright: ignore[reportPrivateUsage]
    assert connection._idle_frame_due() == pytest.approx(6.3)  # pyright: ignore[reportPrivateUsage]
    await connection.aclose()


async def test_the_idle_pump_streams_silence_until_closed() -> None:
    """Without application audio the pump streams 100 ms frames of silence, and closing the connection stops it."""
    connection = _AudioSink()
    connection._start_idle_audio()  # pyright: ignore[reportPrivateUsage]
    task = connection._idle_audio_task  # pyright: ignore[reportPrivateUsage]
    assert task is not None

    with anyio.fail_after(READINESS_WAIT_TIMEOUT):
        await connection.silence_sent.wait()
    await connection.aclose()

    assert task.done()
    # 100 ms of 24 kHz PCM16.
    assert len(base64.b64decode(connection.sent[0]['audio'])) == 4800


async def test_the_idle_pump_stops_when_the_socket_does() -> None:
    """A socket that has gone away ends the pump quietly: the read loop is what reports the close."""

    class _Closed(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            raise websockets.ConnectionClosedError(None, None)

    connection = _Closed(object())  # pyright: ignore[reportArgumentType]
    connection._start_idle_audio()  # pyright: ignore[reportPrivateUsage]
    task = connection._idle_audio_task  # pyright: ignore[reportPrivateUsage]
    assert task is not None

    with anyio.fail_after(READINESS_WAIT_TIMEOUT):
        await task
    await connection.aclose()


async def test_idle_audio_starts_only_when_asked_for(model: OpenAILiveModel) -> None:
    started = json.dumps({'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}})
    with _patched_connect(_FakeWebSocket([started])):
        async with model.connect(
            messages=[], model_settings=None, model_request_parameters=ModelRequestParameters()
        ) as connection:
            assert connection._idle_audio_task is None  # pyright: ignore[reportPrivateUsage]
    with _patched_connect(_FakeWebSocket([started])):
        async with model.connect(
            messages=[],
            model_settings=OpenAILiveModelSettings(openai_live_idle_audio=True),
            model_request_parameters=ModelRequestParameters(),
        ) as connection:
            # The pump starts with the connection's reading, as a session's does straight after connecting.
            events = connection.__aiter__()
            first = asyncio.ensure_future(events.__anext__())
            await asyncio.sleep(0)
            task = connection._idle_audio_task  # pyright: ignore[reportPrivateUsage]
            assert task is not None and not task.done()
            # Starting again is a no-op rather than a second pump.
            connection._start_idle_audio()  # pyright: ignore[reportPrivateUsage]
            assert connection._idle_audio_task is task  # pyright: ignore[reportPrivateUsage]
            first.cancel()
    assert task.done()


async def test_audio_sent_as_the_pump_wakes_holds_its_frame_back() -> None:
    """Application audio that lands between the pump's wait and its send wins: the pump waits again."""
    connection = _AudioSink()
    waits = 0

    async def wait_for_idle_frame() -> None:
        nonlocal waits
        waits += 1
        if waits == 1:
            await connection.send(BinaryAudio(data=b'\x01\x00' * 10, media_type='audio/pcm'))

    connection._wait_for_idle_frame = wait_for_idle_frame  # pyright: ignore[reportPrivateUsage]
    connection._start_idle_audio()  # pyright: ignore[reportPrivateUsage]
    with anyio.fail_after(READINESS_WAIT_TIMEOUT):
        await connection.silence_sent.wait()
    await connection.aclose()

    assert waits >= 2
    assert any(base64.b64decode(connection.sent[0]['audio']))


# --- browser WebRTC ---------------------------------------------------------------------------------


def _webrtc_model(
    handler: Any, *, settings: OpenAILiveModelSettings | None = None, profile: RealtimeModelProfileSpec | None = None
) -> OpenAILiveModel:
    """A Live model whose signaling request is served by `handler` instead of the network."""
    provider = OpenAIProvider(
        api_key='sk-test', http_client=httpx2.AsyncClient(transport=httpx2.MockTransport(handler))
    )
    return OpenAILiveModel('gpt-live-1', provider=provider, settings=settings, profile=profile)


def _created(session_id: str = 'live_test') -> httpx2.Response:
    return httpx2.Response(
        200, json={'session': {'id': session_id}, 'transport': {'type': 'webrtc', 'sdp': 'v=0\r\nanswer'}}
    )


async def test_answering_an_offer_starts_the_whole_session() -> None:
    """Live can't be reconfigured once started, so the offer carries the complete configuration.

    WebRTC negotiates the audio format, so none is sent, and the browser's data channel is closed.
    """
    sent: list[dict[str, Any]] = []

    def handler(request: httpx2.Request) -> httpx2.Response:
        assert request.url.path == '/v1/live/sessions'
        sent.append(json.loads(request.content))
        return _created()

    model = _webrtc_model(handler, settings=OpenAILiveModelSettings(openai_voice='cedar'))
    tool = ToolDefinition(name='lookup', parameters_json_schema={'type': 'object'})
    answer = await model.answer_webrtc_offer('v=0\r\noffer', instructions='You look things up.', tools=[tool])

    assert answer.sdp == 'v=0\r\nanswer'
    assert answer.session == WebRTCSession(provider_name='openai', session_id='live_test')
    assert sent == snapshot(
        [
            {
                'session': {
                    'model': 'gpt-live-1',
                    'instructions': 'You are a voice assistant. Keep replies short and conversational. When the user asks for something you cannot answer from this conversation alone, delegate the task and tell them you are looking it up.',
                    'audio': {'output': {'voice': 'cedar'}},
                    'delegation': {
                        'type': 'responses',
                        'responses': {
                            'model': AUTO_BACKEND_MODEL,
                            'instructions': 'You look things up.',
                            'tools': [{'type': 'function', 'name': 'lookup', 'parameters': {'type': 'object'}}],
                        },
                    },
                    'client': {'data_channel': {'allowed_client_events': [], 'allowed_server_events': []}},
                },
                'transport': {'type': 'webrtc', 'sdp': 'v=0\r\noffer'},
            }
        ]
    )


async def test_the_browsers_data_channel_can_be_opened() -> None:
    sent: list[dict[str, Any]] = []

    def handler(request: httpx2.Request) -> httpx2.Response:
        sent.append(json.loads(request.content))
        return _created()

    captions = OpenAILiveModelSettings(
        openai_live_data_channel={
            'allowed_client_events': [],
            'allowed_server_events': [{'type': 'session.output_transcript.delta'}],
        }
    )
    await _webrtc_model(handler).answer_webrtc_offer('v=0', model_settings=captions)

    session = sent[0]['session']
    assert session['client'] == {
        'data_channel': {
            'allowed_client_events': [],
            'allowed_server_events': [{'type': 'session.output_transcript.delta'}],
        }
    }
    # With no voice set there is nothing left to say about audio.
    assert 'audio' not in session


async def test_answering_an_offer_uses_the_agents_model_as_the_backend() -> None:
    """As when a WebSocket session connects, the backend defaults to the agent's own model."""
    sent: list[dict[str, Any]] = []

    def handler(request: httpx2.Request) -> httpx2.Response:
        sent.append(json.loads(request.content))
        return _created()

    agent = Agent(OpenAIResponsesModel('gpt-5.6-sol', provider=OpenAIProvider(api_key='sk-test')))
    await agent.realtime(_webrtc_model(handler)).answer_webrtc_offer('v=0')

    assert sent[0]['session']['delegation']['responses']['model'] == 'gpt-5.6-sol'


async def test_a_rejected_offer_is_an_http_error() -> None:
    def handler(request: httpx2.Request) -> httpx2.Response:
        return httpx2.Response(400, json={'error': {'message': 'bad sdp', 'type': 'invalid_request_error'}})

    with pytest.raises(ModelHTTPError) as exc_info:
        await _webrtc_model(handler).answer_webrtc_offer('v=0')
    assert exc_info.value.status_code == 400
    assert exc_info.value.model_name == 'gpt-live-1'


async def test_an_offer_ignores_the_profiles_sample_rates() -> None:
    """WebRTC negotiates the audio format, so a rate the WebSocket path would reject doesn't stop a call."""
    sent: list[dict[str, Any]] = []

    def handler(request: httpx2.Request) -> httpx2.Response:
        sent.append(json.loads(request.content))
        return _created()

    model = _webrtc_model(handler, profile={'audio_input_sample_rate': 48000, 'audio_output_sample_rate': 48000})
    await model.answer_webrtc_offer('v=0')

    assert 'audio' not in sent[0]['session']


async def test_unsupported_settings_raise_before_answering_an_offer() -> None:
    def handler(request: httpx2.Request) -> httpx2.Response:
        raise AssertionError('no HTTP request expected')  # pragma: no cover

    with pytest.raises(UserError, match='`max_tokens` cannot be set'):
        await _webrtc_model(handler).answer_webrtc_offer('v=0', model_settings=OpenAILiveModelSettings(max_tokens=10))


async def test_the_auto_transcription_default_can_be_set_explicitly() -> None:
    """Live always transcribes with its own model, which is what `'auto'` asks for.

    So settings shared across providers can spell out the default and start the same session as leaving
    it out; a pinned model still raises (`test_unsupported_settings_raise_before_connecting`).
    """
    sent: list[dict[str, Any]] = []

    def handler(request: httpx2.Request) -> httpx2.Response:
        sent.append(json.loads(request.content))
        return _created()

    model = _webrtc_model(handler)
    await model.answer_webrtc_offer('v=0')
    await model.answer_webrtc_offer('v=0', model_settings=OpenAILiveModelSettings(input_transcription_model='auto'))

    default, explicit_auto = sent
    assert explicit_auto == default


async def test_there_are_no_client_secrets(model: OpenAILiveModel) -> None:
    with pytest.raises(UserError, match=r'has no ephemeral client secrets.*answer_webrtc_offer'):
        await model.create_client_secret()


def test_the_sideband_attaches_to_the_session(model: OpenAILiveModel) -> None:
    assert model._sideband_url('live_u1/x') == snapshot(  # pyright: ignore[reportPrivateUsage]
        'wss://api.openai.com/v1/live/sessions/live_u1%2Fx/attach'
    )


def _started_frame(**session: Any) -> str:
    return json.dumps(
        {
            'type': 'session.started',
            'event_id': 'e',
            'session': {'id': 'live_test', 'expires_at': 0, 'model': 'gpt-live-1', 'status': 'active', **session},
        }
    )


async def test_the_sideband_runs_the_session_it_attaches_to(model: OpenAILiveModel) -> None:
    """The sideband sends nothing to set up: Live replays `session.started`, which names the backend."""
    ws = _FakeWebSocket(
        [_started_frame(delegation={'type': 'responses', 'responses': {'model': 'gpt-5.6-luna', 'tools': []}})]
    )
    with _patched_connect(ws):
        async with model.connect_webrtc(
            WebRTCSession(provider_name='openai', session_id='live_test'),
            messages=[],
            model_settings=None,
            model_request_parameters=ModelRequestParameters(),
        ) as connection:
            assert connection.model_name == 'gpt-live-1'
            assert connection._backend_model == 'gpt-5.6-luna'  # pyright: ignore[reportPrivateUsage]
            # The browser plays the call's audio, so the sideband's copy only drives the turn clock.
            assert connection._map_output_audio(b'\x7f\x7f' * 240) == []  # pyright: ignore[reportPrivateUsage]
            assert connection._response_open  # pyright: ignore[reportPrivateUsage]
            assert connection._map_output_audio(bytes(480)) == []  # pyright: ignore[reportPrivateUsage]
    assert ws.sent == []


async def test_a_sideband_on_a_client_delegated_session_has_no_backend(model: OpenAILiveModel) -> None:
    with _patched_connect(_FakeWebSocket([_started_frame(delegation={'type': 'client'})])):
        async with model.connect_webrtc(
            WebRTCSession(provider_name='openai', session_id='live_test'),
            messages=[],
            model_settings=None,
            model_request_parameters=ModelRequestParameters(),
        ) as connection:
            assert connection._backend_model is None  # pyright: ignore[reportPrivateUsage]


async def test_a_malformed_started_event_on_the_sideband_raises(model: OpenAILiveModel) -> None:
    with _patched_connect(_FakeWebSocket([json.dumps({'type': 'session.started', 'session': {}})])):
        with pytest.raises(RealtimeError, match=r'Malformed `session\.started`'):
            async with model.connect_webrtc(
                WebRTCSession(provider_name='openai', session_id='live_test'),
                messages=[],
                model_settings=None,
                model_request_parameters=ModelRequestParameters(),
            ):
                pass  # pragma: no cover


async def test_a_sideband_must_attach_through_the_same_provider(model: OpenAILiveModel) -> None:
    with pytest.raises(UserError, match="negotiated by provider 'azure'"):
        async with model.connect_webrtc(
            WebRTCSession(provider_name='azure', session_id='live_test'),
            messages=[],
            model_settings=None,
            model_request_parameters=ModelRequestParameters(),
        ):
            pass  # pragma: no cover


async def test_a_sideband_refuses_idle_audio(model: OpenAILiveModel) -> None:
    """The browser carries a WebRTC call's audio, so a sideband has none of its own to replace with silence."""
    with pytest.raises(UserError, match='`openai_live_idle_audio` cannot be set'):
        async with model.connect_webrtc(
            WebRTCSession(provider_name='openai', session_id='live_test'),
            messages=[],
            model_settings=OpenAILiveModelSettings(openai_live_idle_audio=True),
            model_request_parameters=ModelRequestParameters(),
        ):
            pass  # pragma: no cover


_HISTORY = [
    ModelRequest(parts=[UserPromptPart(content='My name is Ada.')]),
    ModelResponse(parts=[TextPart(content='Nice to meet you, Ada.')]),
]
_SEEDED_INPUT = [
    {'role': 'user', 'content': [{'type': 'input_text', 'text': 'My name is Ada.'}]},
    {'role': 'assistant', 'content': [{'type': 'output_text', 'text': 'Nice to meet you, Ada.'}]},
]


async def test_answering_an_offer_seeds_the_history() -> None:
    """Live takes history only when a session starts, which on a WebRTC call is the offer."""
    sent: list[dict[str, Any]] = []

    def handler(request: httpx2.Request) -> httpx2.Response:
        sent.append(json.loads(request.content))
        return _created()

    await _webrtc_model(handler).answer_webrtc_offer('v=0', message_history=_HISTORY)

    assert sent[0]['session']['input'] == _SEEDED_INPUT


async def test_a_sideband_opened_with_the_offers_history_seeds_nothing(model: OpenAILiveModel) -> None:
    """The history the offer seeded is already in the session Live replays, so the sideband adds nothing."""
    ws = _FakeWebSocket([_started_frame(input=_SEEDED_INPUT)])
    with _patched_connect(ws):
        async with model.connect_webrtc(
            WebRTCSession(provider_name='openai', session_id='live_test'),
            # The trailing request is the one the session adds for the instructions; it seeds nothing.
            messages=[*_HISTORY, ModelRequest(parts=[], instructions='Be brief.')],
            model_settings=None,
            model_request_parameters=ModelRequestParameters(),
        ):
            pass
    assert ws.sent == []


async def test_a_sideband_accepts_history_live_echoes_with_other_whitespace(model: OpenAILiveModel) -> None:
    """The check is that it is the same conversation, so whitespace Live might normalize doesn't fail a call."""
    echoed = [
        {'role': 'user', 'content': [{'type': 'input_text', 'text': 'My name  is\nAda.'}]},
        _SEEDED_INPUT[1],
    ]
    with _patched_connect(_FakeWebSocket([_started_frame(input=echoed)])):
        async with model.connect_webrtc(
            WebRTCSession(provider_name='openai', session_id='live_test'),
            messages=_HISTORY,
            model_settings=None,
            model_request_parameters=ModelRequestParameters(),
        ):
            pass


@pytest.mark.parametrize(
    ('started_input', 'sideband_history'),
    [
        pytest.param([], _HISTORY, id='offer-seeded-nothing'),
        pytest.param(_SEEDED_INPUT[:1], _HISTORY, id='offer-seeded-other-history'),
        # The other direction: the offer seeded history, and the sideband was opened without it.
        pytest.param(_SEEDED_INPUT, [], id='sideband-opened-without-the-offers-history'),
    ],
)
async def test_a_sideband_with_history_the_offer_did_not_seed_raises(
    model: OpenAILiveModel, started_input: list[dict[str, Any]], sideband_history: list[ModelMessage]
) -> None:
    """Live can't take history after the session starts, so the model would never see what history records."""
    with _patched_connect(_FakeWebSocket([_started_frame(input=started_input)])):
        with pytest.raises(UserError, match='must be opened with the same `message_history`'):
            async with model.connect_webrtc(
                WebRTCSession(provider_name='openai', session_id='live_test'),
                messages=sideband_history,
                model_settings=None,
                model_request_parameters=ModelRequestParameters(),
            ):
                pass  # pragma: no cover


async def test_closing_a_session_records_the_seconds_live_reports_as_it_ends(model: OpenAILiveModel) -> None:
    """Live reports its billed seconds only now and then, and last in `session.closed`, which `session.close` asks for.

    A short call gets no periodic report at all (checked live: six seconds of audio, none), so without
    this the call would record no seconds.
    """
    started = json.dumps({'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}})
    ws = _FakeWebSocket([started], closed_seconds=5)
    with _patched_connect(ws):
        async with Agent().realtime(model).session() as session:
            # The session reads the connection, so a read is in flight when it closes: `session.closed`
            # arrives on that read, which the closing connection picks up.
            reading = asyncio.ensure_future(anext(aiter(session)))
            await asyncio.sleep(0.01)
    reading.cancel()

    assert [json.loads(frame)['type'] for frame in ws.sent[1:]] == ['session.close']
    assert session.usage.audio_seconds == 5


async def test_final_usage_live_reported_before_the_session_stopped_reading_is_kept() -> None:
    """A session that stops reading between `session.closed` and taking its usage still gets that usage, once."""
    ws = _FakeWebSocket([])
    connection = _LiveSink(ws)
    connection._map_frame(json.dumps(_session_closed('expired', seconds=7)))  # pyright: ignore[reportPrivateUsage]

    assert [report.usage.audio_seconds for report in await _ended(connection)] == [7]
    assert await _ended(connection) == []
    # Live already ended the session, so there is nothing to ask it.
    assert ws.sent == []


async def test_final_usage_already_taken_is_not_returned_again() -> None:
    ws = _FakeWebSocket([json.dumps(_session_closed('close_requested', seconds=7))])
    connection = _LiveSink(ws)
    events = aiter(connection)
    assert isinstance(await anext(events), SessionUsage)

    assert await _ended(connection) == []
    assert ws.sent == []


async def _ended(connection: OpenAILiveConnection) -> list[SessionUsage]:
    return [report async for report in connection._end_session()]  # pyright: ignore[reportPrivateUsage]


class _LiveSink(OpenAILiveConnection):
    def __init__(self, ws: _FakeWebSocket) -> None:
        super().__init__(ws)  # pyright: ignore[reportArgumentType]


async def test_ending_the_session_stops_the_idle_pump_first() -> None:
    """Silence after `session.close` would only be billed, so the pump stops before it is sent."""
    ws = _FakeWebSocket([], closed_seconds=4)
    connection = OpenAILiveConnection(ws, idle_audio=True)  # pyright: ignore[reportArgumentType]
    connection._start_idle_audio()  # pyright: ignore[reportPrivateUsage]
    pump = connection._idle_audio_task  # pyright: ignore[reportPrivateUsage]
    assert pump is not None

    await _ended(connection)

    assert pump.done()
    assert [json.loads(frame)['type'] for frame in ws.sent][-1:] == ['session.close']
    await connection.aclose()


async def test_ending_the_session_reads_every_frame_until_session_closed() -> None:
    """Frames still arriving are handled as ever; only session-scoped usage is returned, the backend's has no reply left."""
    usage_frame = json.dumps({'type': 'session.usage.updated', 'event_id': 'e', 'usage': {'seconds': 3}})
    ws = _FakeWebSocket([usage_frame], closed_seconds=4)
    connection = _LiveSink(ws)

    reports = await _ended(connection)

    assert [report.usage.audio_seconds for report in reports] == [3, 1]
    # Only once: the provider session is over.
    assert await _ended(connection) == []
    assert len(ws.sent) == 1


async def test_ending_a_closed_connection_sends_nothing() -> None:
    ws = _FakeWebSocket([])
    connection = _LiveSink(ws)
    await connection.aclose()

    assert await _ended(connection) == []
    assert ws.sent == []


async def test_ending_the_session_stops_when_the_socket_closes() -> None:
    """A Live that closes the socket without `session.closed` leaves nothing more to read."""

    class _ClosingSocket(_FakeWebSocket):
        async def recv(self) -> str:
            raise websockets.ConnectionClosedOK(Close(1000, ''), Close(1000, ''), True)

    connection = _LiveSink(_ClosingSocket([]))

    assert await _ended(connection) == []


async def test_a_session_whose_socket_closed_is_not_asked_to_end_again() -> None:
    class _ClosingSocket(_FakeWebSocket):
        async def recv(self) -> str:
            raise websockets.ConnectionClosedOK(Close(1000, ''), Close(1000, ''), True)

    ws = _ClosingSocket([])
    connection = _LiveSink(ws)
    async for _ in connection:
        pass  # pragma: no cover

    assert await _ended(connection) == []
    assert ws.sent == []


async def test_backend_response_ending_as_the_session_ends_is_reported_as_a_request() -> None:
    """A backend response finishing during the drain has no reply left to land on, but it is still billed.

    Its report stays response-scoped: it was a request the backend made, which the session counts.
    """
    completed = {
        'type': 'response.event',
        'event_id': 'e1',
        'delegation_id': 'd1',
        'event': _backend_terminal(
            usage={
                'input_tokens': 10,
                'input_tokens_details': {'cache_write_tokens': 0, 'cached_tokens': 0},
                'output_tokens': 2,
                'output_tokens_details': {'reasoning_tokens': 0},
                'total_tokens': 12,
            }
        ),
    }
    ws = _FakeWebSocket([json.dumps(completed)], closed_seconds=4)

    reports = await _ended(_LiveSink(ws))

    assert [(report.usage.input_tokens, report.usage.audio_seconds, report.response_scoped) for report in reports] == [
        (10, 0, True),
        (0, 4, False),
    ]


@pytest.mark.parametrize(
    ('limits', 'exceeded'),
    [
        (UsageLimits(request_limit=0), True),
        (UsageLimits(per_request_input_tokens_limit=5), True),
        (UsageLimits(request_limit=1), False),
    ],
    ids=['request_limit', 'per_request_input_tokens_limit', 'within_limits'],
)
async def test_a_backend_request_reported_while_closing_is_held_to_the_request_limits(
    model: OpenAILiveModel, limits: UsageLimits, exceeded: bool
) -> None:
    """A backend response that ends as the session closes is a request like any other: one over a limit fails `close()`."""

    reading = asyncio.Event()

    class _BackendFinishingSocket(_FakeWebSocket):
        async def recv(self) -> str:
            if not self._frames:
                # The session is reading with nothing to read yet: waiting on the socket, as it is when it closes.
                reading.set()
            return await super().recv()

        async def send(self, data: str) -> None:
            if json.loads(data)['type'] == 'session.close':
                terminal = _backend_terminal(
                    usage={
                        'input_tokens': 10,
                        'input_tokens_details': {'cache_write_tokens': 0, 'cached_tokens': 0},
                        'output_tokens': 2,
                        'output_tokens_details': {'reasoning_tokens': 0},
                        'total_tokens': 12,
                    }
                )
                self._frames.append(
                    json.dumps({'type': 'response.event', 'event_id': 'e1', 'delegation_id': 'd1', 'event': terminal})
                )
            await super().send(data)

    started = json.dumps({'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}})
    ws = _BackendFinishingSocket([started], closed_seconds=1)
    sessions: list[RealtimeSession] = []
    readings: list[asyncio.Future[Any]] = []
    with _patched_connect(ws), pytest.raises(UsageLimitExceeded) if exceeded else nullcontext():
        async with Agent().realtime(model, usage_limits=limits).session() as session:
            sessions.append(session)
            readings.append(asyncio.ensure_future(anext(aiter(session))))
            await reading.wait()
    readings[0].cancel()
    assert (sessions[0].usage.requests, sessions[0].usage.input_tokens) == (1, 10)


async def test_closing_a_session_whose_socket_drops_finishes_promptly(model: OpenAILiveModel) -> None:
    """A link that fails while Live is asked to end the session leaves nothing to wait for."""

    class _DroppingSocket(_FakeWebSocket):
        async def send(self, data: str) -> None:
            self.sent.append(data)
            if json.loads(data)['type'] == 'session.close':
                self._frames.append('drop')
                self._arrived.set()

        async def recv(self) -> str:
            if (raw := await super().recv()) == 'drop':
                raise websockets.ConnectionClosedError(Close(1006, ''), None)
            return raw

    started = json.dumps({'type': 'session.started', 'event_id': 'e', 'session': {'id': 's', 'model': 'gpt-live-1'}})
    ws = _DroppingSocket([started])
    with _patched_connect(ws), anyio.fail_after(1):
        async with Agent().realtime(model).session() as session:
            reading = asyncio.ensure_future(anext(aiter(session)))
            await asyncio.sleep(0.01)
    reading.cancel()

    assert [json.loads(frame)['type'] for frame in ws.sent[1:]] == ['session.close']
    assert session.usage.audio_seconds == 0


async def test_a_session_that_expires_as_it_is_asked_to_end_still_reports_its_usage() -> None:
    ws = _FakeWebSocket([json.dumps(_session_closed('expired', seconds=3))])

    assert [report.usage.audio_seconds for report in await _ended(_LiveSink(ws))] == [3]


# --- reconnecting -----------------------------------------------------------------------------------


class _DroppingWebSocket(_FakeWebSocket):
    """A socket that delivers its frames, then drops the way a lost connection does."""

    async def recv(self) -> str:
        if self._frames:
            return self._frames.pop(0)
        raise websockets.ConnectionClosedError(None, None)


def _started(session_id: str, **session: Any) -> str:
    return json.dumps(
        {
            'type': 'session.started',
            'event_id': 'e',
            'session': {'id': session_id, 'expires_at': 0, 'model': 'gpt-live-1', 'status': 'active', **session},
        }
    )


@contextmanager
def _patched_dials(*sockets: _FakeWebSocket) -> Any:
    """Stand in for `websockets.connect`, answering each dial with the next socket and noting its URL."""
    urls: list[str] = []
    queue = list(sockets)

    class _Opening:
        def __init__(self, ws: _FakeWebSocket) -> None:
            self.ws = ws

        async def __aenter__(self) -> _FakeWebSocket:
            return self.ws

        async def __aexit__(self, *args: Any) -> None:
            self.ws.closed = True

    original = live_module.websockets.connect

    def _connect(url: str, **kwargs: Any) -> _Opening:
        urls.append(url)
        return _Opening(queue.pop(0))

    live_module.websockets.connect = _connect
    try:
        yield urls
    finally:
        live_module.websockets.connect = original


_RECONNECT = OpenAILiveModelSettings(reconnect={'base_delay': 0.0, 'jitter': False, 'max_attempts': 2})
_STORED_RECONNECT = OpenAILiveModelSettings(_RECONNECT, openai_live_store=True)


async def _first_events(connection: OpenAILiveConnection, count: int) -> list[Any]:
    events: list[Any] = []
    with anyio.fail_after(5):
        async for event in connection:  # pragma: no branch
            events.append(event)
            if len(events) == count:
                break
    return events


async def test_a_drop_without_a_reconnect_policy_still_ends_the_session(model: OpenAILiveModel) -> None:
    with _patched_dials(_DroppingWebSocket([_started('s1')])):
        async with model.connect(
            messages=[], model_settings=None, model_request_parameters=ModelRequestParameters()
        ) as connection:
            assert not connection._can_reconnect  # pyright: ignore[reportPrivateUsage]
            assert [event async for event in connection] == snapshot(
                [
                    RealtimeSessionErrorEvent(
                        message='OpenAI GPT-Live connection closed: no close frame received or sent', recoverable=False
                    )
                ]
            )


async def test_a_session_with_no_history_reconnects_to_an_unseeded_session(model: OpenAILiveModel) -> None:
    """Nothing to replay is not a reason to fail: the replacement just starts empty."""
    first, second = _DroppingWebSocket([_started('s1')]), _FakeWebSocket([_started('s2')])
    with _patched_dials(first, second) as urls:
        async with model.connect(
            messages=[], model_settings=_RECONNECT, model_request_parameters=ModelRequestParameters()
        ) as connection:
            assert connection._can_reconnect  # pyright: ignore[reportPrivateUsage]
            assert await _first_events(connection, 1) == [RealtimeSessionReconnectEvent(state_restored=False)]
    assert urls == ['wss://api.openai.com/v1/live/sessions'] * 2
    assert first.closed
    replacement = json.loads(second.sent[0])['session']
    assert 'input' not in replacement and replacement['model'] == 'gpt-live-1'


async def test_a_replacement_session_is_seeded_with_the_history_so_far(model: OpenAILiveModel) -> None:
    first, second = _DroppingWebSocket([_started('s1')]), _FakeWebSocket([_started('s2')])
    history = [
        ModelRequest(parts=[UserPromptPart(content=['Look at this:', BinaryImage(data=b'x', media_type='image/png')])])
    ]
    with _patched_dials(first, second):
        async with model.connect(
            messages=[], model_settings=_RECONNECT, model_request_parameters=ModelRequestParameters()
        ) as connection:
            connection.set_message_history(lambda: history)
            # Like gpt-realtime's replay, a replay of the offered history restores the call.
            assert await _first_events(connection, 1) == [RealtimeSessionReconnectEvent(state_restored=True)]
    # A replay has nothing to refuse: the image is left out rather than raising.
    assert json.loads(second.sent[0])['session']['input'] == [
        {'role': 'user', 'content': [{'type': 'input_text', 'text': 'Look at this:'}]}
    ]


async def test_a_stored_session_is_forked_from_the_latest_session(model: OpenAILiveModel) -> None:
    """Each fork is a new session, so the next drop forks that one."""
    sockets = (
        _DroppingWebSocket([_started('s1')]),
        _DroppingWebSocket([_started('s2')]),
        _FakeWebSocket([_started('s3')]),
    )
    settings = _STORED_RECONNECT
    with _patched_dials(*sockets) as urls:
        async with model.connect(
            messages=[], model_settings=settings, model_request_parameters=ModelRequestParameters()
        ) as connection:
            assert await _first_events(connection, 2) == [RealtimeSessionReconnectEvent(state_restored=True)] * 2
    assert urls == snapshot(
        [
            'wss://api.openai.com/v1/live/sessions',
            'wss://api.openai.com/v1/live/sessions/s1/fork',
            'wss://api.openai.com/v1/live/sessions/s2/fork',
        ]
    )
    assert [json.loads(ws.sent[0])['session'] for ws in sockets[1:]] == [{}, {}]


async def test_a_reconnect_that_keeps_failing_ends_the_session(model: OpenAILiveModel) -> None:
    """A refused start counts as a failed attempt; once they're spent, the session ends with a reason."""
    refused = json.dumps(
        {'type': 'error', 'error': {'type': 'invalid_request_error', 'message': 'The stored session was not found.'}}
    )
    sockets = (_DroppingWebSocket([_started('s1')]), _FakeWebSocket([refused]), _FakeWebSocket([refused]))
    settings = _RECONNECT
    with _patched_dials(*sockets):
        async with model.connect(
            messages=[], model_settings=settings, model_request_parameters=ModelRequestParameters()
        ) as connection:
            with anyio.fail_after(5):
                # The stream ends after the error, rather than trying again.
                [error] = [event async for event in connection]
            assert isinstance(error, RealtimeSessionErrorEvent) and not error.recoverable
            assert 'reconnect failed' in error.message
            assert not connection._can_reconnect  # pyright: ignore[reportPrivateUsage]


async def test_a_call_the_lost_session_asked_for_is_not_answered_on_the_new_one() -> None:
    """The new session has no record of the call (checked live), and its turn and usage start over."""
    sent: list[dict[str, Any]] = []

    class _Sink(OpenAILiveConnection):
        async def _send_event(self, event: dict[str, Any]) -> None:
            sent.append(event)  # pragma: no cover

    async def dial(fork_from: str | None, seed: list[dict[str, Any]]) -> tuple[Any, str | None]:
        return object(), 's2'

    connection = _Sink(object(), dial=dial, reconnect={'base_delay': 0.0, 'jitter': False}, forks=True, session_id='s1')  # pyright: ignore[reportArgumentType]
    _open_delegation(connection, call_ids=('c1',))
    connection._reported_seconds = 30.0  # pyright: ignore[reportPrivateUsage]

    assert await connection._try_reconnect()  # pyright: ignore[reportPrivateUsage]
    assert connection._session_id == 's2'  # pyright: ignore[reportPrivateUsage]
    assert not connection._delegations and not connection._response_open  # pyright: ignore[reportPrivateUsage]
    assert connection._silence_timeout() is None  # pyright: ignore[reportPrivateUsage]
    assert connection._reported_seconds == 0.0  # pyright: ignore[reportPrivateUsage]
    await connection.send(ToolResult('c1', output='too late'))
    assert sent == []


async def test_a_reconnect_budget_that_is_spent_is_not_retried() -> None:
    async def dial(fork_from: str | None, seed: list[dict[str, Any]]) -> tuple[Any, str | None]:
        raise AssertionError('no dial expected')  # pragma: no cover

    connection = OpenAILiveConnection(object(), dial=dial, reconnect={'max_reconnects': 0})  # pyright: ignore[reportArgumentType]
    assert not connection._can_reconnect  # pyright: ignore[reportPrivateUsage]
    assert not await connection._try_reconnect()  # pyright: ignore[reportPrivateUsage]


async def test_a_replay_keeps_the_most_recent_history_within_lives_caps(monkeypatch: pytest.MonkeyPatch) -> None:
    """Live refuses more than 128 items or 8,192 tokens at the start, so a long call replays its recent end."""
    many = [ModelRequest(parts=[UserPromptPart(content=f'message {i}')]) for i in range(200)]
    items = await live_module.replay_input_items(many, provider_name='openai')
    assert len(items) == 128
    assert items[-1]['content'][0]['text'] == 'message 199'

    long = [ModelRequest(parts=[UserPromptPart(content=' '.join(['word'] * 1000) + f' {i}')]) for i in range(20)]
    items = await live_module.replay_input_items(long, provider_name='openai')
    assert [item['content'][0]['text'].rsplit(' ', 1)[-1] for item in items] == [
        '12',
        '13',
        '14',
        '15',
        '16',
        '17',
        '18',
        '19',
    ]


class _ClosingWebSocket(_FakeWebSocket):
    """A socket that delivers its frames, then closes cleanly, as Live does after `session.closed`."""

    async def recv(self) -> str:
        if self._frames:
            return self._frames.pop(0)
        raise websockets.ConnectionClosedOK(None, None)


@pytest.mark.parametrize('reason', ['expired', 'connection_lost'])
async def test_a_session_live_ends_itself_reconnects(model: OpenAILiveModel, reason: str) -> None:
    """Live announces a duration limit or a lost connection before its clean close; the policy re-opens it."""
    audio = json.dumps({'type': 'session.output_audio.delta', 'delta': 'f39/f39/f38='})
    first = _ClosingWebSocket([_started('s1'), audio, json.dumps(_session_closed(reason))])
    second = _FakeWebSocket([_started('s2')])
    with _patched_dials(first, second) as urls:
        async with model.connect(
            messages=[], model_settings=_STORED_RECONNECT, model_request_parameters=ModelRequestParameters()
        ) as connection:
            events = await _first_events(connection, 3)
    assert events == [
        AudioDelta(data=b'\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f'),
        ResponseDone(interrupted=True),
        RealtimeSessionReconnectEvent(state_restored=True),
    ]
    assert urls[-1] == 'wss://api.openai.com/v1/live/sessions/s1/fork'


async def test_a_session_the_safety_filter_ended_stays_ended(model: OpenAILiveModel) -> None:
    first = _ClosingWebSocket([_started('s1'), json.dumps(_session_closed('content'))])
    with _patched_dials(first):
        async with model.connect(
            messages=[], model_settings=_STORED_RECONNECT, model_request_parameters=ModelRequestParameters()
        ) as connection:
            with anyio.fail_after(5):
                events = [event async for event in connection]
    assert events[-1] == RealtimeSessionErrorEvent(
        message='The OpenAI GPT-Live session ended: content.', code='live_session_content', recoverable=False
    )


async def test_a_session_live_refuses_to_fork_is_replayed_instead(model: OpenAILiveModel) -> None:
    refused = json.dumps(
        {'type': 'error', 'error': {'type': 'invalid_request_error', 'message': 'The stored session was not found.'}}
    )
    sockets = (_DroppingWebSocket([_started('s1')]), _FakeWebSocket([refused]), _FakeWebSocket([_started('s2')]))
    history = [ModelRequest(parts=[UserPromptPart(content='Hi')])]
    with _patched_dials(*sockets) as urls:
        async with model.connect(
            messages=[], model_settings=_STORED_RECONNECT, model_request_parameters=ModelRequestParameters()
        ) as connection:
            connection.set_message_history(lambda: history)
            assert await _first_events(connection, 1) == [RealtimeSessionReconnectEvent(state_restored=True)]
    assert urls[1:] == ['wss://api.openai.com/v1/live/sessions/s1/fork', 'wss://api.openai.com/v1/live/sessions']
    replacement = json.loads(sockets[2].sent[0])['session']
    assert replacement['store'] is True
    assert replacement['input'] == [{'role': 'user', 'content': [{'type': 'input_text', 'text': 'Hi'}]}]


async def test_a_stored_session_without_an_id_is_replayed() -> None:
    """With no session to fork, a fork would start blank; replaying at least carries the history."""
    dials: list[str | None] = []

    async def dial(fork_from: str | None, seed: list[dict[str, Any]]) -> tuple[Any, str | None]:
        dials.append(fork_from)
        return _FakeWebSocket([]), 's2'

    connection = OpenAILiveConnection(object(), dial=dial, reconnect={'base_delay': 0.0}, forks=True)  # pyright: ignore[reportArgumentType]
    assert await connection._try_reconnect()  # pyright: ignore[reportPrivateUsage]
    assert dials == [None]
    assert not connection._restored  # pyright: ignore[reportPrivateUsage]


class _SendDroppingWebSocket(_FakeWebSocket):
    async def send(self, data: str) -> None:
        raise websockets.ConnectionClosedError(None, None)


async def test_a_drop_while_continuing_a_delegation_reconnects() -> None:
    """The continuation goes out from the receive loop, so a drop there takes the same reconnect path."""

    async def dial(fork_from: str | None, seed: list[dict[str, Any]]) -> tuple[Any, str | None]:
        return _FakeWebSocket([]), 's2'

    ws = _SendDroppingWebSocket([_transcript_frame('Checking.')])
    connection = OpenAILiveConnection(ws, dial=dial, reconnect={'base_delay': 0.0}, session_id='s1')  # pyright: ignore[reportArgumentType]
    connection._continuations_due.append(live_module._Delegation('d1'))  # pyright: ignore[reportPrivateUsage]
    events = await _first_events(connection, 2)
    assert events[-1] == RealtimeSessionReconnectEvent(state_restored=False)
    assert connection._session_id == 's2'  # pyright: ignore[reportPrivateUsage]


async def test_a_drop_while_continuing_without_a_policy_ends_the_session() -> None:
    ws = _SendDroppingWebSocket([_transcript_frame('Checking.')])
    connection = OpenAILiveConnection(ws)  # pyright: ignore[reportArgumentType]
    connection._continuations_due.append(live_module._Delegation('d1'))  # pyright: ignore[reportPrivateUsage]
    events = await _first_events(connection, 2)
    assert events[-1] == snapshot(
        RealtimeSessionErrorEvent(
            message='OpenAI GPT-Live connection closed: no close frame received or sent', recoverable=False
        )
    )


async def test_a_spoken_turn_without_a_transcript_replays_as_a_marker() -> None:
    """The fresh Live session sees that the user spoke before the answer, not an answer out of nowhere."""
    messages = [
        ModelRequest(parts=[SpeechPart(speaker='user', audio=BinaryContent(data=b'\x02\x03', media_type='audio/wav'))]),
        ModelResponse(parts=[SpeechPart(speaker='assistant', transcript='Booked for Friday.')]),
    ]
    items = await live_module.replay_input_items(messages, provider_name='openai')
    assert items == snapshot(
        [
            {
                'role': 'user',
                'content': [{'type': 'input_text', 'text': '[The user spoke; no transcript is available.]'}],
            },
            {'role': 'assistant', 'content': [{'type': 'output_text', 'text': 'Booked for Friday.'}]},
        ]
    )


async def test_a_message_too_long_to_replay_alone_is_skipped() -> None:
    messages = [
        ModelRequest(parts=[UserPromptPart(content='earlier')]),
        ModelRequest(parts=[UserPromptPart(content=' '.join(['word'] * 9000))]),
    ]
    items = await live_module.replay_input_items(messages, provider_name='openai')
    assert [item['content'][0]['text'] for item in items] == ['earlier']

    # A skipped message doesn't take up one of the 128 places.
    many = [ModelRequest(parts=[UserPromptPart(content=f'message {i}')]) for i in range(130)]
    items = await live_module.replay_input_items([*many, *messages[1:]], provider_name='openai')
    assert len(items) == 128
    assert items[0]['content'][0]['text'] == 'message 2'


def test_a_document_url_of_unknown_type_is_left_to_the_mapper() -> None:
    """Whether it can be sent is the Responses mapping's call, as on `OpenAIResponsesModel`."""
    assert not live_module._is_audio_or_video_url(DocumentUrl(url='https://example.com/noext'))  # pyright: ignore[reportPrivateUsage]


async def test_the_idle_pump_carries_on_to_the_replacement_socket(monkeypatch: pytest.MonkeyPatch) -> None:
    """A drop the connection can redial doesn't stop the pump: the silence that follows goes to the new socket."""
    # A clock a second further on at each look: each frame of silence is due by the time the pump asks, so the test
    # waits on no real quiet gap.
    monkeypatch.setattr(live_module, '_pump_clock', itertools.count(0.0, 1.0).__next__)

    class _DeadSocket(_FakeWebSocket):
        def __init__(self) -> None:
            super().__init__([])
            self.pump_hit_the_drop = anyio.Event()

        async def send(self, data: str) -> None:
            self.pump_hit_the_drop.set()
            raise websockets.ConnectionClosedError(None, None)

        async def recv(self) -> str:
            # The read loop only learns of the drop once the pump has already run into it.
            await self.pump_hit_the_drop.wait()
            raise websockets.ConnectionClosedError(None, None)

    class _Replacement(_FakeWebSocket):
        def __init__(self) -> None:
            super().__init__([])
            self.silence_arrived = anyio.Event()

        async def send(self, data: str) -> None:
            await super().send(data)
            self.silence_arrived.set()

    dead, replacement = _DeadSocket(), _Replacement()

    async def dial(fork_from: str | None, seed: list[dict[str, Any]]) -> tuple[Any, str | None]:
        return replacement, 's2'

    connection = OpenAILiveConnection(dead, dial=dial, reconnect={'base_delay': 0.0}, session_id='s1', idle_audio=True)  # pyright: ignore[reportArgumentType]
    assert await _first_events(connection, 1) == [RealtimeSessionReconnectEvent(state_restored=False)]
    with anyio.fail_after(READINESS_WAIT_TIMEOUT):
        await replacement.silence_arrived.wait()
    pump = connection._idle_audio_task  # pyright: ignore[reportPrivateUsage]
    assert pump is not None and not pump.done()
    await connection.aclose()

    assert json.loads(replacement.sent[0]) == {
        'type': 'session.input_audio.append',
        'audio': base64.b64encode(bytes(4800)).decode(),
    }


async def test_audio_booked_on_a_lost_session_doesnt_hold_back_the_replacements_silence() -> None:
    """A redial drops the application audio still due to play on the old session, so idle frames start at once."""
    replacement = _FakeWebSocket([])

    async def dial(fork_from: str | None, seed: list[dict[str, Any]]) -> tuple[Any, str | None]:
        return replacement, 's2'

    dropping: Any = _DroppingWebSocket([])
    connection = OpenAILiveConnection(
        dropping, dial=dial, reconnect={'base_delay': 0.0}, session_id='s1', idle_audio=True
    )
    # A minute of audio sent just before the drop, which will now never play.
    connection._input_audio_end = live_module._pump_clock() + 60  # pyright: ignore[reportPrivateUsage]
    assert await _first_events(connection, 1) == [RealtimeSessionReconnectEvent(state_restored=False)]
    with anyio.fail_after(READINESS_WAIT_TIMEOUT):
        while not replacement.sent:
            await anyio.sleep(0.05)
    await connection.aclose()


async def test_application_audio_after_an_idle_frame_plays_once_that_frame_has(monkeypatch: pytest.MonkeyPatch) -> None:
    """Audio sent just after a frame of silence queues behind it on Live's timeline, so the gap counts from there."""
    clock = [10.0]
    monkeypatch.setattr(live_module, '_pump_clock', lambda: clock[0])
    connection = _AudioSink()
    connection._start_idle_audio()  # pyright: ignore[reportPrivateUsage]
    clock[0] = 10.3
    with anyio.fail_after(READINESS_WAIT_TIMEOUT):
        await connection.silence_sent.wait()

    await connection.send(BinaryAudio(data=b'\x01\x00' * 10, media_type='audio/pcm'))

    # The silence plays until 10.4, the application's 10 samples after it, and then the quiet gap.
    assert connection._idle_frame_due() == pytest.approx(10.7 + 10 / 24000)  # pyright: ignore[reportPrivateUsage]
    await connection.aclose()


async def test_audio_whose_send_was_cancelled_doesnt_hold_the_pump_back(monkeypatch: pytest.MonkeyPatch) -> None:
    clock = [5.0]
    monkeypatch.setattr(live_module, '_pump_clock', lambda: clock[0])

    class _Stuck(_AudioSink):
        def __init__(self) -> None:
            super().__init__()
            self.sending = anyio.Event()

        async def _send_event(self, event: dict[str, Any]) -> None:
            self.sending.set()
            await anyio.sleep_forever()

    connection = _Stuck()
    sending = asyncio.create_task(connection.send(BinaryAudio(data=bytes(48000), media_type='audio/pcm')))
    with anyio.fail_after(READINESS_WAIT_TIMEOUT):
        await connection.sending.wait()
    # A second of audio booked while it was going out.
    assert connection._idle_frame_due() == pytest.approx(6.3)  # pyright: ignore[reportPrivateUsage]
    sending.cancel()
    with pytest.raises(asyncio.CancelledError):
        await sending

    assert connection._idle_frame_due() == pytest.approx(0.3)  # pyright: ignore[reportPrivateUsage]


@pytest.mark.parametrize('ending', ['expired', 'connection_lost', 'dropped'])
async def test_closing_after_a_reconnect_ends_the_replacement_session(model: OpenAILiveModel, ending: str) -> None:
    """The session Live ended was replaced, so closing still asks the replacement to end, and records its seconds."""
    if ending == 'dropped':
        first: _FakeWebSocket = _DroppingWebSocket([_started('s1')])
    else:
        first = _ClosingWebSocket([_started('s1'), json.dumps(_session_closed(ending, seconds=3))])
    second = _FakeWebSocket([_started('s2')], closed_seconds=6)
    with _patched_dials(first, second):
        async with model.connect(
            messages=[], model_settings=_STORED_RECONNECT, model_request_parameters=ModelRequestParameters()
        ) as connection:
            with anyio.fail_after(5):
                async for event in connection:  # pragma: no branch
                    if isinstance(event, RealtimeSessionReconnectEvent):
                        break
                reports = await _ended(connection)

    assert [report.usage.audio_seconds for report in reports] == [6]
    assert [json.loads(frame)['type'] for frame in first.sent if json.loads(frame)['type'] == 'session.close'] == []
    assert [json.loads(frame)['type'] for frame in second.sent[1:]] == ['session.close']


async def test_a_redial_with_nothing_to_replay_doesnt_load_the_tokenizer(monkeypatch: pytest.MonkeyPatch) -> None:
    """Loading it takes seconds on first use, which a session with no history to replay shouldn't wait out."""

    def get_encoding(name: str) -> Any:  # pragma: no cover
        raise AssertionError('the tokenizer was loaded')

    monkeypatch.setattr(live_module.tiktoken, 'get_encoding', get_encoding)
    assert await live_module.replay_input_items([], provider_name='openai') == []
