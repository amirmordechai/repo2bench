"""The simulation of a session with an OpenAI Realtime protocol model (OpenAI, Azure OpenAI, xAI, ElevenLabs)."""

from __future__ import annotations as _annotations

import asyncio
from collections.abc import AsyncIterator, Generator, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Literal
from unittest.mock import patch

from hypothesis import strategies as st
from hypothesis.stateful import precondition, rule

from pydantic_ai.providers.azure import AzureProvider
from pydantic_ai.providers.elevenlabs import ElevenLabsProvider
from pydantic_ai.providers.openai import OpenAIProvider
from pydantic_ai.providers.xai import XaiProvider
from pydantic_ai.realtime import RealtimeModel
from pydantic_ai.realtime.azure import AzureRealtimeModel
from pydantic_ai.realtime.elevenlabs import ElevenLabsRealtimeConnection, ElevenLabsRealtimeModel
from pydantic_ai.realtime.lifecycle import RealtimeFrame, StaleEvent
from pydantic_ai.realtime.openai import OpenAIRealtimeConnection, OpenAIRealtimeModel, OpenAIRealtimeModelSettings
from pydantic_ai.realtime.settings import RealtimeModelSettings
from pydantic_ai.realtime.xai import XaiRealtimeModel

from ._machine import TICKS, ManualTurnMachine
from ._openai_server import Dialect, OpenAIServer, ServerSession
from ._simulation import SessionOptions, Simulation, step
from ._truth import GroundTruth
from ._wire import SendFault


@dataclass
class OpenAIOptions:
    """Connect-time configuration of the simulated OpenAI-protocol session."""

    turn_detection: Literal['server_vad', 'manual'] = 'server_vad'
    transcription: bool = True
    dialect: Dialect = 'openai'
    """Which provider's model the session connects to: OpenAI, Azure OpenAI, xAI Grok Voice, or ElevenLabs."""
    vad_interrupts: bool = True
    """Server VAD's `interrupt_response`: whether the user starting to speak cancels the active response."""
    vad_responds: bool = True
    """Server VAD's `create_response`: whether the user stopping answers their turn (xAI answers regardless)."""
    prune_tool_items: bool = False
    """`openai_prune_tool_items`: whether answered tool rounds are deleted from the server conversation."""
    keep_tool_items: frozenset[str] = frozenset()
    """`openai_keep_tool_items`: the tools whose rounds pruning leaves in the server conversation."""


class OpenAISimulation(Simulation):
    """A session with an OpenAI Realtime protocol model over the simulated server."""

    def __init__(
        self,
        *,
        seed: int = 0,
        options: SessionOptions | None = None,
        openai: OpenAIOptions | None = None,
        strict: bool | None = None,
    ) -> None:
        super().__init__(seed=seed, options=options, strict=strict)
        self.openai = openai or OpenAIOptions()
        self.provider = self.openai.dialect
        self.server = OpenAIServer(dialect=self.openai.dialect, model=_SERVED_MODELS[self.openai.dialect])
        self.deferred_requests = 0
        """How many requests for a response the connection deferred behind an active one."""
        self.requests_cut_off = 0
        """How many requests for a response were cancelled while the connection was sending them."""
        if self.options.latency:
            self.server.network.latency = lambda: self.rng.choice((0, 0, 0, 1, 2, 4))

    @property
    def truth(self) -> GroundTruth:
        return self.server.truth

    def observe_connection(self, connection: Any) -> None:
        """Count the requests for a response the connection held back behind an active one (it folds them)."""
        assert isinstance(connection, OpenAIRealtimeConnection)
        request_response = connection._request_response  # pyright: ignore[reportPrivateUsage]

        async def counted(input_indexes: Sequence[int], *, answers: Sequence[int] | None = None) -> None:
            if connection._response_active:  # pyright: ignore[reportPrivateUsage]
                self.deferred_requests += len(input_indexes)
            await request_response(input_indexes, answers=answers)

        connection._request_response = counted  # pyright: ignore[reportPrivateUsage]
        create_response = connection._create_response  # pyright: ignore[reportPrivateUsage]

        async def cut_off(input_indexes: Sequence[int], answers: Sequence[int]) -> None:
            try:
                await create_response(input_indexes, answers)
            except asyncio.CancelledError:
                self.requests_cut_off += 1
                raise

        connection._create_response = cut_off  # pyright: ignore[reportPrivateUsage]

        # The session reads the codec stream; the lifecycle stream the same frames make is checked on the side.
        connection_frames = connection.frames
        observe = self.checker.observe_lifecycle_stream(lambda: connection._inputs_received)  # pyright: ignore[reportPrivateUsage]

        async def observed() -> AsyncIterator[RealtimeFrame]:
            async for frame in connection_frames():
                for event in frame:
                    if not isinstance(event, StaleEvent):
                        observe(event)
                yield frame
            observe(None)

        connection.frames = observed

    def build_model(self) -> RealtimeModel:
        if self.openai.dialect == 'azure':
            return AzureRealtimeModel(
                'gpt-realtime',
                provider=AzureProvider(
                    azure_endpoint='https://simulated.openai.azure.com', api_version='2026-04-10', api_key='simulated'
                ),
            )
        if self.openai.dialect == 'xai':
            return XaiRealtimeModel('grok-voice-latest', provider=XaiProvider(api_key='simulated'))
        if self.openai.dialect == 'elevenlabs':
            return ElevenLabsRealtimeModel(
                _SERVED_MODELS['elevenlabs'], provider=ElevenLabsProvider(api_key='simulated')
            )
        return OpenAIRealtimeModel('gpt-realtime', provider=OpenAIProvider(api_key='simulated'))

    def model_settings(self) -> RealtimeModelSettings:
        transcription_model = 'auto' if self.openai.dialect == 'elevenlabs' else 'gpt-4o-mini-transcribe'
        settings: OpenAIRealtimeModelSettings = {
            'turn_detection': self.openai.turn_detection == 'server_vad',
            'input_transcription_model': transcription_model if self.openai.transcription else None,
        }
        settings['reconnect'] = {'max_attempts': 2, 'base_delay': 0.1, 'jitter': False}
        if self.openai.prune_tool_items:
            settings['openai_prune_tool_items'] = True
        if self.openai.keep_tool_items:
            settings['openai_keep_tool_items'] = self.openai.keep_tool_items
        vad = self.openai
        if (
            vad.turn_detection == 'server_vad'
            and vad.dialect != 'xai'
            and not (vad.vad_interrupts and vad.vad_responds)
        ):
            if vad.dialect == 'elevenlabs':
                # ElevenLabs only takes semantic VAD, with the same two flags.
                settings['openai_turn_detection'] = {
                    'type': 'semantic_vad',
                    'interrupt_response': vad.vad_interrupts,
                    'create_response': vad.vad_responds,
                }
            else:
                settings['openai_turn_detection'] = {
                    'type': 'server_vad',
                    'interrupt_response': vad.vad_interrupts,
                    'create_response': vad.vad_responds,
                }
        return settings

    @contextmanager
    def transport(self) -> Generator[None]:
        # ElevenLabs' keep-alive is a timer that never stops, so the simulation could never come to rest with it.
        with self.server.network.patch(), patch.object(ElevenLabsRealtimeConnection, '_keep_alive_after', None):
            yield

    # --- provider behavior --------------------------------------------------------------------------

    def _after_server(self, deliver: bool, ticks: int | None) -> None:
        if deliver:
            self.server.network.deliver()
        self._advance(ticks)

    @step
    def deliver(self, count: int | None = None, ticks: int | None = None) -> None:
        """Let up to `count` in-flight server frames (all by default) reach the client."""
        self.server.network.deliver(count)
        self._advance(ticks)

    @step
    def speak(self, chunks: int = 1, deliver: bool = True, ticks: int | None = None) -> None:
        """The active response says a word, with `chunks` × 100 ms of audio."""
        self.server.speak(chunks)
        self._after_server(deliver, ticks)

    @step
    def call_tool(self, name: str = 'lookup', deliver: bool = True, ticks: int | None = None) -> str:
        """The active response calls a tool."""
        call_id = self.server.call_tool(name)
        self._after_server(deliver, ticks)
        return call_id

    @step
    def finish(
        self,
        status: Literal['completed', 'incomplete', 'failed'] = 'completed',
        late: bool = False,
        deliver: bool = True,
        ticks: int | None = None,
    ) -> None:
        """The active response ends (as cancelled, if the client asked for that; only then can its done be `late`)."""
        self.server.finish(status, late=late)
        self._after_server(deliver, ticks)

    @step
    def release_late_done(self, deliver: bool = True, ticks: int | None = None) -> None:
        self.server.release_late_done()
        self._after_server(deliver, ticks)

    @step
    def repeat_done(self, deliver: bool = True, ticks: int | None = None) -> None:
        """The server sends the latest `response.done` again."""
        self.server.repeat_done()
        self._after_server(deliver, ticks)

    @step
    def speech_start(self, late: bool = False, deliver: bool = True, ticks: int | None = None) -> None:
        """Server VAD hears the user start, cutting off the active response (its `response.done` late, if `late`)."""
        self.server.speech_start(late=late)
        self._after_server(deliver, ticks)

    @step
    def speech_stop(self, deliver: bool = True, ticks: int | None = None, commit: bool = True) -> None:
        self.server.speech_stop(commit=commit)
        self._after_server(deliver, ticks)

    @step
    def transcribe(self, fail: bool = False, deliver: bool = True, ticks: int | None = None) -> None:
        self.server.transcribe(fail=fail)
        self._after_server(deliver, ticks)

    @step
    def reject_next(self, kind: Literal['content', 'response'] = 'content', ticks: int | None = None) -> None:
        """The provider will refuse the next user content item, or the next response request."""
        self.server.arm_rejection(kind)
        self._advance(ticks)

    @step
    def fail_next_send(self, fault: SendFault = 'lost', ticks: int | None = None) -> None:
        """The next frame the client sends hits a dead socket."""
        self.server.network.send_faults.append(fault)
        self._advance(ticks)

    @step
    def drop(self, refuse_dials: int = 0, ticks: int | None = None) -> None:
        """The connection drops; the next `refuse_dials` re-dials fail."""
        self.server.network.dial_failures += refuse_dials
        self.server.drop()
        self._advance(ticks)

    # --- settling -----------------------------------------------------------------------------------

    def drive_server_to_rest(self) -> bool:
        server = self.server
        session = server.session
        if session is None or not session.socket.alive:
            return False
        if server.network.in_flight():
            server.network.deliver()
        elif session.late_done is not None:
            server.release_late_done()
        elif session.stopped_uncommitted is not None:
            # (Ahead of the reply xAI started at the stop, which says nothing until the turn is committed.)
            server.commit_stopped()
        elif session.active is not None:
            if not session.active.truth.words and not session.active.truth.tool_calls:
                server.speak(1)
            server.finish()
        elif session.speaking is not None:
            server.speech_stop()
        elif session.pending_transcripts:
            server.transcribe()
        else:
            return False
        server.network.deliver()
        return True


_SERVED_MODELS: dict[Dialect, str] = {
    'openai': 'gpt-realtime',
    'azure': 'gpt-realtime',
    'xai': 'grok-voice-latest',
    'elevenlabs': 'eleven_realtime_v1_mini',
}
"""The model each dialect's server reports in `session.created`."""


def _options(dialect: Dialect) -> st.SearchStrategy[OpenAIOptions]:
    # The VAD flags only matter under server VAD, and xAI ignores them.
    vad_flag = st.just(True) if dialect == 'xai' else st.booleans()
    # (xAI's settings have no `openai_prune_tool_items`.)
    prune = st.just(False) if dialect == 'xai' else st.booleans()
    manual = st.builds(
        OpenAIOptions,
        turn_detection=st.just('manual'),
        transcription=st.booleans(),
        dialect=st.just(dialect),
        prune_tool_items=prune,
    )
    server_vad = st.builds(
        OpenAIOptions,
        turn_detection=st.just('server_vad'),
        transcription=st.booleans(),
        dialect=st.just(dialect),
        vad_interrupts=vad_flag,
        vad_responds=vad_flag,
        prune_tool_items=prune,
    )
    return manual | server_vad


class OpenAIMachine(ManualTurnMachine):  # pragma: lax no cover (driven only by randomized exploration)
    """Randomized traces against the simulated OpenAI Realtime server."""

    provider_options = _options('openai')

    @staticmethod
    def make_simulation(seed: int, options: SessionOptions, provider_options: OpenAIOptions) -> Simulation:
        return OpenAISimulation(seed=seed, options=options, openai=provider_options)

    @property
    def openai_sim(self) -> OpenAISimulation:
        sim = self.s
        assert isinstance(sim, OpenAISimulation)
        return sim

    def server_session(self) -> ServerSession | None:
        """The live server session, if the simulation is still running and connected."""
        session = self.openai_sim.server.session if self.live() else None
        return session if session is not None and session.socket.alive else None

    def active(self) -> bool:
        session = self.server_session()
        # The reply xAI starts at its VAD's stop says nothing until it commits the turn.
        return session is not None and session.active is not None and session.stopped_reply is None

    def can_drop(self) -> bool:
        return self.server_session() is not None

    @precondition(lambda self: self.active())
    @rule(chunks=st.integers(min_value=1, max_value=2), deliver=st.booleans(), ticks=TICKS)
    def speak(self, chunks: int, deliver: bool, ticks: int | None) -> None:
        self.run(lambda: self.openai_sim.speak(chunks=chunks, deliver=deliver, ticks=ticks))

    @precondition(lambda self: self.active())
    @rule(deliver=st.booleans(), ticks=TICKS)
    def call_tool(self, deliver: bool, ticks: int | None) -> None:
        self.run(lambda: self.openai_sim.call_tool(deliver=deliver, ticks=ticks))

    @precondition(lambda self: self.active())
    @rule(
        status=st.sampled_from(['completed', 'completed', 'completed', 'incomplete', 'failed']),
        late=st.booleans(),
        deliver=st.booleans(),
        ticks=TICKS,
    )
    def finish(
        self, status: Literal['completed', 'incomplete', 'failed'], late: bool, deliver: bool, ticks: int | None
    ) -> None:
        session = self.server_session()
        # Only a cancelled response's `response.done` can come after the next response starts.
        late = (
            late
            and session is not None
            and session.active is not None
            and session.active.cancel_requested
            and session.late_done is None
        )
        self.run(lambda: self.openai_sim.finish(status=status, late=late, deliver=deliver, ticks=ticks))

    @precondition(lambda self: (session := self.server_session()) is not None and session.late_done is not None)
    @rule(deliver=st.booleans(), ticks=TICKS)
    def release_late_done(self, deliver: bool, ticks: int | None) -> None:
        self.run(lambda: self.openai_sim.release_late_done(deliver=deliver, ticks=ticks))

    @precondition(lambda self: (session := self.server_session()) is not None and bool(session.ended_responses))
    @rule(deliver=st.booleans(), ticks=TICKS)
    def repeat_done(self, deliver: bool, ticks: int | None) -> None:
        self.run(lambda: self.openai_sim.repeat_done(deliver=deliver, ticks=ticks))

    @precondition(
        lambda self: (
            (session := self.server_session()) is not None
            and session.server_vad
            and session.speaking is None
            and session.audio_ms > 0
        )
    )
    @rule(late=st.booleans(), deliver=st.booleans(), ticks=TICKS)
    def speech_start(self, late: bool, deliver: bool, ticks: int | None) -> None:
        session = self.server_session()
        late = late and session is not None and session.active is not None and session.late_done is None
        self.run(lambda: self.openai_sim.speech_start(late=late, deliver=deliver, ticks=ticks))

    @precondition(lambda self: (session := self.server_session()) is not None and session.speaking is not None)
    @rule(deliver=st.booleans(), ticks=TICKS, commit=st.booleans())
    def speech_stop(self, deliver: bool, ticks: int | None, commit: bool) -> None:
        self.run(lambda: self.openai_sim.speech_stop(deliver=deliver, ticks=ticks, commit=commit))

    @precondition(lambda self: (session := self.server_session()) is not None and bool(session.pending_transcripts))
    @rule(fail=st.booleans(), deliver=st.booleans(), ticks=TICKS)
    def transcribe(self, fail: bool, deliver: bool, ticks: int | None) -> None:
        self.run(lambda: self.openai_sim.transcribe(fail=fail, deliver=deliver, ticks=ticks))

    @precondition(lambda self: self.server_session() is not None and bool(self.openai_sim.server.network.in_flight()))
    @rule(count=st.one_of(st.none(), st.integers(min_value=1, max_value=3)), ticks=TICKS)
    def deliver(self, count: int | None, ticks: int | None) -> None:
        self.run(lambda: self.openai_sim.deliver(count=count, ticks=ticks))

    @precondition(lambda self: self.live())
    @rule(kind=st.sampled_from(['content', 'response']), ticks=TICKS)
    def reject_next(self, kind: Literal['content', 'response'], ticks: int | None) -> None:
        self.run(lambda: self.openai_sim.reject_next(kind=kind, ticks=ticks))

    @precondition(lambda self: self.can_drop())
    @rule(fault=st.sampled_from(['lost', 'ambiguous']), ticks=TICKS)
    def fail_next_send(self, fault: SendFault, ticks: int | None) -> None:
        self.run(lambda: self.openai_sim.fail_next_send(fault=fault, ticks=ticks))

    @precondition(lambda self: self.can_drop())
    @rule(refuse_dials=st.integers(min_value=0, max_value=2), ticks=TICKS)
    def drop(self, refuse_dials: int, ticks: int | None) -> None:
        self.run(lambda: self.openai_sim.drop(refuse_dials=refuse_dials, ticks=ticks))


class AzureMachine(OpenAIMachine):  # pragma: lax no cover (driven only by randomized exploration)
    """Randomized traces against the simulated server speaking as Azure OpenAI."""

    provider_options = _options('azure')


class XaiMachine(OpenAIMachine):  # pragma: lax no cover (driven only by randomized exploration)
    """Randomized traces against the simulated server speaking as xAI Grok Voice."""

    provider_options = _options('xai')


class ElevenLabsMachine(OpenAIMachine):  # pragma: lax no cover (driven only by randomized exploration)
    """Randomized traces against the simulated server speaking as ElevenLabs."""

    provider_options = _options('elevenlabs')
