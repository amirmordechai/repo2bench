"""Cassette-backed tests for the OpenAI Realtime provider, exercising the real WebSocket protocol.

These complement the network-free `test_openai.py` unit tests: the fakes there pin event mapping and
send/handshake logic cheaply, while these replay recorded provider frames end-to-end through
[`Agent.realtime_session`][pydantic_ai.agent.Agent.realtime_session] to prove the real protocol —
the streamed part events, the tool round-trip, and message-history seeding. Recorded once against the
live API with `--record-mode=rewrite`, then replayed offline forever.
"""

from __future__ import annotations as _annotations

import asyncio
import importlib
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager
from decimal import Decimal
from pathlib import Path
from typing import Any

import anyio
import pytest
from inline_snapshot import snapshot

from pydantic_ai import Agent, RequestUsage, RunContext
from pydantic_ai.capabilities.instrumentation import Instrumentation
from pydantic_ai.exceptions import UserError
from pydantic_ai.messages import (
    BinaryContent,
    EnqueuedMessagesEvent,
    FunctionToolCallEvent,
    FunctionToolResultEvent,
    ModelRequest,
    ModelResponse,
    PartDeltaEvent,
    PartEndEvent,
    PartStartEvent,
    RealtimeSessionErrorEvent,
    SpeechPart,
    SpeechPartDelta,
    SystemPromptPart,
    TextPart,
    ToolCallPart,
    ToolReturnPart,
    UserPromptPart,
)
from pydantic_ai.realtime import (
    RealtimeInputSpeechEndEvent,
    RealtimeModelProfile,
    RealtimeOutputSpeechEndEvent,
    RealtimeSession,
    RealtimeTurnCompleteEvent,
)
from pydantic_ai.usage import RunUsage

from ..conftest import IsDatetime, IsSameStr, IsStr, try_import
from .conftest import REAL_SDP_OFFER
from .ws_cassettes import CassetteMessage, RealtimeCassette
from .ws_helpers import collapse_event_types, sent_frames_containing

with try_import() as imports_successful:
    from pydantic_ai.providers import Provider
    from pydantic_ai.providers.openai import OpenAIProvider
    from pydantic_ai.realtime import infer_realtime_model
    from pydantic_ai.realtime.openai import (
        OpenAIRealtimeConnection,
        OpenAIRealtimeModel,
        OpenAIRealtimeModelSettings,
    )

with try_import() as logfire_imports_successful:
    from logfire.testing import CaptureLogfire

_WAV_HEADER_BYTES = 44
"""Retained speech audio is a WAV file; subtract its header to compare against the PCM that was sent."""

pytestmark = [
    pytest.mark.skipif(not imports_successful(), reason='openai / websockets not installed'),
]


async def test_enqueued_message_delivery_event(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """OpenAI delivery emits the enqueued request object recorded in session history."""
    provider, _ = openai_ws_cassette
    model = OpenAIRealtimeModel(
        'gpt-realtime', provider=provider, settings=OpenAIRealtimeModelSettings(output_modality='text')
    )
    agent = Agent(instructions='Reply exactly "DELIVERED".')

    events: list[Any] = []
    async with agent.realtime(model).session() as session:
        enqueue_id = session.enqueue('Reply now.')
        assert enqueue_id is not None
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    enqueued_events = [event for event in events if isinstance(event, EnqueuedMessagesEvent)]
    assert len(enqueued_events) == 1
    assert enqueued_events[0].enqueue_id == enqueue_id
    assert enqueued_events[0].messages[0] is session.new_messages()[0]
    assert session.new_messages()[1] == snapshot(
        ModelResponse(
            parts=[TextPart(content='DELIVERED')],
            usage=RequestUsage(
                details={
                    'input_text_tokens': 14,
                    'input_image_tokens': 0,
                    'output_text_tokens': 5,
                    'audio_tokens': 0,
                },
                output_tokens=5,
                input_tokens=14,
                cost=Decimal('0.000136'),
            ),
            model_name='gpt-realtime',
            timestamp=IsDatetime(),
            provider_name='openai',
            provider_url='https://api.openai.com/v1/',
            provider_details={'status': 'completed'},
            provider_response_id=IsStr(),
            finish_reason='stop',
            run_id=IsStr(),
            conversation_id=IsStr(),
        )
    )


async def test_session_when_idle_enqueue_waits_for_response_boundary(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """A session-level system prompt waits for OpenAI's active response to finish."""
    provider, _ = openai_ws_cassette
    model = OpenAIRealtimeModel(
        'gpt-realtime', provider=provider, settings=OpenAIRealtimeModelSettings(output_modality='text')
    )
    agent = Agent(
        instructions=(
            'First say exactly "FIRST RESPONSE COMPLETE". After any later message, follow its instruction exactly.'
        )
    )

    completions: list[RealtimeTurnCompleteEvent] = []
    enqueued = False
    async with agent.realtime(model).session() as session:
        await session.send('Begin.')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                if not enqueued and isinstance(event, PartDeltaEvent):
                    session.enqueue(
                        SystemPromptPart(content='Say exactly "QUEUED MARKER RECEIVED".'),
                        priority='when_idle',
                    )
                    enqueued = True
                if isinstance(event, RealtimeTurnCompleteEvent):
                    completions.append(event)
                    if len(completions) == 2:
                        break

    assert len(completions) == 2
    assert session.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='Begin.', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='FIRST RESPONSE COMPLETE')],
                usage=RequestUsage(
                    details={
                        'input_text_tokens': 24,
                        'input_image_tokens': 0,
                        'output_text_tokens': 5,
                        'audio_tokens': 0,
                    },
                    output_tokens=5,
                    input_tokens=24,
                    cost=Decimal('0.000176'),
                ),
                model_name='gpt-realtime',
                timestamp=IsDatetime(),
                provider_name='openai',
                provider_url='https://api.openai.com/v1/',
                provider_details={'status': 'completed'},
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content='<system>Say exactly "QUEUED MARKER RECEIVED".</system>', timestamp=IsDatetime()
                    )
                ],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='QUEUED MARKER RECEIVED')],
                usage=RequestUsage(
                    details={
                        'input_text_tokens': 52,
                        'input_image_tokens': 0,
                        'output_text_tokens': 9,
                        'audio_tokens': 0,
                    },
                    output_tokens=9,
                    input_tokens=52,
                    cost=Decimal('0.000352'),
                ),
                model_name='gpt-realtime',
                timestamp=IsDatetime(),
                provider_name='openai',
                provider_url='https://api.openai.com/v1/',
                provider_details={'status': 'completed'},
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_text_in_audio_out_turn(openai_ws_cassette: tuple[Provider[Any], RealtimeCassette]) -> None:
    """A text-in turn yields streamed audio+transcript parts and a classic-shaped history."""
    provider, cassette = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    agent = Agent(instructions='Answer in two or three words.')

    events: list[Any] = []
    async with agent.realtime(model).session(audio_retention='output_audio') as session:
        await session.send('Say a short greeting.')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    assert sent_frames_containing(cassette, 'Answer in two or three words.') == snapshot(
        [
            {
                'type': 'session.update',
                'session': {
                    'type': 'realtime',
                    'instructions': 'Answer in two or three words.',
                    'output_modalities': ['audio'],
                    'audio': {
                        'input': {
                            'format': {'type': 'audio/pcm', 'rate': 24000},
                            'turn_detection': {
                                'type': 'server_vad',
                                'create_response': True,
                                'interrupt_response': True,
                            },
                            'transcription': {'model': 'gpt-realtime-whisper'},
                        },
                        'output': {'format': {'type': 'audio/pcm', 'rate': 24000}},
                    },
                },
            }
        ]
    )

    messages = session.all_messages()
    assert collapse_event_types(events) == snapshot(
        ['PartStartEvent', 'PartDeltaEvent', 'PartEndEvent', 'RealtimeTurnCompleteEvent']
    )
    assert [type(m).__name__ for m in messages] == snapshot(['ModelRequest', 'ModelResponse'])
    assert messages[0] == ModelRequest(
        parts=[UserPromptPart(content='Say a short greeting.', timestamp=IsDatetime())],
        timestamp=IsDatetime(),
        conversation_id=IsStr(),
        run_id=IsStr(),
    )
    response = messages[1]
    assert isinstance(response, ModelResponse)
    assert response.model_name == 'gpt-realtime'
    part = response.parts[0]
    assert isinstance(part, SpeechPart)
    assert part.speaker == 'assistant'
    assert part.transcript == snapshot('Hi there!')
    assert isinstance(part.audio, BinaryContent)
    assert part.audio.media_type == 'audio/wav'
    assert len(part.audio.data) > 0


async def test_text_context_waits_for_next_turn(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette], realtime_recording: bool
) -> None:
    provider, _ = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    agent = Agent(instructions='Answer in one short sentence.')

    async with agent.realtime(model).session() as session:
        await session.send('The visitor is called Ada.', respond=False)
        # Gives a reply the model shouldn't have started time to arrive. Replay delivers the recorded frames
        # back to back, so it needs only a moment.
        await asyncio.sleep(1 if realtime_recording else 0.1)
        assert not [message for message in session.new_messages() if isinstance(message, ModelResponse)]
        await session.send('What is the visitor called?')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    messages = session.all_messages()
    assert [type(message).__name__ for message in messages] == snapshot(
        ['ModelRequest', 'ModelRequest', 'ModelResponse']
    )
    response = messages[-1]
    assert isinstance(response, ModelResponse)
    part = response.parts[0]
    assert isinstance(part, SpeechPart)
    assert 'ada' in (part.transcript or '').lower()


async def test_refused_text_is_taken_out_of_history(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    # OpenAI caps an input text at 256,000 characters and refuses a longer one with an `error` naming
    # the item's `event_id`, so the refused text is taken back out of history rather than recorded as
    # something the model saw.
    provider, _ = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime-mini', provider=provider)
    agent = Agent(instructions='Answer in one short sentence.')

    errors: list[RealtimeSessionErrorEvent] = []
    async with agent.realtime(model).session() as session:
        await session.send('a' * 256_001, respond=False)
        await session.send('Say hello.')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                if isinstance(event, RealtimeSessionErrorEvent):
                    errors.append(event)
                elif isinstance(event, RealtimeTurnCompleteEvent):
                    break

    assert [(error.code, error.recoverable) for error in errors] == snapshot([('string_above_max_length', True)])
    messages = session.all_messages()
    assert [type(message).__name__ for message in messages] == snapshot(['ModelRequest', 'ModelResponse'])
    request = messages[0]
    assert isinstance(request, ModelRequest)
    assert request.parts == [UserPromptPart(content='Say hello.', timestamp=IsDatetime())]


async def test_image_can_solicit_one_response(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette], assets_path: Path
) -> None:
    provider, _ = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    agent = Agent(instructions='Describe the image briefly.')
    image = BinaryContent(data=assets_path.joinpath('kiwi.jpg').read_bytes(), media_type='image/jpeg')

    async with agent.realtime(model).session() as session:
        await session.send(image, respond=True)
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    responses = [message for message in session.all_messages() if isinstance(message, ModelResponse)]
    assert len(responses) == 1


async def test_failed_response_surfaces_its_error(openai_ws_cassette: tuple[Provider[Any], RealtimeCassette]) -> None:
    """A response the server fails reports its error, which OpenAI sends only inside `response.done`."""
    provider, _ = openai_ws_cassette
    model = OpenAIRealtimeModel(
        'gpt-realtime-2.1-mini', provider=provider, settings=OpenAIRealtimeModelSettings(output_modality='text')
    )
    agent = Agent(instructions='Reply in at most five words.')

    events: list[Any] = []
    async with agent.realtime(model).session() as session:
        await session.send(BinaryContent(data=b'this is not a png', media_type='image/png'))
        await session.send('What is in the image?')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    assert [event for event in events if isinstance(event, RealtimeSessionErrorEvent)] == snapshot(
        [
            RealtimeSessionErrorEvent(
                message='Input image was rejected by the safety system. If you believe this is an error, contact us at help.openai.com and include the request ID sess_ERrGMIS70H4J8DcCl7sFe',
                type='invalid_request_error',
                code='input_image_safety_violation',
            )
        ]
    )
    assert session.all_messages()[-1] == snapshot(
        ModelResponse(
            parts=[],
            usage=RequestUsage(
                details={'input_text_tokens': 0, 'input_image_tokens': 0, 'output_text_tokens': 0, 'audio_tokens': 0},
                cost=Decimal('0.00'),
            ),
            model_name='gpt-realtime-2.1-mini',
            timestamp=IsDatetime(),
            provider_name='openai',
            provider_url='https://api.openai.com/v1/',
            provider_details={
                'status': 'failed',
                'error': {
                    'code': 'input_image_safety_violation',
                    'type': 'invalid_request_error',
                    'message': 'Input image was rejected by the safety system. If you believe this is an error, contact us at help.openai.com and include the request ID sess_ERrGMIS70H4J8DcCl7sFe',
                },
            },
            provider_response_id='resp_ERrGMce4TS5sXXTRnSOkR',
            finish_reason='error',
            run_id=IsStr(),
            conversation_id=IsStr(),
        )
    )


@pytest.mark.realtime_ws_hold_open
async def test_media_views_subscribe_before_iteration(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """Audio and transcripts produced before their consumers start are buffered by the live session."""
    provider, _ = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    agent = Agent(instructions='Reply only with hello.')

    async with agent.realtime(model).session() as session:
        audio = session.stream_audio()
        transcripts = session.stream_transcripts()
        await session.send('Say hello.')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

        async def consume_audio() -> list[bytes]:
            return [chunk async for chunk in audio]

        async def consume_transcripts() -> list[SpeechPart]:
            return [part async for part in transcripts]

        audio_task = asyncio.create_task(consume_audio())
        transcript_task = asyncio.create_task(consume_transcripts())
        for _ in range(5):
            await asyncio.sleep(0)

    audio_chunks = await audio_task
    transcript_parts = await transcript_task
    assert audio_chunks
    assert all(audio_chunks)
    assert len(transcript_parts) == 1
    assert transcript_parts[0].speaker == 'assistant'
    assert transcript_parts[0].transcript


@pytest.mark.realtime_ws_hold_open
async def test_wait_for_playback_drains_audio_before_close(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """A generation boundary does not let session teardown cut off device-paced playback.

    The recording ends with the reply, but the session is still live: this test stops iterating and
    then calls another session method, so without holding the socket open the replay's
    end-of-conversation close would reach that call as a receive-side failure.
    """
    provider, _ = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    agent = Agent(instructions='Reply in one short sentence.')
    emitted: list[bytes] = []
    played: list[bytes] = []

    async with agent.realtime(model).session() as session:
        audio = session.stream_audio()

        async def play_audio() -> None:
            async for chunk in audio:
                await asyncio.sleep(0.005)
                played.append(chunk)

        playback = asyncio.create_task(play_audio())
        await session.send('Say hello.')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                if (
                    isinstance(event, PartDeltaEvent)
                    and isinstance(event.delta, SpeechPartDelta)
                    and event.delta.audio_chunk
                ):
                    emitted.append(event.delta.audio_chunk)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break
            await session.wait_for_playback()
        assert played == emitted

    await playback


async def test_provider_factory_text_turn(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette], openai_api_key: str
) -> None:
    """A factory-built provider authenticates and runs an inferred realtime model end to end."""
    model = infer_realtime_model(
        'openai:gpt-realtime', provider_factory=lambda _: OpenAIProvider(api_key=openai_api_key)
    )
    agent = Agent(instructions='Answer in two words.')

    async with agent.realtime(model, model_settings={'output_modality': 'text'}).session() as session:
        await session.send('Say hello.')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    assert session.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='Say hello.', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[TextPart(content='Hello there!')],
                usage=RequestUsage(
                    input_tokens=12,
                    output_tokens=5,
                    details={
                        'input_text_tokens': 12,
                        'input_image_tokens': 0,
                        'output_text_tokens': 5,
                        'audio_tokens': 0,
                    },
                    cost=Decimal('0.000128'),
                ),
                model_name='gpt-realtime',
                timestamp=IsDatetime(),
                provider_name='openai',
                provider_url='https://api.openai.com/v1/',
                provider_details={'status': 'completed'},
                provider_response_id=IsStr(),
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_dated_ga_snapshot_ignores_thinking(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """The dated GA snapshot completes a turn without receiving unsupported `reasoning` config."""
    provider, cassette = openai_ws_cassette
    model = OpenAIRealtimeModel(
        'gpt-realtime-2025-08-28',
        provider=provider,
        settings=OpenAIRealtimeModelSettings(thinking='low', output_modality='text'),
    )

    events: list[Any] = []
    async with Agent(instructions='Answer in two or three words.').realtime(model).session() as session:
        await session.send('Say a short greeting.')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    session_updates = sent_frames_containing(cassette, 'session.update')
    assert len(session_updates) == 1
    assert 'reasoning' not in session_updates[0]['session']
    assert any(isinstance(event, PartEndEvent) for event in events)
    assert isinstance(events[-1], RealtimeTurnCompleteEvent)


async def test_thinking_false_turns_reasoning_off(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """`thinking=False` sends `reasoning.effort: 'none'`, which a reasoning model accepts and honors."""
    provider, cassette = openai_ws_cassette
    model = OpenAIRealtimeModel(
        'gpt-realtime-2.1-mini',
        provider=provider,
        settings=OpenAIRealtimeModelSettings(thinking=False, output_modality='text'),
    )

    events: list[Any] = []
    async with Agent(instructions='Answer with the number only.').realtime(model).session() as session:
        await session.send(
            'A bat and a ball cost 1.10 total; the bat costs 1 more than the ball. What does the ball cost?'
        )
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    session_updates = sent_frames_containing(cassette, 'session.update')
    assert len(session_updates) == 1
    assert session_updates[0]['session']['reasoning'] == {'effort': 'none'}
    assert not any(isinstance(event, RealtimeSessionErrorEvent) for event in events)
    response = session.all_messages()[-1]
    assert isinstance(response, ModelResponse)
    assert response.usage.output_tokens > 0
    # Left at its default effort, this model spends tens of reasoning tokens on this question.
    assert 'reasoning_tokens' not in response.usage.details


async def test_audio_in_server_vad_turn(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette], assets_path: Path
) -> None:
    """A spoken user turn (audio in, server VAD) is transcribed into a user turn in history.

    The default microphone workflow — no explicit turn control, input transcription on by default —
    must land the user's turn in history, not just the assistant's reply. This is the end-to-end
    guard for the dropped-user-turn bug: without a transcription default, an audio-only turn produces
    neither an `InputTranscript` nor a retained recording, so `all_messages()` would hold only the
    assistant response.

    It also guards live-transcript *attribution*. OpenAI transcribes the user's audio asynchronously,
    so this recording interleaves the two speakers' transcripts delta by delta. Each delta must be
    attributable on its own — via `SpeechPartDelta.speaker` — and the two concurrently-assembling
    parts must hold distinct indices (they were both 0 once, which made the interleaved stream
    impossible to split).
    """
    provider, _ = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    agent = Agent(instructions='Reply in a few words.')
    pcm = assets_path.joinpath('marcelo_24khz.pcm').read_bytes()

    events: list[Any] = []
    async with agent.realtime(model).session() as session:
        # Stream the clip in ~100 ms chunks like a live mic; the trailing silence lets server VAD end
        # the turn without any manual `commit_audio()`.
        for start in range(0, len(pcm), 4800):
            await session.send_audio(pcm[start : start + 4800])
        with anyio.fail_after(45):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    # Pin the canonical spoken-turn event order: speech start -> stop -> user turn -> assistant reply.
    assert collapse_event_types(events) == snapshot(
        [
            'RealtimeInputSpeechStartEvent',
            'RealtimeInputSpeechEndEvent',
            'PartStartEvent',
            'PartDeltaEvent',
            'PartStartEvent',
            'PartDeltaEvent',
            'PartEndEvent',
            'PartDeltaEvent',
            'PartEndEvent',
            'RealtimeTurnCompleteEvent',
        ]
    )

    # Reassembling both transcripts from the deltas alone — no correlating back to a `PartStartEvent` —
    # recovers each speaker's turn intact, which is only possible if every delta names its speaker.
    speakers_by_index = {
        e.index: e.part.speaker for e in events if isinstance(e, PartStartEvent) and isinstance(e.part, SpeechPart)
    }
    streamed = {'user': '', 'assistant': ''}
    for event in events:
        if isinstance(event, PartDeltaEvent) and isinstance(delta := event.delta, SpeechPartDelta):
            if delta.transcript_delta:
                assert delta.speaker is not None
                # The delta agrees with the part it belongs to, so either is usable on its own.
                assert delta.speaker == speakers_by_index[event.index]
                streamed[delta.speaker] += delta.transcript_delta
    # Two parts assembled at once, on distinct indices, one per speaker.
    assert sorted(speakers_by_index.values()) == ['assistant', 'user']
    assert streamed['user'].strip() == snapshot('Hello, my name is Marcelo.')
    # The model says a curly apostrophe, normalized here to a straight one: the smartquote
    # pre-commit hook rewrites a literal curly quote in source, which would break the comparison.
    assert streamed['assistant'].strip().replace('\u2019', "'") == snapshot(
        'Hello, Marcelo! Great to meet you. How can I help you today?'
    )

    messages = session.all_messages()
    # The spoken turn is transcribed into a user request ahead of the assistant's reply.
    assert [type(m).__name__ for m in messages] == snapshot(['ModelRequest', 'ModelResponse'])
    user_turn = messages[0]
    assert isinstance(user_turn, ModelRequest)
    user_part = user_turn.parts[0]
    assert isinstance(user_part, SpeechPart)
    assert user_part.speaker == 'user'
    assert user_part.transcript == snapshot('Hello, my name is Marcelo.')
    reply = messages[1]
    assert isinstance(reply, ModelResponse)
    assert isinstance(reply.parts[0], SpeechPart)
    assert session.usage == snapshot(
        RunUsage(
            input_tokens=41,
            output_tokens=164,
            input_audio_tokens=27,
            output_audio_tokens=136,
            details={
                'input_transcription_seconds': 3,
                'input_text_tokens': 14,
                'input_image_tokens': 0,
                'output_text_tokens': 28,
                'audio_tokens': 136,
            },
            cost=Decimal('0.010072'),
            requests=1,
        )
    )
    assert reply.usage.details.get('input_transcription_seconds') is None


@pytest.mark.realtime_ws_hold_open
async def test_idle_timeout_nudge_is_not_a_user_turn(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """Server VAD's `idle_timeout_ms` makes the model follow up after silence without recording a user turn.

    When it fires, OpenAI commits the silent input audio as an empty user item and starts a response to it.
    Nobody spoke, so history must hold the follow-up reply but no (empty) spoken user turn.
    """
    provider, cassette = openai_ws_cassette
    recording = not cassette.interactions
    model = OpenAIRealtimeModel(
        'gpt-realtime-2.1-mini',
        provider=provider,
        settings=OpenAIRealtimeModelSettings(openai_turn_detection={'type': 'server_vad', 'idle_timeout_ms': 5000}),
    )
    agent = Agent(instructions='Reply in a few words.')
    silence = bytes(4800)  # 100 ms of 24 kHz PCM16

    events: list[Any] = []
    async with agent.realtime(model).session() as session:
        # The timeout counts from the end of the model's last reply, so there has to be one.
        await session.send('Say hi in two words.')
        turns = 0
        with anyio.fail_after(60):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    turns += 1
                    if turns == 2:
                        break
                    # The timeout runs on the wire clock, so the silence streams at a microphone's pace.
                    for _ in range(80):
                        await cassette.before_audio_send()
                        await session.send_audio(silence)
                        await anyio.sleep(0.1 if recording else 0)

    assert not any(
        isinstance(event, PartStartEvent) and isinstance(event.part, SpeechPart) and event.part.speaker == 'user'
        for event in events
    )
    messages = session.all_messages()
    assert [type(m).__name__ for m in messages] == snapshot(['ModelRequest', 'ModelResponse', 'ModelResponse'])
    assert [part.transcript for m in messages for part in m.parts if isinstance(part, SpeechPart)] == snapshot(
        ['Hi there.', "Hey, I'm still here! Anything you want to chat about?"]
    )


@pytest.mark.realtime_ws_hold_open
async def test_auto_input_transcription_uses_gpt_live_transcribe(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette], assets_path: Path
) -> None:
    """`input_transcription_model='auto'` transcribes a spoken turn with `gpt-live-transcribe` on OpenAI.

    Its final transcript can arrive after the reply's turn is complete (as in this recording), and still lands
    in the user turn it describes.
    """
    provider, cassette = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime-2.1-mini', provider=provider)
    agent = Agent(instructions='Reply in a few words.')
    pcm = assets_path.joinpath('marcelo_24khz.pcm').read_bytes()

    order: list[str] = []
    async with agent.realtime(model).session() as session:
        for start in range(0, len(pcm), 4800):
            await session.send_audio(pcm[start : start + 4800])
        with anyio.fail_after(45):
            async for event in session:  # pragma: no branch
                if isinstance(event, RealtimeTurnCompleteEvent):
                    order.append('turn complete')
                elif isinstance(event, PartEndEvent) and isinstance(event.part, SpeechPart):
                    order.append(f'{event.part.speaker} part end')
                if 'turn complete' in order and 'user part end' in order:
                    break

    assert order == snapshot(['assistant part end', 'turn complete', 'user part end'])

    [session_update] = [
        frame
        for frame in sent_frames_containing(cassette, 'Reply in a few words.')
        if frame['type'] == 'session.update'
    ]
    assert session_update['session']['audio']['input']['transcription'] == {'model': 'gpt-live-transcribe'}
    user_turn = session.all_messages()[0]
    assert isinstance(user_turn, ModelRequest)
    assert [part.transcript for part in user_turn.parts if isinstance(part, SpeechPart)] == snapshot(
        ['Hello, my name is Marcelo.']
    )


@pytest.mark.realtime_ws_hold_open
async def test_input_audio_retention_segments_three_server_vad_turns(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette], assets_path: Path
) -> None:
    """Every retained OpenAI input turn ends at its own server-VAD boundary.

    Each turn sends the same schedule: one clip plus two seconds of trailing silence. Server VAD cuts
    the turn partway through, so what is retained must always be *less* than the schedule — a turn
    that retains all of it is one that carried the previous turn's leftovers as its own prefix.
    """
    provider, cassette = openai_ws_cassette
    recording = not cassette.interactions
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    agent = Agent(instructions='Reply in two or three words.')
    pcm = assets_path.joinpath('marcelo_24khz.pcm').read_bytes() + bytes(96_000)
    retained_pcm: list[int] = []

    async with agent.realtime(model).session(audio_retention='input_audio') as session:
        turn_completed = anyio.Event()

        async def consume() -> None:
            async for event in session:  # pragma: no branch - always returns on the third turn
                if (
                    isinstance(event, PartEndEvent)
                    and isinstance(event.part, SpeechPart)
                    and event.part.speaker == 'user'
                    and event.part.audio is not None
                ):
                    retained_pcm.append(len(event.part.audio.data) - _WAV_HEADER_BYTES)
                elif isinstance(event, RealtimeTurnCompleteEvent):
                    turn_completed.set()
                    if len(retained_pcm) == 3:
                        return

        async with anyio.create_task_group() as tg:
            tg.start_soon(consume)
            for _ in range(3):
                turn_completed = anyio.Event()
                for offset in range(0, len(pcm), 4_800):
                    await session.send_audio(pcm[offset : offset + 4_800])
                    await anyio.sleep(0.1 if recording else 0)
                with anyio.fail_after(45):
                    await turn_completed.wait()
                await anyio.sleep(1 if recording else 0)

    assert len(pcm) == 359_424
    assert retained_pcm == [206_400, 321_024, 325_824]
    assert all(retained < len(pcm) for retained in retained_pcm)


async def test_tool_call_round(openai_ws_cassette: tuple[Provider[Any], RealtimeCassette]) -> None:
    """A tool call is executed by the session and its result folded back into a classic-shaped history.

    Consumed the way the docs tell you to — stopping on `RealtimeTurnCompleteEvent` — against a real recording,
    where the protocol suppresses the function-call-only `response.done` and the *only* terminal frame is
    the answer's. That makes this the case a turn boundary derived from the suppressed response's
    bookkeeping would silently swallow, leaving the loop hanging until the socket closed.
    """
    provider, cassette = openai_ws_cassette
    model = OpenAIRealtimeModel(
        'gpt-realtime', provider=provider, settings=OpenAIRealtimeModelSettings(output_modality='text')
    )
    agent = Agent(instructions='Use the get_weather tool for any weather question, then answer in one short sentence.')

    @agent.tool_plain
    def get_weather(city: str) -> str:
        """Look up the weather for a city."""
        return f'It is foggy and 12 degrees in {city}.'

    events: list[Any] = []
    async with agent.realtime(model).session() as session:
        await session.send('What is the weather in London?')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    # One turn boundary, after the tool round is over — not one per response.
    assert [type(event).__name__ for event in events].count('RealtimeTurnCompleteEvent') == 1
    assert sent_frames_containing(cassette, 'Look up the weather for a city.') == snapshot(
        [
            {
                'type': 'session.update',
                'session': {
                    'type': 'realtime',
                    'instructions': 'Use the get_weather tool for any weather question, then answer in one short sentence.',
                    'output_modalities': ['text'],
                    'audio': {
                        'input': {
                            'format': {'type': 'audio/pcm', 'rate': 24000},
                            'turn_detection': {
                                'type': 'server_vad',
                                'create_response': True,
                                'interrupt_response': True,
                            },
                            'transcription': {'model': 'gpt-realtime-whisper'},
                        },
                        'output': {'format': {'type': 'audio/pcm', 'rate': 24000}},
                    },
                    'tools': [
                        {
                            'type': 'function',
                            'name': 'get_weather',
                            'parameters': {
                                'additionalProperties': False,
                                'properties': {'city': {'type': 'string'}},
                                'required': ['city'],
                                'type': 'object',
                            },
                            'description': 'Look up the weather for a city.',
                        }
                    ],
                },
            }
        ]
    )

    call_events = [e for e in events if isinstance(e, FunctionToolCallEvent)]
    result_events = [e for e in events if isinstance(e, FunctionToolResultEvent)]
    assert len(call_events) == 1
    assert call_events[0].part.tool_name == 'get_weather'
    assert call_events[0].part.args_as_dict() == {'city': 'London'}
    assert len(result_events) == 1
    assert isinstance(result_events[0].part, ToolReturnPart)
    assert result_events[0].part.content == 'It is foggy and 12 degrees in London.'

    messages = session.all_messages()
    assert [type(m).__name__ for m in messages] == snapshot(
        ['ModelRequest', 'ModelResponse', 'ModelRequest', 'ModelResponse']
    )
    assert messages[0] == ModelRequest(
        parts=[UserPromptPart(content='What is the weather in London?', timestamp=IsDatetime())],
        timestamp=IsDatetime(),
        conversation_id=IsStr(),
        run_id=IsStr(),
    )
    tool_response = messages[1]
    assert isinstance(tool_response, ModelResponse)
    assert tool_response.parts == [ToolCallPart(tool_name='get_weather', args=IsStr(), tool_call_id=IsStr())]
    assert (tool_response.usage.input_tokens, tool_response.usage.output_tokens) == (63, 22)
    # Recorded from the function-call-only `response.done`'s usage, it carries the same provider fields
    # as every other response rather than dropping the `status` its suppressed `ResponseDone` held.
    assert (tool_response.provider_details, tool_response.provider_response_id, tool_response.finish_reason) == (
        {'status': 'completed'},
        IsStr(),
        'tool_call',
    )
    tool_return = messages[2]
    assert isinstance(tool_return, ModelRequest)
    assert tool_return.parts == [
        ToolReturnPart(
            tool_name='get_weather',
            content='It is foggy and 12 degrees in London.',
            tool_call_id=IsStr(),
            timestamp=IsDatetime(),
        )
    ]
    final = messages[3]
    assert isinstance(final, ModelResponse)
    assert (final.usage.input_tokens, final.usage.output_tokens) == (103, 13)
    final_part = final.parts[0]
    # The session runs in text-output modality, so the reply is a `TextPart`, not a `SpeechPart`.
    assert isinstance(final_part, TextPart)
    assert 'fog' in final_part.content.lower()

    # Usage from BOTH provider responses is accounted for. The intermediate function-call-only
    # response's `response.done` maps to no turn event (the turn isn't over), but its tokens are
    # still counted — the connection emits a `SessionUsage` for every `response.done`, so a
    # tool-calling turn reports two usage updates, not just the final text response's.
    assert session.usage.requests == 2
    assert session.usage.input_tokens > 0 and session.usage.output_tokens > 0


async def test_pruned_tool_items_stop_costing_input_tokens(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """With `openai_prune_tool_items`, a tool round's items leave the server conversation once it is answered.

    The tool returns a long report, so the next response's input tokens show whether the server still reads it.
    History keeps the round.
    """
    provider, cassette = openai_ws_cassette
    model = OpenAIRealtimeModel(
        'gpt-realtime',
        provider=provider,
        settings=OpenAIRealtimeModelSettings(output_modality='text', openai_prune_tool_items=True),
    )
    agent = Agent(
        instructions='Use the weather_report tool for any weather question, then answer in one short sentence.'
    )

    @agent.tool_plain
    def weather_report(city: str) -> str:
        """Fetch the full weather station report for a city."""
        return f'Station report for {city}: foggy, 12 degrees, light wind from the west. ' * 150

    async def reply_to(text: str) -> None:
        await session.send(text)
        with anyio.fail_after(30):
            async for event in stream:  # pragma: no branch
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    async with agent.realtime(model).session() as session:
        stream = session.__aiter__()
        await reply_to('What is the weather in London?')
        await reply_to('Thanks! Now just say goodbye.')

    deleted = [
        frame for frame in sent_frames_containing(cassette, 'item_id') if frame['type'] == 'conversation.item.delete'
    ]
    assert len(deleted) == 2
    responses = [message for message in session.all_messages() if isinstance(message, ModelResponse)]
    assert [response.usage.input_tokens for response in responses] == snapshot([65, 2795, 102])
    assert any(isinstance(part, ToolReturnPart) for message in session.all_messages() for part in message.parts), (
        'history keeps the round'
    )


async def test_tool_can_close_session(openai_ws_cassette: tuple[Provider[Any], RealtimeCassette]) -> None:
    """A provider-requested tool can hang up without wedging its own task or the session iterator."""
    provider, _ = openai_ws_cassette
    model = OpenAIRealtimeModel(
        'gpt-realtime', provider=provider, settings=OpenAIRealtimeModelSettings(output_modality='text')
    )
    agent = Agent[None, str](
        deps_type=type(None), instructions='Always call the hang_up tool immediately when asked to end the call.'
    )

    @agent.tool
    async def hang_up(ctx: RunContext[None]) -> None:
        """End the call now."""
        assert ctx.realtime_session is not None
        await ctx.realtime_session.close()

    async with agent.realtime(model).session() as session:
        await session.send('End the call now by calling hang_up.')
        with anyio.fail_after(30):
            _ = [event async for event in session]

    assert session.closed
    assert session.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='End the call now by calling hang_up.', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                run_id=(run_id := IsSameStr()),
                conversation_id=(conversation_id := IsSameStr()),
            ),
            ModelResponse(
                parts=[ToolCallPart(tool_name='hang_up', args='{}', tool_call_id=(tool_call_id := IsSameStr()))],
                usage=RequestUsage(cost=Decimal('0.0')),
                model_name='gpt-realtime',
                timestamp=IsDatetime(),
                provider_name='openai',
                provider_url='https://api.openai.com/v1/',
                provider_response_id='resp_EKSmUJpNeUEiyalwKu31r',
                run_id=run_id,
                conversation_id=conversation_id,
                state='interrupted',
            ),
            ModelRequest(
                parts=[
                    ToolReturnPart(
                        tool_name='hang_up',
                        content='The tool call was interrupted before a result was produced.',
                        tool_call_id=tool_call_id,
                        timestamp=IsDatetime(),
                        outcome='interrupted',
                    )
                ],
                timestamp=IsDatetime(),
                run_id=run_id,
                conversation_id=conversation_id,
            ),
        ]
    )


@pytest.mark.realtime_ws_hold_open
async def test_tool_error_ends_transcript_only_session(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """A raising tool ends a transcript-only consumer instead of leaving the live session mute."""
    provider, _ = openai_ws_cassette
    model = OpenAIRealtimeModel(
        'gpt-realtime', provider=provider, settings=OpenAIRealtimeModelSettings(output_modality='text')
    )
    agent = Agent(instructions='Use the get_weather tool for any weather question.')

    @agent.tool_plain
    async def get_weather(city: str) -> str:
        """Look up the weather for a city."""
        raise ValueError(f'weather service unavailable for {city}')

    session: RealtimeSession | None = None
    with pytest.raises(ValueError, match='weather service unavailable for London'):
        async with agent.realtime(model).session() as session:
            await session.send('What is the weather in London?')
            with anyio.fail_after(30):
                assert [part async for part in session.stream_transcripts()] == []

    assert session is not None
    assert session.all_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='What is the weather in London?', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[
                    ToolCallPart(
                        tool_name='get_weather',
                        args=IsStr(),
                        tool_call_id=IsStr(),
                    )
                ],
                usage=RequestUsage(cost=Decimal('0.0')),
                model_name='gpt-realtime',
                timestamp=IsDatetime(),
                provider_name='openai',
                provider_url='https://api.openai.com/v1/',
                provider_response_id='resp_EKSoZDrBYT3y3OzgBEMya',
                run_id=IsStr(),
                conversation_id=IsStr(),
                state='interrupted',
            ),
            ModelRequest(
                parts=[
                    ToolReturnPart(
                        tool_name='get_weather',
                        content='The tool raised an unhandled error.',
                        tool_call_id=IsStr(),
                        timestamp=IsDatetime(),
                        outcome='failed',
                    )
                ],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


async def test_message_history_seeding(openai_ws_cassette: tuple[Provider[Any], RealtimeCassette]) -> None:
    """Seeded prior turns are sent on the wire and reflected in the model's reply."""
    provider, cassette = openai_ws_cassette
    model = OpenAIRealtimeModel(
        'gpt-realtime', provider=provider, settings=OpenAIRealtimeModelSettings(output_modality='text')
    )
    agent = Agent()

    history = [
        ModelRequest(parts=[UserPromptPart(content='My name is Alice and my favorite color is teal.')]),
        ModelResponse(parts=[TextPart(content='Nice to meet you, Alice!')]),
    ]

    events: list[Any] = []
    async with agent.realtime(model, message_history=history).session() as session:
        await session.send('What is my name and favorite color?')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    # A server-side rejection of the seeded items (e.g. a bad content-type shape) surfaces as a
    # `RealtimeSessionErrorEvent`; assert none occurred so a broken seed payload fails the test loudly.
    assert [event for event in events if isinstance(event, RealtimeSessionErrorEvent)] == []

    # The seeded user/assistant turns were sent as `conversation.item.create` frames on the wire.
    assert sent_frames_containing(cassette, 'My name is Alice') == snapshot(
        [
            {
                'type': 'conversation.item.create',
                'item': {
                    'type': 'message',
                    'role': 'user',
                    'content': [{'type': 'input_text', 'text': 'My name is Alice and my favorite color is teal.'}],
                },
            }
        ]
    )
    # The seeded assistant turn is sent as an `output_text` item (its own serialization path, distinct
    # from the user seed above), so a wrong role/item/content shape fails here rather than passing on a
    # mere substring match.
    assert sent_frames_containing(cassette, 'Nice to meet you') == snapshot(
        [
            {
                'type': 'conversation.item.create',
                'item': {
                    'type': 'message',
                    'role': 'assistant',
                    'content': [{'type': 'output_text', 'text': 'Nice to meet you, Alice!'}],
                },
            }
        ]
    )

    # `all_messages()` carries the seeded history ahead of this session's turns.
    messages = session.all_messages()
    assert messages[:2] == history
    reply = messages[-1]
    assert isinstance(reply, ModelResponse)
    reply_part = reply.parts[0]
    # Text-output modality → a `TextPart` reply.
    assert isinstance(reply_part, TextPart)
    content = reply_part.content.lower()
    assert 'alice' in content and 'teal' in content


@pytest.mark.usefixtures('no_genai_prices_context_window')
def test_profile_allow_seeding() -> None:
    """Unit guard: the model advertises session seeding, which the seeding cassette test relies on.

    Kept as a plain unit assertion (not a cassette test) because it pins an intrinsic capability flag
    that a recording wouldn't protect.
    """
    profile = OpenAIRealtimeModel('gpt-realtime').profile
    assert profile == RealtimeModelProfile(
        supports_image_input=True,
        image_input_requires_response=False,
        supports_manual_turn_control=True,
        supports_interruption=True,
        supports_output_truncation=True,
        supports_text_output=True,
        supports_session_seeding=True,
        supports_webrtc=True,
        supports_seeding_images=True,
        supports_seeding_audio=True,
        supports_thinking=False,  # GA `gpt-realtime` is not a reasoning model
        async_tool_call_mode='always',  # the realtime models keep talking through a tool call
        supports_async_tool_calls=True,  # deprecated, derived from `async_tool_call_mode`
        supports_tool_return_schema=False,  # no native surface; opted-in schemas go into descriptions
        supported_native_tools=frozenset(),
        emits_input_speech_events=True,
        synthesizes_turn_boundary=False,
        responses_are_requests=True,
        response_usage_covers_context=True,
        audio_input_sample_rate=24000,
        audio_output_sample_rate=24000,
        context_window=None,
    )


# Applies the provider's WebRTC answer to the media peer, connecting the audio path.
MediaConnect = Callable[[str], Awaitable[None]]


async def _no_media_to_connect(answer_sdp: str) -> None:
    """Replay's `MediaConnect`: the recorded control frames already carry the playback boundaries."""


@asynccontextmanager
async def _live_webrtc_media_peer() -> AsyncGenerator[tuple[str, MediaConnect]]:  # pragma: no cover
    """Negotiate a real WebRTC call with `aiortc`, standing in for the browser that owns the media.

    Recording only — see `_webrtc_media_peer`. `aiortc` is not a project dependency (it pulls in a
    media stack no offline test needs), so it's imported dynamically and installed ad hoc when
    recording: `uv run --with aiortc --env-file .env pytest ... --record-mode=rewrite`.
    """
    aiortc = importlib.import_module('aiortc')
    mediastreams = importlib.import_module('aiortc.mediastreams')

    # No STUN server: a server-reflexive candidate would put the recorder's own public address in the
    # cassette, and OpenAI's ICE-lite endpoint is reachable from the host candidates alone.
    pc = aiortc.RTCPeerConnection(aiortc.RTCConfiguration(iceServers=[]))
    pc.addTrack(mediastreams.AudioStreamTrack())

    @pc.on('track')
    def _drain_inbound_audio(track: Any) -> None:
        # The provider stops filling its output buffer if nobody reads the track, which would cut the
        # playback window this recording exists to capture.
        async def pump() -> None:
            while True:
                try:
                    await track.recv()
                except Exception:
                    return

        asyncio.ensure_future(pump())

    await pc.setLocalDescription(await pc.createOffer())
    while pc.iceGatheringState != 'complete':
        await anyio.sleep(0.1)

    async def connect(answer_sdp: str) -> None:
        await pc.setRemoteDescription(aiortc.RTCSessionDescription(sdp=answer_sdp, type='answer'))

    try:
        yield pc.localDescription.sdp, connect
    finally:
        await pc.close()


@asynccontextmanager
async def _webrtc_media_peer(*, recording: bool) -> AsyncGenerator[tuple[str, MediaConnect]]:
    """The browser side of a WebRTC call, as `(offer_sdp, connect)`.

    The provider reports playback boundaries (`output_audio_buffer.*`, and so the `OutputSpeech*`
    events) only while media is actually flowing: it answers a canned offer that never completes ICE
    quite happily, but then never sends a single playback frame. So a recording that is to contain
    them needs a real peer, which `aiortc` negotiates headlessly.

    Replay needs no peer at all — the cassette holds the frames, and dialling a recorded answer's
    long-dead ICE candidates would put real UDP traffic in an offline test — so it reuses the canned
    offer and connects nothing. The recorded offer is never matched on, so the two are interchangeable.
    """
    if recording:  # pragma: no cover
        async with _live_webrtc_media_peer() as peer:
            yield peer
        return
    yield REAL_SDP_OFFER, _no_media_to_connect


@pytest.mark.vcr
async def test_webrtc_sideband_text_turn(
    openai_ws_sideband_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """The secure WebRTC flow end to end: relay the offer over HTTP, then run the agent over the sideband.

    The HTTP offer relay is a VCR cassette; the control WebSocket (attached by `call_id`) is a WS
    cassette. The browser's media path isn't involved — this proves the server-side control plane: the
    sideband applies the session config, runs the tool-free turn, and builds the conversation history,
    while the audio methods are unavailable because the session doesn't own the media transport.
    """
    provider, cassette = openai_ws_sideband_cassette
    model = OpenAIRealtimeModel(
        'gpt-realtime', provider=provider, settings=OpenAIRealtimeModelSettings(output_modality='text')
    )
    agent = Agent(instructions='Answer in two words.')

    answer = await model.answer_webrtc_offer(REAL_SDP_OFFER, instructions='Answer in two words.')
    assert answer.sdp.startswith('v=0')
    assert answer.session.provider_name == 'openai'
    assert answer.session.call_id.startswith('rtc_')

    events: list[Any] = []
    async with agent.realtime(model).session(provider_session=answer.session) as session:
        # The sideband doesn't own the audio transport, so the audio methods are unavailable.
        with pytest.raises(UserError, match='does not own the audio transport'):
            await session.send_audio(b'\x00\x00')

        # It sees no output-audio deltas either, which is what makes a barge-in clear the provider's
        # outbound buffer instead of clamping a truncation against a byte counter that stays zero.
        connection = session._connection  # pyright: ignore[reportPrivateUsage]
        assert isinstance(connection, OpenAIRealtimeConnection)
        assert not connection._observes_output_audio  # pyright: ignore[reportPrivateUsage]

        await session.send('Say hello.')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch - the loop always breaks on RealtimeTurnCompleteEvent
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    # The first control frame applies the session config (no `session.created` handshake wait).
    assert cassette.interactions[0].data['type'] == 'session.update'  # type: ignore[union-attr]

    assert [event for event in events if isinstance(event, RealtimeSessionErrorEvent)] == []
    messages = session.all_messages()
    assert [type(m).__name__ for m in messages] == snapshot(['ModelRequest', 'ModelResponse'])
    assert messages[0] == ModelRequest(
        parts=[UserPromptPart(content='Say hello.', timestamp=IsDatetime())],
        timestamp=IsDatetime(),
        conversation_id=IsStr(),
        run_id=IsStr(),
    )
    reply = messages[1]
    assert isinstance(reply, ModelResponse)
    assert reply.model_name == 'gpt-realtime'
    assert isinstance(reply.parts[0], TextPart)


def _span_tree(spans: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Render exported spans as nested `{name, msg, children}` dicts, ordered by start time.

    Spans are keyed by both their OTel name and their `logfire.msg` — the latter is what a user
    actually reads in Logfire (a `chat {model}` span displays as `response {model}`), so a rename of
    either can't slip through unnoticed.
    """
    by_id = {span['context']['span_id']: span for span in spans}
    children: dict[int | None, list[dict[str, Any]]] = {}
    for span in spans:
        parent = span['parent']
        parent_id = parent['span_id'] if parent is not None and parent['span_id'] in by_id else None
        children.setdefault(parent_id, []).append(span)

    def render(span: dict[str, Any]) -> dict[str, Any]:
        kids = sorted(children.get(span['context']['span_id'], []), key=lambda child: child['start_time'])
        return {
            'name': span['name'],
            'msg': span['attributes'].get('logfire.msg'),
            'children': [render(kid) for kid in kids],
        }

    return [render(root) for root in sorted(children.get(None, []), key=lambda span: span['start_time'])]


@pytest.mark.vcr
async def test_webrtc_hang_up_ends_the_call(
    openai_ws_sideband_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """`hang_up()` on a sideband ends the browser's call; `close()` alone would only detach from it.

    Hanging up again finds no call to end, which is not an error. The offer and both hangups are an HTTP
    VCR cassette, the sideband a WebSocket cassette.
    """
    provider, _ = openai_ws_sideband_cassette
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    realtime = Agent(instructions='Answer in two words.').realtime(model)

    answer = await realtime.answer_webrtc_offer(REAL_SDP_OFFER)
    async with realtime.session(provider_session=answer.session) as session:
        await session.hang_up()
    assert session.closed

    # The call is gone now: hanging it up again, without a sideband, finds nothing to end.
    await realtime.hang_up(answer.session)


@pytest.mark.vcr
@pytest.mark.skipif(not logfire_imports_successful(), reason='logfire not installed')
async def test_webrtc_sideband_audio_turn(
    openai_ws_sideband_cassette: tuple[Provider[Any], RealtimeCassette],
    request: pytest.FixtureRequest,
    capfire: CaptureLogfire,
) -> None:
    """A sideband session in the default audio modality, where the provider reports playback.

    The sideband never sees an audio byte — the browser holds the media — so the only thing that tells
    the session when the model is *audible* is the provider's `output_audio_buffer.*` frames. This is
    the one recording that contains them (a canned offer that never completes ICE yields none, which is
    how a barge-in bug on this path went unnoticed), pinning that they arrive at all, that they bracket
    the turn as `RealtimeOutputSpeechStartEvent` / `RealtimeOutputSpeechEndEvent`, and that speech outlasts generation:
    the end event lands *after* `RealtimeTurnCompleteEvent`, which is exactly the gap the `speak` span measures
    and the reason it can't be derived from the turn spans.
    """
    provider, _ = openai_ws_sideband_cassette
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    # Default `InstrumentationSettings`, so the trace is the one a user gets from `logfire.configure()`.
    agent = Agent(instructions='Answer in two words.', capabilities=[Instrumentation()])

    recording = request.config.getoption('record_mode') == 'rewrite'
    async with _webrtc_media_peer(recording=recording) as (offer_sdp, connect_media):
        answer = await model.answer_webrtc_offer(offer_sdp, instructions='Answer in two words.')
        await connect_media(answer.sdp)

        events: list[Any] = []
        async with agent.realtime(model).session(provider_session=answer.session) as session:
            await session.send('Say hello.')
            with anyio.fail_after(60):
                async for event in session:  # pragma: no branch - the loop always breaks on the end event
                    events.append(event)
                    if isinstance(event, RealtimeOutputSpeechEndEvent):
                        break

    assert [event for event in events if isinstance(event, RealtimeSessionErrorEvent)] == []
    assert collapse_event_types(events) == snapshot(
        [
            'PartStartEvent',
            'PartDeltaEvent',
            'RealtimeOutputSpeechStartEvent',
            'PartEndEvent',
            'RealtimeTurnCompleteEvent',
            'RealtimeOutputSpeechEndEvent',
        ]
    )

    # The turn lands in history as a spoken assistant turn with a transcript — and only a transcript,
    # since no audio bytes reach a sideband session.
    messages = session.all_messages()
    assert [type(m).__name__ for m in messages] == snapshot(['ModelRequest', 'ModelResponse'])
    assert messages[0] == ModelRequest(
        parts=[UserPromptPart(content='Say hello.', timestamp=IsDatetime())],
        timestamp=IsDatetime(),
        conversation_id=IsStr(),
        run_id=IsStr(),
    )
    reply = messages[1]
    assert isinstance(reply, ModelResponse)
    assert reply.model_name == 'gpt-realtime'
    part = reply.parts[0]
    assert isinstance(part, SpeechPart)
    assert part.speaker == 'assistant'
    assert part.transcript == snapshot('Hello there.')
    assert part.audio is None

    # The `speak` span hangs off the session span, alongside the turn's own spans.
    assert _span_tree(capfire.exporter.exported_spans_as_dict()) == snapshot(
        [
            {
                'name': 'invoke_agent agent',
                'msg': 'agent realtime',
                'children': [
                    {'name': 'chat gpt-realtime', 'msg': 'response gpt-realtime', 'children': []},
                    {'name': 'speak gpt-realtime', 'msg': 'speak gpt-realtime', 'children': []},
                    {'name': 'model turn complete', 'msg': 'model turn complete', 'children': []},
                ],
            }
        ]
    )


async def test_handle_barge_in_over_live_speech(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette], assets_path: Path
) -> None:
    """`handle_barge_in=True` runs the whole barge-in against the live protocol.

    The user speaks over the model's reply: the session must send the truncation on its own — and
    *only* the truncation, because with the default `interrupt_response: true` server VAD the
    provider cancels the response itself (`reason: turn_detected`), and a client cancel racing that
    was observed being applied to the *next* response, silencing the reply to the barge-in. The
    provider must accept the truncate, and the session must stay usable: the barged-in utterance
    still gets a completed reply. The playback position is deterministic across record and replay:
    exactly one audio chunk is pulled and never confirmed, so the truncation point is 0 ms (any
    other value would be recomputed on replay from cassette-truncated chunk sizes and mismatch the
    recorded frame).
    """
    provider, cassette = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    agent = Agent(instructions='Reply in a few words.')
    pcm = assets_path.joinpath('marcelo_24khz.pcm').read_bytes()

    events: list[Any] = []
    async with agent.realtime(model).session(handle_barge_in=True) as session:
        stream = session.stream_audio()
        with anyio.fail_after(90):
            for start in range(0, len(pcm), 4800):
                await session.send_audio(pcm[start : start + 4800])
            # Wait for the reply's audio to start flowing; the chunk stays unconfirmed, pinning the
            # session's tracked playback position at 0.
            assert len(await anext(stream)) > 0
            # Speak over the reply: server VAD reports speech onset and the session barges in.
            for start in range(0, len(pcm), 4800):
                await session.send_audio(pcm[start : start + 4800])
            turns_complete = 0
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    # The interrupted reply settles as its own turn; break after the reply to the
                    # barge-in utterance.
                    turns_complete += 1
                    if turns_complete == 2:
                        break

    # The session sent the barge-in itself — nothing in this test called `interrupt()` — and left
    # the cancellation to the server's own VAD.
    truncates = sent_frames_containing(cassette, 'conversation.item.truncate')
    assert [frame['audio_end_ms'] for frame in truncates] == [0]
    assert sent_frames_containing(cassette, 'response.cancel') == []

    # The provider accepted it: the first reply settles as interrupted with the truncation point on
    # its speech part, and the barged-in utterance still got a completed reply.
    responses = [message for message in session.all_messages() if isinstance(message, ModelResponse)]
    assert [response.state for response in responses] == snapshot(['interrupted', 'complete'])
    speech = next(part for part in responses[0].parts if isinstance(part, SpeechPart))
    assert speech.interrupted_at_ms == 0


async def test_interrupt_after_the_reply_finished_generating(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """Generation outruns playback, so the user usually barges in after the reply's `response.done`.

    The reply is still being heard, so the barge-in must still truncate its item, and the provider must
    accept that for a finished response, so the model doesn't believe it was heard in full. History records
    the reply as cut off where playback stopped, keeping the transcript the provider gave (it doesn't say
    which words were heard), and the next reply is unaffected. The playback position is 0 so it replays
    deterministically.
    """
    provider, cassette = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    agent = Agent(instructions='Reply in one short sentence.')

    async with agent.realtime(model).session() as session:
        _stream = session.stream_audio()  # the single playback view the position is attributed to
        events = aiter(session)
        with anyio.fail_after(60):
            await session.send('Say hello.')
            while not isinstance(await anext(events), RealtimeTurnCompleteEvent):
                pass
            # The reply has finished generating but none of it has been played.
            assert await session.interrupt(played_bytes=0) is True
            await session.send('Say goodbye.')
            while not isinstance(await anext(events), RealtimeTurnCompleteEvent):
                pass

    truncates = sent_frames_containing(cassette, 'conversation.item.truncate')
    assert [frame['audio_end_ms'] for frame in truncates] == [0]
    # No response was active, so there was nothing to cancel.
    assert sent_frames_containing(cassette, 'response.cancel') == []
    received = [
        message.data['type']
        for message in cassette.interactions
        if isinstance(message, CassetteMessage) and message.direction == 'received'
    ]
    assert 'conversation.item.truncated' in received
    assert 'error' not in received

    responses = [message for message in session.all_messages() if isinstance(message, ModelResponse)]
    assert [response.state for response in responses] == snapshot(['interrupted', 'complete'])
    speech = [[part for part in response.parts if isinstance(part, SpeechPart)] for response in responses]
    assert [[(part.transcript, part.interrupted_at_ms) for part in parts] for parts in speech] == snapshot(
        [[('Hello! Great to connect with you.', 0)], [('Take care, talk soon!', None)]]
    )
    assert responses[0].provider_response_id is not None
    # The truncation named the first reply's output item.
    first_item = next(
        message.data['item']['id']
        for message in cassette.interactions
        if isinstance(message, CassetteMessage) and message.data.get('type') == 'response.output_item.added'
    )
    assert truncates[0]['item_id'] == first_item


async def test_interrupt_partway_through_a_finished_reply(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette],
) -> None:
    """A barge-in partway into a reply that already finished truncates it there, and history records the cut.

    The transcript stays what the provider gave (it doesn't say which words were heard), so a text model or
    a replay reads it with the interruption marker. The cassette keeps only a few bytes of each audio delta,
    so the position attributed as played (20 ms) lies within what replays too.
    """
    provider, cassette = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime', provider=provider)
    agent = Agent(instructions='Reply in two full sentences.')

    async with agent.realtime(model).session() as session:
        _stream = session.stream_audio()  # the single playback view the position is attributed to
        events = aiter(session)
        with anyio.fail_after(60):
            await session.send('Tell me about the moon.')
            while not isinstance(await anext(events), RealtimeTurnCompleteEvent):
                pass
            assert await session.interrupt(played_bytes=960) is True
            # The next turn, so the provider's acknowledgement of the truncation is read before closing.
            await session.send('Say goodbye.')
            while not isinstance(await anext(events), RealtimeTurnCompleteEvent):
                pass

    truncates = sent_frames_containing(cassette, 'conversation.item.truncate')
    assert [frame['audio_end_ms'] for frame in truncates] == snapshot([20])
    received = [
        message.data['type']
        for message in cassette.interactions
        if isinstance(message, CassetteMessage) and message.direction == 'received'
    ]
    assert 'conversation.item.truncated' in received
    assert 'error' not in received

    response, goodbye = [message for message in session.all_messages() if isinstance(message, ModelResponse)]
    assert (response.state, goodbye.state) == ('interrupted', 'complete')
    [speech] = [part for part in response.parts if isinstance(part, SpeechPart)]
    assert speech.interrupted_at_ms == snapshot(20)
    assert speech.transcript == snapshot(
        "The moon is Earth's only natural satellite, and it's the fifth largest moon in the solar system. It's about a quarter the size of Earth, and it takes roughly 27 days to orbit our planet, showing phases as it moves through its cycle."
    )


@pytest.mark.realtime_ws_hold_open
async def test_text_sent_as_server_vad_starts_a_reply_gets_one_of_its_own(
    openai_ws_cassette: tuple[Provider[Any], RealtimeCassette], assets_path: Path
) -> None:
    """Text sent just as server VAD answers a spoken turn: the reply under way never saw it.

    Server VAD starts its reply before the text joins the conversation, and OpenAI refuses the text's
    `response.create` (only once that reply is done) as another response is active. The connection asks
    again, so the wait for the text's reply ends with a reply that answers it, and the refusal it handled
    is reported to nobody.
    """
    provider, cassette = openai_ws_cassette
    model = OpenAIRealtimeModel('gpt-realtime-2.1-mini', provider=provider)
    agent = Agent(instructions='Reply in one short sentence.')
    pcm = assets_path.joinpath('marcelo_24khz.pcm').read_bytes() + bytes(48_000)

    events: list[Any] = []
    speech_ended = anyio.Event()

    async def watch(session: RealtimeSession) -> None:
        async for event in session:  # pragma: no branch
            events.append(event)
            if isinstance(event, RealtimeInputSpeechEndEvent):
                speech_ended.set()

    async with agent.realtime(model).session() as session, anyio.create_task_group() as tasks:
        tasks.start_soon(watch, session)
        for start in range(0, len(pcm), 4800):
            await session.send_audio(pcm[start : start + 4800])
        with anyio.fail_after(45):
            await speech_ended.wait()
            await session.send('Also, what is 2 plus 2? Answer with the number.')
            await session.wait_for_reply()
        tasks.cancel_scope.cancel()

    assert [event for event in events if isinstance(event, RealtimeSessionErrorEvent)] == []
    requests = [
        frame for frame in sent_frames_containing(cassette, 'response.create') if frame['type'] == 'response.create'
    ]
    assert [request['event_id'] for request in requests] == snapshot(
        ['pydantic_ai.response.65', 'pydantic_ai.response.65']
    )
    messages = session.all_messages()
    text_turn = next(
        index
        for index, message in enumerate(messages)
        if isinstance(message, ModelRequest) and any(isinstance(part, UserPromptPart) for part in message.parts)
    )
    replies = [message for message in messages[text_turn + 1 :] if isinstance(message, ModelResponse)]
    assert replies
    assert [part.transcript for part in replies[-1].parts if isinstance(part, SpeechPart)] == snapshot(
        ['Alright, let me think this through for a moment.', 'Four']
    )
