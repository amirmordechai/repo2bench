"""Tests for `RealtimeSession`: event translation, history assembly, tool dispatch, and `Agent.realtime_session`."""

from __future__ import annotations as _annotations

import asyncio
import gc
import io
import wave
from collections.abc import AsyncGenerator, AsyncIterator, Awaitable, Callable, Sequence
from contextlib import asynccontextmanager
from dataclasses import replace
from decimal import Decimal
from threading import Event as ThreadEvent
from typing import Any, Literal, TypeVar, cast
from uuid import UUID

import anyio
import pytest
from inline_snapshot import snapshot
from opentelemetry.context import Context
from pydantic import ValidationError
from pydantic_core import SchemaValidator, core_schema

from pydantic_ai import Agent, ModelRetry, RunContext
from pydantic_ai._agent_graph import resolve_conversation_id
from pydantic_ai._enqueue import PendingMessage
from pydantic_ai.capabilities import AbstractCapability, HandleDeferredToolCalls, NativeTool, WebFetch
from pydantic_ai.exceptions import (
    ApprovalRequired,
    CallDeferred,
    ModelAPIError,
    RunCancelled,
    ToolFailed,
    UnexpectedModelBehavior,
    UsageLimitExceeded,
    UserError,
)
from pydantic_ai.messages import (
    BinaryAudio,
    BinaryContent,
    BinaryImage,
    DeferredToolRequestsEvent,
    DeferredToolResultsEvent,
    EnqueuedMessagesEvent,
    FunctionToolCallEvent,
    FunctionToolResultEvent,
    InstructionPart,
    ModelMessage,
    ModelMessagesTypeAdapter,
    ModelRequest,
    ModelResponse,
    NativeToolCallPart,
    NativeToolReturnPart,
    PartDeltaEvent,
    PartEndEvent,
    PartStartEvent,
    RealtimeSessionErrorEvent,
    SpeechPart,
    SpeechPartDelta,
    SystemPromptPart,
    TextContent,
    TextPart,
    TextPartDelta,
    ToolCallPart,
    ToolReturn,
    ToolReturnPart,
    UserPromptPart,
)
from pydantic_ai.models import ModelRequestParameters
from pydantic_ai.models.function import AgentInfo, FunctionModel
from pydantic_ai.models.test import TestModel
from pydantic_ai.native_tools import AbstractNativeTool, CodeExecutionTool, WebFetchTool, WebSearchTool
from pydantic_ai.profiles import ModelProfile
from pydantic_ai.realtime import (
    RealtimeError,
    RealtimeEvent,
    RealtimeInputSpeechEndEvent,
    RealtimeInputSpeechStartEvent,
    RealtimeInputTranscriptionErrorEvent,
    RealtimeModel,
    RealtimeModelProfile,
    RealtimeModelSettings,
    RealtimeResponseInterruptedEvent,
    RealtimeSession as _RealtimeSession,
    RealtimeSessionReconnectEvent,
    RealtimeTurnCompleteEvent,
    TranscriptUpdate,
    _session as realtime_session_module,  # pyright: ignore[reportPrivateUsage]
)
from pydantic_ai.realtime._retained_audio import RetainedAudioBudget
from pydantic_ai.realtime._session import (
    _AUDIO_TAP_MAX_CHUNKS,  # pyright: ignore[reportPrivateUsage]
    _AUDIO_TAP_SECONDS,  # pyright: ignore[reportPrivateUsage]
    _pending_message_text,  # pyright: ignore[reportPrivateUsage]
    _TapView,  # pyright: ignore[reportPrivateUsage]
)
from pydantic_ai.realtime._utils import (
    resolve_advertised_tools,
    seed_pcm_audio,
    seed_speech_content,
    session_instructions,
)
from pydantic_ai.realtime.codec import (
    AudioDelta,
    CancelResponse,
    ClearAudio,
    CommitAudio,
    ConversationCreated,
    ConversationItemCreated,
    CreateResponse,
    InputRejected,
    InputTranscript,
    OutputTranscript,
    RealtimeCodecEvent,
    RealtimeConnection,
    RealtimeInput,
    ResponseDone,
    SessionUsage,
    TextContext,
    ToolCall,
    ToolCallCancelled,
    ToolResult,
    TruncateOutput,
)
from pydantic_ai.realtime.lifecycle import RealtimeFrame, ResponseEnded, ResponseStarted, StaleEvent
from pydantic_ai.settings import ModelSettings, ToolOrOutput
from pydantic_ai.tool_manager import ToolManager
from pydantic_ai.tools import DeferredToolRequests, DeferredToolResults, ToolDefinition
from pydantic_ai.toolsets import AbstractToolset, ExternalToolset, FunctionToolset
from pydantic_ai.toolsets.abstract import ToolsetTool
from pydantic_ai.usage import RequestUsage, RunUsage, UsageLimits

from ..conftest import IsDatetime, IsStr, legacy_retry_prompt_part
from ..realtime_connections import InferredConnection
from .conversation import assert_conversation_invariants

T = TypeVar('T')


def test_resolve_advertised_tools_enforces_tool_choice() -> None:
    tools = [
        ToolDefinition(name='weather', parameters_json_schema={'type': 'object'}),
        ToolDefinition(name='time', parameters_json_schema={'type': 'object'}),
    ]

    assert resolve_advertised_tools(tools, None) == (tools, None)
    assert resolve_advertised_tools(tools, 'auto') == (tools, 'auto')
    assert resolve_advertised_tools(tools, 'required') == (tools, 'required')
    assert resolve_advertised_tools(tools, 'none') == ([], 'none')
    assert resolve_advertised_tools(tools, []) == ([], 'none')
    assert resolve_advertised_tools(tools, ['weather']) == (tools[:1], ('required', {'weather'}))
    assert resolve_advertised_tools(tools, ToolOrOutput(['time'])) == (tools[1:], ('auto', {'time'}))
    assert resolve_advertised_tools(None, None) == ([], None)


def test_resolve_advertised_tools_rejects_a_tool_choice_it_cannot_honor() -> None:
    """Same errors as a standard run: a tool_choice that names nothing real is a bug, not a no-op."""
    tools = [ToolDefinition(name='weather', parameters_json_schema={'type': 'object'})]

    with pytest.raises(UserError, match='not_a_tool'):
        resolve_advertised_tools(tools, ['not_a_tool'])
    with pytest.raises(UserError, match='no function tools are defined'):
        resolve_advertised_tools(None, 'required')


def _wav_content(pcm: bytes, sample_rate: int = 24000) -> BinaryContent:
    buffer = io.BytesIO()
    with wave.open(buffer, 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(pcm)
    return BinaryContent(data=buffer.getvalue(), media_type='audio/wav')


def test_seed_pcm_audio_rejects_truncated_wav() -> None:
    audio = _wav_content(b'\x00\x01')
    truncated = BinaryContent(data=audio.data[:-2], media_type='audio/wav')

    with pytest.raises(UserError, match='not valid WAV audio'):
        seed_pcm_audio(audio=truncated, provider_name='test', sample_rate=24000)


async def _noop_runner(name: str, args: dict[str, Any], call_id: str) -> str:  # pragma: no cover
    raise AssertionError('tool runner should not be called')


_TEST_TOOL_NAMES = {
    'boom',
    'f',
    'fast',
    'get_weather',
    'hang',
    'noop',
    'slow',
}


class _RunnerToolset(AbstractToolset[None]):
    """Adapt legacy-shaped test callables to the real tool-management path."""

    def __init__(self, runner: Any):
        self.runner = runner

    @property
    def id(self) -> str:
        return 'realtime-test-runner'

    async def get_tools(self, ctx: RunContext[None]) -> dict[str, ToolsetTool[None]]:
        return {name: _toolset_tool(self, name) for name in _TEST_TOOL_NAMES}

    async def call_tool(
        self, name: str, tool_args: dict[str, Any], ctx: RunContext[None], tool: ToolsetTool[None]
    ) -> Any:
        assert ctx.tool_call_id is not None
        return await self.runner(name, tool_args, ctx.tool_call_id)


def _toolset_tool(toolset: AbstractToolset[None], name: str) -> ToolsetTool[None]:
    return ToolsetTool(
        toolset=toolset,
        tool_def=ToolDefinition(name=name, parameters_json_schema={'type': 'object', 'additionalProperties': True}),
        max_retries=1,
        args_validator=SchemaValidator(core_schema.dict_schema()),
    )


def make_tool_manager(runner: Any = _noop_runner) -> ToolManager[None]:
    toolset = _RunnerToolset(runner)
    ctx = RunContext(deps=None, model=TestModel(), usage=RunUsage(), run_step=0)
    manager = ToolManager(toolset, ctx=ctx, tools={name: _toolset_tool(toolset, name) for name in _TEST_TOOL_NAMES})
    ctx.tool_manager = manager
    return manager


def test_runner_toolset_has_stable_id() -> None:
    assert _RunnerToolset(_noop_runner).id == 'realtime-test-runner'


def RealtimeSession(connection: RealtimeConnection, runner: Any = _noop_runner, **kwargs: Any) -> _RealtimeSession:
    """Construct a session with the real `ToolManager` API while keeping test setup compact."""
    if any(name in kwargs for name in ('model_name', 'provider_name', 'provider_url')):
        kwargs['model'] = FakeRealtimeModel(
            connection,
            model_name=kwargs.pop('model_name', None),
            system=kwargs.pop('provider_name', None),
            base_url=kwargs.pop('provider_url', None),
        )
    return _RealtimeSession(connection, tool_manager=make_tool_manager(runner), **kwargs)


async def collect_events(session: _RealtimeSession) -> list[RealtimeEvent]:
    """Enter a directly constructed session and drain its public event iterator."""
    async with session:
        return [event async for event in session]


async def drain_events(session: _RealtimeSession) -> list[RealtimeEvent]:
    """Drain an already-entered session."""
    return [event async for event in session]


async def _consume_until(events: AsyncIterator[RealtimeEvent], stop: Callable[[RealtimeEvent], bool]) -> None:
    """Consume events up to and including the first one `stop` matches."""
    while not stop(await anext(events)):
        pass


def _is_delta_of(index: int) -> Callable[[RealtimeEvent], bool]:
    return lambda event: isinstance(event, PartDeltaEvent) and event.index == index


def _is_turn_complete(event: RealtimeEvent) -> bool:
    return isinstance(event, RealtimeTurnCompleteEvent)


def _speech_cuts(session: _RealtimeSession) -> list[tuple[str, list[int | None]]]:
    """Each recorded response's state and the cut positions on its speech parts."""
    return [
        (message.state, [part.interrupted_at_ms for part in message.parts if isinstance(part, SpeechPart)])
        for message in session.all_messages()
        if isinstance(message, ModelResponse)
    ]


async def aiter_to_list(iterator: AsyncIterator[T]) -> list[T]:
    return [item async for item in iterator]


def _profile(
    *,
    supports_image_input: bool = True,
    supports_manual_turn_control: bool = True,
    supports_interruption: bool = True,
    supports_output_truncation: bool = True,
    supports_text_output: bool = True,
    supports_session_seeding: bool = True,
    supported_native_tools: frozenset[type[AbstractNativeTool]] = frozenset(
        {WebSearchTool, WebFetchTool, CodeExecutionTool}
    ),
) -> RealtimeModelProfile:
    """A full-support profile with per-field overrides, so a guard test can flip one flag off."""
    return RealtimeModelProfile(
        supports_image_input=supports_image_input,
        supports_manual_turn_control=supports_manual_turn_control,
        supports_interruption=supports_interruption,
        supports_output_truncation=supports_output_truncation,
        supports_text_output=supports_text_output,
        supports_session_seeding=supports_session_seeding,
        supported_native_tools=supported_native_tools,
    )


def _reply_under_way(session: _RealtimeSession) -> bool:
    """Whether a response of the model's is under way, as the session's core has it."""
    return any(response.status is None for response in session._core._responses.values())  # pyright: ignore[reportPrivateUsage]


class FakeRealtimeConnection(InferredConnection):
    """A connection that replays a fixed list of events and records what is sent."""

    def __init__(
        self,
        events: list[RealtimeCodecEvent],
        *,
        release: asyncio.Event | None = None,
        input_transcription_enabled: bool = True,
        interrupts_response_on_speech: bool = False,
        model_name: str | None = None,
        reconnect_restores_in_flight_state: bool = True,
        after_input: bool = False,
    ) -> None:
        self._events = events
        # Whether the scripted events answer an input, and so only come once one was sent: a provider can't
        # answer what it hasn't received.
        self._after_input = after_input
        self._input_sent = asyncio.Event()
        self._release = release
        self._input_transcription_enabled = input_transcription_enabled
        self._interrupts_response_on_speech = interrupts_response_on_speech
        self._model_name = model_name
        self._reconnect_restores_in_flight_state = reconnect_restores_in_flight_state
        self.sent: list[RealtimeInput] = []

    @property
    def model_name(self) -> str | None:
        return self._model_name

    @property
    def input_transcription_enabled(self) -> bool:
        return self._input_transcription_enabled

    @property
    def interrupts_response_on_speech(self) -> bool:
        return self._interrupts_response_on_speech

    @property
    def reconnect_restores_in_flight_state(self) -> bool:
        return self._reconnect_restores_in_flight_state

    async def send_input(self, content: RealtimeInput) -> None:
        self.sent.append(content)
        self._input_sent.set()

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        if self._after_input:
            await self._input_sent.wait()
        for event in self._events:
            yield event
        if self._release is not None:
            self._release.set()


# Seconds to wait on something that should finish promptly. These guards assert that a view ends or a
# task completes *at all* — a real hang still fails, just later — so the bound only has to outlast a
# loaded CI runner. One second did not: the 3.14 all-extras cell timed out on a session teardown that
# passes ten times out of ten locally.
_LIVENESS_TIMEOUT = 5


class BlockingRealtimeConnection(FakeRealtimeConnection):
    """Replay fixed events, then remain open until the session closes."""

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        async for event in super().codec_events():
            yield event
        await asyncio.Event().wait()


class FakeRealtimeModel(RealtimeModel):
    """A model that yields a pre-built connection and records connect arguments."""

    def __init__(
        self,
        connection: RealtimeConnection,
        *,
        settings: RealtimeModelSettings | None = None,
        profile: RealtimeModelProfile | None = None,
        model_name: str | None = 'fake-realtime',
        system: str | None = 'fake',
        base_url: str | None = None,
    ) -> None:
        self._connection = connection
        self.settings = settings
        self._fixed_profile = profile or _profile()
        self._model_name = model_name
        self._system = system
        self._base_url = base_url
        self.last_instructions: str | None = None
        self.last_tools: list[ToolDefinition] | None = None
        self.last_native_tools: list[AbstractNativeTool] | None = None
        self.last_model_settings: RealtimeModelSettings | None = None
        self.last_messages: Sequence[ModelMessage] | None = None

    @property
    def model_name(self) -> str:
        return cast('str', self._model_name)

    @property
    def system(self) -> str:
        return cast('str', self._system)

    @property
    def base_url(self) -> str | None:
        return self._base_url

    @property
    def profile(self) -> RealtimeModelProfile:
        # A fixed, already-resolved profile: these tests pin session behavior per flag, not the
        # default/provider/user layering the base class does (covered in the provider tests).
        return self._fixed_profile

    @asynccontextmanager
    async def connect(
        self,
        *,
        messages: Sequence[ModelMessage],
        model_settings: RealtimeModelSettings | None,
        model_request_parameters: ModelRequestParameters,
    ) -> AsyncGenerator[RealtimeConnection]:
        # The same call every provider's `connect` makes.
        self.last_instructions = session_instructions(messages, model_request_parameters)
        self.last_tools = model_request_parameters.function_tools
        self.last_native_tools = model_request_parameters.native_tools
        self.last_model_settings = model_settings
        self.last_messages = messages
        yield self._connection


# --- event translation -------------------------------------------------------------------------


async def test_consumption_views_run_concurrently_with_event_stream() -> None:
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='hello', is_final=True),
            AudioDelta(b'audio-1'),
            OutputTranscript(text='hi', is_final=False),
            AudioDelta(b'audio-2'),
            OutputTranscript(text='hi there', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn)

    async with session:
        events, audio, transcripts, deltas = await asyncio.gather(
            drain_events(session),
            aiter_to_list(session.stream_audio()),
            aiter_to_list(session.stream_transcripts()),
            aiter_to_list(session.stream_transcripts(delta=True)),
        )

        assert events == [
            PartStartEvent(index=0, part=SpeechPart(speaker='user', transcript='')),
            PartDeltaEvent(
                index=0, delta=SpeechPartDelta(speaker='user', transcript_delta='hello', transcript='hello')
            ),
            PartEndEvent(index=0, part=SpeechPart(speaker='user', transcript='hello')),
            PartStartEvent(index=1, part=SpeechPart(speaker='assistant', transcript='')),
            PartDeltaEvent(index=1, delta=SpeechPartDelta(speaker='assistant', audio_chunk=b'audio-1')),
            PartDeltaEvent(index=1, delta=SpeechPartDelta(speaker='assistant', transcript_delta='hi', transcript='hi')),
            PartDeltaEvent(index=1, delta=SpeechPartDelta(speaker='assistant', audio_chunk=b'audio-2')),
            PartDeltaEvent(
                index=1, delta=SpeechPartDelta(speaker='assistant', transcript_delta=' there', transcript='hi there')
            ),
            PartEndEvent(index=1, part=SpeechPart(speaker='assistant', transcript='hi there')),
            RealtimeTurnCompleteEvent(),
        ]
        assert audio == [b'audio-1', b'audio-2']
        assert transcripts == [
            SpeechPart(speaker='user', transcript='hello'),
            SpeechPart(speaker='assistant', transcript='hi there'),
        ]
        # Each update names its turn, so a caption UI keeps the two speakers apart, and carries the
        # turn's text so far so it can replace instead of accumulating itself.
        assert deltas == [
            TranscriptUpdate(index=0, speaker='user', delta='hello', transcript='hello'),
            TranscriptUpdate(index=1, speaker='assistant', delta='hi', transcript='hi'),
            TranscriptUpdate(index=1, speaker='assistant', delta=' there', transcript='hi there'),
        ]


async def test_cumulative_transcripts_revise_the_turn_instead_of_doubling_up() -> None:
    """A provider that revises its own partials reaches captions as a replacement, not an append.

    xAI Grok Voice streams the user's transcript as cumulative snapshots and corrects earlier words
    (`'Hello?'` becomes `'Hello, my name is'`). Appending that would double the corrected text, so the
    session replaces — including on the `stream_transcripts` view, which is what captions render.
    """
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='Hello?', cumulative=True),
            InputTranscript(text='Hello, my name is', cumulative=True),
            InputTranscript(text='Hello, my name is Marcelo.', cumulative=True, is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn)

    async with session:
        events, transcripts, deltas = await asyncio.gather(
            drain_events(session),
            aiter_to_list(session.stream_transcripts()),
            aiter_to_list(session.stream_transcripts(delta=True)),
        )

    assert [event for event in events if isinstance(event, PartDeltaEvent)] == [
        PartDeltaEvent(index=0, delta=SpeechPartDelta(speaker='user', transcript_delta='Hello?', transcript='Hello?')),
        # The revision added no text, so only the corrected whole is reported.
        PartDeltaEvent(
            index=0, delta=SpeechPartDelta(speaker='user', transcript_delta='', transcript='Hello, my name is')
        ),
        PartDeltaEvent(
            index=0,
            delta=SpeechPartDelta(
                speaker='user', transcript_delta=' Marcelo.', transcript='Hello, my name is Marcelo.'
            ),
        ),
    ]
    # The revision reaches the caption view, and `transcript` is the turn's real text throughout.
    assert deltas == [
        TranscriptUpdate(index=0, speaker='user', delta='Hello?', transcript='Hello?'),
        # A revision adds nothing, so `delta` is empty and `transcript` carries the correction.
        TranscriptUpdate(index=0, speaker='user', delta='', transcript='Hello, my name is'),
        TranscriptUpdate(index=0, speaker='user', delta=' Marcelo.', transcript='Hello, my name is Marcelo.'),
    ]
    assert transcripts == [SpeechPart(speaker='user', transcript='Hello, my name is Marcelo.')]


async def test_cumulative_transcript_extending_across_padding_is_still_an_append() -> None:
    """A snapshot that only extends its predecessor once padding is ignored is an append, not a revision.

    Providers pad transcripts unevenly (`' Hello'` then `'Hello there'`), and reporting that as a
    revision would make a caption redraw the whole turn for text the user already saw.
    """
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text=' Hello', cumulative=True),
            InputTranscript(text='Hello there', cumulative=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn)

    async with session:
        deltas = (await asyncio.gather(drain_events(session), aiter_to_list(session.stream_transcripts(delta=True))))[1]

    assert deltas == [
        TranscriptUpdate(index=0, speaker='user', delta=' Hello', transcript=' Hello'),
        TranscriptUpdate(index=0, speaker='user', delta=' there', transcript='Hello there'),
    ]


async def test_cumulative_transcript_repeating_itself_emits_nothing() -> None:
    """An unchanged snapshot is not news; re-emitting it would flicker a caption for no reason."""
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='Hello', cumulative=True),
            InputTranscript(text='Hello', cumulative=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn)

    async with session:
        events, deltas = await asyncio.gather(
            drain_events(session), aiter_to_list(session.stream_transcripts(delta=True))
        )

    assert [event for event in events if isinstance(event, PartDeltaEvent)] == [
        PartDeltaEvent(index=0, delta=SpeechPartDelta(speaker='user', transcript_delta='Hello', transcript='Hello'))
    ]
    assert deltas == [TranscriptUpdate(index=0, speaker='user', delta='Hello', transcript='Hello')]


# One second of the default 24 kHz mono PCM16 output.
_SECOND = 48000
_MINUTE = 60 * _SECOND
# How much audio a `stream_audio()` view buffers before it drops the oldest chunk.
_AUDIO_TAP_BYTES = _AUDIO_TAP_SECONDS * _SECOND


async def test_audio_view_drops_oldest_chunk_on_overflow_without_instrumentation() -> None:
    # Minute-long chunks, so seven of them overflow the five-minute window by two.
    chunks = [bytes([index]) * _MINUTE for index in range(7)]
    session = RealtimeSession(FakeRealtimeConnection([AudioDelta(chunk) for chunk in chunks]))

    async with session:
        assert [chunk async for chunk in session.stream_audio()] == chunks[-5:]
        assert [type(event).__name__ for event in await drain_events(session)] == snapshot(
            [
                'PartStartEvent',
                'PartDeltaEvent',
                'PartDeltaEvent',
                'PartDeltaEvent',
                'PartDeltaEvent',
                'PartDeltaEvent',
                'PartDeltaEvent',
                'PartDeltaEvent',
                'PartEndEvent',
            ]
        )
        assert session._audio_tap_drops == 2  # pyright: ignore[reportPrivateUsage]


async def test_audio_view_caps_the_number_of_tiny_chunks_it_buffers() -> None:
    # A byte budget alone would let tiny deltas queue without bound, so the chunk count is capped too.
    chunks = [index.to_bytes(2, 'big') for index in range(_AUDIO_TAP_MAX_CHUNKS + 5)]
    session = RealtimeSession(FakeRealtimeConnection([AudioDelta(chunk) for chunk in chunks]))

    async with session:
        assert [chunk async for chunk in session.stream_audio()] == chunks[-_AUDIO_TAP_MAX_CHUNKS:]
        assert session._audio_tap_drops == 5  # pyright: ignore[reportPrivateUsage]


@pytest.mark.parametrize(
    'chunk_bytes',
    [
        pytest.param(1920, id='40ms-chunks'),  # Gemini native audio
        pytest.param(19200, id='400ms-chunks'),  # OpenAI Realtime
    ],
)
async def test_audio_view_keeps_a_whole_reply_generated_ahead_of_playback(chunk_bytes: int) -> None:
    # Providers generate speech several times faster than it plays, so a device-paced consumer has most
    # of a long reply queued before it has heard the start of it. A minute-long reply arriving in one
    # burst, ahead of a consumer that plays each chunk before pulling the next, must reach it whole.
    chunks = [bytes([index % 256]) * chunk_bytes for index in range(60 * _SECOND // chunk_bytes)]
    session = RealtimeSession(BlockingRealtimeConnection([AudioDelta(chunk) for chunk in chunks]), _noop_runner)
    played: list[bytes] = []

    async with session:
        stream = session.stream_audio()

        async def play() -> None:
            async for chunk in stream:
                await asyncio.sleep(0)
                played.append(chunk)

        playback = asyncio.create_task(play())
        # The whole reply has been generated before the wait starts.
        deltas = 0
        async for event in session:  # pragma: no branch
            if isinstance(event, PartDeltaEvent):
                deltas += 1
                if deltas == len(chunks):
                    break
        await session.wait_for_playback()
        assert played == chunks
        assert session.played_audio_bytes == 60 * _SECOND
        assert session._audio_tap_drops == 0  # pyright: ignore[reportPrivateUsage]
        playback.cancel()
        with pytest.raises(asyncio.CancelledError):
            await playback


async def test_final_transcripts_survive_a_flood_of_deltas() -> None:
    # The two speakers' transcripts stream at once, so a finalized user turn is routinely followed by
    # a long run of assistant deltas. Final parts and deltas are separate subscriptions for exactly
    # this reason: sharing one bounded queue and filtering on the way out let those deltas evict the
    # finalized part a `delta=False` consumer was waiting for, losing it silently.
    words = [f'word{index} ' for index in range(60)]
    session = RealtimeSession(
        FakeRealtimeConnection(
            [
                InputTranscript(text='what is the weather', is_final=True),
                *[OutputTranscript(text=''.join(words[: index + 1]), is_final=False) for index in range(len(words))],
                OutputTranscript(text=''.join(words), is_final=True),
                ResponseDone(),
            ]
        )
    )

    async with session:
        transcripts, _ = await asyncio.gather(
            aiter_to_list(session.stream_transcripts()),
            drain_events(session),
        )

    # Both speakers' finalized turns arrive, despite far more deltas than any single window holds.
    assert [(part.speaker, part.transcript) for part in transcripts] == [
        ('user', 'what is the weather'),
        # Assistant transcripts are recorded verbatim; only user turns are stripped at finalization.
        ('assistant', ''.join(words)),
    ]


async def test_send_audio_finalizes_late_anonymous_transcript_for_transcript_view() -> None:
    late_transcript_processed = asyncio.Event()
    next_audio_sent = asyncio.Event()

    class _LateTranscriptBeforeNextAudio(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            for event in [
                OutputTranscript(text='answer one', is_final=True),
                ResponseDone(),
                InputTranscript(text='question one'),
            ]:
                yield event
            late_transcript_processed.set()
            await next_audio_sent.wait()

        async def send_input(self, content: RealtimeInput) -> None:
            await super().send_input(content)
            if len(self.sent) == 2:
                next_audio_sent.set()

    session = RealtimeSession(_LateTranscriptBeforeNextAudio([]), _noop_runner)

    async with session:
        await session.send_audio(b'first')
        transcript_task = asyncio.create_task(aiter_to_list(session.stream_transcripts()))
        await late_transcript_processed.wait()
        await session.send_audio(b'second')
        transcripts = await transcript_task

    assert transcripts == snapshot(
        [
            SpeechPart(speaker='user', transcript='question one'),
        ]
    )


async def test_send_only_session_still_runs_tools() -> None:
    # Tool execution, turn tracking, and usage limits all run off the receive loop, and a caller who
    # sends a prompt and then goes off to do something else has no reason to think iterating is what
    # switches the agent on. Sending starts the loop, so the tool runs without anyone consuming.
    ran = asyncio.Event()

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        ran.set()
        return 'done'

    conn = BlockingRealtimeConnection([ToolCall(tool_call_id='c1', tool_name='fast', args='{}')])
    async with RealtimeSession(conn, runner) as session:
        await session.send('do the task')
        # No `async for` and no view: the agent still has to run the tool and return its result.
        with anyio.fail_after(5):
            await ran.wait()
            while len(conn.sent) < 2:
                await asyncio.sleep(0)
    assert [type(sent).__name__ for sent in conn.sent] == ['str', 'ToolResult']


async def test_close_discards_buffered_view_items() -> None:
    # Closing is a hangup, not a flush: whatever a view had buffered is dropped rather than delivered
    # after the session is over. This is the case where a consumer is behind at close time, so the
    # queue is non-empty -- distinct from closing a view that has already caught up.
    session = RealtimeSession(BlockingRealtimeConnection([AudioDelta(bytes([index])) for index in range(5)]))

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'\x00'
        # Let the pump run so the rest of the chunks pile up behind the consumer.
        for _ in range(10):
            await asyncio.sleep(0)
        await session.close()
        assert [chunk async for chunk in stream] == []


async def test_session_reports_the_connected_model_profile() -> None:
    """A session exposes the model's profile, because it may be all the caller holds.

    `agent.realtime('google:…')` takes a model *name* and builds the model internally, so without this
    there is nothing to read the input sample rate (or any capability flag) off of.
    """
    profile = RealtimeModelProfile(supports_interruption=False, audio_input_sample_rate=16000)
    model = FakeRealtimeModel(FakeRealtimeConnection([]), profile=profile)
    agent = Agent()
    async with agent.realtime(model).session() as session:
        assert session.profile == profile
        # The sample-rate properties are the supported read surface: they resolve the profile keys and
        # supply the 24 kHz default for keys a profile omits, so callers never index the profile dict.
        assert session.audio_input_sample_rate == 16000
        assert session.audio_output_sample_rate == 24000
    # The same properties exist on the model, for configuring capture/playback before a session exists.
    assert model.audio_input_sample_rate == 16000
    assert model.audio_output_sample_rate == 24000


async def test_close_ends_views_and_is_idempotent() -> None:
    session = RealtimeSession(BlockingRealtimeConnection([AudioDelta(b'audio')]))

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'audio'
        transcript_task = asyncio.create_task(aiter_to_list(session.stream_transcripts()))
        await asyncio.sleep(0)
        assert session.closed is False
        await session.close()
        await session.close()
        assert session.closed is True
        assert [chunk async for chunk in stream] == []
        assert await transcript_task == []
        with pytest.raises(UserError, match='This realtime session is closed'):
            await session.send_audio(b'more audio')
        with pytest.raises(UserError, match='closed and cannot be streamed'):
            await anext(session.stream_audio())


async def test_view_subscribes_at_call_time_and_does_not_replay_earlier_events() -> None:
    session = RealtimeSession(FakeRealtimeConnection([AudioDelta(b'audio')]))

    async with session:
        audio = session.stream_audio()
        assert [event async for event in session]
        assert [chunk async for chunk in audio] == [b'audio']
        # Views created after the pump has finished get nothing: no replay, and they end at once.
        assert [chunk async for chunk in session.stream_audio()] == []
        assert [part async for part in session.stream_transcripts()] == []


async def test_view_requires_entered_session() -> None:
    session = RealtimeSession(FakeRealtimeConnection([]))

    with pytest.raises(UserError, match='Enter the realtime session'):
        session.stream_audio()


async def test_views_created_before_response_are_consumed_after_it() -> None:
    conn = BlockingRealtimeConnection(
        [AudioDelta(b'a1'), AudioDelta(b'a2'), OutputTranscript(text='hi there', is_final=True), ResponseDone()]
    )
    session = RealtimeSession(conn)

    async with session:
        audio = session.stream_audio()
        transcripts = session.stream_transcripts()
        await session.create_response()
        audio_task = asyncio.create_task(aiter_to_list(audio))
        transcript_task = asyncio.create_task(aiter_to_list(transcripts))
        events: list[RealtimeEvent] = []
        async for event in session:  # pragma: no branch
            events.append(event)
            if isinstance(event, RealtimeTurnCompleteEvent):
                break
        for _ in range(5):
            await asyncio.sleep(0)

    assert RealtimeTurnCompleteEvent() in events
    assert await audio_task == [b'a1', b'a2']
    assert [part.transcript for part in await transcript_task] == ['hi there']


async def test_view_consumer_can_await_before_iterating() -> None:
    session = RealtimeSession(BlockingRealtimeConnection([AudioDelta(b'audio'), ResponseDone()]))
    got: list[bytes] = []

    async def play_audio(chunks: AsyncIterator[bytes]) -> None:
        await asyncio.sleep(0)
        async for chunk in chunks:
            got.append(chunk)

    async with session:
        task = asyncio.create_task(play_audio(session.stream_audio()))
        async for event in session:  # pragma: no branch
            if isinstance(event, RealtimeTurnCompleteEvent):
                break
        for _ in range(5):
            await asyncio.sleep(0)

    await task
    assert got == [b'audio']


async def test_closing_an_unstarted_view_releases_its_tap() -> None:
    session = RealtimeSession(FakeRealtimeConnection([AudioDelta(b'audio')]))

    async with session:
        audio = session.stream_audio()
        transcripts = session.stream_transcripts()
        assert isinstance(audio, _TapView) and isinstance(transcripts, _TapView)
        assert len(session._audio_taps) == 1  # pyright: ignore[reportPrivateUsage]
        assert len(session._transcript_taps) == 1  # pyright: ignore[reportPrivateUsage]
        # `aclose()` on a never-started async generator runs no `finally`; the view releases the tap itself.
        await audio.aclose()
        await transcripts.aclose()
        assert len(session._audio_taps) == 0  # pyright: ignore[reportPrivateUsage]
        assert len(session._transcript_taps) == 0  # pyright: ignore[reportPrivateUsage]
        await drain_events(session)
        assert session._audio_tap_drops == 0  # pyright: ignore[reportPrivateUsage]


@pytest.mark.usefixtures('young_gc')
async def test_abandoned_unstarted_view_releases_its_tap() -> None:
    chunks = [bytes([index]) for index in range(40)]
    session = RealtimeSession(FakeRealtimeConnection([AudioDelta(chunk) for chunk in chunks]))

    async with session:
        view = session.stream_audio()
        assert len(session._audio_taps) == 1  # pyright: ignore[reportPrivateUsage]
        del view
        gc.collect()
        assert len(session._audio_taps) == 0  # pyright: ignore[reportPrivateUsage]
        await drain_events(session)
        assert session._audio_tap_drops == 0  # pyright: ignore[reportPrivateUsage]


async def test_assistant_transcript_partials_then_final() -> None:
    # Partial transcript deltas stream as PartDeltaEvents; the final (full-text) event adds nothing new.
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='Hi ', is_final=False),
            OutputTranscript(text='there', is_final=False),
            OutputTranscript(text='Hi there', is_final=True),  # provider repeats the full text
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m')
    events = await collect_events(session)
    assert events == snapshot(
        [
            PartStartEvent(index=0, part=SpeechPart(speaker='assistant', transcript='')),
            PartDeltaEvent(
                index=0, delta=SpeechPartDelta(speaker='assistant', transcript_delta='Hi ', transcript='Hi ')
            ),
            PartDeltaEvent(
                index=0, delta=SpeechPartDelta(speaker='assistant', transcript_delta='there', transcript='Hi there')
            ),
            PartEndEvent(index=0, part=SpeechPart(speaker='assistant', transcript='Hi there')),
            RealtimeTurnCompleteEvent(),
        ]
    )
    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='Hi there')],
                model_name='m',
                timestamp=IsDatetime(),
                finish_reason='stop',
            )
        ]
    )


async def test_assistant_transcript_final_only() -> None:
    # A provider that only sends a single final transcript still yields a delta then the completed part.
    conn = FakeRealtimeConnection([OutputTranscript(text='Hello world', is_final=True), ResponseDone()])
    session = RealtimeSession(conn, _noop_runner, model_name='m')
    events = await collect_events(session)
    assert events == snapshot(
        [
            PartStartEvent(index=0, part=SpeechPart(speaker='assistant', transcript='')),
            PartDeltaEvent(
                index=0,
                delta=SpeechPartDelta(speaker='assistant', transcript_delta='Hello world', transcript='Hello world'),
            ),
            PartEndEvent(index=0, part=SpeechPart(speaker='assistant', transcript='Hello world')),
            RealtimeTurnCompleteEvent(),
        ]
    )


async def test_multiple_assistant_items_fold_into_one_response() -> None:
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='first', is_final=True, item_id='item-1'),
            OutputTranscript(text='second', is_final=True, item_id='item-2', output_text=True),
            ResponseDone(provider_response_id='response-1', finish_reason='stop'),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, provider_name='openai')

    _ = await collect_events(session)

    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[
                    SpeechPart(speaker='assistant', transcript='first'),
                    TextPart(content='second'),
                ],
                provider_name='openai',
                provider_response_id='response-1',
                timestamp=IsDatetime(),
                finish_reason='stop',
            )
        ]
    )


@pytest.mark.parametrize(
    ('finish_reason', 'provider_details', 'expected_messages'),
    [
        (
            'length',
            {'status': 'incomplete', 'finish_reason': 'max_output_tokens'},
            # Each case carries its own `snapshot(...)` call site: `inline-snapshot` keys snapshots by
            # source location, so a single shared `snapshot()` in the test body would raise `UsageError`
            # when the two parametrized cases evaluate it to different values.
            snapshot(
                [
                    ModelResponse(
                        parts=[],
                        provider_details={'status': 'incomplete', 'finish_reason': 'max_output_tokens'},
                        provider_response_id='response-empty',
                        timestamp=IsDatetime(),
                        finish_reason='length',
                        conversation_id='conversation-1',
                    )
                ]
            ),
        ),
        (
            'error',
            {'status': 'failed'},
            snapshot(
                [
                    ModelResponse(
                        parts=[],
                        provider_details={'status': 'failed'},
                        provider_response_id='response-empty',
                        timestamp=IsDatetime(),
                        finish_reason='error',
                        conversation_id='conversation-1',
                    )
                ]
            ),
        ),
    ],
)
async def test_empty_terminal_response_is_recorded(
    finish_reason: Literal['length', 'error'],
    provider_details: dict[str, Any],
    expected_messages: list[ModelResponse],
) -> None:
    conn = FakeRealtimeConnection(
        [
            ResponseDone(
                provider_response_id='response-empty',
                finish_reason=finish_reason,
                provider_details=provider_details,
            )
        ]
    )
    session = RealtimeSession(conn, _noop_runner, conversation_id='conversation-1')

    _ = await collect_events(session)

    assert session.new_messages() == expected_messages
    assert session.usage.requests == 1


async def test_empty_interrupted_response_is_recorded() -> None:
    conn = FakeRealtimeConnection(
        [
            ResponseDone(
                interrupted=True,
                provider_response_id='response-cancelled',
                provider_details={'status': 'cancelled'},
            )
        ]
    )
    session = RealtimeSession(conn, _noop_runner)

    _ = await collect_events(session)

    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[],
                provider_details={'status': 'cancelled'},
                provider_response_id='response-cancelled',
                timestamp=IsDatetime(),
                state='interrupted',
            )
        ]
    )


async def test_bare_turn_boundary_does_not_create_empty_response() -> None:
    session = RealtimeSession(FakeRealtimeConnection([ResponseDone()]), _noop_runner)

    _ = await collect_events(session)

    assert session.new_messages() == []


async def test_user_transcript_final_becomes_request() -> None:
    conn = FakeRealtimeConnection(
        [InputTranscript(text='what is ', is_final=False), InputTranscript(text='the weather', is_final=True)]
    )
    session = RealtimeSession(conn, _noop_runner)
    events = await collect_events(session)
    assert events == snapshot(
        [
            PartStartEvent(index=0, part=SpeechPart(speaker='user', transcript='')),
            PartDeltaEvent(
                index=0, delta=SpeechPartDelta(speaker='user', transcript_delta='what is ', transcript='what is ')
            ),
            PartDeltaEvent(
                index=0,
                delta=SpeechPartDelta(speaker='user', transcript_delta='the weather', transcript='what is the weather'),
            ),
            PartEndEvent(index=0, part=SpeechPart(speaker='user', transcript='what is the weather')),
        ]
    )
    assert session.new_messages() == snapshot(
        [ModelRequest(parts=[SpeechPart(speaker='user', transcript='what is the weather')], timestamp=IsDatetime())]
    )


async def test_interleaved_user_transcripts_use_item_ids() -> None:
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='first ', item_id='item-1'),
            InputTranscript(text='second ', item_id='item-2'),
            InputTranscript(text='second turn', is_final=True, item_id='item-2'),
            InputTranscript(text='first turn', is_final=True, item_id='item-1'),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, provider_name='openai')
    _ = await collect_events(session)

    parts = [message.parts[0] for message in session.new_messages() if isinstance(message, ModelRequest)]
    assert parts == [
        SpeechPart(speaker='user', transcript='first turn'),
        SpeechPart(speaker='user', transcript='second turn'),
    ]


async def test_session_close_flushes_user_transcripts_blocked_by_missing_final() -> None:
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='first partial', item_id='item-1'),
            InputTranscript(text='second final', is_final=True, item_id='item-2'),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, provider_name='openai')
    _ = await collect_events(session)

    assert session.new_messages() == [
        ModelRequest(
            parts=[SpeechPart(speaker='user', transcript='first partial')],
            timestamp=IsDatetime(),
        ),
        ModelRequest(
            parts=[SpeechPart(speaker='user', transcript='second final')],
            timestamp=IsDatetime(),
        ),
    ]


async def test_partial_only_user_transcript_finalized_on_turn_complete() -> None:
    # Gemini streams only partial input transcripts (never `is_final`) and no `RealtimeInputSpeechEndEvent`, so
    # the user turn is finalized at the turn boundary. Without that, the transcribed user turn is
    # dropped from history entirely (only the assistant response would remain).
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='what is ', is_final=False),
            InputTranscript(text='the weather', is_final=False),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)
    _ = await collect_events(session)
    assert session.new_messages() == snapshot(
        [ModelRequest(parts=[SpeechPart(speaker='user', transcript='what is the weather')], timestamp=IsDatetime())]
    )


async def test_partial_only_user_transcript_strips_leading_space() -> None:
    # Gemini streams partial-only transcripts whose first delta carries a leading space; with no final
    # snapshot to reconcile against (unlike OpenAI's `.completed`), the finalized turn would keep the
    # space. Finalization strips it so the result matches the OpenAI transcription of the same utterance.
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text=' Hello, my name', is_final=False),
            InputTranscript(text=' is Marcelo.', is_final=False),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)
    _ = await collect_events(session)
    [request] = [message for message in session.new_messages() if isinstance(message, ModelRequest)]
    [part] = request.parts
    assert isinstance(part, SpeechPart)
    assert part.transcript == 'Hello, my name is Marcelo.'


async def test_user_transcript_final_snapshot_reconciles_whitespace_drift() -> None:
    # OpenAI's input-transcription deltas can carry a leading space that the `.completed` full-text
    # snapshot trims. The final snapshot must replace the accumulated deltas, not append a near-
    # duplicate (` Hello…` + `Hello…` = ` Hello…Hello…`).
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text=' Hello, my name', is_final=False),
            InputTranscript(text=' is Marcelo.', is_final=False),
            InputTranscript(text='Hello, my name is Marcelo.', is_final=True),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)
    _ = await collect_events(session)
    assert session.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[SpeechPart(speaker='user', transcript='Hello, my name is Marcelo.')], timestamp=IsDatetime()
            )
        ]
    )


async def test_audio_delta_streams_and_transcript_pairs() -> None:
    conn = FakeRealtimeConnection(
        [AudioDelta(data=b'\x00\x01'), OutputTranscript(text='hi', is_final=True), ResponseDone()]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m')
    events = await collect_events(session)
    assert [type(e).__name__ for e in events] == snapshot(
        [
            'PartStartEvent',
            'PartDeltaEvent',
            'PartDeltaEvent',
            'PartEndEvent',
            'RealtimeTurnCompleteEvent',
        ]
    )
    # transcript_only (default): the completed part keeps the transcript but not the audio bytes.
    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='hi')],
                model_name='m',
                timestamp=IsDatetime(),
                finish_reason='stop',
            )
        ]
    )


async def test_control_events_and_recoverable_error_pass_through() -> None:
    conn = FakeRealtimeConnection([ResponseDone(interrupted=True), RealtimeSessionErrorEvent(message='oops')])
    session = RealtimeSession(conn, _noop_runner)
    events = await collect_events(session)
    # A recoverable error is mid-stream: the session keeps running and surfaces the event to the
    # consumer (rather than swallowing it) so a quiet failure is observable.
    assert events == [
        RealtimeTurnCompleteEvent(),
        RealtimeSessionErrorEvent(message='oops'),
    ]


async def test_input_transcription_failure_passes_through_and_session_continues() -> None:
    # Failures finalize placeholder turns whether or not they identify their turn (`item_id` may be absent).
    identified = RealtimeInputTranscriptionErrorEvent(message='audio unintelligible', item_id='user-1', content_index=0)
    anonymous = RealtimeInputTranscriptionErrorEvent(message='transcription unavailable')
    conn = FakeRealtimeConnection([identified, anonymous, ResponseDone()])
    session = RealtimeSession(conn, _noop_runner)

    events = await collect_events(session)
    assert [type(event).__name__ for event in events] == snapshot(
        [
            'PartStartEvent',
            'PartEndEvent',
            'RealtimeInputTranscriptionErrorEvent',
            'PartStartEvent',
            'PartEndEvent',
            'RealtimeInputTranscriptionErrorEvent',
        ]
    )
    assert session.new_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user')], timestamp=IsDatetime()),
            ModelRequest(parts=[SpeechPart(speaker='user')], timestamp=IsDatetime()),
        ]
    )


async def test_input_transcription_failure_finalizes_speech_end_placeholder() -> None:
    conn = FakeRealtimeConnection(
        [
            RealtimeInputSpeechStartEvent(item_id='user-1'),
            RealtimeInputSpeechEndEvent(item_id='user-1'),
            RealtimeInputTranscriptionErrorEvent(message='transcription failed', item_id='user-1'),
            OutputTranscript(text='I could not hear you.', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)

    events = await collect_events(session)

    assert [type(event).__name__ for event in events] == [
        'RealtimeInputSpeechStartEvent',
        'RealtimeInputSpeechEndEvent',
        'PartStartEvent',
        'PartEndEvent',
        'RealtimeInputTranscriptionErrorEvent',
        'PartStartEvent',
        'PartDeltaEvent',
        'PartEndEvent',
        'RealtimeTurnCompleteEvent',
    ]
    assert session.new_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='I could not hear you.')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


async def test_input_transcription_failure_after_partial_does_not_block_later_turns() -> None:
    # Item A streams a partial transcript, item B finalizes out of order, then A's transcription fails.
    # A's placeholder must unblock the ordered prefix so both turns reach history in provider order.
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='partial A', is_final=False, item_id='A'),
            InputTranscript(text='hello from B', is_final=True, item_id='B'),
            RealtimeInputTranscriptionErrorEvent(message='transcription failed', item_id='A'),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)
    _ = await collect_events(session)
    assert session.new_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user')], timestamp=IsDatetime()),
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='hello from B')], timestamp=IsDatetime()),
        ]
    )


async def test_input_transcription_failure_ends_the_part_it_opened() -> None:
    """A failed transcription closes the failed turn's own part index and keeps overlapping turns active.

    Regression: the failed turn's end hardcoded `PartEndEvent(index=0, ...)` — with any earlier part in the
    session, a live caption UI saw the failed turn left open and part 0 closed again.
    """
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='hello from A', is_final=True, item_id='A'),  # claims part index 0
            InputTranscript(text='partial B', is_final=False, item_id='B'),  # opens part index 1
            InputTranscript(text='partial C', is_final=False, item_id='C'),  # opens part index 2, overlapping
            RealtimeInputTranscriptionErrorEvent(message='failed', item_id='B'),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)

    events: list[RealtimeEvent] = []
    failed_index: int | None = None
    async with session:
        async for event in session:  # pragma: no branch
            events.append(event)
            if (
                isinstance(event, PartDeltaEvent)
                and isinstance(event.delta, SpeechPartDelta)
                and event.delta.transcript == 'partial B'
            ):
                failed_index = event.index

    assert failed_index is not None and failed_index != 0
    assert any(isinstance(event, PartStartEvent) and event.index == failed_index for event in events)
    assert any(isinstance(event, PartEndEvent) and event.index == failed_index for event in events)


async def test_input_transcription_failure_ignores_already_closed_items() -> None:
    """A duplicate or late transcription-error event for a closed item must not re-open it.

    Regression: `_finalize_failed_user_item` lacked `_handle_input_transcript`'s closed-item guard, so a
    stray error for an already finalized (or already failed) item minted a fresh blank `SpeechPart` with
    a new part index and recorded a second user turn in history.
    """
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='hello from A', is_final=True, item_id='A'),
            RealtimeInputTranscriptionErrorEvent(message='late error for finalized item', item_id='A'),
            InputTranscript(text='partial B', is_final=False, item_id='B'),
            RealtimeInputTranscriptionErrorEvent(message='failed', item_id='B'),
            RealtimeInputTranscriptionErrorEvent(message='duplicate failure', item_id='B'),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)

    events = await collect_events(session)

    ended = [e.part for e in events if isinstance(e, PartEndEvent) and isinstance(e.part, SpeechPart)]
    assert ended == [SpeechPart(speaker='user', transcript='hello from A'), SpeechPart(speaker='user')]
    user_parts = [
        part for message in session.new_messages() if isinstance(message, ModelRequest) for part in message.parts
    ]
    assert user_parts == [
        SpeechPart(speaker='user', transcript='hello from A'),
        SpeechPart(speaker='user'),
    ]


@pytest.mark.parametrize('item_id', [None, 'user-1'])
async def test_input_transcription_failure_retained_audio_fallback(item_id: str | None) -> None:
    conn = FakeRealtimeConnection([RealtimeInputTranscriptionErrorEvent(message='failed', item_id=item_id)])
    session = RealtimeSession(conn, _noop_runner, audio_retention='input_audio')
    if item_id is None:
        await session.send_audio(b'\xaa')

    _ = await collect_events(session)

    expected_audio = _wav_content(b'\xaa') if item_id is None else None
    assert session.new_messages() == [
        ModelRequest(parts=[SpeechPart(speaker='user', audio=expected_audio)], timestamp=IsDatetime())
    ]


async def test_fatal_session_error_raises() -> None:
    conn = FakeRealtimeConnection([RealtimeSessionErrorEvent(message='provider failed', recoverable=False)])
    session = RealtimeSession(conn, _noop_runner)
    with pytest.raises(RealtimeError, match='provider failed'):
        _ = await collect_events(session)


async def test_interrupted_turn_keeps_partial_transcript() -> None:
    # A barge-in cancels the turn; the completed part reflects the partial transcript seen so far.
    conn = FakeRealtimeConnection(
        [OutputTranscript(text='the answer is ', is_final=False), ResponseDone(interrupted=True)]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m')
    events = await collect_events(session)
    # A barge-in ends the exchange too: nothing more is coming, so the turn completes with it.
    assert events[-1] == RealtimeTurnCompleteEvent()
    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='the answer is ')],
                model_name='m',
                timestamp=IsDatetime(),
                state='interrupted',
            )
        ]
    )


async def test_explicit_interrupt_records_audio_offset_on_last_speech_part() -> None:
    conn = _GatedRealtimeConnection(
        [
            OutputTranscript(text='first', is_final=True, item_id='item-1'),
            OutputTranscript(text='second', is_final=True, item_id='item-2'),
        ],
        [ResponseDone(interrupted=True)],
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m')

    async with session:
        events = aiter(session)
        await _consume_until(events, _is_delta_of(1))
        await session.interrupt(played_ms=640)
        conn.release.set()
        _ = [event async for event in events]

    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[
                    SpeechPart(speaker='assistant', transcript='first'),
                    SpeechPart(speaker='assistant', transcript='second', interrupted_at_ms=640),
                ],
                model_name='m',
                timestamp=IsDatetime(),
                state='interrupted',
            )
        ]
    )


async def test_deltas_still_in_flight_when_a_cancel_lands_stay_in_the_interrupted_turn() -> None:
    """Audio already on the wire when `interrupt()` is sent belongs to the turn it was generated for.

    Cancelling is a round trip, so a provider keeps emitting for the few milliseconds it takes to
    arrive. Those deltas must land in the response being cancelled — starting a second response for
    them would show the user a turn the model never took.
    """
    conn = _GatedRealtimeConnection(
        [OutputTranscript(text='I was saying', is_final=False, item_id='item-1')],
        [
            OutputTranscript(text=' something', is_final=True, item_id='item-1'),
            ResponseDone(interrupted=True),
        ],
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m')

    async with session:
        events = aiter(session)
        await _consume_until(events, _is_delta_of(0))
        await session.interrupt(played_ms=120)
        conn.release.set()
        _ = [event async for event in events]

    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[
                    SpeechPart(
                        speaker='assistant',
                        transcript='I was saying something',
                        interrupted_at_ms=120,
                    )
                ],
                model_name='m',
                timestamp=IsDatetime(),
                state='interrupted',
            )
        ]
    )


async def test_interrupted_turn_without_trailing_speech_records_no_offset() -> None:
    # The offset is recorded on the last *speech* part, so a turn interrupted while the model was
    # calling a tool (its trailing part is a `ToolCallPart`) walks past it to the speech before it.
    # With no speech in the response at all, nothing is marked and `state='interrupted'` carries the
    # whole meaning.
    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='tc_1', tool_name='noop', args='', response_usage_follows=True),
            ResponseDone(interrupted=True),
        ]
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'ok'

    session = RealtimeSession(conn, runner, model_name='m')

    await session.interrupt(played_ms=120)
    _ = await collect_events(session)

    response = next(m for m in session.new_messages() if isinstance(m, ModelResponse))
    assert response.state == 'interrupted'
    assert not any(isinstance(part, SpeechPart) for part in response.parts)


class _GatedRealtimeConnection(FakeRealtimeConnection):
    """Replay one batch of events, wait for `release`, then replay a second batch.

    Lets a test act (consume audio, interrupt) between two known points in the wire stream — a plain
    replay publishes everything before the test can get a word in.
    """

    def __init__(self, first: list[RealtimeCodecEvent], second: list[RealtimeCodecEvent], **kwargs: Any) -> None:
        super().__init__(first, **kwargs)
        self._second = second
        self.release = asyncio.Event()

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        for event in self._events:
            yield event
        await self.release.wait()
        for event in self._second:
            yield event


class _CancelGatedRealtimeConnection(FakeRealtimeConnection):
    """Replay one batch, then replay a second only once the session has sent `CancelResponse`.

    A real provider keeps generating for a moment after a cancel goes out, so the audio already in
    flight arrives *after* it — the ordering a test of straggler suppression needs.
    """

    def __init__(self, first: list[RealtimeCodecEvent], after_cancel: list[RealtimeCodecEvent], **kwargs: Any) -> None:
        super().__init__(first, **kwargs)
        self._after_cancel = after_cancel
        self.cancelled = asyncio.Event()

    async def send_input(self, content: RealtimeInput) -> None:
        await super().send_input(content)
        # The think-time barge-in this gate exists for sends the cancel on its own, with no
        # truncation beside it, so nothing else reaches this fake.
        if isinstance(content, CancelResponse):  # pragma: no branch
            self.cancelled.set()

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        for event in self._events:
            yield event
        await self.cancelled.wait()
        for event in self._after_cancel:
            yield event


# 100 ms per chunk at the default 24 kHz mono PCM16 output rate, so byte positions map to round
# millisecond counts (4800 bytes == 100 ms).
_CHUNK = 4800

# The barge-in playback-accounting tests below are unit tests for a shared reason: every claim is
# about state a recording cannot contain. What a tap delivered, what it dropped, how a device
# position maps onto a turn, and when the consumer resumed the iterator are local to the session and
# to the timing of a *consumer* that no cassette replays. A recording can only show the frames that
# resulted, which is what the cassette-backed `test_handle_barge_in_over_live_speech` in each
# provider's WS module pins; these fix the bookkeeping that decides which frames those are, and the
# sequences (overflow bursts, a straggler racing a cancel, a turn heard in full) are ones a live
# session produces only by luck.


async def test_interrupt_played_bytes_flushes_and_attributes_to_the_current_turn() -> None:
    """`interrupt(played_bytes=...)` owns the whole barge-in: attribution, flush, and stragglers."""
    conn = _GatedRealtimeConnection(
        [
            AudioDelta(b'a' * _CHUNK),
            ResponseDone(),  # turn 1, played in full
            AudioDelta(b'b' * _CHUNK),
            AudioDelta(b'c' * _CHUNK),  # turn 2: `b` gets played, `c` stays buffered
        ],
        [
            AudioDelta(b'd' * _CHUNK),  # straggler of the interrupted turn, in flight past the cancel
            ResponseDone(interrupted=True),
            AudioDelta(b'e' * _CHUNK),
            ResponseDone(),  # the reply to the barge-in
        ],
    )
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        played = [await anext(stream), await anext(stream)]
        assert played == [b'a' * _CHUNK, b'b' * _CHUNK]

        # One full turn plus 100 ms of the current one were played; `c` is buffered and unheard.
        assert await session.interrupt(played_bytes=2 * _CHUNK) is True
        assert conn.sent == [TruncateOutput(audio_end_ms=100), CancelResponse()]

        conn.release.set()
        # `c` was flushed and the straggler `d` erased; the next thing heard is the new reply.
        assert await anext(stream) == b'e' * _CHUNK

        # The flushed and erased audio also left the accounting: with `e` played, everything
        # emitted was heard, so a speech start with nothing left to cut off does not interrupt.
        assert await session.interrupt(played_bytes=3 * _CHUNK) is False
        assert conn.sent == [TruncateOutput(audio_end_ms=100), CancelResponse()]

        # Nothing further arrives; the stream ends when the connection does.
        assert [chunk async for chunk in stream] == []


def _speech(item_id: str, chunks: int = 1) -> list[RealtimeCodecEvent]:
    return [AudioDelta(b'a' * _CHUNK, item_id=item_id) for _ in range(chunks)]


async def test_interrupt_played_bytes_after_the_reply_finished_generating_truncates_it() -> None:
    """Generation outruns playback, so the user usually cuts off a reply that has finished generating.

    The provider's copy is still truncated where playback stopped, so the model doesn't take the whole
    reply as heard, and history records the reply as cut off there: an interrupted copy in its place, leaving
    a snapshot already taken as it was. The position isn't left behind for the next response that happens to
    be interrupted.
    """
    conn = _GatedRealtimeConnection(
        [*_speech('item-a', 2), ResponseDone()],
        [*_speech('item-b'), ResponseDone(interrupted=True)],  # a later reply, cut with no position
    )
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        events = aiter(session)
        await _consume_until(events, _is_turn_complete)
        await anext(stream)  # the second chunk stays buffered and unheard
        before = session.all_messages()
        recorded = [message for message in before if isinstance(message, ModelResponse)]
        assert [message.state for message in recorded] == ['complete']

        assert await session.interrupt(played_bytes=_CHUNK) is True
        assert conn.sent == [TruncateOutput(audio_end_ms=100, item_id='item-a'), CancelResponse()]
        after = session.all_messages()
        assert len(after) == len(before)
        cut = after[before.index(recorded[0])]
        assert cut is not recorded[0]
        assert cut.parts[0] == replace(recorded[0].parts[0], interrupted_at_ms=100)
        assert recorded[0].state == 'complete'  # the snapshot taken before is untouched

        conn.release.set()
        _ = [event async for event in events]

    assert _speech_cuts(session) == [('interrupted', [100]), ('interrupted', [None])]


async def test_interrupt_played_bytes_after_the_reply_finished_generating_records_it_cut_without_truncation() -> None:
    """Without output truncation (xAI), a finished reply the user cuts off is still recorded where playback stopped.

    Only the provider's copy can't be truncated: no truncation goes out, and the transcript stays whole.
    """
    conn = _GatedRealtimeConnection(
        [*_speech('item-a', 2), ResponseDone()],
        [*_speech('item-b'), ResponseDone(interrupted=True)],  # a later reply, cut with no position
    )
    session = RealtimeSession(conn, _noop_runner, profile=_profile(supports_output_truncation=False))

    async with session:
        stream = session.stream_audio()
        events = aiter(session)
        await _consume_until(events, _is_turn_complete)
        await anext(stream)  # the second chunk stays buffered and unheard
        assert [message.state for message in session.all_messages() if isinstance(message, ModelResponse)] == [
            'complete'
        ]

        assert await session.interrupt(played_bytes=_CHUNK) is True
        assert conn.sent == [CancelResponse()]

        conn.release.set()
        _ = [event async for event in events]

    assert _speech_cuts(session) == [('interrupted', [100]), ('interrupted', [None])]


async def test_interrupt_played_bytes_without_truncation_records_the_cut_when_the_cancel_fails() -> None:
    """A cancel that fails on a dropped link still leaves the reply recorded as cut where playback stopped."""

    class _DroppedLink(_GatedRealtimeConnection):
        transport_errors = (ConnectionResetError,)

        async def send_input(self, content: RealtimeInput) -> None:
            raise ConnectionResetError('link dropped')

    conn = _DroppedLink([*_speech('item-a', 2), ResponseDone()], [])
    session = RealtimeSession(conn, _noop_runner, profile=_profile(supports_output_truncation=False))

    async with session:
        stream = session.stream_audio()
        events = aiter(session)
        await _consume_until(events, _is_turn_complete)
        await anext(stream)  # the second chunk stays buffered and unheard

        with pytest.raises(RealtimeError, match='link dropped'):
            await session.interrupt(played_bytes=_CHUNK)
        conn.release.set()

    assert _speech_cuts(session) == [('interrupted', [100])]


async def test_a_tool_after_a_barge_in_on_a_finished_reply_sees_it_cut_off() -> None:
    """A tool's `ctx.messages` (and a chat span's input) record the cut-off reply as `all_messages()` does."""
    seen: list[ModelMessage] = []
    agent: Agent[None, str] = Agent(deps_type=type(None))

    @agent.tool
    def recall(ctx: RunContext[None]) -> str:
        seen.extend(ctx.messages)
        return 'ok'

    conn = _GatedRealtimeConnection(
        [*_speech('item-a', 2), ResponseDone(provider_response_id='resp-a')],
        [ToolCall(tool_call_id='t1', tool_name='recall', args='{}'), ResponseDone(provider_response_id='resp-b')],
    )
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        stream = session.stream_audio()
        events = aiter(session)
        await _consume_until(events, _is_turn_complete)
        await anext(stream)  # the second chunk stays buffered and unheard
        assert await session.interrupt(played_bytes=_CHUNK) is True
        conn.release.set()
        _ = [event async for event in events]

    def cuts(messages: list[ModelMessage]) -> list[tuple[str, list[int | None]]]:
        return [
            (message.state, [part.interrupted_at_ms for part in message.parts if isinstance(part, SpeechPart)])
            for message in messages
            if isinstance(message, ModelResponse) and message.provider_response_id == 'resp-a'
        ]

    assert cuts(seen) == cuts(session.all_messages()) == [('interrupted', [100])]


async def test_interrupt_played_bytes_leaves_a_reply_from_before_a_reconnect_as_recorded() -> None:
    """The fresh conversation holds a reply from before a reconnect only as replayed text, which can't be truncated.

    The connection drops a truncation of an item it no longer has, so history doesn't record that reply as cut
    off either.
    """
    conn = BlockingRealtimeConnection(
        [*_speech('item-a', 2), ResponseDone(), RealtimeSessionReconnectEvent(state_restored=False)]
    )
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        events = aiter(session)
        await _consume_until(events, lambda event: isinstance(event, RealtimeSessionReconnectEvent))
        await anext(stream)

        assert await session.interrupt(played_bytes=_CHUNK) is True

    assert _speech_cuts(session) == [('complete', [None])]


async def test_interrupt_played_ms_after_the_reply_finished_generating_leaves_no_position_behind() -> None:
    conn = _GatedRealtimeConnection(
        [*_speech('item-a'), ResponseDone()],
        [*_speech('item-b'), ResponseDone(interrupted=True)],
    )
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        events = aiter(session)
        await _consume_until(events, _is_turn_complete)
        await session.interrupt(played_ms=40)
        assert conn.sent == [TruncateOutput(audio_end_ms=40), CancelResponse()]
        conn.release.set()
        _ = [event async for event in events]

    assert _speech_cuts(session) == [('complete', [None]), ('interrupted', [None])]


async def test_interrupt_played_bytes_truncates_every_reply_generated_ahead_of_playback() -> None:
    """Two replies can finish generating before the first has finished playing — after a tool round, say.

    The one playing is truncated where playback stopped, and the one after it, never heard, at 0, and
    history records both as cut off there.
    """
    conn = BlockingRealtimeConnection([*_speech('item-a', 2), ResponseDone(), *_speech('item-b', 2), ResponseDone()])
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        events = aiter(session)
        await _consume_until(events, _is_turn_complete)
        await _consume_until(events, _is_turn_complete)
        await anext(stream)

        assert await session.interrupt(played_bytes=_CHUNK) is True
        assert conn.sent == [
            TruncateOutput(audio_end_ms=100, item_id='item-a'),
            TruncateOutput(audio_end_ms=0, item_id='item-b'),
            CancelResponse(),
        ]

    assert _speech_cuts(session) == [('interrupted', [100]), ('interrupted', [0])]


async def test_interrupt_played_bytes_without_item_ids_truncates_the_current_item() -> None:
    """A provider that names no output items can only truncate its current one: the last reply."""
    conn = BlockingRealtimeConnection(
        [
            AudioDelta(b'a' * _CHUNK),
            AudioDelta(b'a' * _CHUNK),
            ResponseDone(),
            AudioDelta(b'b' * _CHUNK),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        events = aiter(session)
        await _consume_until(events, _is_turn_complete)
        await _consume_until(events, _is_turn_complete)
        await anext(stream)

        assert await session.interrupt(played_bytes=_CHUNK) is True
        assert conn.sent == [TruncateOutput(audio_end_ms=0), CancelResponse()]


async def test_interrupt_played_bytes_clamps_to_zero_inside_a_previous_turn() -> None:
    """A playhead still inside the previous turn's audio reports 0 ms of the current turn."""
    conn = BlockingRealtimeConnection([AudioDelta(b'a' * _CHUNK), ResponseDone(), AudioDelta(b'b' * _CHUNK)])
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK
        assert await anext(stream) == b'b' * _CHUNK

        # Both turns reached the device, but it is only 50 ms into *turn 1* when the user speaks:
        # none of turn 2 was heard, so its played duration clamps to zero.
        assert await session.interrupt(played_bytes=_CHUNK // 2) is True
        assert conn.sent == [TruncateOutput(audio_end_ms=0), CancelResponse()]


async def test_interrupt_played_bytes_counts_overflow_drops_as_played_ground() -> None:
    """Chunks the tap overflow-dropped sit behind the playhead when a position is attributed.

    The consumer never saw the dropped chunks, so the device position undercounts the session's
    byte offsets by exactly their size; the mapping adds them back.
    """
    # Published in one burst before the consumer runs (the replay has no suspension points): the last
    # chunk tops the buffer up past its bound by exactly the first, which is overflow-dropped.
    chunks = [bytes([0]) * _CHUNK, bytes([1]) * _CHUNK, bytes([2]) * (_AUDIO_TAP_BYTES - _CHUNK)]
    conn = _GatedRealtimeConnection([AudioDelta(chunk) for chunk in chunks], [])
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == bytes([1]) * _CHUNK  # the first chunk was overflow-dropped

        # 100 ms reached the device, 100 ms were dropped: the playhead sits 200 ms in.
        assert await session.interrupt(played_bytes=_CHUNK) is True
        assert conn.sent == [TruncateOutput(audio_end_ms=200), CancelResponse()]


async def test_interrupt_played_bytes_anchors_at_the_subscription_point() -> None:
    """A stream subscribed mid-session reports positions relative to its own start.

    The first subscriber heard turn 1 in full and unsubscribed; the second only ever saw turn 2, so
    its device position starts at zero — without the subscription anchor the session would think a
    turn's worth of audio was never played and interrupt a fully-heard reply.
    """
    conn = _GatedRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK), ResponseDone()],
        [AudioDelta(b'b' * _CHUNK), ResponseDone()],
    )
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK
        assert isinstance(stream, _TapView)
        await stream.aclose()  # unsubscribe, so the second stream is the session's only one

        conn.release.set()
        stream2 = session.stream_audio()
        assert await anext(stream2) == b'b' * _CHUNK

        assert await session.interrupt(played_bytes=_CHUNK) is False
        assert conn.sent == []


async def test_interrupt_played_bytes_requires_exactly_one_audio_stream() -> None:
    # The audio is gated so both subscriptions register before the chunk flows to them.
    conn = _GatedRealtimeConnection([], [AudioDelta(b'a' * _CHUNK)])
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        with pytest.raises(UserError, match=r'needs exactly one active `stream_audio\(\)` iterator.*not 0'):
            await session.interrupt(played_bytes=0)

        stream1 = session.stream_audio()
        stream2 = session.stream_audio()
        pulls = [asyncio.ensure_future(anext(stream1)), asyncio.ensure_future(anext(stream2))]
        conn.release.set()
        assert await asyncio.gather(*pulls) == [b'a' * _CHUNK, b'a' * _CHUNK]
        with pytest.raises(UserError, match=r'needs exactly one active `stream_audio\(\)` iterator.*not 2'):
            await session.interrupt(played_bytes=0)


async def test_interrupt_played_bytes_degrades_without_output_truncation() -> None:
    """On a model without output truncation (xAI), `played_bytes` still flushes and cancels.

    Only the provider-side transcript sync is unavailable, so no `TruncateOutput` frame goes out —
    raising instead would make the one portable barge-in call crash on a whole provider. The
    truncating side of the profile flag runs in the attribution tests above.
    """
    conn = BlockingRealtimeConnection([AudioDelta(b'a' * _CHUNK), AudioDelta(b'b' * _CHUNK)])
    session = RealtimeSession(conn, _noop_runner, profile=_profile(supports_output_truncation=False))

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK  # `b` stays buffered and unheard

        assert await session.interrupt(played_bytes=0) is True
        assert conn.sent == [CancelResponse()]
        # Once `a` finishes playing, the flushed `b` is accounted for and nothing is left unheard.
        assert await session.interrupt(played_bytes=_CHUNK) is False
        assert conn.sent == [CancelResponse()]


async def test_interrupt_played_bytes_cancels_a_response_before_its_first_audio() -> None:
    """Barge-in during the model's think time cancels untruncated instead of no-opping.

    Everything emitted has been heard, so there is nothing to cut off — but the next response has
    started and is about to speak over the user, which returning `False` would leave running. Only
    the truncation is skipped: it is what would discard part of the reply the user did hear. Audio
    the cancelled reply had already generated must not reach the playback stream either.
    """
    conn = _CancelGatedRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK), ResponseDone(), OutputTranscript(text='Sure, one moment')],
        [AudioDelta(b'z' * _CHUNK), ResponseDone(interrupted=True)],  # in flight past the cancel
    )
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK

        async for event in session:  # pragma: no branch
            if (
                isinstance(event, PartDeltaEvent)
                and isinstance(delta := event.delta, SpeechPartDelta)
                and delta.transcript
            ):
                break

        assert await session.interrupt(played_bytes=_CHUNK) is True
        assert conn.sent == [CancelResponse()]
        # The straggler belongs to the reply that was stopped before it spoke: it is erased, so the
        # stream ends without ever playing it.
        assert [chunk async for chunk in stream] == []


async def test_interrupt_played_bytes_skips_the_cancel_while_the_server_interrupts_on_speech() -> None:
    """The manual barge-in call obeys the same client-cancel rule as `handle_barge_in=True`.

    Reacting to the speech-start event with `interrupt(played_bytes=...)` on a provider whose VAD
    already cancels the response server-side must truncate only: a client cancel racing the
    server's own can be applied to the *next* response and silence the reply to the barge-in. The
    sibling test below pins that an interruption raised outside a speech segment still cancels,
    since nothing else is stopping the response then.

    The user's whole utterance is replayed — start *and* end — before the app acts, which is the
    ordering that matters: the pump can reach the speech end long before the app dequeues the start
    it is reacting to, so the rule cannot be read off "is the user speaking right now".
    """
    conn = _GatedRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK), AudioDelta(b'b' * _CHUNK)],
        [RealtimeInputSpeechStartEvent(), RealtimeInputSpeechEndEvent()],
        interrupts_response_on_speech=True,
    )
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK  # `b` stays buffered and unheard

        conn.release.set()
        async for event in session:  # pragma: no branch
            if isinstance(event, RealtimeInputSpeechEndEvent):
                break

        assert await session.interrupt(played_bytes=0) is True
        assert conn.sent == [TruncateOutput(audio_end_ms=0)]


async def test_interrupt_played_bytes_cancels_once_the_next_response_has_started() -> None:
    """The provider only cancelled the response the user spoke over, not the reply that follows it.

    An app that interrupts again after the barge-in's reply has started is asking to stop a
    response nothing else is stopping, so the client cancel goes out — the suppression is scoped to
    one response, not latched for the rest of the session.
    """
    conn = _GatedRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK), RealtimeInputSpeechStartEvent(), RealtimeInputSpeechEndEvent()],
        [ResponseDone(interrupted=True), AudioDelta(b'r' * _CHUNK), AudioDelta(b's' * _CHUNK)],
        interrupts_response_on_speech=True,
    )
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK

        conn.release.set()
        assert await anext(stream) == b'r' * _CHUNK  # the reply to the barge-in is playing; `s` is not

        assert await session.interrupt(played_bytes=_CHUNK) is True
        assert conn.sent == [TruncateOutput(audio_end_ms=0), CancelResponse()]


async def test_interrupt_played_ms_skips_the_cancel_while_the_server_interrupts_on_speech() -> None:
    """`interrupt(played_ms=...)` and a bare `interrupt()` follow the same client-cancel rule as `played_bytes`.

    The docs promise that an interruption raised between the provider's speech onset and its next
    response sends only the truncation on a VAD that cancels server-side, whichever form of
    `interrupt()` the app uses; before this, only the `played_bytes` path honoured that.
    """
    conn = _GatedRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK)],
        [RealtimeInputSpeechStartEvent(), RealtimeInputSpeechEndEvent()],
        interrupts_response_on_speech=True,
    )
    session = RealtimeSession(conn, _noop_runner)
    async with session:
        conn.release.set()
        async for event in session:  # pragma: no branch
            if isinstance(event, RealtimeInputSpeechEndEvent):
                break
        await session.interrupt(played_ms=50)
        assert conn.sent == [TruncateOutput(audio_end_ms=50)]
        await session.interrupt()
        assert conn.sent == [TruncateOutput(audio_end_ms=50)]


async def test_interrupt_played_bytes_cancels_outside_a_speech_segment() -> None:
    """An interruption the app raises itself still cancels, even on a VAD that interrupts on speech.

    The flag says the provider stops the response *when the user speaks over it*; a stop button or
    a tool cutting the model off is not that, and skipping the cancel there would leave the
    response running.
    """
    conn = BlockingRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK), AudioDelta(b'b' * _CHUNK)], interrupts_response_on_speech=True
    )
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK  # `b` stays buffered and unheard

        assert await session.interrupt(played_bytes=0) is True
        assert conn.sent == [TruncateOutput(audio_end_ms=0), CancelResponse()]


async def test_interrupt_played_bytes_leaves_drops_ahead_of_the_device_out_of_the_playhead() -> None:
    """Chunks overflow-dropped while the device is still on an earlier one do not move the playhead.

    Drop-oldest discards what the consumer would have taken next, so a gap opens *ahead* of the
    playback position; counting it right away would report a turn as heard further in than the
    device ever reached, and truncate the model's transcript at that later point.
    """
    conn = _GatedRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK)],
        # The burst that lands while `a` is playing fills the buffer exactly, then overflows it by
        # exactly its first chunk.
        [
            AudioDelta(bytes([1]) * _CHUNK),
            AudioDelta(bytes([2]) * (_AUDIO_TAP_BYTES - _CHUNK)),
            AudioDelta(bytes([3]) * _CHUNK),
        ],
    )
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK  # the device is still playing this chunk

        conn.release.set()
        async for event in session:  # pragma: no branch
            if (
                isinstance(event, PartDeltaEvent)
                and isinstance(delta := event.delta, SpeechPartDelta)
                and delta.audio_chunk == bytes([3]) * _CHUNK
            ):
                break

        # Nothing has been played yet, and the dropped chunk is one the device had not reached.
        assert await session.interrupt(played_bytes=0) is True
        assert conn.sent == [TruncateOutput(audio_end_ms=0), CancelResponse()]

        # The burst was the last of the wire stream, so the flush also had to step over the
        # completion sentinel behind it and put it back: the iterator still ends cleanly.
        assert [chunk async for chunk in stream] == []


async def test_interrupt_rejects_both_playback_positions() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)
    with pytest.raises(UserError, match='either `played_ms` or `played_bytes`, not both'):
        await session.interrupt(played_ms=100, played_bytes=4800)  # pyright: ignore[reportCallIssue]
    with pytest.raises(UserError, match='must be a non-negative playback position'):
        await session.interrupt(played_bytes=-1)


async def test_played_audio_bytes_counts_a_chunk_when_the_consumer_returns_for_the_next() -> None:
    """`played_audio_bytes` is the iteration-confirmed playback position.

    Under the documented playback pattern the consumer only comes back for the next chunk once the
    device consumed the previous one, so resuming the iterator is the exact moment a chunk finished
    playing; the chunk just handed out is still in flight and must not be counted yet.
    """
    conn = BlockingRealtimeConnection([AudioDelta(b'a' * _CHUNK), AudioDelta(b'b' * _CHUNK)])
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK
        assert session.played_audio_bytes == 0  # `a` is still in flight
        assert await anext(stream) == b'b' * _CHUNK
        assert session.played_audio_bytes == _CHUNK  # coming back for `b` confirmed `a`

        # The one-line barge-in the docs show: the confirmed position feeds `interrupt()` directly,
        # here 100 ms into the turn with `b` in flight and nothing else emitted yet.
        assert await session.interrupt(played_bytes=session.played_audio_bytes) is True
        assert conn.sent == [TruncateOutput(audio_end_ms=100), CancelResponse()]


async def test_played_audio_bytes_requires_exactly_one_audio_stream() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)
    with pytest.raises(UserError, match=r'`played_audio_bytes` needs exactly one active.*not 0'):
        _ = session.played_audio_bytes


async def test_played_audio_bytes_after_the_connection_fails_raises_the_failure() -> None:
    """Once the receive loop dies, the audio view ends; the playback position reports why, not a misuse.

    The failure is not marked delivered, so an event-stream consumer still receives it too.
    """
    session = RealtimeSession(ExplodingConnection(), _noop_runner)
    async with session:
        assert [chunk async for chunk in session.stream_audio()] == [b'\x00']
        with pytest.raises(RuntimeError, match='connection dropped'):
            _ = session.played_audio_bytes
        with pytest.raises(RuntimeError, match='connection dropped'):
            await session.wait_for_playback()
        with pytest.raises(RuntimeError, match='connection dropped'):
            async for _ in session:
                pass


async def test_wait_for_playback_waits_for_device_paced_consumer() -> None:
    chunks = [bytes([index]) * _CHUNK for index in range(20)]
    session = RealtimeSession(BlockingRealtimeConnection([AudioDelta(chunk) for chunk in chunks]), _noop_runner)
    played: list[bytes] = []

    async with session:
        stream = session.stream_audio()

        async def play() -> None:
            async for chunk in stream:
                await asyncio.sleep(0.005)
                played.append(chunk)

        playback = asyncio.create_task(play())
        await asyncio.sleep(0)
        waiting = asyncio.create_task(session.wait_for_playback())
        await asyncio.sleep(0.005)
        assert not waiting.done()
        await waiting
        assert played == chunks
        playback.cancel()
        with pytest.raises(asyncio.CancelledError):
            await playback


async def test_wait_for_playback_returns_immediately_without_audio() -> None:
    session = RealtimeSession(BlockingRealtimeConnection([]), _noop_runner)
    async with session:
        stream = session.stream_audio()
        await session.wait_for_playback()
        assert isinstance(stream, _TapView)
        await stream.aclose()


async def test_wait_for_playback_requires_exactly_one_audio_stream() -> None:
    session = RealtimeSession(FakeRealtimeConnection([]), _noop_runner)
    async with session:
        with pytest.raises(UserError, match=r'`wait_for_playback\(\)` needs exactly one active.*not 0'):
            await session.wait_for_playback()

        first = session.stream_audio()
        second = session.stream_audio()
        with pytest.raises(UserError, match=r'`wait_for_playback\(\)` needs exactly one active.*not 2'):
            await session.wait_for_playback()
        assert isinstance(first, _TapView) and isinstance(second, _TapView)
        await first.aclose()
        await second.aclose()


async def test_wait_for_playback_returns_when_session_closes() -> None:
    session = RealtimeSession(BlockingRealtimeConnection([AudioDelta(b'audio')]), _noop_runner)
    await session.__aenter__()
    stream = session.stream_audio()
    assert await anext(stream) == b'audio'
    waiting = asyncio.create_task(session.wait_for_playback())
    await asyncio.sleep(0)
    assert not waiting.done()
    await session.close()
    await waiting


async def test_wait_for_playback_drains_after_pump_finishes() -> None:
    chunks = [b'first', b'second']
    session = RealtimeSession(FakeRealtimeConnection([AudioDelta(chunk) for chunk in chunks]), _noop_runner)
    async with session:
        stream = session.stream_audio()
        await asyncio.sleep(0)
        waiting = asyncio.create_task(session.wait_for_playback())
        await asyncio.sleep(0)
        assert not waiting.done()
        assert [chunk async for chunk in stream] == chunks
        await waiting


async def test_wait_for_playback_returns_when_view_is_closed() -> None:
    session = RealtimeSession(BlockingRealtimeConnection([AudioDelta(b'audio')]), _noop_runner)
    async with session:
        stream = session.stream_audio()
        await asyncio.sleep(0)
        waiting = asyncio.create_task(session.wait_for_playback())
        await asyncio.sleep(0)
        assert not waiting.done()
        assert isinstance(stream, _TapView)
        await stream.aclose()
        await waiting


async def test_handle_barge_in_interrupts_automatically_on_speech_start() -> None:
    """With `handle_barge_in=True` the session runs the whole local half of barge-in itself.

    The app writes no handler at all: the session attributes its own tracked playback position,
    flushes the unheard chunk, truncates, and cancels — and the speech-start event still reaches
    the app's iterator afterwards, already handled.
    """
    conn = _GatedRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK), AudioDelta(b'b' * _CHUNK), AudioDelta(b'c' * _CHUNK)],
        [RealtimeInputSpeechStartEvent()],
    )
    session = RealtimeSession(conn, _noop_runner, handle_barge_in=True)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK
        assert await anext(stream) == b'b' * _CHUNK  # confirms `a`; `b` in flight, `c` buffered

        conn.release.set()
        events = await drain_events(session)

        assert RealtimeInputSpeechStartEvent() in events
        assert conn.sent == [TruncateOutput(audio_end_ms=100), CancelResponse()]
        # `c` was flushed; the stream ends without delivering it.
        assert [chunk async for chunk in stream] == []


async def test_handle_barge_in_without_truncation_flushes_and_cancels() -> None:
    """On a model without output truncation (xAI), unheard audio still means flush plus a bare cancel."""
    conn = _GatedRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK), AudioDelta(b'b' * _CHUNK)],
        [RealtimeInputSpeechStartEvent()],
    )
    session = RealtimeSession(
        conn, _noop_runner, handle_barge_in=True, profile=_profile(supports_output_truncation=False)
    )

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK  # `a` in flight, `b` buffered and unheard

        conn.release.set()
        _ = await drain_events(session)

        assert conn.sent == [CancelResponse()]
        assert [chunk async for chunk in stream] == []


async def test_handle_barge_in_does_nothing_on_a_quiet_turn() -> None:
    """A speech start with no unheard audio must not send anything.

    Here nothing was ever spoken (an ordinary user turn); on a model without truncation this is the
    guard that prevents cancel-spamming the provider on every user utterance.
    """
    conn = _GatedRealtimeConnection([], [RealtimeInputSpeechStartEvent()])
    session = RealtimeSession(
        conn, _noop_runner, handle_barge_in=True, profile=_profile(supports_output_truncation=False)
    )

    async with session:
        stream = session.stream_audio()
        pull = asyncio.ensure_future(anext(stream))  # subscribe the single tap
        await asyncio.sleep(0)
        conn.release.set()
        _ = await drain_events(session)

        assert conn.sent == []
        with pytest.raises(StopAsyncIteration):
            await pull


async def test_handle_barge_in_stands_down_without_a_single_audio_stream() -> None:
    """Auto barge-in only acts on the single device-paced consumer setup it can reason about.

    With no `stream_audio()` subscriber the session has no playback position and no buffer to
    flush, so it must leave barge-in to the app rather than guess.
    """
    conn = FakeRealtimeConnection([AudioDelta(b'a' * _CHUNK), RealtimeInputSpeechStartEvent()])
    session = RealtimeSession(conn, _noop_runner, handle_barge_in=True)

    _ = await collect_events(session)

    assert conn.sent == []


async def test_handle_barge_in_respects_missing_interruption_support() -> None:
    conn = _GatedRealtimeConnection([AudioDelta(b'a' * _CHUNK)], [RealtimeInputSpeechStartEvent()])
    session = RealtimeSession(conn, _noop_runner, handle_barge_in=True, profile=_profile(supports_interruption=False))

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK
        conn.release.set()
        _ = await drain_events(session)

        assert conn.sent == []


async def test_handle_barge_in_skips_the_cancel_when_the_server_interrupts_on_speech() -> None:
    """When the configured VAD already cancels the response on speech onset, only the truncation goes out.

    A client cancel racing the server's own cancellation can be applied to the *next* response and
    silence the reply to the barge-in (observed live against OpenAI's `interrupt_response: true`
    server VAD), so the connection advertises the behavior and the automatic path defers to it.
    """
    conn = _GatedRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK), AudioDelta(b'b' * _CHUNK)],
        [RealtimeInputSpeechStartEvent()],
        interrupts_response_on_speech=True,
    )
    session = RealtimeSession(conn, _noop_runner, handle_barge_in=True)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK  # `a` in flight, `b` buffered and unheard

        conn.release.set()
        _ = await drain_events(session)

        assert conn.sent == [TruncateOutput(audio_end_ms=0)]
        assert [chunk async for chunk in stream] == []


async def test_handle_barge_in_sends_nothing_when_the_server_interrupts_without_truncation() -> None:
    """Server-side interruption plus no output truncation (xAI defaults) leaves only the local flush."""
    conn = _GatedRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK), AudioDelta(b'b' * _CHUNK)],
        [RealtimeInputSpeechStartEvent()],
        interrupts_response_on_speech=True,
    )
    session = RealtimeSession(
        conn, _noop_runner, handle_barge_in=True, profile=_profile(supports_output_truncation=False)
    )

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK

        conn.release.set()
        _ = await drain_events(session)

        assert conn.sent == []
        assert [chunk async for chunk in stream] == []


async def test_handle_barge_in_flushes_on_provider_initiated_interruption() -> None:
    """Gemini reports no speech start; it interrupts itself, leaving only the local flush to do."""
    conn = _GatedRealtimeConnection(
        [AudioDelta(b'a' * _CHUNK), AudioDelta(b'b' * _CHUNK)],
        [RealtimeResponseInterruptedEvent()],
    )
    session = RealtimeSession(conn, _noop_runner, handle_barge_in=True)

    async with session:
        stream = session.stream_audio()
        assert await anext(stream) == b'a' * _CHUNK  # `b` stays buffered, then unheard

        conn.release.set()
        _ = await drain_events(session)

        # The interruption is provider-side already: nothing to send, only local audio to drop.
        assert conn.sent == []
        assert [chunk async for chunk in stream] == []


async def test_speech_parts_do_not_persist_provider_item_ids() -> None:
    openai = RealtimeSession(
        FakeRealtimeConnection([OutputTranscript(text='hello', is_final=True, item_id='item-a'), ResponseDone()]),
        _noop_runner,
        provider_name='openai',
    )
    gemini = RealtimeSession(
        FakeRealtimeConnection([OutputTranscript(text='hello', is_final=True), ResponseDone()]),
        _noop_runner,
        provider_name='google',
    )
    _ = await collect_events(openai)
    _ = await collect_events(gemini)

    openai_part = openai.new_messages()[0].parts[0]
    gemini_part = gemini.new_messages()[0].parts[0]
    assert isinstance(openai_part, SpeechPart) and isinstance(gemini_part, SpeechPart)
    assert (openai_part.id, openai_part.provider_name) == (None, None)
    assert (gemini_part.id, gemini_part.provider_name) == (None, None)


# --- tool calls: history + events --------------------------------------------------------------


async def test_turn_completes_once_the_tool_round_is_over_not_before() -> None:
    """`RealtimeTurnCompleteEvent` waits for the response *after* the tool, which is the whole point of it.

    The provider's own turn boundary arrives once per response, so a tool round produces several and
    which one is last differs by model — `gpt-realtime-2.1` and xAI Grok Voice speak *before* calling the
    tool, so stopping on their first boundary truncates the exchange. This connection answers the tool
    result the way a provider does, so the ordering is the real one rather than the fixture's.
    """
    tool_answered = asyncio.Event()

    class _AnswersTheTool(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            # The tool result is the only thing the session sends in this scenario.
            if isinstance(content, ToolResult):  # pragma: no branch
                tool_answered.set()
            self.sent.append(content)

        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='tc_1', tool_name='get_weather', args='{"city": "Paris"}')
            yield ResponseDone()  # the tool-call response; the exchange is not over
            await tool_answered.wait()
            yield OutputTranscript(text='It is sunny in Paris', is_final=True)
            yield ResponseDone()  # the answer; now it is

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'Sunny, 22C'

    session = RealtimeSession(_AnswersTheTool([]), runner, model_name='m')
    events = await collect_events(session)

    assert [type(event).__name__ for event in events] == snapshot(
        [
            'PartStartEvent',
            'PartEndEvent',
            'FunctionToolCallEvent',
            'FunctionToolResultEvent',
            'PartStartEvent',
            'PartDeltaEvent',
            'PartEndEvent',
            'RealtimeTurnCompleteEvent',
        ]
    )
    # Exactly one, and it lands after the model has actually answered.
    assert [i for i, e in enumerate(events) if isinstance(e, RealtimeTurnCompleteEvent)] == [len(events) - 1]


async def test_tool_call_round_builds_classic_history() -> None:
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text="what's the weather in Paris", is_final=True),
            ToolCall(tool_call_id='tc_1', tool_name='get_weather', args='{"city": "Paris"}'),
            OutputTranscript(text="It's sunny in Paris", is_final=True),
            ResponseDone(),
        ]
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        assert name == 'get_weather'
        assert args == {'city': 'Paris'}
        return 'Sunny, 22C'

    session = RealtimeSession(conn, runner, model_name='m')
    events = await collect_events(session)

    assert [type(e).__name__ for e in events] == snapshot(
        [
            'PartStartEvent',  # user transcript start
            'PartDeltaEvent',
            'PartEndEvent',  # user transcript end
            'PartStartEvent',  # tool call part start
            'PartEndEvent',  # tool call part end
            'FunctionToolCallEvent',
            'PartStartEvent',  # assistant answer start
            'PartDeltaEvent',
            'PartEndEvent',
            'FunctionToolResultEvent',
        ]
    )

    assert conn.sent == [ToolResult(tool_call_id='tc_1', output='Sunny, 22C')]
    # History mirrors a classic tool-call round: user request, tool-call response, tool result, answer.
    assert session.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[SpeechPart(speaker='user', transcript="what's the weather in Paris")], timestamp=IsDatetime()
            ),
            ModelResponse(
                parts=[ToolCallPart(tool_name='get_weather', args='{"city": "Paris"}', tool_call_id='tc_1')],
                model_name='m',
                timestamp=IsDatetime(),
                finish_reason='tool_call',
            ),
            ModelRequest(
                parts=[
                    ToolReturnPart(
                        tool_name='get_weather', content='Sunny, 22C', tool_call_id='tc_1', timestamp=IsDatetime()
                    )
                ],
                timestamp=IsDatetime(),
            ),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript="It's sunny in Paris")],
                model_name='m',
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


async def test_speech_finalized_by_a_tool_call_reaches_the_transcript_view() -> None:
    """Speech the model finalizes by calling a tool still reaches `stream_transcripts()`.

    A voice agent's most useful turn says something ("let me look that up") *and* calls a tool. The
    tool-call dispatch path finalizes the in-flight `SpeechPart` before folding the call in, so that
    turn's transcript only reaches subscribers if the dispatch path publishes to the taps the way the
    ordinary translation path does.
    """
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text="what's the weather in Paris", is_final=True),
            OutputTranscript(text='Let me check that for you.', is_final=True),
            ToolCall(tool_call_id='tc_1', tool_name='get_weather', args='{"city": "Paris"}'),
            OutputTranscript(text="It's sunny in Paris", is_final=True),
            ResponseDone(),
        ]
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'Sunny, 22C'

    session = RealtimeSession(conn, runner, model_name='m')
    async with session:
        _, transcripts, deltas = await asyncio.gather(
            drain_events(session),
            aiter_to_list(session.stream_transcripts()),
            aiter_to_list(session.stream_transcripts(delta=True)),
        )

    # The speech that preceded the call is on the view, not just in history.
    assert transcripts == snapshot(
        [
            SpeechPart(speaker='user', transcript="what's the weather in Paris"),
            SpeechPart(speaker='assistant', transcript='Let me check that for you.'),
            SpeechPart(speaker='assistant', transcript="It's sunny in Paris"),
        ]
    )
    # The same turns as history records, so a consumer reading the view sees what the assistant said.
    assert [
        (part.speaker, part.transcript)
        for message in session.new_messages()
        for part in message.parts
        if isinstance(part, SpeechPart)
    ] == [(part.speaker, part.transcript) for part in transcripts]
    # The delta view already tracked the pre-call speech; ending its turn clears the running text so
    # the answer's deltas don't continue it.
    assert deltas == snapshot(
        [
            TranscriptUpdate(
                index=0,
                speaker='user',
                delta="what's the weather in Paris",
                transcript="what's the weather in Paris",
            ),
            TranscriptUpdate(
                index=1,
                speaker='assistant',
                delta='Let me check that for you.',
                transcript='Let me check that for you.',
            ),
            TranscriptUpdate(
                index=3, speaker='assistant', delta="It's sunny in Paris", transcript="It's sunny in Paris"
            ),
        ]
    )


async def test_tool_returning_a_file_frames_it_with_its_call() -> None:
    """A tool's file rides `ToolResult.content` framed with the call it came from.

    The realtime tool channel is text-only, so a tool's file travels the same user channel the end
    user speaks on. Seeding covers the other two realtime paths; this is the live send, and nothing
    else exercises it with a tool whose return value actually carries a file.
    """
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text="what's the weather in Paris", is_final=True),
            ToolCall(tool_call_id='tc_1', tool_name='get_weather', args='{"city": "Paris"}'),
            OutputTranscript(text='Rain moving in', is_final=True),
            ResponseDone(),
        ]
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> BinaryImage:
        return BinaryImage(data=b'png', media_type='image/png', identifier='radar')

    session = RealtimeSession(conn, runner, model_name='m')
    await collect_events(session)

    assert conn.sent == snapshot(
        [
            ToolResult(
                tool_call_id='tc_1',
                output='See file radar.',
                content=[
                    '<tool_result tool_name="get_weather" tool_call_id="tc_1" file_id="radar">',
                    BinaryImage(data=b'png', media_type='image/png', identifier='radar'),
                    '</tool_result>',
                ],
            )
        ]
    )


async def test_late_input_transcript_still_precedes_the_response_it_prompted() -> None:
    """A user turn keeps its place in history however late the provider transcribes it.

    Input transcription is asynchronous, and the final event can land after the response the speech
    prompted has already been recorded — measured live on Azure and Gemini Live, and reachable on OpenAI
    and xAI under load, because a function-call-only response finalizes long before the transcript. Read
    back, an appended user turn says the model called a tool unprompted and only then heard the question.

    The wire order here is Azure's, measured live: speech start, the transcript's partials, then the whole
    tool round, and only afterwards the `.completed` snapshot.
    """
    conn = FakeRealtimeConnection(
        [
            RealtimeInputSpeechStartEvent(),
            InputTranscript(text="what's the weather in Paris", item_id='item-1'),
            ToolCall(tool_call_id='tc_1', tool_name='get_weather', args='{"city": "Paris"}'),
            InputTranscript(text="what's the weather in Paris", is_final=True, item_id='item-1'),
            OutputTranscript(text="It's sunny in Paris", is_final=True),
            ResponseDone(),
        ]
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'Sunny, 22C'

    session = RealtimeSession(conn, runner, model_name='m')
    await collect_events(session)

    assert [
        (type(message).__name__, [type(part).__name__ for part in message.parts]) for message in session.new_messages()
    ] == snapshot(
        [
            ('ModelRequest', ['SpeechPart']),
            ('ModelResponse', ['ToolCallPart']),
            ('ModelRequest', ['ToolReturnPart']),
            ('ModelResponse', ['SpeechPart']),
        ]
    )


async def test_late_input_transcript_of_a_second_turn_follows_the_first_exchange() -> None:
    """A late transcript joins the conversation where its turn started, not at the front of history.

    The first exchange is already recorded when the second spoken turn opens, so that turn's place is
    after it — the same rule that keeps a first turn ahead of its own response has to know how far along
    the conversation was.
    """
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='what is the weather', is_final=True, item_id='item-1'),
            OutputTranscript(text='Sunny.', is_final=True),
            ResponseDone(),
            RealtimeInputSpeechStartEvent(),
            InputTranscript(text='and tomorrow', item_id='item-2'),
            ToolCall(tool_call_id='tc_1', tool_name='get_weather', args='{"city": "Paris"}'),
            InputTranscript(text='and tomorrow', is_final=True, item_id='item-2'),
            OutputTranscript(text='Rain.', is_final=True),
            ResponseDone(),
        ]
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'Rain, 12C'

    session = RealtimeSession(conn, runner, model_name='m')
    await collect_events(session)

    assert [
        (type(message).__name__, [type(part).__name__ for part in message.parts]) for message in session.new_messages()
    ] == snapshot(
        [
            ('ModelRequest', ['SpeechPart']),
            ('ModelResponse', ['SpeechPart']),
            ('ModelRequest', ['SpeechPart']),
            ('ModelResponse', ['ToolCallPart']),
            ('ModelRequest', ['ToolReturnPart']),
            ('ModelResponse', ['SpeechPart']),
        ]
    )


async def test_late_input_transcript_anchors_from_sent_audio_without_speech_boundaries() -> None:
    """The turn is placed even on a provider that reports no speech boundary at all.

    Gemini Live sends neither `RealtimeInputSpeechStartEvent` nor a final input transcript, so the turn is only
    finalized at `ResponseDone` — by which time its tool round is long recorded. Audio starting is
    then the only signal that a user turn began, so that is where its place in history comes from.
    """
    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='tc_1', tool_name='get_weather', args='{"city": "Paris"}'),
            InputTranscript(text="what's the weather in Paris"),
            OutputTranscript(text="It's sunny in Paris", is_final=True),
            ResponseDone(),
        ],
        after_input=True,
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'Sunny, 22C'

    session = RealtimeSession(conn, runner, model_name='m')
    async with session:
        await session.send_audio(b'\x00\x01')
        await drain_events(session)

    assert [
        (type(message).__name__, [type(part).__name__ for part in message.parts]) for message in session.new_messages()
    ] == snapshot(
        [
            ('ModelRequest', ['SpeechPart']),
            ('ModelResponse', ['ToolCallPart']),
            ('ModelRequest', ['ToolReturnPart']),
            ('ModelResponse', ['SpeechPart']),
        ]
    )


async def test_late_overlapping_input_transcripts_keep_their_speech_start_anchors() -> None:
    conn = FakeRealtimeConnection(
        [
            RealtimeInputSpeechStartEvent(item_id='u1'),
            RealtimeInputSpeechEndEvent(item_id='u1'),
            OutputTranscript(text='answer one', is_final=True),
            ResponseDone(),
            RealtimeInputSpeechStartEvent(item_id='u2'),
            InputTranscript(text='question one', is_final=True, item_id='u1'),
            RealtimeInputSpeechEndEvent(item_id='u2'),
            InputTranscript(text='question two', is_final=True, item_id='u2'),
            OutputTranscript(text='answer two', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)

    await collect_events(session)

    assert session.all_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question one')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer one')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question two')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer two')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


async def test_repeated_speech_end_for_finalized_item_does_not_duplicate_user_turn() -> None:
    conn = FakeRealtimeConnection(
        [
            RealtimeInputSpeechStartEvent(item_id='u1'),
            RealtimeInputSpeechEndEvent(item_id='u1'),
            InputTranscript(text='question one', is_final=True, item_id='u1'),
            RealtimeInputSpeechEndEvent(item_id='u1'),
            OutputTranscript(text='answer one', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)

    events = await collect_events(session)

    assert events == snapshot(
        [
            RealtimeInputSpeechStartEvent(item_id='u1'),
            RealtimeInputSpeechEndEvent(item_id='u1'),
            PartStartEvent(index=0, part=SpeechPart(speaker='user', transcript='')),
            PartDeltaEvent(
                index=0,
                delta=SpeechPartDelta(speaker='user', transcript_delta='question one', transcript='question one'),
            ),
            PartEndEvent(index=0, part=SpeechPart(speaker='user', transcript='question one')),
            RealtimeInputSpeechEndEvent(item_id='u1'),
            PartStartEvent(index=1, part=SpeechPart(speaker='assistant', transcript='')),
            PartDeltaEvent(
                index=1,
                delta=SpeechPartDelta(speaker='assistant', transcript_delta='answer one', transcript='answer one'),
            ),
            PartEndEvent(index=1, part=SpeechPart(speaker='assistant', transcript='answer one')),
            RealtimeTurnCompleteEvent(),
        ]
    )
    assert session.all_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question one')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer one')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


async def test_speech_end_after_finalized_anonymous_transcript_does_not_duplicate_user_turn() -> None:
    conn = FakeRealtimeConnection(
        [
            RealtimeInputSpeechStartEvent(),
            InputTranscript(text='hello there', is_final=True),
            RealtimeInputSpeechEndEvent(),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)

    await collect_events(session)

    assert session.all_messages() == snapshot(
        [ModelRequest(parts=[SpeechPart(speaker='user', transcript='hello there')], timestamp=IsDatetime())]
    )


async def test_later_transcript_waits_for_earlier_speech_end_placeholder() -> None:
    conn = FakeRealtimeConnection(
        [
            RealtimeInputSpeechStartEvent(item_id='u1'),
            RealtimeInputSpeechEndEvent(item_id='u1'),
            RealtimeInputSpeechStartEvent(item_id='u2'),
            InputTranscript(text='question two', is_final=True, item_id='u2'),
            InputTranscript(text='question one', is_final=True, item_id='u1'),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)

    await collect_events(session)

    assert session.all_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question one')], timestamp=IsDatetime()),
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question two')], timestamp=IsDatetime()),
        ]
    )


async def test_missing_input_transcript_keeps_a_contentless_user_turn() -> None:
    conn = FakeRealtimeConnection(
        [
            RealtimeInputSpeechStartEvent(item_id='u1'),
            RealtimeInputSpeechEndEvent(item_id='u1'),
            OutputTranscript(text='answer one', is_final=True),
            ResponseDone(),
            RealtimeInputSpeechStartEvent(item_id='u2'),
            RealtimeInputSpeechEndEvent(item_id='u2'),
            InputTranscript(text='question two', is_final=True, item_id='u2'),
            OutputTranscript(text='answer two', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)

    await collect_events(session)

    assert session.all_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer one')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question two')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer two')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


async def test_idless_late_transcript_closes_before_the_next_audio_turn() -> None:
    first_transcript_processed = asyncio.Event()
    second_audio_sent = asyncio.Event()

    class _LateIdlessTranscript(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            await self._input_sent.wait()  # the model answers the audio sent
            for event in [
                OutputTranscript(text='answer one', is_final=True),
                ResponseDone(),
                InputTranscript(text='question one'),
            ]:
                yield event
            first_transcript_processed.set()
            await second_audio_sent.wait()
            for event in [
                InputTranscript(text='question two'),
                OutputTranscript(text='answer two', is_final=True),
                ResponseDone(),
            ]:
                yield event

        async def send_input(self, content: RealtimeInput) -> None:
            await super().send_input(content)
            if len(self.sent) == 2:
                second_audio_sent.set()

    conn = _LateIdlessTranscript([])
    session = RealtimeSession(conn, _noop_runner)

    async with session:
        await session.send_audio(b'first')
        events_task = asyncio.create_task(drain_events(session))
        await first_transcript_processed.wait()
        await session.send_audio(b'second')
        await events_task

    assert session.all_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question one')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer one')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question two')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer two')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


async def test_idless_next_audio_turn_keeps_anchor_when_output_precedes_transcript() -> None:
    first_transcript_processed = asyncio.Event()
    second_audio_sent = asyncio.Event()

    class _OutputBeforeSecondTranscript(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            await self._input_sent.wait()  # the model answers the audio sent
            for event in [
                OutputTranscript(text='answer one', is_final=True),
                ResponseDone(),
                InputTranscript(text='question one'),
            ]:
                yield event
            first_transcript_processed.set()
            await second_audio_sent.wait()
            for event in [
                OutputTranscript(text='answer two', is_final=True),
                ResponseDone(),
                InputTranscript(text='question two', is_final=True),
            ]:
                yield event

        async def send_input(self, content: RealtimeInput) -> None:
            await super().send_input(content)
            if len(self.sent) == 2:
                second_audio_sent.set()

    session = RealtimeSession(_OutputBeforeSecondTranscript([]), _noop_runner)

    async with session:
        await session.send_audio(b'first')
        events_task = asyncio.create_task(drain_events(session))
        await first_transcript_processed.wait()
        await session.send_audio(b'second')
        await events_task

    assert session.all_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question one')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer one')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question two')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer two')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


async def test_idless_speech_start_reanchors_the_turn_local_audio_opened() -> None:
    """Local audio reserves the turn's place; an id-less speech start for the same turn must not reserve a second one."""
    conn = FakeRealtimeConnection(
        [
            RealtimeInputSpeechStartEvent(),
            InputTranscript(text='question one', is_final=True),
            OutputTranscript(text='answer one', is_final=True),
            ResponseDone(),
            RealtimeInputSpeechStartEvent(),
            InputTranscript(text='question two', is_final=True),
            OutputTranscript(text='answer two', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)
    async with session:
        await session.send_audio(b'first')
        await drain_events(session)

    assert session.all_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question one')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer one')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question two')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer two')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


async def test_idless_late_transcript_does_not_merge_with_next_audio_turn() -> None:
    second_audio_sent = asyncio.Event()

    class _LateTranscriptAfterNextAudio(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            await self._input_sent.wait()  # the model answers the audio sent
            for event in [OutputTranscript(text='answer one', is_final=True), ResponseDone()]:
                yield event
            await second_audio_sent.wait()
            for event in [
                InputTranscript(text='question one', is_final=True),
                InputTranscript(text='question two', is_final=True),
                OutputTranscript(text='answer two', is_final=True),
                ResponseDone(),
            ]:
                yield event

        async def send_input(self, content: RealtimeInput) -> None:
            await super().send_input(content)
            if len(self.sent) == 2:
                second_audio_sent.set()

    session = RealtimeSession(_LateTranscriptAfterNextAudio([]), _noop_runner)

    async with session:
        transcripts = session.stream_transcripts()
        await session.send_audio(b'first')
        events_task = asyncio.create_task(drain_events(session))
        assert (await anext(transcripts)).transcript == 'answer one'  # the first reply is in history
        await session.send_audio(b'second')
        await events_task

    assert session.all_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question one')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer one')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='question two')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer two')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


class _UserAction:
    """Marks where a scripted connection's user acts on the session, in between the provider's events."""

    def __init__(self, act: Callable[[_RealtimeSession], Awaitable[None]]) -> None:
        self.act = act


async def _send_microphone_frame(session: _RealtimeSession) -> None:
    await session.send_audio(bytes(3200))


async def _release_push_to_talk(session: _RealtimeSession) -> None:
    await session.commit_audio()
    await session.create_response()


_MIC = _UserAction(_send_microphone_frame)
"""The microphone sends another frame: speech, or the silence an always-on microphone streams between turns."""
_RELEASE = _UserAction(_release_push_to_talk)
"""The user lets go of the push-to-talk button: the buffered audio is committed and a response requested."""


class _ContinuousMicrophoneConnection(FakeRealtimeConnection):
    """A connection whose script interleaves what the user does, their microphone above all, with its events.

    The microphone never stops, so a frame lands between most provider events, and each is sent only
    after the session has handled every event before it.
    """

    def __init__(
        self, script: list[RealtimeCodecEvent | _UserAction], *, input_transcription_enabled: bool = True
    ) -> None:
        super().__init__([], input_transcription_enabled=input_transcription_enabled)
        self._script = script
        self.session: _RealtimeSession | None = None
        self._tool_result_sent = asyncio.Event()

    async def send_input(self, content: RealtimeInput) -> None:
        await super().send_input(content)
        if isinstance(content, ToolResult):
            self._tool_result_sent.set()

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        assert self.session is not None
        for item in self._script:
            if isinstance(item, _UserAction):
                await item.act(self.session)
                continue
            yield item
            if isinstance(item, ToolCall):
                # Gemini closes the tool-call turn once it has the result, as the recording shows.
                await self._tool_result_sent.wait()


async def test_idless_continuous_microphone_keeps_one_user_request_per_turn() -> None:
    """A microphone that streams silence between turns doesn't split or reorder id-less user turns.

    Audio arriving while the model answers is not the user's next turn: it must neither reserve that
    turn's place in history ahead of the answer, nor count as a turn the answer ended, which would close
    the next real turn after its first transcript fragment. Covers a transcript that arrives before the
    answer, one finalized ahead of a tool round, and one that lags behind the answer it prompted.
    """
    conn = _ContinuousMicrophoneConnection(
        [
            _MIC,
            _MIC,
            InputTranscript(text='My'),
            _MIC,
            InputTranscript(text=' name is Alice.'),
            _MIC,
            AudioDelta(data=b'\x01\x00'),
            _MIC,
            OutputTranscript(text='Hi Alice.'),
            _MIC,
            AudioDelta(data=b'\x01\x00'),
            _MIC,
            ResponseDone(),
            _MIC,
            _MIC,
            InputTranscript(text="What's the"),
            _MIC,
            InputTranscript(text=' weather in Paris?', is_final=True),
            ToolCall(tool_call_id='tc-1', tool_name='get_weather', args='{"city": "Paris"}'),
            ResponseDone(),
            _MIC,
            AudioDelta(data=b'\x01\x00'),
            _MIC,
            OutputTranscript(text='It is foggy.'),
            _MIC,
            ResponseDone(),
            _MIC,
            _MIC,
            AudioDelta(data=b'\x01\x00'),
            _MIC,
            OutputTranscript(text='Your name is Alice.'),
            _MIC,
            InputTranscript(text='Can you remind'),
            _MIC,
            InputTranscript(text=' me of my name?'),
            _MIC,
            ResponseDone(),
            _MIC,
        ]
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'Foggy, 12C'

    session = RealtimeSession(conn, runner)
    conn.session = session
    async with session:
        await drain_events(session)

    assert session.all_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='My name is Alice.')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='Hi Alice.')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
            ModelRequest(
                parts=[SpeechPart(speaker='user', transcript="What's the weather in Paris?")], timestamp=IsDatetime()
            ),
            ModelResponse(
                parts=[ToolCallPart(tool_name='get_weather', args='{"city": "Paris"}', tool_call_id='tc-1')],
                timestamp=IsDatetime(),
                finish_reason='tool_call',
            ),
            ModelRequest(
                parts=[
                    ToolReturnPart(
                        tool_name='get_weather', content='Foggy, 12C', tool_call_id='tc-1', timestamp=IsDatetime()
                    )
                ],
                timestamp=IsDatetime(),
            ),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='It is foggy.')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
            ModelRequest(
                parts=[SpeechPart(speaker='user', transcript='Can you remind me of my name?')], timestamp=IsDatetime()
            ),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='Your name is Alice.')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )
    assert_conversation_invariants(session, ['alice', 'paris', 'remind'])


async def test_push_to_talk_user_turn_precedes_its_answer_when_its_transcript_lags() -> None:
    """A push-to-talk turn whose transcript lands after its answer is still recorded ahead of that answer.

    With manual turn-taking nothing reports speech boundaries: the audio the user sent is the only sign
    a turn began, and the transcript that names its item routinely arrives after `response.done`.
    """
    conn = _ContinuousMicrophoneConnection(
        [
            _MIC,
            _MIC,
            _RELEASE,
            InputTranscript(text='What is the capital of France?', is_final=True),
            OutputTranscript(text='Paris.', is_final=True),
            ResponseDone(),
            _MIC,
            _MIC,
            _RELEASE,
            OutputTranscript(text='Lima.', is_final=True),
            ResponseDone(),
            InputTranscript(text='And of Peru?', is_final=True),
            _MIC,
            _RELEASE,
            InputTranscript(text='Remind me of the first one.', is_final=True),
            OutputTranscript(text='Paris.', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn)
    conn.session = session
    async with session:
        await drain_events(session)

    assert_conversation_invariants(session, ['france', 'peru', 'remind'])


async def test_push_to_talk_turn_committed_while_the_model_answers_follows_that_answer() -> None:
    """A turn recorded and committed while the previous answer is still streaming is filed after that answer.

    Audio sent while the model answers reserves no place in history, so the commit that ends the turn is
    what places it.
    """
    conn = _ContinuousMicrophoneConnection(
        [
            _MIC,
            _RELEASE,
            AudioDelta(data=b'\x01\x00'),
            OutputTranscript(text='Paris.'),
            _MIC,
            _RELEASE,
            ResponseDone(),
            InputTranscript(text='What is the capital of France?', is_final=True),
            AudioDelta(data=b'\x01\x00'),
            OutputTranscript(text='Lima.'),
            ResponseDone(),
            InputTranscript(text='And of Peru?', is_final=True),
        ]
    )
    session = RealtimeSession(conn)
    conn.session = session
    async with session:
        await drain_events(session)

    assert_conversation_invariants(session, ['france', 'peru'])


@pytest.mark.parametrize(
    'interrupted_turn',
    [
        pytest.param(
            [
                RealtimeInputSpeechStartEvent(item_id='u2'),
                ResponseDone(interrupted=True),
                _MIC,
                RealtimeInputSpeechEndEvent(item_id='u2'),
                InputTranscript(text='Stop, what is two plus two?', is_final=True, item_id='u2'),
            ],
            id='cancelled-before-transcript',
        ),
        pytest.param(
            [
                RealtimeInputSpeechStartEvent(item_id='u2'),
                _MIC,
                RealtimeInputSpeechEndEvent(item_id='u2'),
                InputTranscript(text='Stop, what is two plus two?', is_final=True, item_id='u2'),
                ResponseDone(interrupted=True),
            ],
            id='transcript-before-cancelled',
        ),
        pytest.param(
            [
                RealtimeInputSpeechStartEvent(item_id='u2'),
                _MIC,
                RealtimeInputSpeechEndEvent(item_id='u2'),
                InputTranscript(text='Stop, what is', item_id='u2'),
                ResponseDone(interrupted=True),
                InputTranscript(text='Stop, what is two plus two?', is_final=True, item_id='u2', cumulative=True),
            ],
            id='transcript-streaming-across-cancelled',
        ),
    ],
)
async def test_barge_in_user_turn_follows_the_response_it_interrupted(
    interrupted_turn: list[RealtimeCodecEvent | _UserAction],
) -> None:
    """Speech that starts while the model is still answering is filed after that answer, not before it."""
    conn = _ContinuousMicrophoneConnection(
        [
            _MIC,
            RealtimeInputSpeechStartEvent(item_id='u1'),
            _MIC,
            RealtimeInputSpeechEndEvent(item_id='u1'),
            InputTranscript(text='Tell me a story.', is_final=True, item_id='u1'),
            AudioDelta(data=b'\x01\x00'),
            _MIC,
            OutputTranscript(text='Once upon a time'),
            _MIC,
            *interrupted_turn,
            AudioDelta(data=b'\x01\x00'),
            _MIC,
            OutputTranscript(text='Four.', is_final=True),
            ResponseDone(),
            _MIC,
        ]
    )
    session = RealtimeSession(conn)
    conn.session = session
    async with session:
        await drain_events(session)

    assert_conversation_invariants(session, ['story', 'two'])
    assert [message.state for message in session.all_messages() if isinstance(message, ModelResponse)] == [
        'interrupted',
        'complete',
    ]


@pytest.mark.parametrize(
    'script',
    [
        pytest.param(
            [
                _MIC,
                InputTranscript(text='Tell me a story.'),
                _MIC,
                InputTranscript(text='', is_final=True),
                AudioDelta(data=b'\x01\x00'),
                OutputTranscript(text='Once upon a time'),
                _MIC,
                InputTranscript(text='Stop, what is two plus two?'),
                _MIC,
                InputTranscript(text='', is_final=True),
                OutputTranscript(text=' - four.'),
                AudioDelta(data=b'\x01\x00'),
                ResponseDone(),
            ],
            id='no-speech-boundaries',
        ),
    ],
)
async def test_idless_barge_in_transcript_follows_the_answer_it_spoke_over(
    script: list[RealtimeCodecEvent | _UserAction],
) -> None:
    """An id-less turn first heard of through its transcript, while the model answers, is filed after that answer.

    Audio sent during an answer reserves no place, so the transcript is the turn's first sign: on a provider that
    reports no speech boundaries at all (GPT-Live), the model's next output closes the turn.
    """
    conn = _ContinuousMicrophoneConnection(script)
    session = RealtimeSession(conn)
    conn.session = session
    async with session:
        await drain_events(session)

    messages = session.all_messages()
    first_answer = next(index for index, message in enumerate(messages) if isinstance(message, ModelResponse))
    assert _user_transcripts(session) == ['Tell me a story.', 'Stop, what is two plus two?']
    barge_in = next(
        index
        for index, message in enumerate(messages)
        if any(
            isinstance(part, SpeechPart) and part.transcript == 'Stop, what is two plus two?' for part in message.parts
        )
    )
    assert first_answer < barge_in


async def test_idless_mid_reply_transcript_streams_into_the_turn_being_answered() -> None:
    """Words Gemini reports mid-reply, before it reports the interruption they caused, are the answered turn's.

    Nothing marks them as new speech when they arrive, so they stream into the turn the reply answers; the
    interruption that follows settles the split, and the speech after it is a turn of its own.
    """
    conn = _ContinuousMicrophoneConnection(
        [
            _MIC,
            InputTranscript(text='Tell me a story.'),
            AudioDelta(data=b'\x01\x00'),
            OutputTranscript(text='Once upon a time'),
            _MIC,
            InputTranscript(text='Stop, what is two plus two?'),
            _MIC,
            RealtimeResponseInterruptedEvent(),
            ResponseDone(interrupted=True),
            _MIC,
            AudioDelta(data=b'\x01\x00'),
            OutputTranscript(text='Four.'),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn)
    conn.session = session
    async with session:
        await drain_events(session)

    assert [
        (type(message).__name__, [part.transcript for part in message.parts if isinstance(part, SpeechPart)])
        for message in session.all_messages()
    ] == snapshot(
        [
            ('ModelRequest', ['Tell me a story.Stop, what is two plus two?']),
            ('ModelResponse', ['Once upon a time']),
            ('ModelRequest', [None]),
            ('ModelResponse', ['Four.']),
        ]
    )


async def test_untranscribed_push_to_talk_commit_after_a_reconnect_records_one_turn() -> None:
    """Audio a reconnect already settled as a turn isn't committed again by the next `commit_audio()`."""
    conn = _ContinuousMicrophoneConnection(
        [
            _MIC,
            RealtimeSessionReconnectEvent(state_restored=False),
            _RELEASE,
            AudioDelta(data=b'\x01\x00'),
            OutputTranscript(text='Could you say that again?', is_final=True),
            ResponseDone(),
        ],
        input_transcription_enabled=False,
    )
    conn._reconnect_restores_in_flight_state = False  # pyright: ignore[reportPrivateUsage]
    session = RealtimeSession(conn)
    conn.session = session
    async with session:
        await drain_events(session)

    assert [type(message).__name__ for message in session.all_messages()] == ['ModelRequest', 'ModelResponse']


_BARGE_IN_OPENING: list[RealtimeCodecEvent] = [
    RealtimeInputSpeechStartEvent(item_id='u1'),
    RealtimeInputSpeechEndEvent(item_id='u1'),
    InputTranscript(text='Tell me a story.', is_final=True, item_id='u1'),
    AudioDelta(data=b'\x01\x00'),
    OutputTranscript(text='Once upon a time'),
    RealtimeInputSpeechStartEvent(item_id='u2'),
    RealtimeInputSpeechEndEvent(item_id='u2'),
    InputTranscript(text='Stop, what is two plus two?', is_final=True, item_id='u2'),
]


async def test_barge_in_user_turn_is_recorded_when_the_interrupted_response_never_ends(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A barge-in turn waits for the response it interrupted only so long: then it's recorded where history stands."""
    monkeypatch.setattr('pydantic_ai.realtime._session._BARGE_IN_TURN_HOLD_SECONDS', 0.01)
    seen: list[list[str]] = []

    async def look_after_the_hold(session: _RealtimeSession) -> None:
        await asyncio.sleep(0.05)
        seen.append(_user_transcripts(session))

    conn = _ContinuousMicrophoneConnection(
        [
            *_BARGE_IN_OPENING,
            RealtimeInputSpeechStartEvent(item_id='u3'),
            RealtimeInputSpeechEndEvent(item_id='u3'),
            InputTranscript(text='Hello?', is_final=True, item_id='u3'),
            _UserAction(look_after_the_hold),
            OutputTranscript(text=' there was'),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn)
    conn.session = session
    async with session:
        await drain_events(session)

    assert seen == [['Tell me a story.', 'Stop, what is two plus two?', 'Hello?']]
    assert [type(message).__name__ for message in session.all_messages()] == [
        'ModelRequest',
        'ModelRequest',
        'ModelRequest',
        'ModelResponse',
    ]


async def test_held_barge_in_user_turn_is_recorded_after_its_response_on_close() -> None:
    """Closing while a barge-in turn waits on the response it interrupted records both, in order."""
    conn = BlockingRealtimeConnection(_BARGE_IN_OPENING)
    session = RealtimeSession(conn)
    async with session:
        events_task = asyncio.create_task(drain_events(session))
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            while session._core.response_holding_turns() is None:  # pyright: ignore[reportPrivateUsage]
                await asyncio.sleep(0)
        await session.close()
        await events_task

    assert [(type(message).__name__, getattr(message, 'state', None)) for message in session.all_messages()] == [
        ('ModelRequest', 'complete'),
        ('ModelResponse', 'interrupted'),
        ('ModelRequest', 'complete'),
    ]
    assert _user_transcripts(session) == ['Tell me a story.', 'Stop, what is two plus two?']


def _user_transcripts(session: _RealtimeSession) -> list[str]:
    return [
        part.transcript or ''
        for message in session.all_messages()
        for part in message.parts
        if isinstance(part, SpeechPart) and part.speaker == 'user'
    ]


@pytest.mark.parametrize('audio_retention', ['transcript_only', 'input_audio'])
async def test_untranscribed_continuous_microphone_records_one_user_turn_per_utterance(
    audio_retention: Literal['transcript_only', 'input_audio'],
) -> None:
    """Without input transcription, the silence an always-on microphone streams between turns is no turn.

    The provider's speech boundaries delimit each utterance; neither the audio sent while the model
    answers nor the trailing audio at close becomes a user turn of its own.
    """
    conn = _ContinuousMicrophoneConnection(
        [
            _MIC,
            RealtimeInputSpeechStartEvent(item_id='u1'),
            _MIC,
            RealtimeInputSpeechEndEvent(item_id='u1'),
            _MIC,
            AudioDelta(data=b'\x01\x00'),
            _MIC,
            OutputTranscript(text='Hello Alice.', is_final=True),
            ResponseDone(),
            _MIC,
            _MIC,
            RealtimeInputSpeechStartEvent(item_id='u2'),
            _MIC,
            RealtimeInputSpeechEndEvent(item_id='u2'),
            _MIC,
            AudioDelta(data=b'\x01\x00'),
            OutputTranscript(text='It is foggy in Paris.', is_final=True),
            ResponseDone(),
            _MIC,
        ],
        input_transcription_enabled=False,
    )
    session = RealtimeSession(conn, audio_retention=audio_retention)
    conn.session = session
    async with session:
        await drain_events(session)

    assert_conversation_invariants(session, [None, None])


async def test_empty_push_to_talk_commit_without_transcription_records_no_user_turn() -> None:
    """Committing an empty input buffer is no user turn, even with no transcript to wait for."""
    session = RealtimeSession(FakeRealtimeConnection([], input_transcription_enabled=False))
    async with session:
        await session.commit_audio()
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await drain_events(session)

    assert session.all_messages() == []


async def test_tool_response_finalized_on_usage_is_not_duplicated_at_terminal() -> None:
    conn = FakeRealtimeConnection(
        [
            ToolCall(
                tool_call_id='tc-1',
                tool_name='noop',
                args='{}',
                response_usage_follows=True,
            ),
            OutputTranscript(text='I will check that now.', is_final=True),
            SessionUsage(
                usage=RequestUsage(output_tokens=1),
                provider_response_id='response-tool',
                finish_reason='tool_call',
            ),
            ResponseDone(
                provider_response_id='response-tool',
                finish_reason='stop',
                provider_details={'status': 'completed'},
            ),
        ]
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'done'

    session = RealtimeSession(conn, runner)
    events = await collect_events(session)

    responses = [message for message in session.new_messages() if isinstance(message, ModelResponse)]
    assert len(responses) == 1
    assert responses[0].parts == [
        ToolCallPart(tool_name='noop', args='{}', tool_call_id='tc-1'),
        SpeechPart(speaker='assistant', transcript='I will check that now.'),
    ]
    assert responses[0].provider_response_id == 'response-tool'
    assert responses[0].usage == RequestUsage(output_tokens=1)
    assert session.usage.requests == 1
    assert [
        event.part for event in events if isinstance(event, PartEndEvent) and isinstance(event.part, SpeechPart)
    ] == [SpeechPart(speaker='assistant', transcript='I will check that now.')]


async def test_tool_call_events_carry_real_parts() -> None:
    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='f', args='{"x": 1}')])

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return '42'

    session = RealtimeSession(conn, runner)
    events = await collect_events(session)
    call_event = next(e for e in events if isinstance(e, FunctionToolCallEvent))
    result_event = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert call_event.part == ToolCallPart(tool_name='f', args='{"x": 1}', tool_call_id='tc')
    assert call_event.args_valid is True
    result_part = result_event.part
    assert isinstance(result_part, ToolReturnPart)
    assert (result_part.tool_name, result_part.content, result_part.tool_call_id) == ('f', '42', 'tc')


async def test_empty_args_call_runner_with_empty_dict() -> None:
    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='noop', args='')])
    seen: dict[str, Any] | None = None

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        nonlocal seen
        seen = args
        return 'ok'

    session = RealtimeSession(conn, runner)
    _ = await collect_events(session)
    assert seen == {}


async def test_invalid_json_args_reported_without_calling_tool() -> None:
    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc_4', tool_name='noop', args='not json')])
    session = RealtimeSession(conn, _noop_runner)
    events = await collect_events(session)
    call = next(e for e in events if isinstance(e, FunctionToolCallEvent))
    assert call.args_valid is False
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart) and result.part.outcome == 'retried'
    assert 'Invalid JSON' in str(result.part.content)
    assert isinstance(conn.sent[0], ToolResult)
    assert conn.sent[0].output == result.part.model_response_str()


async def test_non_object_json_args_reported() -> None:
    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='noop', args='[1, 2]')])
    session = RealtimeSession(conn, _noop_runner)
    events = await collect_events(session)
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart) and result.part.outcome == 'retried'
    assert 'Input should be an object' in str(result.part.content)


class _RepeatedMalformedToolArgsConnection(FakeRealtimeConnection):
    """Start a new response after the first malformed call is returned for retry."""

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        yield ToolCall(tool_call_id='tc1', tool_name='noop', args='not json')
        while not self.sent:
            await asyncio.sleep(0)
        yield ResponseDone()
        yield ToolCall(tool_call_id='tc2', tool_name='noop', args='still not json')


async def test_repeated_malformed_json_args_exceed_tool_retry_budget() -> None:
    session = RealtimeSession(_RepeatedMalformedToolArgsConnection([]), _noop_runner)

    with pytest.raises(UnexpectedModelBehavior, match="Tool 'noop' exceeded max retries count of 1"):
        await collect_events(session)

    assert session._tool_manager.failed_tools == set()  # pyright: ignore[reportPrivateUsage]
    assert session._tool_manager.ctx is not None  # pyright: ignore[reportPrivateUsage]
    assert session._tool_manager.ctx.retries == {'noop': 1}  # pyright: ignore[reportPrivateUsage]


async def test_tool_runner_exception_ends_session() -> None:
    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='boom', args='{}')])

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        raise RuntimeError('kaboom')

    session = RealtimeSession(conn, runner)
    with pytest.raises(RuntimeError, match='kaboom'):
        await collect_events(session)
    assert conn.sent == []


class _SendsFailedResults(FakeRealtimeConnection):
    """A connection whose model can't move on without a result for every call (GPT-Live's delegated backend)."""

    def __init__(self, events: list[RealtimeCodecEvent]) -> None:
        super().__init__(events)
        self.unanswered: list[str] = []

    @property
    def _sends_failed_tool_results(self) -> bool:
        return True

    def _tool_call_unanswered(self, tool_call_id: str) -> None:
        self.unanswered.append(tool_call_id)


async def test_tool_exception_is_sent_as_a_failure_where_the_connection_needs_it() -> None:
    """The failure history records goes out as the call's result, and the exception is still raised."""
    conn = _SendsFailedResults([ToolCall(tool_call_id='tc', tool_name='boom', args='{}')])

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        raise RuntimeError('kaboom')

    session = RealtimeSession(conn, runner)
    with pytest.raises(RuntimeError, match='kaboom'):
        await collect_events(session)
    assert conn.sent == snapshot(
        [ToolResult(tool_call_id='tc', output='{"error":"The tool raised an unhandled error."}', failed=True)]
    )
    assert conn.unanswered == []
    returned = [
        part for message in session.all_messages() for part in message.parts if isinstance(part, ToolReturnPart)
    ]
    assert [(part.content, part.outcome) for part in returned] == snapshot(
        [('The tool raised an unhandled error.', 'failed')]
    )


async def test_tool_failure_stopped_by_a_usage_limit_sends_nothing() -> None:
    """A usage limit stops the exchange, so its result must not ask for another request: nothing goes out.

    The connection is told no result will follow.
    """
    conn = _SendsFailedResults([ToolCall(tool_call_id='tc', tool_name='boom', args='{}')])

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        raise UsageLimitExceeded('The next request would exceed the request_limit of 1')

    session = RealtimeSession(conn, runner)
    with pytest.raises(UsageLimitExceeded):
        await collect_events(session)
    assert conn.sent == []
    assert conn.unanswered == ['tc']


async def test_tool_failure_that_cannot_be_sent_tells_the_connection() -> None:
    """The link drops as the failure goes out: the connection is told no result will follow, as for a limit."""

    class _Dropped(_SendsFailedResults):
        transport_errors = (ConnectionResetError,)

        async def send_input(self, content: RealtimeInput) -> None:
            raise ConnectionResetError('link dropped')

    conn = _Dropped([ToolCall(tool_call_id='tc', tool_name='boom', args='{}')])

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        raise RuntimeError('kaboom')

    session = RealtimeSession(conn, runner)
    with pytest.raises(RuntimeError, match='kaboom'):
        await collect_events(session)
    assert conn.unanswered == ['tc']


async def test_tool_runner_base_exception_ends_session() -> None:
    class ToolFailure(BaseException):
        pass

    conn = BlockingRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='boom', args='{}')])

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        raise ToolFailure('kaboom')

    session = RealtimeSession(conn, runner)
    with pytest.raises(ToolFailure, match='kaboom'):
        await collect_events(session)
    assert conn.sent == []


async def test_tool_runner_base_exception_wins_connection_completion_race() -> None:
    class ToolFailure(BaseException):
        pass

    connection_finished = asyncio.Event()

    class _ConnectionEndsWithTool(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            try:
                yield ToolCall(tool_call_id='tc', tool_name='boom', args='{}')
            finally:
                connection_finished.set()

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        raise ToolFailure('kaboom')

    conn = _ConnectionEndsWithTool([])
    session = RealtimeSession(conn, runner)
    with pytest.raises(ToolFailure, match='kaboom'):
        await collect_events(session)
    assert connection_finished.is_set()
    assert conn.sent == []


async def test_tool_runner_cancelled_call_ends_cleanly() -> None:
    started = asyncio.Event()
    cancelled = asyncio.Event()

    class _CancelAfterToolStarts(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='tc', tool_name='slow', args='{}')
            await started.wait()
            yield ToolCallCancelled(tool_call_ids=['tc'])

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        started.set()
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            cancelled.set()
            raise
        return 'never'  # pragma: no cover

    conn = _CancelAfterToolStarts([])
    events = await collect_events(RealtimeSession(conn, runner))

    assert cancelled.is_set()
    assert conn.sent == []
    results = [event for event in events if isinstance(event, FunctionToolResultEvent)]
    assert len(results) == 1 and isinstance(results[0].part, ToolReturnPart)
    assert results[0].part.content == 'The tool call was interrupted before a result was produced.'


async def test_validation_hook_exception_reports_failed_validation(monkeypatch: pytest.MonkeyPatch) -> None:
    manager = make_tool_manager()
    outcomes: list[bool] = []

    async def fail_validation(*args: Any, **kwargs: Any) -> Any:
        raise RuntimeError('validation hook failed')

    async def record_validation(valid: bool) -> None:
        outcomes.append(valid)

    monkeypatch.setattr(manager, 'validate_tool_call', fail_validation)
    with pytest.raises(RuntimeError, match='validation hook failed'):
        await manager.handle_call(
            ToolCallPart(tool_name='noop', args={}, tool_call_id='call'),
            on_validate=record_validation,
        )
    assert outcomes == [False]


@pytest.mark.parametrize(
    ('exception', 'reason'),
    [(ApprovalRequired, 'requires approval'), (CallDeferred, 'runs externally')],
)
async def test_deferred_tool_becomes_deliberate_error_result(exception: type[Exception], reason: str) -> None:
    # Deferred-tool flows are graph-only: a live session can't pause for out-of-band approval or an
    # external result, so the model gets a deliberate explanation (not a leaked exception repr) and
    # the conversation keeps flowing.
    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='boom', args='{}')])

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        raise exception

    session = RealtimeSession(conn, runner)
    events = await collect_events(session)
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert result.part.content == f"Error: The 'boom' tool {reason} and cannot be completed during a realtime session."


async def test_response_model_name_prefers_server_reported() -> None:
    # `ModelResponse.model_name` records the model the connection reports the server actually served
    # (it can differ from the requested id — xAI silently substitutes its default for unknown slugs),
    # mirroring how request-response models stamp the response's reported model, not the requested one.
    conn = FakeRealtimeConnection(
        [OutputTranscript(text='hi', is_final=True), ResponseDone()], model_name='grok-voice-latest'
    )
    session = RealtimeSession(conn, _noop_runner, model_name='grok-voice-4-turbo')
    _ = await collect_events(session)
    response = next(m for m in session.all_messages() if isinstance(m, ModelResponse))
    assert response.model_name == 'grok-voice-latest'


async def test_agent_realtime_session_threads_provider_name() -> None:
    agent: Agent[object, str] = Agent()
    model = FakeRealtimeModel(FakeRealtimeConnection([OutputTranscript(text='hi', is_final=True), ResponseDone()]))
    async with agent.realtime(model).session() as session:
        _ = [event async for event in session]
    response = next(message for message in session.new_messages() if isinstance(message, ModelResponse))
    assert response.provider_name == 'fake'


async def test_tool_does_not_block_other_events() -> None:
    release = asyncio.Event()
    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='bg_1', tool_name='slow', args='{}'),
            OutputTranscript(text='let me check', is_final=False),
            ResponseDone(),
        ],
        release=release,
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        await release.wait()
        return 'done in background'

    session = RealtimeSession(conn, runner)
    events = await collect_events(session)

    # The tool call fires immediately, the model keeps talking, and the result lands only after the turn.
    assert [type(e).__name__ for e in events] == snapshot(
        [
            'PartStartEvent',  # tool call part
            'PartEndEvent',
            'FunctionToolCallEvent',
            'PartStartEvent',  # assistant transcript
            'PartDeltaEvent',
            'PartEndEvent',
            'FunctionToolResultEvent',
        ]
    )
    result = events[-1]
    assert isinstance(result, FunctionToolResultEvent)
    assert result.part.content == 'done in background'
    assert conn.sent == [ToolResult(tool_call_id='bg_1', output='done in background')]


async def test_tool_result_adjacent_to_call_in_history() -> None:
    """A late result streams last, but sits right after its call in `all_messages()`.

    Request-response APIs demand call/return adjacency (OpenAI rejects a `tool` message that doesn't
    directly follow the assistant message carrying the call), so the portable history must keep it
    even when the model spoke again before the tool finished.
    """
    release = asyncio.Event()
    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='bg_1', tool_name='slow', args='{}'),
            OutputTranscript(text='still working on it', is_final=False),
            ResponseDone(),
        ],
        release=release,
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        await release.wait()
        return 'late result'

    session = RealtimeSession(conn, runner)
    events = await collect_events(session)

    # The result event streams in completion order: after the intervening assistant turn.
    assert isinstance(events[-1], FunctionToolResultEvent)

    # But in history the return is adjacent to its call, with the intervening turn after it.
    call_response, tool_return, speech_response = session.all_messages()
    assert isinstance(call_response, ModelResponse)
    assert isinstance(call_response.parts[0], ToolCallPart)
    assert isinstance(tool_return, ModelRequest)
    assert isinstance(tool_return.parts[0], ToolReturnPart)
    assert tool_return.parts[0].tool_call_id == 'bg_1'
    assert tool_return.parts[0].content == 'late result'
    assert isinstance(speech_response, ModelResponse)
    assert isinstance(speech_response.parts[0], SpeechPart)
    assert speech_response.parts[0].transcript == 'still working on it'


async def test_parallel_tool_returns_stay_grouped_after_calling_response() -> None:
    release = asyncio.Event()
    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='one', tool_name='fast', args='{}'),
            ToolCall(tool_call_id='two', tool_name='slow', args='{}'),
            ResponseDone(),
        ],
        release=release,
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        await release.wait()
        return call_id

    session = RealtimeSession(conn, runner)
    _ = await collect_events(session)

    assert [
        message.parts[0].tool_call_id
        for message in session.new_messages()[1:]
        if isinstance(message, ModelRequest) and isinstance(message.parts[0], ToolReturnPart)
    ] == ['one', 'two']


class AwaitBetweenConnection(InferredConnection):
    """A connection that yields control between events so tool tasks can progress."""

    def __init__(self, events: list[RealtimeCodecEvent]) -> None:
        self._events = events
        self.sent: list[RealtimeInput] = []

    async def send_input(self, content: RealtimeInput) -> None:
        self.sent.append(content)

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        for event in self._events:
            yield event
            await asyncio.sleep(0)


async def test_tool_completion_drained_between_events() -> None:
    conn = AwaitBetweenConnection(
        [ToolCall(tool_call_id='bg', tool_name='fast', args='{}'), AudioDelta(data=b'\x01'), AudioDelta(data=b'\x02')]
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'quick'

    session = RealtimeSession(conn, runner)
    events = await collect_events(session)

    # The point is that the finished tool's result is drained while the upstream is still producing,
    # rather than waiting for the stream to end. Its exact position among the audio deltas depends on
    # how many event-loop checkpoints the send path takes, so read this as "early", not as a contract.
    assert [type(e).__name__ for e in events] == snapshot(
        [
            'PartStartEvent',
            'PartEndEvent',
            'FunctionToolCallEvent',
            'PartStartEvent',
            'PartDeltaEvent',
            'FunctionToolResultEvent',
            'PartDeltaEvent',
            'PartEndEvent',
        ]
    )
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert result.part.content == 'quick'


class IdleAfterToolConnection(InferredConnection):
    """Yields one ToolCall, then blocks forever — the model goes idle with no further events."""

    def __init__(self, call: ToolCall) -> None:
        self._call = call
        self.sent: list[RealtimeInput] = []
        self.iteration_task: asyncio.Task[Any] | None = None

    async def send_input(self, content: RealtimeInput) -> None:
        self.sent.append(content)

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        self.iteration_task = asyncio.current_task()
        yield self._call
        await asyncio.Event().wait()


async def test_tool_completion_delivered_while_upstream_idle() -> None:
    # The connection goes silent after the tool call; the completion must still surface promptly
    # rather than waiting for a provider event that never arrives.
    conn = IdleAfterToolConnection(ToolCall(tool_call_id='bg', tool_name='fast', args='{}'))

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'ready'

    session = RealtimeSession(conn, runner)
    async with session:
        events = session.__aiter__()
        # Drain the tool-call part events + FunctionToolCallEvent.
        assert isinstance(await anext(events), PartStartEvent)
        assert isinstance(await anext(events), PartEndEvent)
        assert isinstance(await anext(events), FunctionToolCallEvent)
        # Without multiplexing this would hang forever waiting on the idle connection.
        completed = await asyncio.wait_for(anext(events), timeout=_LIVENESS_TIMEOUT)
        assert isinstance(completed, FunctionToolResultEvent)
        assert completed.part.content == 'ready'


class ExplodingConnection(InferredConnection):
    """A connection whose iteration raises after yielding one event."""

    def __init__(self) -> None:
        self.sent: list[RealtimeInput] = []

    async def send_input(self, content: RealtimeInput) -> None:
        self.sent.append(content)

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        yield AudioDelta(data=b'\x00')
        raise RuntimeError('connection dropped')


async def test_upstream_error_propagates_to_consumer() -> None:
    session = RealtimeSession(ExplodingConnection(), _noop_runner)
    with pytest.raises(RuntimeError, match='connection dropped'):
        _ = await collect_events(session)


async def test_upstream_error_surfaces_at_close_when_the_stream_was_never_iterated() -> None:
    """A session used without its event stream still reports what ended it.

    The pump's error is normally raised out of the event iterator, so a caller driving the session with
    `send()` and the audio/transcript views alone — which the quickstart shows — would otherwise exit
    *cleanly* from a provider hangup, or from an exceeded `usage_limits` it silently spent past.
    """
    session = RealtimeSession(ExplodingConnection(), _noop_runner)
    with pytest.raises(RuntimeError, match='connection dropped'):
        async with session:
            assert [chunk async for chunk in session.stream_audio()] == [b'\x00']

    # Not re-raised over an exception already leaving the body, which would hide the caller's own error.
    other = RealtimeSession(ExplodingConnection(), _noop_runner)
    with pytest.raises(ValueError, match='mine'):
        async with other:
            assert [chunk async for chunk in other.stream_audio()] == [b'\x00']
            raise ValueError('mine')


async def test_close_completes_when_the_closing_task_is_cancelled() -> None:
    agent: Agent[None, str] = Agent()
    tool_started = asyncio.Event()
    tool_cancelled = asyncio.Event()
    tool_task: asyncio.Task[Any] | None = None

    @agent.tool_plain
    async def slow() -> None:
        nonlocal tool_task
        tool_task = asyncio.current_task()
        tool_started.set()
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            tool_cancelled.set()
            raise

    conn = BlockingRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='slow', args='{}')])

    async def close_after(session: _RealtimeSession) -> None:
        await tool_started.wait()
        await session.close()

    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        watchdog = asyncio.create_task(close_after(session))
        try:
            async for _ in session:
                pass
        finally:
            watchdog.cancel()

    assert session.closed
    assert session._pump_task is not None and session._pump_task.done()  # pyright: ignore[reportPrivateUsage]
    assert tool_task is not None and tool_task.done()
    assert tool_cancelled.is_set()
    assert [
        (part.tool_name, part.content, part.tool_call_id, part.outcome)
        for message in session.all_messages()
        if isinstance(message, ModelRequest)
        for part in message.parts
        if isinstance(part, ToolReturnPart)
    ] == [
        (
            'slow',
            'The tool call was interrupted before a result was produced.',
            'tc',
            'interrupted',
        )
    ]
    assert session._loop is None  # pyright: ignore[reportPrivateUsage]
    assert isinstance((await asyncio.gather(watchdog, return_exceptions=True))[0], asyncio.CancelledError)


async def test_concurrent_close_calls_wait_for_the_teardown() -> None:
    agent: Agent[None, str] = Agent()
    tool_started = asyncio.Event()
    tool_cancelling = asyncio.Event()
    finish_tool_cleanup = asyncio.Event()
    tool_task: asyncio.Task[Any] | None = None

    @agent.tool_plain
    async def slow() -> None:
        nonlocal tool_task
        tool_task = asyncio.current_task()
        tool_started.set()
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            tool_cancelling.set()
            while not finish_tool_cleanup.is_set():
                try:
                    await finish_tool_cleanup.wait()
                except asyncio.CancelledError:
                    pass
            raise

    conn = BlockingRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='slow', args='{}')])
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        consumer = asyncio.create_task(drain_events(session))
        await tool_started.wait()
        first = asyncio.create_task(session.close())
        second = asyncio.create_task(session.close())
        await tool_cancelling.wait()
        await asyncio.sleep(0)

        assert not first.done()
        assert not second.done()
        assert session._pump_task is not None and session._pump_task.done()  # pyright: ignore[reportPrivateUsage]
        assert tool_task is not None and not tool_task.done()

        finish_tool_cleanup.set()
        await asyncio.gather(first, second, consumer)

        assert tool_task.done()


async def test_tool_that_swallows_its_close_cancellation_and_closes_again_does_not_deadlock() -> None:
    agent = Agent[None, str](deps_type=type(None))
    closed_twice = asyncio.Event()

    @agent.tool
    async def hang_up(ctx: RunContext[None]) -> str:
        session = ctx.realtime_session
        assert session is not None
        try:
            await session.close()
        except asyncio.CancelledError:
            pass
        await session.close()  # would wait for the teardown that is waiting for this task
        closed_twice.set()
        return 'done'

    conn = BlockingRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='hang_up', args='{}')])
    with anyio.fail_after(5):
        async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
            _ = [e async for e in session]

    assert session.closed
    assert closed_twice.is_set()


async def test_session_exit_waits_for_the_teardown_under_a_cancelled_anyio_scope() -> None:
    """A level-triggered outer cancel must not make the session exit abandon its own teardown."""
    agent: Agent[None, str] = Agent()
    tool_started = asyncio.Event()
    drain_waiting = asyncio.Event()
    finish_tool_cleanup = asyncio.Event()
    exited = asyncio.Event()

    @agent.tool_plain
    async def slow() -> None:
        tool_started.set()
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            pass
        # Closing cancelled the call once; the teardown's drain cancels it again and then waits for it.
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            drain_waiting.set()
        while not finish_tool_cleanup.is_set():
            try:
                await finish_tool_cleanup.wait()
            except asyncio.CancelledError:
                pass
        raise asyncio.CancelledError

    conn = BlockingRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='slow', args='{}')])

    async def cancel_and_watch(scope: anyio.CancelScope) -> None:
        await tool_started.wait()
        scope.cancel()
        await drain_waiting.wait()
        # The teardown is now waiting for the tool; the session exit must still be waiting for the teardown.
        assert not exited.is_set()
        finish_tool_cleanup.set()

    session: _RealtimeSession | None = None
    scope = anyio.CancelScope()
    watcher = asyncio.create_task(cancel_and_watch(scope))
    with scope:
        async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
            async for _ in session:  # pragma: no branch - the scope cancel ends the loop
                pass
    exited.set()

    await watcher
    assert scope.cancel_called
    assert session is not None
    assert session.closed
    assert session._loop is None  # pyright: ignore[reportPrivateUsage]


async def test_close_error_reaches_the_survivor_when_the_closer_was_cancelled() -> None:
    agent: Agent[None, str] = Agent()
    tool_started = asyncio.Event()
    tool_cancelling = asyncio.Event()

    @agent.tool_plain
    async def slow() -> None:
        tool_started.set()
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            tool_cancelling.set()
            raise

    class _ExplodesWithRunningTool(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='tc', tool_name='slow', args='{}')
            await tool_started.wait()
            raise RuntimeError('connection dropped')

    session: _RealtimeSession | None = None
    closer: asyncio.Task[None] | None = None
    with pytest.raises(RuntimeError, match='connection dropped'):
        async with agent.realtime(FakeRealtimeModel(_ExplodesWithRunningTool([]))).session() as session:
            assert [chunk async for chunk in session.stream_audio()] == []
            closer = asyncio.create_task(session.close())
            await tool_cancelling.wait()
            closer.cancel()

    assert session is not None
    assert closer is not None
    assert isinstance((await asyncio.gather(closer, return_exceptions=True))[0], asyncio.CancelledError)
    await session.close()


async def test_tool_error_ends_views_when_the_stream_was_never_iterated() -> None:
    """A failed tool ends taps so a taps-only caller reaches `close()` and receives the error."""

    async def runner(*args: Any) -> str:
        raise ValueError('tool exploded')

    session = RealtimeSession(
        BlockingRealtimeConnection([ToolCall(tool_call_id='tc1', tool_name='noop', args='{}')]),
        runner=runner,
    )
    with pytest.raises(ValueError, match='tool exploded'):
        async with session:
            assert await asyncio.wait_for(_collect(session.stream_audio()), timeout=_LIVENESS_TIMEOUT) == []
            # A view subscribed after the failure also ends immediately.
            assert await asyncio.wait_for(_collect(session.stream_transcripts()), timeout=_LIVENESS_TIMEOUT) == []


async def test_tool_error_preempts_send_while_receive_pump_is_ending() -> None:
    """A send cannot slip between a taps-only tool failure and the cancelled pump finishing."""
    pump_cancelled = asyncio.Event()

    class SlowPumpSession(_RealtimeSession):
        async def _pump(self, context: Context | None) -> None:
            try:
                await super()._pump(context)
            except asyncio.CancelledError:
                pump_cancelled.set()
                await asyncio.Event().wait()

    async def runner(*args: Any) -> str:
        raise ValueError('tool exploded')

    session = SlowPumpSession(
        BlockingRealtimeConnection([ToolCall(tool_call_id='tc1', tool_name='noop', args='{}')]),
        tool_manager=make_tool_manager(runner),
    )
    await session.__aenter__()
    # A taps-only consumer, which is what this test is about: subscribing is what starts receiving.
    transcripts = session.stream_transcripts()
    await asyncio.wait_for(pump_cancelled.wait(), timeout=_LIVENESS_TIMEOUT)
    assert session._pump_task is not None and not session._pump_task.done()  # pyright: ignore[reportPrivateUsage]

    with pytest.raises(ValueError, match='tool exploded'):
        await session.send('x')
    await session.close()
    assert transcripts is not None

    response, request = session.all_messages()
    assert isinstance(response, ModelResponse)
    assert response.parts == [ToolCallPart(tool_name='noop', args='{}', tool_call_id='tc1')]
    assert isinstance(request, ModelRequest)
    assert request.parts == snapshot(
        [
            ToolReturnPart(
                tool_name='noop',
                content='The tool raised an unhandled error.',
                tool_call_id='tc1',
                timestamp=IsDatetime(),
                outcome='failed',
            )
        ]
    )


async def test_tool_retry_exhaustion_ends_views_when_the_stream_was_never_iterated() -> None:
    async def runner(*args: Any) -> str:
        raise UnexpectedModelBehavior('retry budget exhausted')

    session = RealtimeSession(
        BlockingRealtimeConnection([ToolCall(tool_call_id='tc1', tool_name='noop', args='{}')]),
        runner=runner,
    )
    with pytest.raises(UnexpectedModelBehavior, match='retry budget exhausted'):
        async with session:
            assert await asyncio.wait_for(_collect(session.stream_transcripts()), timeout=_LIVENESS_TIMEOUT) == []


async def test_tool_error_leaves_views_open_for_an_iterating_consumer() -> None:
    async def runner(*args: Any) -> str:
        raise ValueError('tool exploded')

    session = RealtimeSession(
        BlockingRealtimeConnection([ToolCall(tool_call_id='tc1', tool_name='noop', args='{}')]),
        runner=runner,
    )
    async with session:
        audio = session.stream_audio()

        async def consume_events() -> None:
            with pytest.raises(ValueError, match='tool exploded'):
                async for _ in session:
                    pass

        consumer = asyncio.create_task(consume_events())
        await asyncio.sleep(0)
        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(anext(audio), timeout=0.05)
        await consumer
        assert session._pump_task is not None and not session._pump_task.done()  # pyright: ignore[reportPrivateUsage]
    with pytest.raises(StopAsyncIteration):
        await anext(audio)


async def test_tool_error_does_not_preempt_send_for_an_active_iterator() -> None:
    async def runner(*args: Any) -> str:
        raise ValueError('tool exploded')

    conn = BlockingRealtimeConnection([ToolCall(tool_call_id='tc1', tool_name='noop', args='{}')])
    session = RealtimeSession(conn, runner=runner)
    async with session:
        events = session.__aiter__()
        assert isinstance(await anext(events), PartStartEvent)
        assert isinstance(await anext(events), PartEndEvent)
        assert isinstance(await anext(events), FunctionToolCallEvent)
        # The failure is parked by the tool task itself, so it is there once that task has finished.
        await asyncio.gather(*session._background_tasks, return_exceptions=True)  # pyright: ignore[reportPrivateUsage]

        await session.send('x')
        assert conn.sent[-1] == 'x'
        with pytest.raises(ValueError, match='tool exploded'):
            await anext(events)


async def test_tool_error_delivered_to_send_is_skipped_by_the_iterator() -> None:
    """Once the receive side has ended, a send raises the parked failure; the iterator then skips it and ends cleanly.

    It still streams the end of the turn the failure ended, which was queued behind the failure.
    """

    async def runner(*args: Any) -> str:
        raise ValueError('tool exploded')

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc1', tool_name='noop', args='{}')])
    session = RealtimeSession(conn, runner=runner)
    async with session:
        events = session.__aiter__()
        assert isinstance(await anext(events), PartStartEvent)
        assert isinstance(await anext(events), PartEndEvent)
        assert isinstance(await anext(events), FunctionToolCallEvent)
        await asyncio.gather(*session._background_tasks, return_exceptions=True)  # pyright: ignore[reportPrivateUsage]
        assert session._pump_task is not None  # pyright: ignore[reportPrivateUsage]
        await session._pump_task  # pyright: ignore[reportPrivateUsage]

        with pytest.raises(ValueError, match='tool exploded'):
            await session.send('x')
        assert isinstance(await anext(events), RealtimeTurnCompleteEvent)
        with pytest.raises(StopAsyncIteration):
            await anext(events)


async def test_pump_error_delivered_to_send_is_not_raised_again_by_the_iterator() -> None:
    class _DyingConnection(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield RealtimeInputSpeechStartEvent()
            raise RuntimeError('socket died')

    session = RealtimeSession(_DyingConnection([]))
    async with session:
        events = session.__aiter__()
        assert isinstance(await anext(events), RealtimeInputSpeechStartEvent)
        assert session._pump_task is not None  # pyright: ignore[reportPrivateUsage]
        await session._pump_task  # pyright: ignore[reportPrivateUsage]

        with pytest.raises(RuntimeError, match='socket died'):
            await session.send('x')
        with pytest.raises(StopAsyncIteration):
            await anext(events)


async def test_delivered_pump_error_still_reports_an_in_flight_tool_result() -> None:
    """A delivered pump error must not cut the iterator off while a tool is still running.

    Ending the stream as soon as the error is seen would drop the `FunctionToolResultEvent` of a tool
    that goes on to complete successfully, losing a result the session did produce. The iterator
    instead keeps reading until the pump is finished *and* the last background task is done, which
    each task's completion callback wakes it to re-check.
    """
    release = asyncio.Event()

    class _DyingAfterToolCall(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield RealtimeInputSpeechStartEvent()
            yield ToolCall(tool_call_id='bg', tool_name='slow', args='{}')
            raise RuntimeError('socket died')

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        await release.wait()
        return 'done'

    session = RealtimeSession(_DyingAfterToolCall([]), runner)
    async with session:
        events = session.__aiter__()
        seen: list[RealtimeEvent] = [await anext(events) for _ in range(3)]

        assert session._pump_task is not None  # pyright: ignore[reportPrivateUsage]
        await session._pump_task  # pyright: ignore[reportPrivateUsage]
        with pytest.raises(RuntimeError, match='socket died'):
            await session.send('x')

        async def drain() -> None:
            with pytest.raises(StopAsyncIteration):
                while True:
                    seen.append(await anext(events))

        draining = asyncio.create_task(drain())
        await asyncio.sleep(0)
        assert not draining.done(), 'the iterator ended while the tool was still running'

        release.set()
        await asyncio.wait_for(draining, timeout=_LIVENESS_TIMEOUT)

    result = seen[-1]
    assert isinstance(result, FunctionToolResultEvent)
    assert result.part.content == 'done'


@pytest.mark.parametrize('consumer', ['iterating', 'taps_only', 'iterated_then_taps'])
async def test_pending_message_error_is_delivered_once_to_every_consumer_shape(
    consumer: Literal['iterating', 'taps_only', 'iterated_then_taps'],
) -> None:
    """A failed background enqueue cannot remain parked on an unread event queue."""
    events: list[RealtimeCodecEvent] = [RealtimeInputSpeechStartEvent()] if consumer == 'iterated_then_taps' else []
    session = RealtimeSession(
        BlockingRealtimeConnection(events),
        usage_limits=UsageLimits(request_limit=0),
    )
    await session.__aenter__()

    event_task: asyncio.Task[list[RealtimeEvent]] | None = None
    if consumer == 'iterating':
        event_task = asyncio.create_task(drain_events(session))
        await asyncio.sleep(0)
    elif consumer == 'iterated_then_taps':
        iterator = session.__aiter__()
        assert isinstance(await anext(iterator), RealtimeInputSpeechStartEvent)
        assert isinstance(iterator, AsyncGenerator)
        await iterator.aclose()

    transcripts = session.stream_transcripts()
    session.enqueue('too expensive')

    if event_task is not None:
        with pytest.raises(UsageLimitExceeded, match='request_limit of 0'):
            await asyncio.wait_for(event_task, timeout=_LIVENESS_TIMEOUT)
        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(anext(transcripts), timeout=0.05)
        await session.close()
    else:
        assert await asyncio.wait_for(_collect(transcripts), timeout=_LIVENESS_TIMEOUT) == []
        with pytest.raises(UsageLimitExceeded, match='request_limit of 0'):
            await session.close()
        await session.close()
    assert session.result is None


async def test_receive_failure_is_delivered_by_next_send() -> None:
    """A send-only bridge exits when the already-ended receive side failed."""
    session = RealtimeSession(ExplodingConnection())
    await session.__aenter__()
    # The first send is what starts receiving, so the failure it lets through is delivered to the next
    # one: there is nothing for an earlier send to have surfaced, since nothing had been received yet.
    await session.send_audio(b'first microphone chunk')
    assert session._pump_task is not None  # pyright: ignore[reportPrivateUsage]
    await session._pump_task  # pyright: ignore[reportPrivateUsage]

    with pytest.raises(RuntimeError, match='connection dropped'):
        await session.send_audio(b'next microphone chunk')
    await session.close()
    assert session.result is None


async def test_send_only_session_surfaces_a_receive_failure_at_exit() -> None:
    """A bridge that only sends still reports what ended the session, with no view and no iterator."""
    session = RealtimeSession(ExplodingConnection())
    with pytest.raises(RuntimeError, match='connection dropped'):
        async with session:
            await session.send_audio(b'microphone chunk')
    await session.close()
    assert session.result is None


async def test_failed_taps_only_agent_session_has_no_result() -> None:
    agent: Agent[None, str] = Agent()
    session: _RealtimeSession | None = None
    with pytest.raises(UsageLimitExceeded, match='request_limit of 0'):
        async with agent.realtime(
            FakeRealtimeModel(BlockingRealtimeConnection([])),
            usage_limits=UsageLimits(request_limit=0),
        ).session() as session:
            session.enqueue('too expensive')
            assert await asyncio.wait_for(_collect(session.stream_transcripts()), timeout=_LIVENESS_TIMEOUT) == []

    assert session is not None
    assert session.result is None


async def _collect(iterator: AsyncIterator[Any]) -> list[Any]:
    return [item async for item in iterator]


async def test_upstream_error_does_not_wait_for_running_tool() -> None:
    class _ExplodingAfterTool(InferredConnection):
        # Tool is cancelled first.
        async def send_input(self, content: RealtimeInput) -> None:  # pragma: no cover
            raise AssertionError

        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='bg', tool_name='hang', args='{}')
            await asyncio.sleep(0)  # let the tool start before the pump fails
            raise RuntimeError('connection dropped')

    blocked = asyncio.Event()
    started = asyncio.Event()
    cancelled = asyncio.Event()
    tool_task: asyncio.Task[Any] | None = None

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        nonlocal tool_task
        tool_task = asyncio.current_task()
        started.set()
        try:
            await blocked.wait()
        except asyncio.CancelledError:
            cancelled.set()
            raise
        return 'never'  # pragma: no cover

    session = RealtimeSession(_ExplodingAfterTool(), runner)
    with pytest.raises(RuntimeError, match='connection dropped'):
        await asyncio.wait_for(collect_events(session), timeout=_LIVENESS_TIMEOUT)

    assert started.is_set()
    assert tool_task is not None and tool_task.done() and tool_task.cancelled()
    assert cancelled.is_set()


class SendFailsConnection(InferredConnection):
    """Replays events but raises on every send — a connection dropping mid tool call (the only thing
    sent through it in these tests is the tool's `ToolResult`).

    With `idle=True` it never closes after the events (an idle provider); with `release` set it
    closes immediately and the tool only runs once released, so the failure lands after upstream end.
    """

    def __init__(
        self, events: list[RealtimeCodecEvent], *, idle: bool = False, release: asyncio.Event | None = None
    ) -> None:
        self._events = events
        self._idle = idle
        self._release = release

    async def send_input(self, content: RealtimeInput) -> None:
        raise RuntimeError('connection lost')

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        for event in self._events:
            yield event
        if self._release is not None:
            self._release.set()
        if self._idle:
            await asyncio.Event().wait()


async def test_tool_failure_propagates_while_idle() -> None:
    conn = SendFailsConnection([ToolCall(tool_call_id='bg', tool_name='boom', args='{}')], idle=True)

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'ok'

    # The tool's ToolResult send fails while the provider is idle; without propagation the
    # consumer would hang waiting for a completion that never arrives.
    session = RealtimeSession(conn, runner)
    with pytest.raises(RuntimeError, match='connection lost'):
        _ = await collect_events(session)


async def test_tool_failure_propagates_after_close() -> None:
    release = asyncio.Event()
    conn = SendFailsConnection([ToolCall(tool_call_id='bg', tool_name='boom', args='{}')], release=release)

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        await release.wait()  # only runs after upstream has closed → failure surfaces during drain
        return 'ok'

    session = RealtimeSession(conn, runner)
    with pytest.raises(RuntimeError, match='connection lost'):
        _ = await collect_events(session)


async def test_early_break_with_running_tool_cancels_task() -> None:
    blocked = asyncio.Event()
    started = asyncio.Event()
    cancelled = asyncio.Event()
    tool_task: asyncio.Task[Any] | None = None
    conn = IdleAfterToolConnection(ToolCall(tool_call_id='bg', tool_name='hang', args='{}'))
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    async def hang() -> str:
        nonlocal tool_task
        tool_task = asyncio.current_task()
        started.set()
        try:
            await blocked.wait()
        except asyncio.CancelledError:
            cancelled.set()
            raise
        return 'never'  # pragma: no cover

    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        async for event in session:
            if isinstance(event, FunctionToolCallEvent):
                await started.wait()
                break

    assert tool_task is not None and tool_task.done() and tool_task.cancelled()
    assert conn.iteration_task is not None and conn.iteration_task.done()
    assert cancelled.is_set()


async def test_tool_call_cancellation_cancels_running_tool() -> None:
    # The model cancels an in-flight tool call (e.g. the user barged in mid-call). The running task is
    # cancelled, no `ToolResult` is sent back to the model, and a cancelled result is recorded so the
    # call still has a matching return in history.
    started = asyncio.Event()
    cancelled = asyncio.Event()
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    async def slow() -> str:
        started.set()
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            cancelled.set()
            raise
        # Always cancelled first.
        return 'never'  # pragma: no cover

    class _CancelAfterStart(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='c1', tool_name='slow', args='{}')
            await started.wait()  # let the tool task start before the model cancels it
            yield ToolCallCancelled(tool_call_ids=['c1'])

    events: list[Any] = []
    conn = _CancelAfterStart([])
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        async for event in session:
            events.append(event)

    assert cancelled.is_set()  # the running tool observed cancellation
    assert conn.sent == []
    results = [e for e in events if isinstance(e, FunctionToolResultEvent)]
    assert len(results) == 1 and isinstance(results[0].part, ToolReturnPart)
    # The cancelled call still has exactly one matching return in history (valid for a handoff).
    returns = [
        part
        for message in session.all_messages()
        if isinstance(message, ModelRequest)
        for part in message.parts
        if isinstance(part, ToolReturnPart)
    ]
    assert [(part.tool_call_id, part.content) for part in returns] == [
        ('c1', 'The tool call was interrupted before a result was produced.')
    ]


async def test_sequential_tool_is_execution_barrier() -> None:
    before_started = asyncio.Event()
    barrier_started = asyncio.Event()
    before_release = asyncio.Event()
    barrier_release = asyncio.Event()
    order: list[str] = []
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    async def before() -> str:
        order.append('before start')
        before_started.set()
        await before_release.wait()
        order.append('before finish')
        return 'before'

    @agent.tool_plain(sequential=True)
    async def barrier() -> str:
        order.append('barrier start')
        barrier_started.set()
        await barrier_release.wait()
        order.append('barrier finish')
        return 'barrier'

    @agent.tool_plain
    async def after() -> str:
        order.append('after start')
        order.append('after finish')
        return 'after'

    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='before', tool_name='before', args='{}'),
            ToolCall(tool_call_id='barrier', tool_name='barrier', args='{}'),
            ToolCall(tool_call_id='after', tool_name='after', args='{}'),
        ]
    )
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        events_task = asyncio.create_task(drain_events(session))
        await before_started.wait()
        assert order == ['before start']
        before_release.set()
        await barrier_started.wait()
        assert order == ['before start', 'before finish', 'barrier start']
        barrier_release.set()
        await events_task

    assert order == [
        'before start',
        'before finish',
        'barrier start',
        'barrier finish',
        'after start',
        'after finish',
    ]


async def test_parallel_execution_mode_sequential_serializes_realtime_tools() -> None:
    release = [asyncio.Event(), asyncio.Event(), asyncio.Event()]
    started = [asyncio.Event(), asyncio.Event(), asyncio.Event()]
    order: list[str] = []
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    async def ordered(index: int) -> int:
        order.append(f'{index} start')
        started[index].set()
        await release[index].wait()
        order.append(f'{index} finish')
        return index

    conn = FakeRealtimeConnection(
        [ToolCall(tool_call_id=str(i), tool_name='ordered', args=f'{{"index": {i}}}') for i in range(3)]
    )
    with ToolManager.parallel_execution_mode('sequential'):
        async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
            events_task = asyncio.create_task(drain_events(session))
            for i in range(3):
                await started[i].wait()
                assert order == [item for j in range(i) for item in (f'{j} start', f'{j} finish')] + [f'{i} start']
                release[i].set()
            await events_task

    assert order == [item for i in range(3) for item in (f'{i} start', f'{i} finish')]


async def test_cancelled_realtime_barrier_releases_following_tool() -> None:
    barrier_started = asyncio.Event()
    after_started = asyncio.Event()
    barrier_cancelled = asyncio.Event()
    agent: Agent[None, str] = Agent()

    @agent.tool_plain(sequential=True)
    async def barrier() -> str:
        barrier_started.set()
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            barrier_cancelled.set()
            raise
        return 'never'  # pragma: no cover

    @agent.tool_plain
    async def after() -> str:
        after_started.set()
        return 'after'

    class _CancelBarrier(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='barrier', tool_name='barrier', args='{}')
            yield ToolCall(tool_call_id='after', tool_name='after', args='{}')
            await barrier_started.wait()
            yield ToolCallCancelled(tool_call_ids=['barrier'])

    conn = _CancelBarrier([])
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        await drain_events(session)

    assert barrier_cancelled.is_set()
    assert after_started.is_set()


async def test_realtime_barrier_exception_releases_following_tool() -> None:
    after_started = asyncio.Event()
    agent: Agent[None, str] = Agent()

    @agent.tool_plain(sequential=True)
    async def barrier() -> str:
        raise RuntimeError('barrier failed')

    @agent.tool_plain
    async def after() -> str:
        after_started.set()
        return 'after'

    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='barrier', tool_name='barrier', args='{}'),
            ToolCall(tool_call_id='after', tool_name='after', args='{}'),
        ]
    )
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        events = session.__aiter__()
        await anext(events)
        await asyncio.wait_for(after_started.wait(), timeout=_LIVENESS_TIMEOUT)
        with pytest.raises(RuntimeError, match='barrier failed'):
            await aiter_to_list(events)

    assert after_started.is_set()


async def test_realtime_tools_run_concurrently_by_default() -> None:
    both_started = asyncio.Event()
    started: set[str] = set()
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    async def parallel(name: str) -> str:
        started.add(name)
        if len(started) == 2:
            both_started.set()
        await both_started.wait()
        return name

    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='one', tool_name='parallel', args='{"name": "one"}'),
            ToolCall(tool_call_id='two', tool_name='parallel', args='{"name": "two"}'),
        ]
    )
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        await drain_events(session)

    assert started == {'one', 'two'}


async def test_tool_call_cancellation_unknown_id_is_ignored() -> None:
    # A cancellation for an id with no matching in-flight call (already finished, or never started) must
    # be a no-op: no crash, no spurious result event, nothing sent. Covers the race where a tool finishes
    # in the window before its cancellation arrives (the `finally`-pop makes that atomic).
    conn = FakeRealtimeConnection(
        [
            ToolCallCancelled(tool_call_ids=['never-started']),
            OutputTranscript(text='hi', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner)
    events = await collect_events(session)
    assert [event for event in events if isinstance(event, FunctionToolResultEvent)] == []
    assert conn.sent == []


async def test_interrupt_does_not_cancel_in_flight_tool() -> None:
    # A user barge-in via `interrupt()` cancels the *model's* response server-side (`CancelResponse`),
    # but deliberately does NOT cancel a local tool that's already running: the work was dispatched, so it
    # runs to completion and its `ToolResult` is still sent back to the model. This is the intended design
    # (matching the OpenAI Agents SDK) and contrasts with a provider-driven `ToolCallCancelled` (above),
    # which *does* cancel the local task. On OpenAI/xAI, sending the result then auto-triggers a fresh
    # response server-side; suppressing that is the model's concern, not ours to second-guess here.
    started = asyncio.Event()
    release = asyncio.Event()
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    async def slow() -> str:
        started.set()
        await release.wait()
        return 'done'

    class _IdleAfterCall(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='c1', tool_name='slow', args='{}')
            await asyncio.Event().wait()  # stay open; the consumer breaks out on the tool result

    conn = _IdleAfterCall([])
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        async for event in session:
            if isinstance(event, FunctionToolCallEvent):
                await started.wait()
                await session.interrupt()
                release.set()
            elif isinstance(event, FunctionToolResultEvent):
                break

    # The barge-in reached the model, and the tool still completed and reported its result afterwards.
    assert CancelResponse() in conn.sent
    assert ToolResult(tool_call_id='c1', output='done') in conn.sent


# --- send helpers + history ---------------------------------------------------------------------


async def test_send_helpers_forward_to_connection() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)
    await session.send_audio(b'\x01\x02')
    await session.send('hello')
    await session.send(BinaryImage(data=b'\xff\xd8', media_type='image/jpeg'))
    await session.send(BinaryAudio(data=b'\x03', media_type='audio/pcm'))
    assert conn.sent == [
        BinaryAudio(data=b'\x01\x02', media_type='audio/pcm'),
        'hello',
        BinaryImage(data=b'\xff\xd8', media_type='image/jpeg'),
        BinaryAudio(data=b'\x03', media_type='audio/pcm'),
    ]


async def test_send_audio_accepts_async_iterable() -> None:
    """`send_audio` drains an async iterable chunk by chunk, so a capture loop can be one call.

    Unit test: the per-chunk forwarding of a caller-supplied iterator has no wire signature of its
    own — a cassette can't distinguish it from a caller looping over `send_audio(chunk)`.
    """
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)

    async def microphone() -> AsyncIterator[bytes]:
        yield b'\x01\x02'
        yield b'\x03\x04'

    await session.send_audio(microphone())

    assert conn.sent == [
        BinaryAudio(data=b'\x01\x02', media_type='audio/pcm'),
        BinaryAudio(data=b'\x03\x04', media_type='audio/pcm'),
    ]


async def test_send_audio_iterable_waits_for_next_chunk_after_close() -> None:
    """Closing does not cancel into a caller-owned async iterable that is blocked between chunks."""
    source_blocked = asyncio.Event()
    next_chunk = asyncio.Event()

    async def microphone() -> AsyncIterator[bytes]:
        yield b'first'
        source_blocked.set()
        await next_chunk.wait()
        yield b'after close'

    conn = BlockingRealtimeConnection([])
    async with RealtimeSession(conn) as session:
        sender = asyncio.create_task(session.send_audio(microphone()))
        await source_blocked.wait()
        await session.close()
        assert not sender.done()
        next_chunk.set()
        await sender

    assert conn.sent == [BinaryAudio(data=b'first', media_type='audio/pcm')]


async def test_send_dispatches_through_bookkeeping_helpers() -> None:
    # `send(<str>)` must route through the text-turn path, so the user turn lands in history rather
    # than bypassing it (the raw pass-through used to skip all session bookkeeping).
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)
    await session.send('hello')
    assert conn.sent == ['hello']
    assert session.new_messages() == snapshot(
        [ModelRequest(parts=[UserPromptPart(content='hello', timestamp=IsDatetime())], timestamp=IsDatetime())]
    )


async def test_send_accepts_plain_content() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)

    # (The image goes first: sent while the reply `'hello'` asks for is owed, it would join history after that.)
    await session.send(BinaryImage(data=b'image', media_type='image/png'))
    await session.send('hello')
    # A WAV container (e.g. retained `SpeechPart.audio`) is unwrapped to the raw PCM the wire expects.
    await session.send(_wav_content(b'\x01\x02\x03\x04'))
    # Raw PCM `BinaryContent` passes through verbatim.
    await session.send(BinaryContent(data=b'\xaa\xbb', media_type='audio/pcm'))

    assert conn.sent == snapshot(
        [
            BinaryImage(data=b'image', media_type='image/png'),
            'hello',
            BinaryAudio(data=b'\x01\x02\x03\x04', media_type='audio/pcm'),
            BinaryAudio(data=b'\xaa\xbb', media_type='audio/pcm'),
        ]
    )
    assert session.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    UserPromptPart(
                        content=[BinaryImage(data=b'image', media_type='image/png')],
                        timestamp=IsDatetime(),
                    )
                ],
                timestamp=IsDatetime(),
            ),
            ModelRequest(parts=[UserPromptPart(content='hello', timestamp=IsDatetime())], timestamp=IsDatetime()),
        ]
    )


async def test_send_accepts_sequence() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)

    await session.send(['look at this', BinaryImage(data=b'image', media_type='image/png')])

    assert conn.sent == ['look at this', BinaryImage(data=b'image', media_type='image/png')]


async def test_send_respond_controls_text_and_image_turns() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)
    image = BinaryImage(data=b'image', media_type='image/png')

    await session.send('default')
    await session.send('explicit', respond=True)
    await session.send('context', respond=False)
    await session.send(image)
    await session.send(image, respond=False)
    await session.send(image, respond=True)

    assert conn.sent == snapshot(
        [
            'default',
            'explicit',
            TextContext(text='context'),
            BinaryImage(data=b'image', media_type='image/png'),
            BinaryImage(data=b'image', media_type='image/png'),
            BinaryImage(data=b'image', media_type='image/png'),
            CreateResponse(),
        ]
    )
    assert session._core.requests_ahead() == 3  # pyright: ignore[reportPrivateUsage]
    # Each is in the provider's conversation; history holds what was sent while a reply is owed until it comes.
    assert len(session._core.replayable_messages()) == 6  # pyright: ignore[reportPrivateUsage]


async def test_send_respond_sequence_contextualizes_all_but_last() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)
    image = BinaryImage(data=b'image', media_type='image/png')

    await session.send(['first', image, 'last'], respond=True)

    assert conn.sent == [TextContext('first'), image, 'last']
    assert session._core.requests_ahead() == 1  # pyright: ignore[reportPrivateUsage]


async def test_send_respond_rejects_audio_and_unsupported_image_response() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)

    for audio in (_wav_content(b'\x01\x02'), BinaryContent(data=b'\x01\x02', media_type='audio/pcm')):
        with pytest.raises(UserError, match=r'`respond=True` cannot be used with audio.*`commit_audio\(\)`'):
            await session.send(audio, respond=True)

    unsupported = RealtimeSession(conn, _noop_runner, profile=_profile(supports_manual_turn_control=False))
    with pytest.raises(UserError, match='does not support manual turn-taking'):
        await unsupported.send(BinaryImage(data=b'image', media_type='image/png'), respond=True)
    assert conn.sent == []


async def test_send_respond_sequence_can_lead_with_audio() -> None:
    """Non-last items are sent as context, so audio ahead of the text turn is fine with an explicit `respond`."""
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn)

    audio = BinaryContent(data=b'\x01\x02', media_type='audio/pcm')
    async with session:
        await session.send([audio, 'How does it look?'], respond=True)
        # `respond=False` is a no-op for audio on its own too: it never solicits a reply.
        await session.send(audio, respond=False)

    assert [type(item).__name__ for item in conn.sent] == ['BinaryAudio', 'str', 'BinaryAudio']


async def test_image_respond_frames_cannot_be_interleaved() -> None:
    image_started = asyncio.Event()
    release_image = asyncio.Event()

    class _PausedImageConnection(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            if isinstance(content, BinaryImage):
                image_started.set()
                await release_image.wait()
            await super().send_input(content)

    conn = _PausedImageConnection([])
    session = RealtimeSession(conn, _noop_runner)
    image_task = asyncio.create_task(session.send(BinaryImage(data=b'image', media_type='image/png'), respond=True))
    await image_started.wait()
    text_task = asyncio.create_task(session.send('later'))
    await asyncio.sleep(0)
    release_image.set()
    await asyncio.gather(image_task, text_task)

    assert conn.sent == [BinaryImage(data=b'image', media_type='image/png'), CreateResponse(), 'later']


async def test_respond_send_failures_roll_back_history_and_reservations() -> None:
    class _FailingConnection(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            raise RuntimeError('send failed')

    conn = _FailingConnection([])
    session = RealtimeSession(conn, _noop_runner)

    with pytest.raises(RuntimeError, match='send failed'):
        await session.send('context', respond=False)
    with pytest.raises(RuntimeError, match='send failed'):
        await session.send(BinaryImage(data=b'image', media_type='image/png'), respond=True)

    assert session.new_messages() == []
    assert session._core.requests_ahead() == 0  # pyright: ignore[reportPrivateUsage]


async def test_image_history_retention_samples_and_round_trips() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner, retain_images_every_n=2)
    images = [BinaryImage(data=f'image-{index}'.encode(), media_type='image/png') for index in range(4)]

    for image in images:
        await session.send(image)

    assert conn.sent == [BinaryImage(data=image.data, media_type='image/png') for image in images]
    assert session.all_messages() == [
        ModelRequest(parts=[UserPromptPart(content=[images[0]], timestamp=IsDatetime())], timestamp=IsDatetime()),
        ModelRequest(parts=[UserPromptPart(content=[images[2]], timestamp=IsDatetime())], timestamp=IsDatetime()),
    ]
    serialized = ModelMessagesTypeAdapter.dump_json(session.all_messages())
    assert ModelMessagesTypeAdapter.validate_json(serialized) == session.all_messages()


async def test_failed_unretained_image_send_has_nothing_to_take_back() -> None:
    # With `retain_images_every_n=2` the second image is never recorded, so when its send fails
    # there is no phantom history to roll back; the failure still propagates.
    class _SecondImageSendFails(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            if isinstance(content, BinaryImage) and self.sent:
                raise RuntimeError('send failed')
            await super().send_input(content)

    conn = _SecondImageSendFails([])
    session = RealtimeSession(conn, _noop_runner, retain_images_every_n=2)
    images = [
        BinaryImage(data=b'image-0', media_type='image/png'),
        BinaryImage(data=b'image-1', media_type='image/png'),
    ]

    await session.send(images[0])
    with pytest.raises(RuntimeError, match='send failed'):
        await session.send(images[1])

    assert session.all_messages() == [
        ModelRequest(parts=[UserPromptPart(content=[images[0]], timestamp=IsDatetime())], timestamp=IsDatetime()),
    ]


async def test_image_history_retention_must_be_positive() -> None:
    with pytest.raises(UserError, match='`retain_images_every_n` must be at least 1'):
        RealtimeSession(FakeRealtimeConnection([]), _noop_runner, retain_images_every_n=0)


async def test_image_history_cap_evicts_oldest() -> None:
    """`retain_images_max` keeps history a sliding window: sampling slows growth, the cap bounds it."""
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner, retain_images_max=2)
    images = [BinaryImage(data=f'image-{index}'.encode(), media_type='image/png') for index in range(4)]

    for image in images:
        await session.send(image)

    # Every frame still reached the provider; only the local record is bounded.
    assert conn.sent == [BinaryImage(data=image.data, media_type='image/png') for image in images]
    assert session.all_messages() == [
        ModelRequest(parts=[UserPromptPart(content=[images[2]], timestamp=IsDatetime())], timestamp=IsDatetime()),
        ModelRequest(parts=[UserPromptPart(content=[images[3]], timestamp=IsDatetime())], timestamp=IsDatetime()),
    ]


async def test_image_history_cap_composes_with_sampling() -> None:
    """With `retain_images_every_n=2` only frames 0 and 2 are retained; a cap of 1 keeps the newest."""
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner, retain_images_every_n=2, retain_images_max=1)
    images = [BinaryImage(data=f'image-{index}'.encode(), media_type='image/png') for index in range(4)]

    for image in images:
        await session.send(image)

    assert session.all_messages() == [
        ModelRequest(parts=[UserPromptPart(content=[images[2]], timestamp=IsDatetime())], timestamp=IsDatetime()),
    ]


async def test_image_history_cap_zero_retains_nothing() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner, retain_images_max=0)
    image = BinaryImage(data=b'image-0', media_type='image/png')

    await session.send(image)

    assert conn.sent == [BinaryImage(data=image.data, media_type='image/png')]
    assert session.all_messages() == []


async def test_image_history_cap_must_be_non_negative() -> None:
    with pytest.raises(UserError, match='`retain_images_max` must be at least 0'):
        RealtimeSession(FakeRealtimeConnection([]), _noop_runner, retain_images_max=-1)


def _tenths_of_a_second(value: int) -> bytes:
    """A tenth of a second of PCM16 at 24 kHz, every byte `value`, so each turn's audio is recognizable."""
    return bytes([value]) * 4800


async def test_audio_retention_budget_keeps_the_latest_audio_of_a_turn_without_boundaries() -> None:
    """A turn that never reaches a boundary keeps only its most recent audio, measured at the input rate."""
    profile = _profile()
    profile['audio_input_sample_rate'] = 16000
    conn = FakeRealtimeConnection([InputTranscript(text='hello', is_final=False, cumulative=True), ResponseDone()])
    # 10 ms at 16 kHz is 320 bytes: two of the five chunks.
    session = RealtimeSession(conn, audio_retention='input_audio', retain_audio_max_seconds=0.01, profile=profile)
    chunks = [bytes([index]) * 160 for index in range(5)]

    for chunk in chunks:
        await session.send_audio(chunk)
    _ = await collect_events(session)

    # Every chunk still reached the provider; only the local copy is bounded.
    assert conn.sent == [BinaryAudio(data=chunk, media_type='audio/pcm') for chunk in chunks]
    assert session.all_messages() == [
        ModelRequest(
            parts=[SpeechPart(speaker='user', transcript='hello', audio=_wav_content(chunks[3] + chunks[4], 16000))],
            timestamp=IsDatetime(),
        )
    ]


async def test_audio_retention_budget_keeps_the_latest_output_audio() -> None:
    conn = FakeRealtimeConnection(
        [
            *(AudioDelta(data=bytes([index]) * 480) for index in range(5)),
            OutputTranscript(text='A long answer.', is_final=True),
            ResponseDone(),
        ]
    )
    # 20 ms at 24 kHz is 960 bytes: two of the five deltas.
    session = RealtimeSession(conn, model_name='m', audio_retention='output_audio', retain_audio_max_seconds=0.02)
    _ = await collect_events(session)

    response = session.all_messages()[0]
    assert isinstance(response, ModelResponse)
    assert response.parts == [
        SpeechPart(
            speaker='assistant', transcript='A long answer.', audio=_wav_content(bytes([3]) * 480 + bytes([4]) * 480)
        )
    ]


def _speak(pcm: bytes) -> _UserAction:
    async def speak(session: _RealtimeSession) -> None:
        await session.send_audio(pcm)

    return _UserAction(speak)


async def test_audio_retention_budget_evicts_the_oldest_turns_and_keeps_their_transcripts() -> None:
    """Short turns past the budget evict the oldest audio, keeping transcripts and history valid for a handoff."""
    snapshots: list[list[ModelMessage]] = []

    async def take_snapshot(session: _RealtimeSession) -> None:
        snapshots.append(session.all_messages())

    script: list[RealtimeCodecEvent | _UserAction] = []
    for turn in range(3):
        script += [
            _speak(_tenths_of_a_second(turn)),
            RealtimeInputSpeechEndEvent(item_id=f'user-{turn}'),
            InputTranscript(text=f'Question {turn}.', is_final=True, item_id=f'user-{turn}'),
            AudioDelta(data=_tenths_of_a_second(100 + turn)),
            OutputTranscript(text=f'Answer {turn}.', is_final=True),
            ResponseDone(),
            _UserAction(take_snapshot),
        ]
    conn = _ContinuousMicrophoneConnection(script)
    session = RealtimeSession(conn, audio_retention='all', retain_audio_max_seconds=0.3)
    conn.session = session
    async with session:
        await drain_events(session)

    def turn_messages(turn: int, *, user_audio: bool, assistant_audio: bool) -> list[ModelMessage]:
        return [
            ModelRequest(
                parts=[
                    SpeechPart(
                        speaker='user',
                        transcript=f'Question {turn}.',
                        audio=_wav_content(_tenths_of_a_second(turn)) if user_audio else None,
                    )
                ],
                timestamp=IsDatetime(),
            ),
            ModelResponse(
                parts=[
                    SpeechPart(
                        speaker='assistant',
                        transcript=f'Answer {turn}.',
                        audio=_wav_content(_tenths_of_a_second(100 + turn)) if assistant_audio else None,
                    )
                ],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]

    # Three tenths of a second fit: the latest three, whichever side spoke them.
    assert session.all_messages() == [
        *turn_messages(0, user_audio=False, assistant_audio=False),
        *turn_messages(1, user_audio=False, assistant_audio=True),
        *turn_messages(2, user_audio=True, assistant_audio=True),
    ]
    # Every chunk still reached the provider.
    assert [content.data for content in conn.sent if isinstance(content, BinaryAudio)] == [
        _tenths_of_a_second(turn) for turn in range(3)
    ]
    # A snapshot taken before an eviction doesn't change.
    assert snapshots[0] == turn_messages(0, user_audio=True, assistant_audio=True)

    def respond(messages: list[ModelMessage], info: AgentInfo) -> ModelResponse:
        return ModelResponse(parts=[TextPart(content=f'seen {len(messages)} messages')])

    result = await Agent(FunctionModel(respond)).run('continue', message_history=session.all_messages())
    assert result.output == 'seen 7 messages'


def _send_context(text: str) -> _UserAction:
    async def send_context(session: _RealtimeSession) -> None:
        await session.send(text, respond=False)

    return _UserAction(send_context)


def _answered_turn(turn: int, *, item_id: str | None = None) -> list[RealtimeCodecEvent | _UserAction]:
    """A spoken question, transcribed at once, and its spoken answer: a tenth of a second of audio each."""
    return [
        _speak(_tenths_of_a_second(turn)),
        *([RealtimeInputSpeechEndEvent(item_id=item_id)] if item_id is not None else []),
        InputTranscript(text=f'Question {turn}.', is_final=True, item_id=item_id),
        AudioDelta(data=_tenths_of_a_second(100 + turn)),
        OutputTranscript(text=f'Answer {turn}.', is_final=True),
        ResponseDone(),
    ]


def _transcripts(session: _RealtimeSession) -> list[tuple[str, str | None, bool]]:
    """Each recorded part as what was said, and whether its audio is still retained."""
    return [
        (part.speaker, part.transcript, part.audio is not None)
        if isinstance(part, SpeechPart)
        else ('user', str(part.content), False)
        for message in session.all_messages()
        for part in message.parts
        if isinstance(part, SpeechPart | UserPromptPart)
    ]


async def test_audio_retention_budget_evicting_the_message_a_turn_started_after_keeps_its_place() -> None:
    """The message a user turn is anchored to can lose its audio before the turn is recorded; the turn keeps its place.

    The context sent after the turn started goes after it, so recording the turn at the end would misplace it.
    The second turn is two tenths of a second, so starting it evicts the first turn's question and answer.
    (Without speech boundaries, a turn joins the conversation at its transcript, so there's no earlier place to keep.)
    """
    conn = _ContinuousMicrophoneConnection(
        [
            *_answered_turn(0, item_id='user-0'),
            RealtimeInputSpeechStartEvent(item_id='user-1'),
            _speak(_tenths_of_a_second(1) * 2),
            _send_context('Context.'),
            RealtimeInputSpeechEndEvent(item_id='user-1'),
            InputTranscript(text='Question 1.', is_final=True, item_id='user-1'),
        ]
    )
    session = RealtimeSession(conn, audio_retention='all', retain_audio_max_seconds=0.2)
    conn.session = session
    async with session:
        await drain_events(session)

    assert _transcripts(session) == [
        ('user', 'Question 0.', False),
        ('assistant', 'Answer 0.', False),
        ('user', 'Question 1.', True),
        ('user', 'Context.', False),
    ]


async def test_audio_retention_budget_evicting_an_id_less_turn_keeps_it_at_its_transcript() -> None:
    """Without speech boundaries, a turn joins the conversation at its transcript, after context sent meanwhile.

    The second turn is two tenths of a second, so it evicts the first turn's question and answer meanwhile.
    """
    conn = _ContinuousMicrophoneConnection(
        [
            *_answered_turn(0),
            _speak(_tenths_of_a_second(1) * 2),
            _send_context('Context.'),
            InputTranscript(text='Question 1.', is_final=True),
        ]
    )
    session = RealtimeSession(conn, audio_retention='all', retain_audio_max_seconds=0.2)
    conn.session = session
    async with session:
        await drain_events(session)

    assert _transcripts(session) == snapshot(
        [
            ('user', 'Question 0.', False),
            ('assistant', 'Answer 0.', False),
            ('user', 'Context.', False),
            ('user', 'Question 1.', True),
        ]
    )


async def test_audio_retention_budget_evicting_the_message_a_late_transcript_waits_on_keeps_its_place() -> None:
    """A turn whose transcript arrives after its answer stays ahead of that answer when its anchor loses its audio.

    The second answer is two tenths of a second, so it evicts the first turn's question and answer.
    """
    conn = _ContinuousMicrophoneConnection(
        [
            *_answered_turn(0, item_id='user-0'),
            _speak(_tenths_of_a_second(1)),
            RealtimeInputSpeechEndEvent(item_id='user-1'),
            AudioDelta(data=_tenths_of_a_second(101) * 2),
            OutputTranscript(text='Answer 1.', is_final=True),
            ResponseDone(),
            InputTranscript(text='Question 1.', is_final=True, item_id='user-1'),
        ]
    )
    session = RealtimeSession(conn, audio_retention='all', retain_audio_max_seconds=0.3)
    conn.session = session
    async with session:
        await drain_events(session)

    assert _transcripts(session) == [
        ('user', 'Question 0.', False),
        ('assistant', 'Answer 0.', False),
        ('user', 'Question 1.', True),
        ('assistant', 'Answer 1.', True),
    ]


async def test_audio_retention_budget_turn_longer_than_the_budget_keeps_only_its_latest_audio() -> None:
    """A turn longer than the whole budget evicts every earlier turn's audio, then keeps its own most recent audio."""
    conn = _ContinuousMicrophoneConnection(
        [
            *_answered_turn(0, item_id='user-0'),
            _speak(_tenths_of_a_second(1) + _tenths_of_a_second(2) + _tenths_of_a_second(3)),
            RealtimeInputSpeechEndEvent(item_id='user-1'),
            InputTranscript(text='Question 1.', is_final=True, item_id='user-1'),
        ]
    )
    session = RealtimeSession(conn, audio_retention='all', retain_audio_max_seconds=0.2)
    conn.session = session
    async with session:
        await drain_events(session)

    assert [part for message in session.all_messages() for part in message.parts] == [
        SpeechPart(speaker='user', transcript='Question 0.'),
        SpeechPart(speaker='assistant', transcript='Answer 0.'),
        SpeechPart(
            speaker='user',
            transcript='Question 1.',
            audio=_wav_content(_tenths_of_a_second(2) + _tenths_of_a_second(3)),
        ),
    ]


async def test_audio_retention_budget_skips_history_while_nothing_there_can_be_evicted(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """While the audio over budget is all in a response still in flight, history isn't searched again on every chunk."""
    strips = 0
    strip = RetainedAudioBudget.strip

    def counting_strip(
        self: RetainedAudioBudget, message: ModelMessage, excess: int | None = None
    ) -> tuple[ModelMessage, int]:
        nonlocal strips
        strips += 1
        return strip(self, message, excess)

    async def count_strips(session: _RealtimeSession) -> None:
        monkeypatch.setattr(RetainedAudioBudget, 'strip', counting_strip)

    async def stream_chunks(session: _RealtimeSession) -> None:
        for _ in range(30):
            await session.send_audio(bytes(480))

    conn = _ContinuousMicrophoneConnection(
        [
            *(event for turn in range(3) for event in _answered_turn(turn, item_id=f'user-{turn}')),
            _UserAction(count_strips),
            AudioDelta(data=_tenths_of_a_second(103) * 2, item_id='answer-3a'),
            AudioDelta(data=b'\x01\x00', item_id='answer-3b'),
            _UserAction(stream_chunks),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, audio_retention='all', retain_audio_max_seconds=0.2)
    conn.session = session
    async with session:
        await drain_events(session)

    # The answer's first part evicts what history holds and the search ends there: the chunks after it
    # start past what was already searched, rather than going over history again each time.
    assert strips <= len(session.all_messages())


async def test_audio_retention_budget_passes_over_history_once_across_many_turns(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Each eviction resumes where the last one stopped, so many short turns cost work linear in their number."""
    strips = 0
    strip = RetainedAudioBudget.strip

    def counting_strip(
        self: RetainedAudioBudget, message: ModelMessage, excess: int | None = None
    ) -> tuple[ModelMessage, int]:
        nonlocal strips
        strips += 1
        return strip(self, message, excess)

    monkeypatch.setattr(RetainedAudioBudget, 'strip', counting_strip)
    conn = _ContinuousMicrophoneConnection(
        [event for turn in range(40) for event in _answered_turn(turn, item_id=f'user-{turn}')]
    )
    session = RealtimeSession(conn, audio_retention='all', retain_audio_max_seconds=0.2)
    conn.session = session
    async with session:
        await drain_events(session)

    messages = session.all_messages()
    assert len(messages) == 80
    # Only the last question and answer still fit.
    assert [
        part.audio is not None for message in messages for part in message.parts if isinstance(part, SpeechPart)
    ] == [False] * 78 + [True] * 2
    # Starting every pass from the beginning of history would be about 80 * 80.
    assert strips <= 3 * len(messages)


def _send_image(index: int) -> _UserAction:
    async def send_image(session: _RealtimeSession) -> None:
        await session.send(BinaryImage(data=bytes([index]), media_type='image/png'))

    return _UserAction(send_image)


async def test_audio_retention_budget_still_evicts_after_an_earlier_message_leaves_history() -> None:
    """An image evicted from ahead of where audio eviction resumes doesn't make it skip the next answer's audio."""
    conn = _ContinuousMicrophoneConnection(
        [
            _send_image(0),
            AudioDelta(data=_tenths_of_a_second(100), item_id='answer-0'),
            ResponseDone(),
            AudioDelta(data=_tenths_of_a_second(101), item_id='answer-1'),
            ResponseDone(),
            # A part finalized mid-response, so the eviction it causes searches all of history.
            AudioDelta(data=_tenths_of_a_second(102), item_id='answer-2a'),
            AudioDelta(data=b'\x01\x00', item_id='answer-2b'),
            ResponseDone(),
            # Evicts the first image, which history held ahead of the answers.
            _send_image(1),
            AudioDelta(data=_tenths_of_a_second(103), item_id='answer-3'),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, audio_retention='output_audio', retain_audio_max_seconds=0.1, retain_images_max=1)
    conn.session = session
    async with session:
        await drain_events(session)

    retained = [
        part.audio is not None
        for message in session.all_messages()
        for part in message.parts
        if isinstance(part, SpeechPart)
    ]
    # Only the latest answer's audio fits, so the one before it was evicted to make room.
    assert retained[-1]
    assert sum(retained) == 1


async def test_audio_retention_budget_counts_segments_waiting_for_their_transcript() -> None:
    """A segment cut at a speech end counts until its transcript records it, and is evicted oldest first."""
    conn = _ContinuousMicrophoneConnection(
        [
            _speak(_tenths_of_a_second(0)),
            RealtimeInputSpeechEndEvent(item_id='user-0'),
            _speak(_tenths_of_a_second(1)),
            RealtimeInputSpeechEndEvent(item_id='user-1'),
            # A repeated boundary (a `committed` after the speech end, say) cuts nothing new: not over the
            # first turn's evicted segment, nor over the second turn's.
            _speak(bytes(960)),
            RealtimeInputSpeechEndEvent(item_id='user-0'),
            _speak(bytes(960)),
            RealtimeInputSpeechEndEvent(item_id='user-1'),
            InputTranscript(text='First.', is_final=True, item_id='user-0'),
            InputTranscript(text='Second.', is_final=True, item_id='user-1'),
        ]
    )
    session = RealtimeSession(conn, audio_retention='input_audio', retain_audio_max_seconds=0.15)
    conn.session = session
    async with session:
        await drain_events(session)

    assert session.all_messages() == [
        ModelRequest(parts=[SpeechPart(speaker='user', transcript='First.')], timestamp=IsDatetime()),
        ModelRequest(
            parts=[SpeechPart(speaker='user', transcript='Second.', audio=_wav_content(_tenths_of_a_second(1)))],
            timestamp=IsDatetime(),
        ),
    ]


async def test_audio_retention_budget_none_keeps_all_audio() -> None:
    conn = FakeRealtimeConnection([InputTranscript(text='hello', is_final=True)])
    session = RealtimeSession(conn, audio_retention='input_audio', retain_audio_max_seconds=None)
    chunks = [_tenths_of_a_second(index) for index in range(5)]

    for chunk in chunks:
        await session.send_audio(chunk)
    _ = await collect_events(session)

    assert session.all_messages() == [
        ModelRequest(
            parts=[SpeechPart(speaker='user', transcript='hello', audio=_wav_content(b''.join(chunks)))],
            timestamp=IsDatetime(),
        )
    ]


async def test_audio_retention_budget_zero_retains_nothing() -> None:
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='hello', is_final=True),
            AudioDelta(data=b'\x01\x00'),
            OutputTranscript(text='hi', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, model_name='m', audio_retention='all', retain_audio_max_seconds=0)

    await session.send_audio(b'\x02\x00')
    _ = await collect_events(session)

    assert conn.sent == [BinaryAudio(data=b'\x02\x00', media_type='audio/pcm')]
    assert [part for message in session.all_messages() for part in message.parts] == [
        SpeechPart(speaker='user', transcript='hello'),
        SpeechPart(speaker='assistant', transcript='hi'),
    ]


@pytest.mark.parametrize('max_seconds', [-1, float('nan'), float('inf')])
async def test_audio_retention_budget_must_be_finite_and_non_negative(max_seconds: float) -> None:
    with pytest.raises(UserError, match='`retain_audio_max_seconds` must be a finite number of at least 0'):
        RealtimeSession(FakeRealtimeConnection([]), retain_audio_max_seconds=max_seconds)


async def test_send_rejects_unsupported_binary_content() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)

    with pytest.raises(UserError, match=r"Unsupported binary media type 'application/pdf'.*WAV audio, or raw PCM"):
        await session.send(BinaryContent(data=b'document', media_type='application/pdf'))

    # A non-WAV audio container can't be unwrapped, so it's rejected rather than streamed as noise.
    with pytest.raises(UserError, match=r"Unsupported binary media type 'audio/mpeg'.*WAV audio, or raw PCM"):
        await session.send(BinaryContent(data=b'\x00mp3', media_type='audio/mpeg'))

    assert conn.sent == []


async def test_send_rejects_raw_bytes_with_audio_hint() -> None:
    # `bytes` is a `Sequence[int]`; sending it must give a clear "use `send_audio`" error, not iterate into
    # a confusing per-byte failure.
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)
    with pytest.raises(UserError, match=r'Raw audio bytes cannot be sent.*send_audio'):
        await session.send(b'\x00\x01')  # type: ignore[arg-type]
    assert conn.sent == []


async def test_send_enforces_model_profile_guard() -> None:
    # `send(BinaryImage(...))` must enforce the same `supports_image_input` guard as `send_image`.
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner, profile=_profile(supports_image_input=False))
    with pytest.raises(UserError, match='does not support image input'):
        await session.send(BinaryImage(data=b'\xff', media_type='image/jpeg'))
    assert conn.sent == []


async def test_send_text_adds_user_prompt_to_history() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner, conversation_id='c1')
    await session.send('turn it up')
    assert session.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='turn it up', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                conversation_id='c1',
            )
        ]
    )


async def test_send_during_response_is_recorded_after_response() -> None:
    response_started = asyncio.Event()
    continue_response = asyncio.Event()

    class MidResponseConnection(InferredConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            assert content == 'next turn'

        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield OutputTranscript(text='first ', item_id='assistant-1')
            response_started.set()
            await continue_response.wait()
            yield OutputTranscript(text='response', is_final=True, item_id='assistant-1')
            yield ResponseDone(provider_response_id='response-1', finish_reason='stop')

    session = RealtimeSession(MidResponseConnection(), _noop_runner)
    async with session:
        stream = session.__aiter__()

        async def next_event() -> RealtimeEvent:
            return await anext(stream)

        events_task = asyncio.create_task(next_event())
        await response_started.wait()
        await session.send('next turn')
        continue_response.set()
        first_event = await events_task
        remaining_events = [event async for event in stream]

    assert isinstance(first_event, PartStartEvent)
    # The response ended, but the text sent meanwhile asked for a reply this connection never gives: the exchange
    # `wait_for_reply()` would wait for isn't over.
    assert isinstance(remaining_events[-1], PartEndEvent)
    assert not any(isinstance(event, RealtimeTurnCompleteEvent) for event in remaining_events)
    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='first response')],
                provider_response_id='response-1',
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
            ModelRequest(parts=[UserPromptPart(content='next turn', timestamp=IsDatetime())], timestamp=IsDatetime()),
        ]
    )


async def test_manual_turn_control_helpers_forward_to_connection() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)
    await session.commit_audio()
    await session.create_response()
    await session.clear_audio()
    assert conn.sent == [CommitAudio(), CreateResponse(), ClearAudio()]


async def test_transport_failure_while_sending_becomes_a_realtime_error() -> None:
    # A send that fails because the link is gone is the same failure the receive side reports, so it
    # surfaces as `RealtimeError` (a `ModelAPIError`) instead of leaking the transport's own exception.
    # Only the types a connection declares are mapped: anything else is a bug, not a lost connection.
    class _DisconnectedConnection(FakeRealtimeConnection):
        transport_errors = (ConnectionResetError,)

        async def send_input(self, content: RealtimeInput) -> None:
            raise ConnectionResetError('connection reset by peer')

    session = RealtimeSession(_DisconnectedConnection([]), model_name='gpt-realtime')
    with pytest.raises(RealtimeError) as exc_info:
        await session.send('anyone there?')
    assert str(exc_info.value) == snapshot('Realtime connection failed while sending: connection reset by peer')
    assert exc_info.value.model_name == 'gpt-realtime'
    assert isinstance(exc_info.value.__cause__, ConnectionResetError)
    assert isinstance(exc_info.value, ModelAPIError)

    # `interrupt()` sends a truncate and a cancel as one group, so the link can also drop *between*
    # them; the second send is mapped like the first, and the interruption is not recorded as having
    # happened. A connection that failed on the first send would never reach the cancel at all.
    class _DisconnectedAfterTruncate(FakeRealtimeConnection):
        transport_errors = (ConnectionResetError,)

        async def send_input(self, content: RealtimeInput) -> None:
            if isinstance(content, CancelResponse):
                raise ConnectionResetError('connection reset by peer')
            self.sent.append(content)

    interrupted = _DisconnectedAfterTruncate([])
    session = RealtimeSession(interrupted, model_name='gpt-realtime')
    with pytest.raises(RealtimeError, match='failed while sending'):
        await session.interrupt(played_ms=120)
    assert interrupted.sent == [TruncateOutput(audio_end_ms=120)]

    # A session built straight from a connection may not know any model id to attribute this to.
    anonymous = RealtimeSession(_DisconnectedConnection([]))
    with pytest.raises(RealtimeError) as exc_info:
        await anonymous.send('anyone there?')
    assert exc_info.value.model_name == 'unknown'


class _ReconnectingDisconnectedConnection(FakeRealtimeConnection):
    """Fails every send while `dropped`, as a link its reconnect policy is still replacing does."""

    transport_errors = (ConnectionResetError,)

    def __init__(self, *, can_reconnect: bool = True) -> None:
        super().__init__([])
        self.dropped = False
        self.can_reconnect = can_reconnect

    @property
    def _can_reconnect(self) -> bool:
        return self.can_reconnect

    async def send_input(self, content: RealtimeInput) -> None:
        if self.dropped:
            raise ConnectionResetError('connection reset by peer')
        self.sent.append(content)


async def test_audio_chunk_that_hits_a_reconnecting_link_is_dropped() -> None:
    # An always-on microphone streams a chunk every ~100 ms and a reconnect's backoff is longer, so a
    # chunk used to hit the dead socket on every reconnect and raise, killing the capture task. While
    # the connection is reconnecting, the chunk is dropped instead (live audio is worthless late) and
    # the capture loop carries on. Other sends still raise, as does audio without a reconnect policy.
    conn = _ReconnectingDisconnectedConnection()
    session = RealtimeSession(conn, model_name='gpt-realtime', audio_retention='input_audio')

    async def microphone() -> AsyncIterator[bytes]:
        yield b'\x01\x01'
        conn.dropped = True
        yield b'\x02\x02'
        conn.dropped = False
        yield b'\x03\x03'

    await session.send_audio(microphone())
    assert [content.data for content in conn.sent if isinstance(content, BinaryAudio)] == [
        b'\x01\x01',
        b'\x03\x03',
    ]

    conn.dropped = True
    with pytest.raises(RealtimeError, match='failed while sending'):
        await session.send('anyone there?')

    without_policy = _ReconnectingDisconnectedConnection(can_reconnect=False)
    without_policy.dropped = True
    with pytest.raises(RealtimeError, match='failed while sending'):
        await RealtimeSession(without_policy, model_name='gpt-realtime').send_audio(b'\x01\x01')


async def test_audio_raises_once_receiving_has_ended_even_if_the_connection_still_claims_a_reconnect() -> None:
    # A re-dial can fail with an error the reconnect loop doesn't expect, ending receiving without the
    # connection marking its reconnect as given up. Once a consumer has caught that failure, nothing will
    # replace the link, so a mic chunk must raise rather than be dropped silently forever.
    class _DialBlowsUp(_ReconnectingDisconnectedConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            raise RuntimeError('handshake rejected')
            yield  # pragma: no cover  (makes this an async generator)

    conn = _DialBlowsUp()
    session = RealtimeSession(conn, model_name='gpt-realtime')
    async with session:
        with pytest.raises(RuntimeError, match='handshake rejected'):
            async for _ in session:
                pass  # pragma: no cover - the failure is the only thing that arrives
        conn.dropped = True
        with pytest.raises(RealtimeError, match='failed while sending'):
            await session.send_audio(b'\x01\x01')


def test_a_connection_does_not_reconnect_by_default() -> None:
    assert FakeRealtimeConnection([])._can_reconnect is False  # pyright: ignore[reportPrivateUsage]


async def test_undeclared_send_failure_is_left_alone() -> None:
    # A connection that fails for a reason it didn't declare as a transport error is reporting a bug,
    # not a lost connection; dressing it up as a `RealtimeError` would hide that.
    class _BuggyConnection(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            raise ValueError('bug in the connection')

    session = RealtimeSession(_BuggyConnection([]))
    with pytest.raises(ValueError, match='bug in the connection'):
        await session.send('hello')


async def test_failed_image_send_is_not_recorded_in_history() -> None:
    # A retained image is recorded before the frame goes out, so history can't disagree with the wire
    # when sends interleave. When the send fails there is no image on the wire to agree with, so the
    # record has to come back out.
    class _BuggyConnection(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            raise ValueError('bug in the connection')

    session = RealtimeSession(_BuggyConnection([]), profile=_profile(supports_image_input=True))
    with pytest.raises(ValueError, match='bug in the connection'):
        await session.send(BinaryContent(data=b'image', media_type='image/png'))

    assert session.all_messages() == []


async def test_failed_create_response_releases_its_reservation() -> None:
    # `create_response` reserves a response slot before asking for one, so a solicited response isn't
    # mistaken for the model speaking on its own. When the frame never reaches the provider there is
    # no response coming, and leaving the reservation would mis-label the next spontaneous turn.
    class _BuggyConnection(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            raise ValueError('bug in the connection')

    session = RealtimeSession(_BuggyConnection([]), profile=_profile(supports_manual_turn_control=True))
    with pytest.raises(ValueError, match='bug in the connection'):
        await session.create_response()
    assert session._core.requests_ahead() == 0  # pyright: ignore[reportPrivateUsage]


async def test_session_accumulates_usage_and_requests() -> None:
    conn = FakeRealtimeConnection(
        [
            SessionUsage(usage=RequestUsage(input_tokens=10, output_tokens=5)),
            SessionUsage(usage=RequestUsage(input_tokens=3, output_tokens=2)),
            OutputTranscript(text='ok', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m')
    _ = await collect_events(session)
    assert session.usage.input_tokens == 13
    assert session.usage.output_tokens == 7
    assert session.usage.requests == 1
    # The turn's combined usage lands on the finalized assistant response.
    response = session.new_messages()[0]
    assert isinstance(response, ModelResponse)
    assert response.usage == snapshot(RequestUsage(input_tokens=13, output_tokens=7))


async def test_session_counts_tool_calls() -> None:
    conn = FakeRealtimeConnection([ToolCall(tool_call_id='t', tool_name='f', args='{}'), ResponseDone()])

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'ok'

    session = RealtimeSession(conn, runner)
    _ = await collect_events(session)
    assert session.usage.tool_calls == 1


async def test_session_does_not_count_invalid_tool_call_as_successful() -> None:
    conn = FakeRealtimeConnection([ToolCall(tool_call_id='t', tool_name='f', args='not json')])
    session = RealtimeSession(conn)

    _ = await collect_events(session)

    assert session.usage.tool_calls == 0


async def test_truncate_output_helper_forwards_to_connection() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)
    await session.interrupt(played_ms=640)
    assert conn.sent == [TruncateOutput(audio_end_ms=640), CancelResponse()]


async def test_interrupt_truncates_before_cancel() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)
    await session.interrupt(played_ms=800)
    # Truncate must precede cancel: cancel triggers response.done, which clears the tracked item.
    assert conn.sent == [TruncateOutput(audio_end_ms=800), CancelResponse()]


async def test_interrupt_without_played_ms_only_cancels() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner)
    await session.interrupt()
    assert conn.sent == [CancelResponse()]


# --- capability guards: unsupported operations raise before sending -----------------------------


async def test_manual_turn_control_guard() -> None:
    # A model without manual turn control (e.g. Gemini Live) rejects push-to-talk verbs up front.
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner, profile=_profile(supports_manual_turn_control=False))
    for method in (session.commit_audio, session.clear_audio, session.create_response):
        with pytest.raises(UserError, match='does not support manual turn-taking'):
            await method()
    assert conn.sent == []  # nothing reached the connection


async def test_interruption_guard() -> None:
    # A model without interruption (e.g. Gemini Live) rejects barge-in cancellation up front.
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner, profile=_profile(supports_interruption=False))
    with pytest.raises(UserError, match='does not support interruption'):
        await session.interrupt()
    assert conn.sent == []


async def test_output_truncation_guard() -> None:
    # A model that supports cancellation but not output truncation (e.g. xAI Grok Voice) rejects
    # `interrupt(played_ms=...)`, while a plain `interrupt()` still cancels.
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner, profile=_profile(supports_output_truncation=False))
    with pytest.raises(UserError, match='does not support output truncation'):
        await session.interrupt(played_ms=100)
    assert conn.sent == []
    await session.interrupt()
    assert conn.sent == [CancelResponse()]


class SlowSendConnection(FakeRealtimeConnection):
    """A connection that yields control inside `send`, so concurrent senders can interleave."""

    async def send_input(self, content: RealtimeInput) -> None:
        await asyncio.sleep(0)
        await super().send_input(content)


async def test_concurrent_image_and_text_history_matches_wire_order() -> None:
    image_send_started = asyncio.Event()
    release_image = asyncio.Event()

    class _PausedImageConnection(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            if isinstance(content, BinaryImage):
                image_send_started.set()
                await release_image.wait()
            await super().send_input(content)

    conn = _PausedImageConnection([])
    session = RealtimeSession(conn)
    image_task = asyncio.create_task(session.send(BinaryImage(data=b'image', media_type='image/png')))
    await image_send_started.wait()
    text_task = asyncio.create_task(session.send('text'))
    await asyncio.sleep(0)
    release_image.set()
    await asyncio.gather(image_task, text_task)

    assert [type(frame) for frame in conn.sent] == [BinaryImage, str]
    image_request, text_request = session.new_messages()
    assert isinstance(image_request, ModelRequest)
    assert isinstance(text_request, ModelRequest)
    image_part, text_part = image_request.parts[0], text_request.parts[0]
    assert isinstance(image_part, UserPromptPart)
    assert isinstance(text_part, UserPromptPart)
    assert image_part.content == [BinaryImage(data=b'image', media_type='image/png')]
    assert text_part.content == 'text'


async def test_interrupt_truncate_and_cancel_cannot_be_split() -> None:
    # `interrupt(played_ms=...)` is two frames, and the cancel is only correct for the response the
    # truncate targeted. On OpenAI-shaped providers a concurrent send starts a new response, so a frame
    # landing in the gap would leave the cancel killing that one instead of the barge-in's target. The
    # session's send lock has to keep the pair adjacent even when sends overlap.
    conn = SlowSendConnection([])
    session = RealtimeSession(conn, _noop_runner, model_name='m')

    await asyncio.gather(
        session.interrupt(played_ms=100),
        *(session.send('concurrent') for _ in range(3)),
    )

    kinds = [type(frame).__name__ for frame in conn.sent]
    truncate = kinds.index('TruncateOutput')
    assert kinds[truncate + 1] == 'CancelResponse', f'a frame was interleaved into the transaction: {kinds}'
    # The concurrent sends still all got through, just never in the middle.
    assert kinds.count('str') == 3


async def test_image_input_guard() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner, profile=_profile(supports_image_input=False))
    with pytest.raises(UserError, match='does not support image input'):
        await session.send(BinaryImage(data=b'\xff\xd8', media_type='image/jpeg'))
    assert conn.sent == []


async def test_owns_media_guard() -> None:
    # A WebRTC sideband session (owns_media=False) doesn't own the audio transport, so the audio
    # methods are unavailable up front — the browser streams audio to the provider directly.
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, _noop_runner, owns_media=False)
    with pytest.raises(UserError, match='does not own the audio transport'):
        await session.send_audio(b'\x00\x00')
    with pytest.raises(UserError, match='does not own the audio transport'):
        await session.commit_audio()
    with pytest.raises(UserError, match='does not own the audio transport'):
        await session.clear_audio()
    # The routing through `send()` (audio input / audio bytes) is gated by the same guard.
    with pytest.raises(UserError, match='does not own the audio transport'):
        await session.send(BinaryAudio(data=b'\x00\x00', media_type='audio/pcm'))
    with pytest.raises(UserError, match='does not own the audio transport'):
        await session.send(BinaryContent(data=b'\x00\x00', media_type='audio/pcm'))
    with pytest.raises(UserError, match='browser exchanges audio with the provider directly over WebRTC'):
        await anext(session.stream_audio())
    assert conn.sent == []  # nothing reached the connection


async def test_owns_media_default_allows_audio() -> None:
    # The default (owns_media=True) leaves both audio directions available.
    conn = FakeRealtimeConnection([AudioDelta(data=b'\x01\x02')])
    async with RealtimeSession(conn, _noop_runner, profile=_profile()) as session:
        audio = asyncio.ensure_future(anext(session.stream_audio()))
        await asyncio.sleep(0)
        await session.send_audio(b'\x00\x00')
        assert await audio == b'\x01\x02'
    assert conn.sent == [BinaryAudio(data=b'\x00\x00', media_type='audio/pcm')]


async def test_early_break_cancels_pump() -> None:
    # Breaking out early must cancel the background pump task so it doesn't leak, parked forever
    # awaiting an upstream event that never comes. A finite connection wouldn't test this — its pump
    # ends on its own; here the pump blocks mid-iteration and only stops if it is cancelled.
    parked = asyncio.Event()
    cancelled = asyncio.Event()

    class _BlockAfterFirst(InferredConnection):
        def __init__(self) -> None:
            self.iteration_task: asyncio.Task[Any] | None = None

        # Never sent to.
        async def send_input(self, content: RealtimeInput) -> None:  # pragma: no cover
            raise AssertionError

        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            self.iteration_task = asyncio.current_task()
            yield AudioDelta(data=b'\x00')
            parked.set()
            try:
                await asyncio.Event().wait()  # park until the pump task is cancelled
            except asyncio.CancelledError:
                cancelled.set()
                raise
            # Unreachable while parked.
            yield AudioDelta(data=b'\x01')  # pragma: no cover

    conn = _BlockAfterFirst()
    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        async for event in session:
            assert isinstance(event, PartStartEvent)
            await parked.wait()  # the pump has consumed the first event and is parked on the next
            break

    # The owner's exit drains cancellation synchronously; no async-generator close or GC pumping is
    # needed before the connection observes cancellation and the receive task is done.
    assert cancelled.is_set()
    assert conn.iteration_task is not None and conn.iteration_task.done()


def test_asap_notification_is_ignored_after_loop_closes() -> None:
    session = RealtimeSession(FakeRealtimeConnection([]), _noop_runner)
    closed_loop = asyncio.new_event_loop()
    closed_loop.close()
    session._loop = closed_loop  # pyright: ignore[reportPrivateUsage]
    session._notify_pending_messages('asap')  # pyright: ignore[reportPrivateUsage]


async def test_concurrent_iteration_raises() -> None:
    class _IdleConnection(InferredConnection):
        # Never sent to.
        async def send_input(self, content: RealtimeInput) -> None:  # pragma: no cover
            raise AssertionError

        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield AudioDelta(data=b'\x00')
            await asyncio.Event().wait()

    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(_IdleConnection())).session() as session:
        first = session.__aiter__()
        assert isinstance(await anext(first), PartStartEvent)

        second = session.__aiter__()
        with pytest.raises(UserError, match='already being iterated'):
            await anext(second)

    late = session.__aiter__()
    with pytest.raises(UserError, match='closed'):
        await anext(late)


def _queued_realtime_events(session: _RealtimeSession) -> list[RealtimeEvent]:
    return [
        item
        for item in session._queue  # pyright: ignore[reportPrivateUsage]
        if isinstance(
            item,
            (
                PartStartEvent,
                PartDeltaEvent,
                PartEndEvent,
                RealtimeInputSpeechStartEvent,
                RealtimeInputSpeechEndEvent,
                RealtimeTurnCompleteEvent,
            ),
        )
    ]


async def test_unconsumed_session_queue_keeps_structural_events_and_latest_deltas() -> None:
    chunks = [index.to_bytes(2, 'big') for index in range(2000)]
    connection = FakeRealtimeConnection(
        [
            RealtimeInputSpeechStartEvent(),
            *[AudioDelta(chunk) for chunk in chunks[:1000]],
            RealtimeInputSpeechEndEvent(),
            *[AudioDelta(chunk) for chunk in chunks[1000:]],
            ResponseDone(),
        ]
    )

    async with RealtimeSession(connection) as session:
        # Two thousand 2-byte chunks are far inside the audio view's windows, so it keeps them all.
        assert [chunk async for chunk in session.stream_audio()] == chunks

        queued = _queued_realtime_events(session)
        assert sum(isinstance(event, PartDeltaEvent) for event in queued) == 512
        # The pair after the turn boundary is the user's turn: a VAD segment whose transcript never arrives is
        # recorded as a content-less `SpeechPart` rather than vanishing, once nothing more of it can come.
        assert [type(event).__name__ for event in queued if not isinstance(event, PartDeltaEvent)] == snapshot(
            [
                'RealtimeInputSpeechStartEvent',
                'PartStartEvent',
                'RealtimeInputSpeechEndEvent',
                'PartEndEvent',
                'RealtimeTurnCompleteEvent',
                'PartStartEvent',
                'PartEndEvent',
            ]
        )

        late_events = [event async for event in session]
        late_chunks = [
            event.delta.audio_chunk
            for event in late_events
            if isinstance(event, PartDeltaEvent) and isinstance(event.delta, SpeechPartDelta)
        ]
        assert late_chunks == chunks[-512:]


async def test_active_session_iterator_does_not_drop_deltas() -> None:
    chunks = [index.to_bytes(2, 'big') for index in range(2000)]
    async with RealtimeSession(FakeRealtimeConnection([AudioDelta(chunk) for chunk in chunks])) as session:
        events = [event async for event in session]
        assert [
            event.delta.audio_chunk
            for event in events
            if isinstance(event, PartDeltaEvent) and isinstance(event.delta, SpeechPartDelta)
        ] == chunks
        assert session._queue_dropped_deltas == 0  # pyright: ignore[reportPrivateUsage]


async def test_closing_session_iterator_bounds_remaining_deltas() -> None:
    chunks = [index.to_bytes(2, 'big') for index in range(2000)]
    async with RealtimeSession(FakeRealtimeConnection([AudioDelta(chunk) for chunk in chunks])) as session:
        events = session.__aiter__()
        assert isinstance(await anext(events), PartStartEvent)
        assert isinstance(events, AsyncGenerator)
        await events.aclose()

        assert session._queue_delta_count == 512  # pyright: ignore[reportPrivateUsage]
        assert session._queue_dropped_deltas == 1488  # pyright: ignore[reportPrivateUsage]


async def test_unconsumed_session_queue_bounds_structural_events() -> None:
    """Structural events are never superseded the way deltas are, so they need their own bound.

    Not a VCR test: it takes more turns than a recording holds to reach the cap at all.
    """
    turns = 200
    events: list[RealtimeCodecEvent] = []
    for index in range(turns):
        events.append(RealtimeInputSpeechStartEvent())
        events.extend(AudioDelta((index * 1000 + frame).to_bytes(4, 'big')) for frame in range(50))
        events.append(RealtimeInputSpeechEndEvent())
        events.append(ResponseDone())

    async with RealtimeSession(FakeRealtimeConnection(events)) as session:
        _ = [chunk async for chunk in session.stream_audio()]

        queued = _queued_realtime_events(session)
        structural = [event for event in queued if not isinstance(event, PartDeltaEvent)]
        # Seven structural events per turn: the untranscribed segment's part starts and ends too. The cap evicts a
        # part's start with the rest of the part, so it can keep one fewer than it allows.
        assert len(structural) == snapshot(511)
        assert session._queue_dropped_structural == snapshot(889)  # pyright: ignore[reportPrivateUsage]
        # The window that survives is the most recent one.
        assert [type(event).__name__ for event in structural[-8:]] == snapshot(
            [
                'PartEndEvent',
                'RealtimeInputSpeechStartEvent',
                'PartStartEvent',
                'RealtimeInputSpeechEndEvent',
                'PartEndEvent',
                'RealtimeTurnCompleteEvent',
                'PartStartEvent',
                'PartEndEvent',
            ]
        )
        # No delta is orphaned; `test_unconsumed_session_queue_never_orphans_a_delta` covers the
        # densities where that takes evicting a part whole.
        started = {event.index for event in structural if isinstance(event, PartStartEvent)}
        assert {event.index for event in queued if isinstance(event, PartDeltaEvent)} <= started


@pytest.mark.parametrize('frames_per_turn', [1, 2, 5, 50])
async def test_unconsumed_session_queue_never_orphans_a_delta(frames_per_turn: int) -> None:
    """Evicting a part start takes the rest of that part with it, at every audio-frame density.

    A turn with few audio frames reaches the structural cap long before the delta cap, so the part
    starts go while their deltas stay — which would leave a late iterator deltas it cannot attach to
    anything. Parametrized because the defect is invisible at the frame counts a real voice turn has.
    """
    events: list[RealtimeCodecEvent] = []
    for index in range(200):
        events.append(RealtimeInputSpeechStartEvent())
        events.extend(AudioDelta((index * 1000 + frame).to_bytes(4, 'big')) for frame in range(frames_per_turn))
        events.append(RealtimeInputSpeechEndEvent())
        events.append(ResponseDone())

    async with RealtimeSession(FakeRealtimeConnection(events)) as session:
        _ = [chunk async for chunk in session.stream_audio()]

        queued = _queued_realtime_events(session)
        started = {event.index for event in queued if isinstance(event, PartStartEvent)}
        assert {event.index for event in queued if isinstance(event, PartDeltaEvent)} <= started
        assert {event.index for event in queued if isinstance(event, PartEndEvent)} <= started


async def test_unconsumed_session_queue_keeps_a_restarted_part_whole(monkeypatch: pytest.MonkeyPatch) -> None:
    """Evicting a part's start leaves alone a later start under the same index, which carries the part again.

    A late transcript streams its item's ended part again under the part's index, so the eviction of the first
    start must stop at the restart rather than take its delta and end too. Not a VCR test: the queue bound is
    internal, and a recording can't produce the late order on demand.
    """
    monkeypatch.setattr('pydantic_ai.realtime._session._SESSION_STRUCTURAL_QUEUE_SIZE', 5)
    events: list[RealtimeCodecEvent] = [
        OutputTranscript('Hello', is_final=False, item_id='a'),
        OutputTranscript('Bonjour.', is_final=False, item_id='b'),
        OutputTranscript(' world.', is_final=False, item_id='a'),
        ResponseDone(),
    ]

    async with RealtimeSession(FakeRealtimeConnection(events)) as session:
        _ = [chunk async for chunk in session.stream_audio()]

        parts: dict[int, list[tuple[str, str | None]]] = {}
        for event in _queued_realtime_events(session):
            if isinstance(event, PartDeltaEvent):
                assert isinstance(event.delta, SpeechPartDelta)
                parts.setdefault(event.index, []).append(('delta', event.delta.transcript_delta))
            elif isinstance(event, (PartStartEvent, PartEndEvent)):
                assert isinstance(event.part, SpeechPart)
                kind = 'start' if isinstance(event, PartStartEvent) else 'end'
                parts.setdefault(event.index, []).append((kind, event.part.transcript))
        assert list(parts.values()) == [
            [('start', ''), ('delta', 'Bonjour.'), ('end', 'Bonjour.')],
            [('start', 'Hello'), ('delta', ' world.'), ('end', 'Hello world.')],
        ]


async def test_late_transcript_yields_its_turn_again_in_stream_transcripts() -> None:
    """Text arriving for an ended part while a later item streams re-yields that turn, with the transcript so far.

    `delta=True` carries the part's `index`, so a caption UI replaces that turn rather than adding one. Not a VCR
    test: a recording can't produce the late order on demand.
    """
    events: list[RealtimeCodecEvent] = [
        OutputTranscript('Hello', is_final=False, item_id='a'),
        OutputTranscript('Bonjour.', is_final=False, item_id='b'),
        OutputTranscript(' world.', is_final=False, item_id='a'),
        ResponseDone(),
    ]

    async with RealtimeSession(FakeRealtimeConnection(events)) as session:
        transcripts, updates = await asyncio.gather(
            aiter_to_list(session.stream_transcripts()), aiter_to_list(session.stream_transcripts(delta=True))
        )

    assert transcripts == snapshot(
        [
            SpeechPart(speaker='assistant', transcript='Hello'),
            SpeechPart(speaker='assistant', transcript='Hello world.'),
            SpeechPart(speaker='assistant', transcript='Bonjour.'),
        ]
    )
    assert updates == snapshot(
        [
            TranscriptUpdate(index=0, speaker='assistant', delta='Hello', transcript='Hello'),
            TranscriptUpdate(index=1, speaker='assistant', delta='Bonjour.', transcript='Bonjour.'),
            TranscriptUpdate(index=0, speaker='assistant', delta=' world.', transcript='Hello world.'),
        ]
    )


async def test_parked_exception_survives_a_trimmed_queue() -> None:
    """A failure parked after heavy trimming is still delivered when the session closes."""
    events: list[RealtimeCodecEvent] = []
    for index in range(200):
        events.append(RealtimeInputSpeechStartEvent())
        events.append(AudioDelta(index.to_bytes(4, 'big')))
        events.append(RealtimeInputSpeechEndEvent())
        events.append(ResponseDone())

    session = RealtimeSession(FakeRealtimeConnection(events))
    with pytest.raises(RuntimeError, match='tool failed'):
        async with session:
            # Drain the turns first so the queue has done its evicting, then park: `_park_error` ends
            # the receive side when nobody is iterating, so a failure cannot sit in the queue *while*
            # trimming continues. That is why `_is_structural` excluding exceptions is defensive.
            _ = [chunk async for chunk in session.stream_audio()]
            session._park_error(RuntimeError('tool failed'))  # pyright: ignore[reportPrivateUsage]


async def test_active_session_iterator_does_not_drop_structural_events() -> None:
    events: list[RealtimeCodecEvent] = []
    for index in range(200):
        events.append(RealtimeInputSpeechStartEvent())
        events.append(AudioDelta(index.to_bytes(4, 'big')))
        events.append(RealtimeInputSpeechEndEvent())
        events.append(ResponseDone())

    async with RealtimeSession(FakeRealtimeConnection(events)) as session:
        received = [event async for event in session]
        assert session._queue_dropped_structural == 0  # pyright: ignore[reportPrivateUsage]
        assert sum(isinstance(event, RealtimeTurnCompleteEvent) for event in received) == 200


async def test_unconsumed_session_queue_keeps_parked_exception() -> None:
    chunks = [index.to_bytes(2, 'big') for index in range(2000)]
    session = RealtimeSession(FakeRealtimeConnection([AudioDelta(chunk) for chunk in chunks]))

    with pytest.raises(RuntimeError, match='tool failed'):
        async with session:
            received: list[bytes] = []
            async for chunk in session.stream_audio():
                received.append(chunk)
                if len(received) == 1:
                    # Parked mid-stream, the shape a failing tool produces: the pump is running, so
                    # ending the receive side finishes this very view and `close()` raises the error.
                    session._park_error(RuntimeError('tool failed'))  # pyright: ignore[reportPrivateUsage]


async def test_direct_session_must_be_entered_and_streams_once() -> None:
    session = RealtimeSession(FakeRealtimeConnection([]), _noop_runner)

    unentered = session.__aiter__()
    with pytest.raises(UserError, match='async with'):
        await anext(unentered)

    async with session:
        assert [event async for event in session] == []
        exhausted = session.__aiter__()
        with pytest.raises(UserError, match='already ended'):
            await anext(exhausted)

    with pytest.raises(UserError, match='cannot be entered more than once'):
        await session.__aenter__()


# --- audio retention ----------------------------------------------------------------------------


async def test_audio_retention_output_keeps_assistant_audio() -> None:
    conn = FakeRealtimeConnection(
        [
            AudioDelta(data=b'\x00\x01'),
            AudioDelta(data=b'\x02\x03'),
            OutputTranscript(text='hi', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m', audio_retention='all')
    _ = await collect_events(session)
    response = session.new_messages()[0]
    assert isinstance(response, ModelResponse)
    part = response.parts[0]
    assert isinstance(part, SpeechPart)
    assert part.transcript == 'hi'
    assert part.audio is not None
    assert part.audio.media_type == 'audio/wav'
    assert part.audio.format == 'wav'
    with wave.open(io.BytesIO(part.audio.data), 'rb') as wav:
        assert (wav.getnchannels(), wav.getsampwidth(), wav.getframerate()) == (1, 2, 24000)
        assert wav.readframes(wav.getnframes()) == b'\x00\x01\x02\x03'


async def test_audio_retention_input_keeps_user_audio() -> None:
    conn = FakeRealtimeConnection([InputTranscript(text='hello', is_final=True)])
    session = RealtimeSession(conn, _noop_runner, audio_retention='input_audio')
    # send_audio before the transcript finalizes buffers into the user part.
    await session.send_audio(b'\xaa\xbb')
    await session.send_audio(b'\xcc')
    _ = await collect_events(session)
    assert session.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    SpeechPart(
                        speaker='user',
                        transcript='hello',
                        audio=_wav_content(b'\xaa\xbb\xcc'),
                    )
                ],
                timestamp=IsDatetime(),
            )
        ]
    )


async def test_audio_retention_segmentation_follows_provider_boundaries() -> None:
    """Speech-end providers cut input early; boundary-less providers retain through response completion."""
    speech_ended = asyncio.Event()
    finish_openai = asyncio.Event()

    class _SpeechEndConnection(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            await speech_ended.wait()
            yield RealtimeInputSpeechEndEvent(item_id='turn')
            await finish_openai.wait()
            yield InputTranscript(text='hello', is_final=True, item_id='turn')
            yield ResponseDone()

    openai_session = RealtimeSession(_SpeechEndConnection([]), _noop_runner, audio_retention='input_audio')
    await openai_session.send_audio(b'speech')
    speech_ended.set()
    async with openai_session:
        events = openai_session.__aiter__()
        assert isinstance(await anext(events), RealtimeInputSpeechEndEvent)
        await openai_session.send_audio(b'inter-turn silence')
        finish_openai.set()
        _ = [event async for event in events]

    gemini_session = RealtimeSession(
        FakeRealtimeConnection([InputTranscript(text='hello', is_final=False, cumulative=True), ResponseDone()]),
        _noop_runner,
        audio_retention='input_audio',
    )
    await gemini_session.send_audio(b'speech')
    await gemini_session.send_audio(b'model-response silence')
    _ = await collect_events(gemini_session)

    assert openai_session.new_messages()[0] == ModelRequest(
        parts=[SpeechPart(speaker='user', transcript='hello', audio=_wav_content(b'speech'))],
        timestamp=IsDatetime(),
    )
    assert gemini_session.new_messages()[0] == ModelRequest(
        parts=[
            SpeechPart(
                speaker='user',
                transcript='hello',
                audio=_wav_content(b'speechmodel-response silence'),
            )
        ],
        timestamp=IsDatetime(),
    )


async def test_audio_retention_uses_profile_rate_for_each_speaker() -> None:
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='hello', is_final=True),
            AudioDelta(data=b'\x01\x02'),
            OutputTranscript(text='hi', is_final=True),
            ResponseDone(),
        ]
    )
    profile = RealtimeModelProfile(audio_input_sample_rate=16000, audio_output_sample_rate=24000)
    session = RealtimeSession(conn, _noop_runner, audio_retention='all', profile=profile)
    await session.send_audio(b'\xaa\xbb')
    _ = await collect_events(session)

    request, response = session.new_messages()
    assert isinstance(request, ModelRequest) and isinstance(response, ModelResponse)
    user, assistant = request.parts[0], response.parts[0]
    assert isinstance(user, SpeechPart) and user.audio is not None
    assert isinstance(assistant, SpeechPart) and assistant.audio is not None
    with wave.open(io.BytesIO(user.audio.data), 'rb') as user_wav:
        assert user_wav.getframerate() == 16000
    with wave.open(io.BytesIO(assistant.audio.data), 'rb') as assistant_wav:
        assert assistant_wav.getframerate() == 24000


async def test_clear_audio_discards_retained_input() -> None:
    # `clear_audio()` must drop the locally retained buffer too, or discarded audio would still attach
    # to the next finalized user turn (with `audio_retention='input_audio'`/`'all'`).
    conn = FakeRealtimeConnection([InputTranscript(text='hello', is_final=True)])
    session = RealtimeSession(conn, _noop_runner, audio_retention='input_audio')
    await session.send_audio(b'\xaa\xbb')
    await session.clear_audio()  # discards the buffered chunk
    await session.send_audio(b'\xcc')  # only this survives into the finalized user turn
    _ = await collect_events(session)
    assert session.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    SpeechPart(
                        speaker='user',
                        transcript='hello',
                        audio=_wav_content(b'\xcc'),
                    )
                ],
                timestamp=IsDatetime(),
            )
        ]
    )


async def test_audio_only_user_turn_finalized_on_speech_stopped() -> None:
    # Transcription off + input audio retained: no `InputTranscript` arrives, so the user's turn is
    # finalized from the retained audio at the speech-stopped boundary (server VAD), as an audio-only
    # `SpeechPart` (no transcript). Bracketed with start/end, since there are no transcript deltas.
    conn = FakeRealtimeConnection(
        [RealtimeInputSpeechEndEvent(), OutputTranscript(text='Hi', is_final=True), ResponseDone()],
        input_transcription_enabled=False,
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m', audio_retention='input_audio')
    await session.send_audio(b'\xaa\xbb')
    events = await collect_events(session)
    user_part = SpeechPart(speaker='user', audio=_wav_content(b'\xaa\xbb'))
    assert events[:3] == [
        RealtimeInputSpeechEndEvent(),
        PartStartEvent(index=0, part=user_part),
        PartEndEvent(index=0, part=user_part),
    ]
    assert session.new_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', audio=_wav_content(b'\xaa\xbb'))], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='Hi')],
                model_name='m',
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


async def test_audio_only_user_turn_finalized_on_turn_complete() -> None:
    # Providers without a speech-stopped signal (e.g. Gemini): the audio-only user turn is finalized at
    # the turn-complete boundary, before the assistant response, so history reads user-then-assistant.
    conn = FakeRealtimeConnection(
        [OutputTranscript(text='Hi', is_final=True), ResponseDone()],
        input_transcription_enabled=False,
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m', audio_retention='input_audio')
    await session.send_audio(b'\xaa\xbb')
    _ = await collect_events(session)
    assert session.new_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', audio=_wav_content(b'\xaa\xbb'))], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='Hi')],
                model_name='m',
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


_SETTLED_IN_FLIGHT = snapshot(
    [
        ModelResponse(
            parts=[SpeechPart(speaker='assistant', transcript='before')],
            timestamp=IsDatetime(),
            state='interrupted',
        ),
        ModelResponse(
            parts=[SpeechPart(speaker='assistant', transcript='after')],
            timestamp=IsDatetime(),
            finish_reason='stop',
        ),
    ]
)


@pytest.mark.parametrize(
    ('reconnect_restores_in_flight_state', 'state_restored', 'expected_state_restored', 'expected'),
    [
        # Native resumption (xAI; Gemini settles the cut turn in its own connection): the connection
        # reports it restored the in-flight response, so the two transcript halves belong to one response
        # and nothing is settled. This is the only path that keeps `state_restored=True`.
        pytest.param(
            True,
            True,
            True,
            snapshot(
                [
                    ModelResponse(
                        parts=[SpeechPart(speaker='assistant', transcript='beforeafter')],
                        timestamp=IsDatetime(),
                        finish_reason='stop',
                    )
                ]
            ),
            id='native-resume-continues',
        ),
        # Local replay (OpenAI, Azure OpenAI): the connection reports `state_restored=True` because it
        # replayed the *finalized* history, but it does not restore in-flight state — the response the
        # drop cut off is gone. The session settles it as an interrupted response and downgrades the
        # user-facing flag to `False`, matching the fully-lost path so an app branches the same way.
        pytest.param(False, True, False, _SETTLED_IN_FLIGHT, id='local-replay-settles-in-flight'),
        # Nothing restored at all: same settlement, flag already `False`.
        pytest.param(False, False, False, _SETTLED_IN_FLIGHT, id='state-lost-settles-in-flight'),
    ],
)
async def test_reconnect_response_state(
    reconnect_restores_in_flight_state: bool,
    state_restored: bool,
    expected_state_restored: bool,
    expected: list[ModelMessage],
) -> None:
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='before', is_final=False),
            RealtimeSessionReconnectEvent(state_restored=state_restored),
            OutputTranscript(text='after', is_final=True),
            ResponseDone(),
        ],
        reconnect_restores_in_flight_state=reconnect_restores_in_flight_state,
    )
    session = RealtimeSession(conn)
    events = await collect_events(session)
    # The flag the app sees reflects what actually survived, not just what the connection replayed.
    assert [e.state_restored for e in events if isinstance(e, RealtimeSessionReconnectEvent)] == [
        expected_state_restored
    ]
    assert session.new_messages() == expected


async def test_response_cut_off_by_a_reconnect_keeps_its_id() -> None:
    """A reply the drop cut off is recorded with the response id its content carried.

    Its `ResponseDone` never arrives, so the content is the only place the session sees that id. The next
    response gets its own id rather than inheriting the cut one.
    """
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='One, two, three', response_id='resp_cut'),
            RealtimeSessionReconnectEvent(state_restored=True),
            OutputTranscript(text='after', is_final=True, response_id='resp_next'),
            ResponseDone(provider_response_id='resp_next'),
        ],
        reconnect_restores_in_flight_state=False,
    )
    session = RealtimeSession(conn)
    await collect_events(session)
    responses = [m for m in session.new_messages() if isinstance(m, ModelResponse)]
    assert [(r.state, r.provider_response_id) for r in responses] == [
        ('interrupted', 'resp_cut'),
        ('complete', 'resp_next'),
    ]


async def test_content_naming_another_response_starts_one_of_its_own() -> None:
    """Content that names a different response than the one under way ends that one: the cut-off one is the new one.

    (Each is named after the id its content carries, as in `test_response_cut_off_by_a_reconnect_keeps_its_id`.)
    """
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='One, ', response_id='resp_a'),
            OutputTranscript(text='two', response_id='resp_b'),
            RealtimeSessionReconnectEvent(state_restored=True),
        ],
        reconnect_restores_in_flight_state=False,
    )
    session = RealtimeSession(conn)
    await collect_events(session)
    responses = [m for m in session.new_messages() if isinstance(m, ModelResponse)]
    assert [(r.state, r.provider_response_id) for r in responses] == [('complete', 'resp_a'), ('interrupted', 'resp_b')]


async def test_response_cut_off_by_close_keeps_its_id() -> None:
    """Closing the session mid-reply records the partial reply with the response id its content carried."""
    conn = BlockingRealtimeConnection([OutputTranscript(text='One, two, three', response_id='resp_cut')])
    async with RealtimeSession(conn) as session:
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            async for event in session:  # pragma: no branch
                # The reply's first event: close with it in flight.
                assert isinstance(event, PartStartEvent)
                break
    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='One, two, three')],
                timestamp=IsDatetime(),
                provider_response_id='resp_cut',
                state='interrupted',
            )
        ]
    )


async def test_reconnect_while_idle_on_replay_provider_keeps_state_restored() -> None:
    # A local-replay provider (OpenAI/Azure) that drops while Listening loses nothing: the replay
    # restores the finalized call and there is no in-flight turn to settle. The connection's
    # `state_restored=True` stands, so an app is not told a seamless renewal was a disruption.
    conn = FakeRealtimeConnection(
        [
            RealtimeSessionReconnectEvent(state_restored=True),
            OutputTranscript(text='after', is_final=True),
            ResponseDone(),
        ],
        reconnect_restores_in_flight_state=False,
    )
    session = RealtimeSession(conn)
    events = await collect_events(session)
    assert [e.state_restored for e in events if isinstance(e, RealtimeSessionReconnectEvent)] == [True]
    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='after')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            )
        ]
    )


async def test_session_offers_the_conversation_for_replay_when_seeding_is_supported() -> None:
    """The session hands the connection a live view of the call, for a provider that must replay it.

    Only where seeding is the mechanism: a provider that resumes natively (Gemini, xAI) has nothing to
    replay, and one that cannot seed at all has nowhere to put it.
    """

    class _RecordsConversation(FakeRealtimeConnection):
        def __init__(self, events: list[RealtimeCodecEvent]) -> None:
            super().__init__(events)
            self.message_history: Callable[[], Sequence[ModelMessage]] | None = None

        def set_message_history(self, message_history: Callable[[], Sequence[ModelMessage]]) -> None:
            self.message_history = message_history

    seeding = _RecordsConversation([])
    async with RealtimeSession(seeding, profile=_profile(supports_session_seeding=True)) as session:
        await session.send('hello')
    assert seeding.message_history is not None
    # A live view, not a snapshot: the call grows after the connection is handed it.
    assert [type(m).__name__ for m in seeding.message_history()] == ['ModelRequest']

    no_seeding = _RecordsConversation([])
    async with RealtimeSession(no_seeding, profile=_profile(supports_session_seeding=False)):
        pass
    assert no_seeding.message_history is None


async def test_reconnect_while_idle_passes_through() -> None:
    # A lost-state reconnect with nothing in flight has no pre-drop response to finalize: the event
    # passes through and the next turn is recorded normally.
    conn = FakeRealtimeConnection(
        [
            RealtimeSessionReconnectEvent(state_restored=False),
            OutputTranscript(text='after', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn)
    events = await collect_events(session)
    assert any(isinstance(e, RealtimeSessionReconnectEvent) for e in events)
    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='after')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            )
        ]
    )


async def test_queued_message_flushes_when_reconnect_closes_orphaned_turn() -> None:
    """A boundary closing a reply the reconnect orphaned flushes messages queued behind the turn.

    Gemini never continues an in-flight generation on a re-dialed connection, so its connection closes
    the orphaned turn with `ResponseDone(interrupted=True)` ahead of the reconnect event (see
    `test_reconnect_closes_orphaned_turn_with_interrupted_boundary` in `test_google.py`). Without that
    boundary the open speech part keeps the response active forever: a `when_idle` prompt enqueued
    during the reply would never be delivered and the turn would never officially end.
    """
    agent: Agent[None, str] = Agent()

    class _DropsMidReply(FakeRealtimeConnection):
        def __init__(self) -> None:
            super().__init__([])
            self.audio_started = asyncio.Event()
            self.enqueued = asyncio.Event()

        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='tc', tool_name='queue_followup', args='{}')
            while not any(isinstance(item, ToolResult) for item in self.sent):
                await asyncio.sleep(0)
            yield AudioDelta(data=b'audio')  # the reply to the tool result begins...
            self.audio_started.set()
            await self.enqueued.wait()
            # ...then the connection drops mid-reply and reconnects with state restored.
            yield ResponseDone(interrupted=True)
            yield RealtimeSessionReconnectEvent(state_restored=True)

    conn = _DropsMidReply()

    @agent.tool
    async def queue_followup(ctx: RunContext[object]) -> str:
        async def enqueue_during_reply() -> None:
            await conn.audio_started.wait()
            ctx.enqueue('queued for the boundary', priority='when_idle')
            conn.enqueued.set()

        asyncio.create_task(enqueue_during_reply())
        return 'done'

    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        events = await drain_events(session)

    # The orphaned reply is closed as interrupted, the turn ends, and the queued prompt goes out.
    assert any(isinstance(e, RealtimeTurnCompleteEvent) for e in events)
    assert [item for item in conn.sent if isinstance(item, str)] == ['queued for the boundary']
    responses = [m for m in session.all_messages() if isinstance(m, ModelResponse)]
    assert responses[-1].state == 'interrupted'


async def test_reconnect_finalizes_multiple_in_flight_user_items() -> None:
    # Two overlapping user turns (partial transcripts routed by item id), with the second finalizing
    # out of order: `u2` is finalized in `_user_turns` behind the still-open `u1`. A lost-state
    # reconnect must finalize `u1` and then flush both in order, so neither turn is dropped or
    # double-recorded.
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='first turn', is_final=False, item_id='u1'),
            InputTranscript(text='second turn', is_final=False, item_id='u2'),
            InputTranscript(text='second turn', is_final=True, item_id='u2'),
            RealtimeSessionReconnectEvent(state_restored=False),
            OutputTranscript(text='after', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn)
    await collect_events(session)
    assert session.new_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='first turn')], timestamp=IsDatetime()),
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='second turn')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='after')],
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


async def test_reconnect_cancels_obsolete_tool_call() -> None:
    cancelled = asyncio.Event()

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        try:
            await asyncio.Event().wait()
            raise AssertionError('unreachable')  # pragma: no cover - the reconnect cancels this task
        finally:
            cancelled.set()

    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='old-call', tool_name='slow', args='{}'),
            RealtimeSessionReconnectEvent(state_restored=False),
        ]
    )
    session = RealtimeSession(conn, runner)
    _ = await collect_events(session)

    assert cancelled.is_set()
    assert conn.sent == []
    response, request = session.new_messages()
    assert isinstance(response, ModelResponse)
    assert isinstance(request, ModelRequest)
    assert len(request.parts) == 1
    result = request.parts[0]
    assert isinstance(result, ToolReturnPart)
    assert result.tool_name == 'slow'
    assert result.content == 'The tool call was interrupted before a result was produced.'
    assert result.tool_call_id == 'old-call'
    assert result.outcome == 'interrupted'


async def test_audio_retained_with_transcription_enabled_waits_for_transcript() -> None:
    # With transcription enabled, a speech-stopped boundary does NOT emit an audio-only turn: the turn is
    # finalized from the (asynchronously delivered) transcript instead, so there's exactly one user turn —
    # never a duplicate audio-only one racing the transcript.
    conn = FakeRealtimeConnection(
        [RealtimeInputSpeechEndEvent(), InputTranscript(text='hello', is_final=True), ResponseDone()],
        input_transcription_enabled=True,
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m', audio_retention='input_audio')
    await session.send_audio(b'\xaa\xbb')
    _ = await collect_events(session)
    assert session.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[
                    SpeechPart(
                        speaker='user',
                        transcript='hello',
                        audio=_wav_content(b'\xaa\xbb'),
                    )
                ],
                timestamp=IsDatetime(),
            )
        ]
    )


async def test_input_audio_segmented_by_item_id_across_overlapping_turns() -> None:
    # With input audio retained and transcription enabled, each speech-stopped boundary carries the input
    # item id, so its audio is cut into a per-item segment. When two turns overlap and their transcripts
    # finalize out of order (the second turn's `is_final` arrives before the first's), each user message
    # still carries its own audio. Without segmentation the whole rolling buffer would attach to whichever
    # transcript finalized first, giving that turn both turns' audio and the other turn none.
    gate_a = asyncio.Event()
    gate_b = asyncio.Event()

    class _Overlapping(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            await gate_a.wait()
            yield RealtimeInputSpeechEndEvent(item_id='A')  # segments turn A's audio
            await gate_b.wait()
            yield RealtimeInputSpeechEndEvent(item_id='B')  # segments turn B's audio
            yield InputTranscript(text='second', is_final=True, item_id='B')  # B finalizes first...
            yield InputTranscript(text='first', is_final=True, item_id='A')  # ...then A, out of order
            yield ResponseDone()

    conn = _Overlapping([])
    session = RealtimeSession(conn, _noop_runner, audio_retention='input_audio')
    await session.send_audio(b'\xaa')  # turn A's audio, buffered before its boundary fires
    gate_a.set()
    async with session:
        async for event in session:
            # When A's boundary has passed (its segment is captured), queue B's audio and release B's.
            if isinstance(event, RealtimeInputSpeechEndEvent) and event.item_id == 'A':
                await session.send_audio(b'\xbb')
                gate_b.set()

    assert session.new_messages() == snapshot(
        [
            ModelRequest(
                parts=[SpeechPart(speaker='user', transcript='first', audio=_wav_content(b'\xaa'))],
                timestamp=IsDatetime(),
            ),
            ModelRequest(
                parts=[SpeechPart(speaker='user', transcript='second', audio=_wav_content(b'\xbb'))],
                timestamp=IsDatetime(),
            ),
        ]
    )


async def test_retained_input_audio_kept_when_transcription_fails() -> None:
    # A failed transcript must keep the retained audio on its placeholder without leaking it to a later turn.
    conn = FakeRealtimeConnection(
        [
            RealtimeInputSpeechEndEvent(item_id='A'),
            RealtimeInputTranscriptionErrorEvent(message='transcription failed', item_id='A'),
            InputTranscript(text='hi', is_final=True, item_id='B'),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, audio_retention='input_audio')
    await session.send_audio(b'\xaa')
    _ = await collect_events(session)
    assert session.new_messages() == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', audio=_wav_content(b'\xaa'))], timestamp=IsDatetime()),
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='hi')], timestamp=IsDatetime()),
        ]
    )


async def test_no_transcription_and_no_input_retention_records_placeholder_once() -> None:
    conn = FakeRealtimeConnection(
        [RealtimeInputSpeechStartEvent(), RealtimeInputSpeechEndEvent(), ResponseDone()],
        input_transcription_enabled=False,
    )
    session = RealtimeSession(conn, _noop_runner)
    events = await collect_events(session)

    assert [type(event).__name__ for event in events] == snapshot(
        ['RealtimeInputSpeechStartEvent', 'RealtimeInputSpeechEndEvent', 'PartStartEvent', 'PartEndEvent']
    )
    assert session.new_messages() == [ModelRequest(parts=[SpeechPart(speaker='user')], timestamp=IsDatetime())]


async def test_no_transcription_with_input_retention_is_allowed() -> None:
    # Disabling transcription is fine as long as input audio is retained (audio-only user turns).
    conn = FakeRealtimeConnection([], input_transcription_enabled=False)
    RealtimeSession(conn, _noop_runner, audio_retention='input_audio')  # no error


async def test_manual_contentless_user_turn_without_transcription() -> None:
    conn = FakeRealtimeConnection([], input_transcription_enabled=False)
    session = RealtimeSession(conn, _noop_runner)

    await session.send_audio(b'\x00\x01')
    await session.commit_audio()
    events = await collect_events(session)

    assert session.new_messages() == [ModelRequest(parts=[SpeechPart(speaker='user')], timestamp=IsDatetime())]
    assert [type(event).__name__ for event in events] == ['PartStartEvent', 'PartEndEvent']


async def test_text_output_modality_produces_text_part() -> None:
    # A text-output response (`OutputTranscript(output_text=True)`, from `output_modalities=('text',)`) must
    # be emitted and persisted as a `TextPart`, not a `SpeechPart` — it carries no speech.
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='hi', is_final=False, output_text=True),
            OutputTranscript(text='hi there', is_final=True, output_text=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m')
    events = await collect_events(session)
    starts = [e for e in events if isinstance(e, PartStartEvent)]
    assert len(starts) == 1 and isinstance(starts[0].part, TextPart)
    assert any(isinstance(e, PartDeltaEvent) and isinstance(e.delta, TextPartDelta) for e in events)
    ends = [e for e in events if isinstance(e, PartEndEvent)]
    assert len(ends) == 1 and isinstance(ends[0].part, TextPart)
    messages = session.new_messages()
    assert len(messages) == 1
    response = messages[0]
    assert isinstance(response, ModelResponse)
    assert response.parts == [TextPart(content='hi there')]


async def test_empty_assistant_turn_is_recorded() -> None:
    # Audio with no transcript and no retention leaves a content-less assistant placeholder in history.
    conn = FakeRealtimeConnection([AudioDelta(data=b'\x00\x01'), ResponseDone()])
    session = RealtimeSession(conn, _noop_runner, model_name='m')
    events = await collect_events(session)
    assert [type(e).__name__ for e in events] == [
        'PartStartEvent',
        'PartDeltaEvent',
        'PartEndEvent',
        'RealtimeTurnCompleteEvent',
    ]
    end = next(e for e in events if isinstance(e, PartEndEvent))
    assert isinstance(end.part, SpeechPart) and end.part.transcript is None and end.part.audio is None
    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[SpeechPart(speaker='assistant')],
                model_name='m',
                timestamp=IsDatetime(),
                finish_reason='stop',
            )
        ]
    )


async def test_empty_input_transcript_produces_placeholder_request() -> None:
    conn = FakeRealtimeConnection([InputTranscript(text='', is_final=True)])
    session = RealtimeSession(conn, _noop_runner, model_name='m')
    events = await collect_events(session)
    assert [type(e).__name__ for e in events] == ['PartStartEvent', 'PartEndEvent']
    end = next(e for e in events if isinstance(e, PartEndEvent))
    assert isinstance(end.part, SpeechPart) and end.part.transcript is None
    assert session.new_messages() == [ModelRequest(parts=[SpeechPart(speaker='user')], timestamp=IsDatetime())]


async def test_duplicate_final_input_transcript_is_idempotent() -> None:
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='hello', is_final=True, item_id='user-1'),
            InputTranscript(text='hello', is_final=True, item_id='user-1'),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m')
    _ = await collect_events(session)

    assert session.all_messages() == [
        ModelRequest(parts=[SpeechPart(speaker='user', transcript='hello')], timestamp=IsDatetime())
    ]


async def test_transcript_only_default_drops_audio() -> None:
    conn = FakeRealtimeConnection(
        [AudioDelta(data=b'\x00'), OutputTranscript(text='hi', is_final=True), ResponseDone()]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='m')
    _ = await collect_events(session)
    response = session.new_messages()[0]
    assert isinstance(response, ModelResponse)
    assert isinstance(response.parts[0], SpeechPart)
    assert response.parts[0].audio is None


# --- seeding + handoff --------------------------------------------------------------------------


async def test_all_messages_includes_seed_new_messages_excludes_it() -> None:
    seed = [ModelRequest(parts=[UserPromptPart(content='earlier')])]
    conn = FakeRealtimeConnection([OutputTranscript(text='reply', is_final=True), ResponseDone()])
    session = RealtimeSession(conn, _noop_runner, model_name='m', message_history=seed)
    _ = await collect_events(session)
    assert session.all_messages() == snapshot(
        [
            ModelRequest(parts=[UserPromptPart(content='earlier', timestamp=IsDatetime())]),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='reply')],
                model_name='m',
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )
    assert session.new_messages() == snapshot(
        [
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='reply')],
                model_name='m',
                timestamp=IsDatetime(),
                finish_reason='stop',
            )
        ]
    )


async def test_snapshot_is_a_copy() -> None:
    conn = FakeRealtimeConnection([OutputTranscript(text='one', is_final=True), ResponseDone()])
    session = RealtimeSession(conn, _noop_runner, model_name='m')
    _ = await collect_events(session)
    snapshot = session.new_messages()
    assert len(snapshot) == 1
    # `new_messages()` returns an independent copy: mutating the returned list must not leak back into
    # the session's own history.
    snapshot.append(ModelRequest(parts=[UserPromptPart(content='later')]))
    assert len(session.new_messages()) == 1


async def test_handoff_to_standard_agent_run() -> None:
    # A realtime session's history feeds straight into a normal agent run.
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='hello', is_final=True),
            OutputTranscript(text='hi there', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='gpt-realtime')
    _ = await collect_events(session)

    def respond(messages: list[ModelMessage], info: AgentInfo) -> ModelResponse:
        return ModelResponse(parts=[TextPart(content=f'seen {len(messages)} messages')])

    agent = Agent(FunctionModel(respond))
    result = await agent.run('continue', message_history=session.all_messages())
    assert result.output == snapshot('seen 3 messages')
    assert result.all_messages()[:2] == snapshot(
        [
            ModelRequest(parts=[SpeechPart(speaker='user', transcript='hello')], timestamp=IsDatetime()),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='hi there')],
                usage=RequestUsage(cost=Decimal('0.0')),
                model_name='gpt-realtime',
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
        ]
    )


async def test_contentless_speech_parts_are_skipped_for_seeding_and_text_handoff() -> None:
    user = SpeechPart(speaker='user')
    assistant = SpeechPart(speaker='assistant')
    assert seed_speech_content(part=user, provider_name='test', supports_audio=False) == ''
    assert seed_speech_content(part=assistant, provider_name='test', supports_audio=False) == ''

    captured: list[ModelMessage] = []

    def respond(messages: list[ModelMessage], info: AgentInfo) -> ModelResponse:
        captured.extend(messages)
        return ModelResponse(parts=[TextPart(content='ok')])

    history: list[ModelMessage] = [ModelRequest(parts=[user]), ModelResponse(parts=[assistant])]
    result = await Agent(FunctionModel(respond)).run('continue', message_history=history)

    assert result.output == 'ok'
    assert len(captured) == 1
    assert isinstance(captured[0], ModelRequest)
    assert captured[0].parts == [UserPromptPart(content='continue', timestamp=IsDatetime())]


async def test_retained_audio_prepares_for_audio_capable_classic_model() -> None:
    conn = FakeRealtimeConnection([InputTranscript(text='hello', is_final=True)])
    session = RealtimeSession(conn, _noop_runner, audio_retention='input_audio')
    await session.send_audio(b'\xaa\xbb')
    _ = await collect_events(session)

    prepared = TestModel(profile=ModelProfile(supports_audio_input=True)).prepare_messages(session.all_messages())
    request = prepared[0]
    assert isinstance(request, ModelRequest)
    prompt = request.parts[0]
    assert isinstance(prompt, UserPromptPart) and isinstance(prompt.content, list)
    audio = prompt.content[0]
    assert isinstance(audio, BinaryContent)
    assert audio.media_type == 'audio/wav'
    assert audio.format == 'wav'


def _grounding_parts() -> list[NativeToolCallPart | NativeToolReturnPart]:
    """The native tool parts a grounded Gemini turn produces (see `test_google.py` for the mapping)."""
    return [
        NativeToolCallPart(
            tool_name='web_search', args={'queries': ['weather rome']}, tool_call_id='g1', provider_name='google'
        ),
        NativeToolReturnPart(
            tool_name='web_search',
            content=[{'domain': 'example.com', 'title': 'Example', 'uri': 'https://example.com'}],
            tool_call_id='g1',
            provider_name='google',
        ),
    ]


def _native_part_events(
    parts: list[NativeToolCallPart | NativeToolReturnPart], *, first_index: int = 0
) -> list[PartStartEvent | PartEndEvent]:
    """Start/end pairs for native-tool parts, numbered from `first_index`.

    A connection numbers these from its own counter (so the default `0`), while the session remaps
    them onto its session-unique allocator before forwarding — hence the two numberings.
    """
    return [
        event
        for index, part in enumerate(parts, start=first_index)
        for event in (PartStartEvent(index=index, part=part), PartEndEvent(index=index, part=part))
    ]


async def test_native_part_end_without_a_start_gets_an_index_of_its_own() -> None:
    # A `PartEndEvent` the session never saw a start for closes nothing, so it must not inherit the
    # connection's index: that index isn't session-unique and would name a live part — here the
    # assistant's speech part, which also holds index 0.
    part = _grounding_parts()[0]
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='It is sunny in Rome', is_final=True),
            PartEndEvent(index=0, part=part),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='gemini-live-2.5-flash')
    events = await collect_events(session)

    speech_indexes = {event.index for event in events if isinstance(event, PartStartEvent)}
    orphan = next(event for event in events if isinstance(event, PartEndEvent) and event.part == part)
    assert speech_indexes == {0}
    assert orphan.index not in speech_indexes


async def test_grounding_streams_and_folds_native_tool_parts() -> None:
    # Grounding parts stream to the consumer and fold into the assistant response ahead of speech,
    # mirroring the classic `GoogleModel`.
    grounding = _grounding_parts()
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='It is sunny in Rome', is_final=True),
            *_native_part_events(grounding),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='gemini-live-2.5-flash')
    events = await collect_events(session)

    assert events == [
        PartStartEvent(index=0, part=SpeechPart(speaker='assistant', transcript='')),
        PartDeltaEvent(
            index=0,
            delta=SpeechPartDelta(
                speaker='assistant', transcript_delta='It is sunny in Rome', transcript='It is sunny in Rome'
            ),
        ),
        # The connection numbered these `0` and `1` from its own counter, which would have collided
        # with the speech part's index `0` above — a repeated index *replaces* the part at it, so a
        # consumer keyed on the index would have shown the search in place of the model's answer. The
        # session remaps them onto its own allocator, which had already handed `0` to the speech part.
        *_native_part_events(grounding, first_index=1),
        PartEndEvent(index=0, part=SpeechPart(speaker='assistant', transcript='It is sunny in Rome')),
        RealtimeTurnCompleteEvent(),
    ]

    assert session.new_messages() == [
        ModelResponse(
            parts=[*grounding, SpeechPart(speaker='assistant', transcript='It is sunny in Rome')],
            usage=RequestUsage(cost=Decimal('0.0')),
            model_name='gemini-live-2.5-flash',
            timestamp=IsDatetime(),
            finish_reason='stop',
        )
    ]


async def test_grounded_history_hands_off_with_native_parts_intact() -> None:
    # The native tool parts from a grounded voice turn survive the `all_messages()` → `agent.run` handoff:
    # `Model.prepare_messages` passes `NativeToolCallPart`/`NativeToolReturnPart` through untouched (only
    # the `SpeechPart`s are converted to the plain user-prompt / text shapes any model can consume).
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='weather in rome?', is_final=True),
            OutputTranscript(text='It is sunny in Rome', is_final=True),
            *_native_part_events(_grounding_parts()),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='gemini-live-2.5-flash')
    _ = await collect_events(session)

    received: list[ModelMessage] = []

    def respond(messages: list[ModelMessage], info: AgentInfo) -> ModelResponse:
        received.extend(messages)
        return ModelResponse(parts=[TextPart(content='ok')])

    agent = Agent(FunctionModel(respond))
    await agent.run('and now?', message_history=session.all_messages())

    assert received == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='weather in rome?', timestamp=IsDatetime())], timestamp=IsDatetime()
            ),
            ModelResponse(
                parts=[
                    NativeToolCallPart(
                        tool_name='web_search',
                        args={'queries': ['weather rome']},
                        tool_call_id='g1',
                        provider_name='google',
                    ),
                    NativeToolReturnPart(
                        tool_name='web_search',
                        content=[{'domain': 'example.com', 'title': 'Example', 'uri': 'https://example.com'}],
                        tool_call_id='g1',
                        timestamp=IsDatetime(),
                        provider_name='google',
                    ),
                    TextPart(content='It is sunny in Rome'),
                ],
                usage=RequestUsage(cost=Decimal('0.0')),
                model_name='gemini-live-2.5-flash',
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
            ModelRequest(
                parts=[UserPromptPart(content='and now?', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


def _code_execution_parts() -> list[NativeToolCallPart | NativeToolReturnPart]:
    """The native tool parts a code-execution Gemini turn produces (see `test_google.py` for the mapping)."""
    return [
        NativeToolCallPart(
            tool_name='code_execution',
            args={'code': 'print(1 + 1)', 'language': 'PYTHON'},
            tool_call_id='c1',
            provider_name='google',
        ),
        NativeToolReturnPart(
            tool_name='code_execution',
            content={'outcome': 'OUTCOME_OK', 'output': '2\n'},
            tool_call_id='c1',
            provider_name='google',
        ),
    ]


async def test_code_execution_history_hands_off_with_native_parts_intact() -> None:
    # A code-execution voice turn writes the `NativeToolCallPart`/`NativeToolReturnPart` pair into history
    # (ahead of the speech, like the classic `GoogleModel`), and those parts survive the `all_messages()`
    # → `agent.run` handoff untouched by `Model.prepare_messages` — the same path grounding takes.
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='what is 1 + 1?', is_final=True),
            OutputTranscript(text='The answer is 2.', is_final=True),
            *_native_part_events(_code_execution_parts()),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, _noop_runner, model_name='gemini-live-2.5-flash')
    _ = await collect_events(session)

    received: list[ModelMessage] = []

    def respond(messages: list[ModelMessage], info: AgentInfo) -> ModelResponse:
        received.extend(messages)
        return ModelResponse(parts=[TextPart(content='ok')])

    agent = Agent(FunctionModel(respond))
    await agent.run('and 2 + 2?', message_history=session.all_messages())

    assert received == snapshot(
        [
            ModelRequest(
                parts=[UserPromptPart(content='what is 1 + 1?', timestamp=IsDatetime())], timestamp=IsDatetime()
            ),
            ModelResponse(
                parts=[
                    NativeToolCallPart(
                        tool_name='code_execution',
                        args={'code': 'print(1 + 1)', 'language': 'PYTHON'},
                        tool_call_id='c1',
                        provider_name='google',
                    ),
                    NativeToolReturnPart(
                        tool_name='code_execution',
                        content={'outcome': 'OUTCOME_OK', 'output': '2\n'},
                        tool_call_id='c1',
                        timestamp=IsDatetime(),
                        provider_name='google',
                    ),
                    TextPart(content='The answer is 2.'),
                ],
                usage=RequestUsage(cost=Decimal('0.0')),
                model_name='gemini-live-2.5-flash',
                timestamp=IsDatetime(),
                finish_reason='stop',
            ),
            ModelRequest(
                parts=[UserPromptPart(content='and 2 + 2?', timestamp=IsDatetime())],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )


# --- Agent.realtime_session integration --------------------------------------------------------


async def test_agent_realtime_session_wires_tools_and_instructions() -> None:
    agent: Agent[None, str] = Agent(instructions='You are a helpful assistant.')

    @agent.tool_plain
    def greet(name: str) -> str:
        """Greet someone."""
        return f'Hello {name}!'

    conn = FakeRealtimeConnection(
        [ToolCall(tool_call_id='tc_5', tool_name='greet', args='{"name": "Alice"}'), ResponseDone()]
    )
    model = FakeRealtimeModel(conn)

    async with agent.realtime(model).session() as session:
        events = [e async for e in session]

    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert result.part.content == 'Hello Alice!'
    assert model.last_instructions == 'You are a helpful assistant.'
    assert model.last_tools is not None
    assert 'greet' in [t.name for t in model.last_tools]


async def test_agent_realtime_session_seeds_message_history() -> None:
    agent: Agent[None, str] = Agent()
    seed = [
        ModelRequest(parts=[UserPromptPart(content='earlier question')]),
        ModelResponse(parts=[TextPart(content='earlier answer')]),
    ]
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, message_history=seed).session() as session:
        _ = [e async for e in session]
        assert session.all_messages() == seed  # seeded into the session's history
    assert model.last_messages == [
        *seed,
        ModelRequest(parts=[]),
    ]  # provider request view includes the current instruction-bearing request


async def test_agent_realtime_session_rejects_seeding_when_unsupported() -> None:
    # A model that can't seed a session rejects `message_history` up front, before dialing.
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn, profile=_profile(supports_session_seeding=False))
    seed = [ModelRequest(parts=[UserPromptPart(content='earlier question')])]
    with pytest.raises(UserError, match='does not support seeding a session'):
        async with agent.realtime(model, message_history=seed).session():
            pass  # pragma: no cover


async def test_agent_realtime_session_rejects_text_output_when_unsupported() -> None:
    # A model that only speaks rejects `output_modality='text'` up front, before dialing. Unlike a
    # setting the provider merely ignores, this one changes what the caller gets back: Gemini fails the
    # handshake over it and xAI would quietly answer with audio.
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn, profile=_profile(supports_text_output=False))
    with pytest.raises(UserError, match="does not support `output_modality='text'`"):
        async with agent.realtime(model, model_settings=RealtimeModelSettings(output_modality='text')).session():
            pass  # pragma: no cover

    # The same model is fine for the default audio modality, so the guard is scoped to the request.
    async with agent.realtime(model, model_settings=RealtimeModelSettings(output_modality='audio')).session():
        pass


async def test_agent_realtime_session_allows_text_output_by_default() -> None:
    # `supports_text_output` defaults to `True` — a realtime model that can't write is the exception —
    # so a profile that says nothing about it still accepts `output_modality='text'`.
    assert 'supports_text_output' not in _profile_without_text_output()
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn, profile=_profile_without_text_output())
    async with agent.realtime(model, model_settings=RealtimeModelSettings(output_modality='text')).session():
        pass
    assert (model.last_model_settings or {}).get('output_modality') == 'text'


def _profile_without_text_output() -> RealtimeModelProfile:
    """A profile that never mentions `supports_text_output`, to pin the `True` default."""
    return RealtimeModelProfile(supports_session_seeding=True)


async def test_agent_realtime_session_audio_retention_forwarded() -> None:
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection(
        [AudioDelta(data=b'\x07'), OutputTranscript(text='hi', is_final=True), ResponseDone()]
    )
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session(audio_retention='output_audio') as session:
        _ = [e async for e in session]
        response = session.new_messages()[0]
    assert isinstance(response, ModelResponse)
    assert isinstance(response.parts[0], SpeechPart)
    assert response.parts[0].audio == _wav_content(b'\x07')


async def test_agent_realtime_session_audio_retention_budget_forwarded() -> None:
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection(
        [AudioDelta(data=b'\x07\x00'), OutputTranscript(text='hi', is_final=True), ResponseDone()]
    )
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session(audio_retention='output_audio', retain_audio_max_seconds=0) as session:
        _ = [e async for e in session]
    assert [part for message in session.all_messages() for part in message.parts] == [
        SpeechPart(speaker='assistant', transcript='hi')
    ]


async def test_agent_realtime_session_image_retention_forwarded() -> None:
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([])
    model = FakeRealtimeModel(conn)
    images = [BinaryImage(data=bytes([index]), media_type='image/png') for index in range(3)]

    async with agent.realtime(model).session(retain_images_every_n=2) as session:
        for image in images:
            await session.send(image)
        retained = session.new_messages()

    assert retained == [
        ModelRequest(
            parts=[UserPromptPart(content=[images[0]], timestamp=IsDatetime())],
            timestamp=IsDatetime(),
            conversation_id=IsStr(),
            run_id=IsStr(),
        ),
        ModelRequest(
            parts=[UserPromptPart(content=[images[2]], timestamp=IsDatetime())],
            timestamp=IsDatetime(),
            conversation_id=IsStr(),
            run_id=IsStr(),
        ),
    ]


async def test_agent_realtime_session_additional_instructions() -> None:
    agent: Agent[None, str] = Agent(instructions='Default')
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, instructions='Custom').session() as session:
        _ = [e async for e in session]
    # Per-run instructions are their own block, so they're separated from the agent's by a blank
    # line, exactly as in a graph run.
    assert model.last_instructions == 'Default\n\nCustom'


async def test_agent_realtime_session_default_instructions_empty() -> None:
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        _ = [e async for e in session]
    assert model.last_instructions == ''


async def test_agent_realtime_session_ignores_seeded_history_instructions() -> None:
    """Instructions recorded on seeded history never become the session's instructions.

    Regression: with no agent instructions, providers fell back to the last seeded request's
    `instructions`, which client-submitted history can set and `sanitize_messages` keeps.
    """
    agent: Agent[None, str] = Agent()
    seed = [
        ModelRequest(parts=[UserPromptPart(content='earlier question')], instructions='Seeded instructions'),
        ModelResponse(parts=[TextPart(content='earlier answer')]),
    ]
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, message_history=seed).session() as session:
        _ = [e async for e in session]
    assert model.last_instructions == ''


async def test_agent_realtime_session_system_prompt_joins_instructions() -> None:
    """The agent's system prompts open the session instructions, ahead of its instructions, as in a standard run."""
    agent: Agent[None, str] = Agent(system_prompt='Static system prompt.', instructions='Agent instructions.')

    @agent.system_prompt
    def dynamic_prompt() -> str:
        return 'Dynamic system prompt.'

    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        _ = [e async for e in session]
    assert model.last_instructions == snapshot("""\
Static system prompt.

Dynamic system prompt.

Agent instructions.\
""")


async def test_agent_realtime_session_seeded_system_prompt_joins_instructions() -> None:
    """Seeded history's standing system prompt opens the session instructions; its request-level instructions don't.

    As in a standard run, history is taken to carry its own system prompt, so the agent's isn't added.
    """
    agent: Agent[None, str] = Agent(system_prompt='Agent system prompt.', instructions='Agent instructions.')
    seed = [
        ModelRequest(
            parts=[SystemPromptPart(content='Seeded system prompt.'), UserPromptPart(content='earlier question')],
            instructions='Client instructions',
        ),
        ModelResponse(parts=[TextPart(content='earlier answer')]),
    ]
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, message_history=seed).session() as session:
        _ = [e async for e in session]
    assert model.last_instructions == 'Seeded system prompt.\n\nAgent instructions.'


async def test_agent_realtime_session_records_system_prompt_for_handoff() -> None:
    """A fresh session records the agent's system prompt first, as a standard run's first request holds it.

    So `new_messages()` includes it, a text run continuing the conversation sends it once (and doesn't add
    the agent's again), and a session seeded with the history configures it as instructions rather than
    replaying it.
    """
    agent: Agent[None, str] = Agent(system_prompt='Static system prompt.', instructions='Agent instructions.')

    @agent.system_prompt(dynamic=True)
    def dynamic_prompt() -> str:
        return 'Dynamic system prompt.'

    conn = FakeRealtimeConnection(
        [
            RealtimeInputSpeechStartEvent(item_id='u1'),
            RealtimeInputSpeechEndEvent(item_id='u1'),
            InputTranscript(text='question', is_final=True, item_id='u1'),
            OutputTranscript(text='answer', is_final=True),
            ResponseDone(),
        ]
    )
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        _ = [e async for e in session]
    history = session.all_messages()
    assert history == snapshot(
        [
            ModelRequest(
                parts=[
                    SystemPromptPart(content='Static system prompt.', timestamp=IsDatetime()),
                    SystemPromptPart(
                        content='Dynamic system prompt.',
                        timestamp=IsDatetime(),
                        dynamic_ref=dynamic_prompt.__qualname__,
                    ),
                ],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelRequest(
                parts=[SpeechPart(speaker='user', transcript='question')],
                timestamp=IsDatetime(),
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
            ModelResponse(
                parts=[SpeechPart(speaker='assistant', transcript='answer')],
                model_name='fake-realtime',
                timestamp=IsDatetime(),
                provider_name='fake',
                finish_reason='stop',
                run_id=IsStr(),
                conversation_id=IsStr(),
            ),
        ]
    )
    assert session.new_messages() == history
    assert session.result is not None and session.result.new_messages() == history

    sent: list[ModelMessage] = []

    def respond(messages: list[ModelMessage], info: AgentInfo) -> ModelResponse:
        sent.extend(messages)
        return ModelResponse(parts=[TextPart(content='done')])

    await agent.run('next', model=FunctionModel(respond), message_history=history)
    assert [part.content for m in sent for part in m.parts if isinstance(part, SystemPromptPart)] == [
        'Static system prompt.',
        'Dynamic system prompt.',
    ]

    reseeded = FakeRealtimeModel(FakeRealtimeConnection([ResponseDone()]))
    async with agent.realtime(reseeded, message_history=history).session() as session:
        _ = [e async for e in session]
    assert reseeded.last_instructions == snapshot("""\
Static system prompt.

Dynamic system prompt.

Agent instructions.\
""")
    # The seeded system prompt isn't recorded a second time.
    assert [type(m) for m in session.all_messages()] == [type(m) for m in history]


async def test_agent_realtime_session_reevaluates_seeded_dynamic_system_prompt() -> None:
    """As in a standard run, a dynamic system prompt in seeded history is re-run before it is sent."""
    agent: Agent[None, str] = Agent()

    @agent.system_prompt(dynamic=True)
    def dynamic_prompt() -> str:
        return 'Current value.'

    seed = [
        ModelRequest(
            parts=[
                SystemPromptPart(content='Stale value.', dynamic_ref=dynamic_prompt.__qualname__),
                UserPromptPart(content='earlier question'),
            ]
        ),
        ModelResponse(parts=[TextPart(content='earlier answer')]),
    ]
    model = FakeRealtimeModel(FakeRealtimeConnection([ResponseDone()]))
    async with agent.realtime(model, message_history=seed).session() as session:
        _ = [e async for e in session]
    assert model.last_instructions == 'Current value.'
    first = session.all_messages()[0]
    assert isinstance(first, ModelRequest) and isinstance(first.parts[0], SystemPromptPart)
    assert first.parts[0].content == 'Current value.'
    # The caller's history is left as it was.
    stale = seed[0]
    assert isinstance(stale, ModelRequest) and isinstance(stale.parts[0], SystemPromptPart)
    assert stale.parts[0].content == 'Stale value.'


async def test_agent_realtime_session_unknown_tool() -> None:
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc_x', tool_name='nonexistent', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert 'Unknown tool name' in str(result.part.content)
    assert 'nonexistent' in str(result.part.content)


async def test_agent_realtime_session_tool_exception() -> None:
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    def explode() -> str:
        raise ValueError('nope')

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='explode', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        with pytest.raises(ValueError, match='nope'):
            _ = [e async for e in session]
    assert conn.sent == []
    assert [(type(message).__name__, message.parts) for message in session.all_messages()] == snapshot(
        [
            (
                'ModelResponse',
                [ToolCallPart(tool_name='explode', args='{}', tool_call_id='tc')],
            ),
            (
                'ModelRequest',
                [
                    ToolReturnPart(
                        tool_name='explode',
                        content='The tool raised an unhandled error.',
                        tool_call_id='tc',
                        timestamp=IsDatetime(),
                        outcome='failed',
                    )
                ],
            ),
        ]
    )

    def respond(messages: list[ModelMessage], info: AgentInfo) -> ModelResponse:
        return ModelResponse(parts=[TextPart(content='continued')])

    result = await Agent(FunctionModel(respond)).run('continue', message_history=session.all_messages())
    assert result.output == 'continued'


async def test_agent_realtime_session_tool_failed_returns_error_result() -> None:
    """A tool raising `ToolFailed` yields a `failed`, error-key-wrapped result — not a crashed session.

    `tool_manager.handle_call` raises `ToolFailedError` for a `ToolFailed`; the session must answer with
    the failed result (like `run`/`iter`) rather than let it tear down the session. Most realtime providers
    have no native failed-tool flag, so the failure is wrapped in an `{"error": ...}` object on the
    string-only tool channel, and flagged for the ones that do.
    """
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    def boom() -> str:
        raise ToolFailed('service down')

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='boom', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart)
    assert result.part.outcome == 'failed'
    sent = next(s for s in conn.sent if isinstance(s, ToolResult))
    assert '"error"' in sent.output  # wrapped so the model sees the failure over the string-only channel
    assert sent.failed


async def test_agent_realtime_session_validates_and_coerces_args() -> None:
    agent: Agent[None, str] = Agent()
    seen: int | None = None

    @agent.tool_plain
    def double(x: int) -> str:
        nonlocal seen
        seen = x
        return str(x * 2)

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='double', args='{"x": "21"}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]

    assert seen == 21
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert result.part.content == '42'


async def test_agent_realtime_session_invalid_args_return_retry_message() -> None:
    agent: Agent[None, str] = Agent()

    # Never reached; validation fails first.
    @agent.tool_plain
    def double(x: int) -> str:  # pragma: no cover
        return str(x * 2)

    conn = FakeRealtimeConnection(
        [ToolCall(tool_call_id='tc', tool_name='double', args='{"x": "not a number"}'), ResponseDone()]
    )
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]

    call = next(e for e in events if isinstance(e, FunctionToolCallEvent))
    assert call.args_valid is False
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart) and result.part.outcome == 'retried'
    assert 'int_parsing' in result.part.model_response_str()
    assert isinstance(session.new_messages()[1], ModelRequest)
    settled = session.new_messages()[1].parts[0]
    assert isinstance(settled, ToolReturnPart) and settled.outcome == 'retried'


class _ToolRoundConnection(FakeRealtimeConnection):
    """Wait for the first retry result before yielding the next tool-call round."""

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        yield ToolCall(tool_call_id='tc1', tool_name='double', args='{"x": 1}')
        while len(self.sent) < 1:
            await asyncio.sleep(0)
        yield ToolCall(tool_call_id='tc2', tool_name='double', args='{"x": 2}')


class _EnqueueConnection(FakeRealtimeConnection):
    """Hold the turn boundary until the tool result has been sent."""

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        yield ToolCall(
            tool_call_id='tc',
            tool_name='queue_followup',
            args='{}',
            response_usage_follows=True,
        )
        while not any(isinstance(item, ToolResult) for item in self.sent):
            await asyncio.sleep(0)
        # Let the pending-message task observe that response usage is still outstanding. The queued
        # prompt must remain deferred until the usage event finalizes the tool-call response.
        await asyncio.sleep(0)
        yield SessionUsage(usage=RequestUsage(input_tokens=1, output_tokens=1))
        yield ResponseDone()


class _EnqueueDuringSpeechConnection(FakeRealtimeConnection):
    """Enqueue while assistant audio is active and expose whether delivery waits for its boundary."""

    def __init__(self) -> None:
        super().__init__([])
        self.audio_started = asyncio.Event()
        self.enqueued = asyncio.Event()
        self.sent_before_response_complete: list[RealtimeInput] = []

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        yield ToolCall(tool_call_id='tc', tool_name='queue_during_speech', args='{}')
        while not any(isinstance(item, ToolResult) for item in self.sent):
            await asyncio.sleep(0)
        self.audio_started.set()
        yield AudioDelta(data=b'audio')
        await self.enqueued.wait()
        await asyncio.sleep(0)
        self.sent_before_response_complete = list(self.sent)
        yield OutputTranscript(text='still speaking')
        yield ResponseDone()


class _SessionEnqueueDuringSpeechConnection(FakeRealtimeConnection):
    """Expose session-level enqueue and immediate send behavior during assistant speech."""

    def __init__(self) -> None:
        super().__init__([])
        self.audio_started = asyncio.Event()
        self.enqueued = asyncio.Event()
        self.sent_before_response_complete: list[RealtimeInput] = []

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        yield AudioDelta(data=b'audio')
        self.audio_started.set()
        await self.enqueued.wait()
        for _ in range(3):
            await asyncio.sleep(0)
        self.sent_before_response_complete = list(self.sent)
        yield OutputTranscript(text='still speaking')
        yield ResponseDone()


async def test_asap_enqueue_waits_for_active_response_to_complete() -> None:
    """`asap` is provider-agnostic: active assistant output finishes before queued text is sent."""
    agent: Agent[None, str] = Agent()
    conn = _EnqueueDuringSpeechConnection()

    @agent.tool
    async def queue_during_speech(ctx: RunContext[object]) -> str:
        async def enqueue_after_audio_starts() -> None:
            await conn.audio_started.wait()
            ctx.enqueue('follow-up context')
            conn.enqueued.set()

        asyncio.create_task(enqueue_after_audio_starts())
        return 'armed'

    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        _ = [event async for event in session]

    assert not any(isinstance(item, str) for item in conn.sent_before_response_complete)
    assert [item for item in conn.sent if isinstance(item, str)] == ['follow-up context']


async def test_session_enqueue_asap_waits_for_active_response_to_complete() -> None:
    conn = _SessionEnqueueDuringSpeechConnection()
    agent: Agent[None, str] = Agent()
    enqueue_ids: list[str] = []

    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:

        async def send_and_enqueue_during_speech() -> None:
            await conn.audio_started.wait()
            await session.send('sent immediately')
            enqueue_id = session.enqueue('queued for the boundary')
            assert enqueue_id is not None
            enqueue_ids.append(enqueue_id)
            conn.enqueued.set()

        task = asyncio.create_task(send_and_enqueue_during_speech())
        events = [event async for event in session]
        await task

    assert [item for item in conn.sent_before_response_complete if isinstance(item, str)] == ['sent immediately']
    assert [item for item in conn.sent if isinstance(item, str)] == ['sent immediately', 'queued for the boundary']
    request = session.new_messages()[-1]
    assert request == ModelRequest(
        parts=[UserPromptPart(content='queued for the boundary', timestamp=IsDatetime())],
        timestamp=IsDatetime(),
        conversation_id=IsStr(),
        run_id=IsStr(),
    )
    enqueued_events = [event for event in events if isinstance(event, EnqueuedMessagesEvent)]
    assert len(enqueued_events) == 1
    assert enqueued_events[0].enqueue_id == enqueue_ids[0]
    assert enqueued_events[0].messages == (request,)
    assert enqueued_events[0].messages[0] is request
    # Delivered once the response under way ended. (No exchange ends here: the text sent asked for a reply, and
    # this connection never gives one.)
    response_end = next(
        index
        for index, event in enumerate(events)
        if isinstance(event, PartEndEvent) and isinstance(event.part, SpeechPart) and event.part.speaker == 'assistant'
    )
    assert events.index(enqueued_events[0]) > response_end


class _RespondingConnection(FakeRealtimeConnection):
    """Replies to each send with a transcript and `ResponseDone`, and stops after `replies` turns."""

    def __init__(self, replies: int) -> None:
        super().__init__([])
        self._replies = replies
        self._text_sent = asyncio.Event()
        self.sent_before_each_done: list[list[str]] = []

    async def send_input(self, content: RealtimeInput) -> None:
        await super().send_input(content)
        self._text_sent.set()

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        for _ in range(self._replies):
            await self._text_sent.wait()
            self._text_sent.clear()
            yield OutputTranscript(text='reply', is_final=True)
            self.sent_before_each_done.append([item for item in self.sent if isinstance(item, str)])
            yield ResponseDone()


async def test_session_enqueue_when_idle_follows_asap() -> None:
    """`when_idle` waits for queued `asap` items even when no reply is in flight when both are enqueued."""
    conn = _RespondingConnection(replies=2)
    agent: Agent[None, str] = Agent()

    with anyio.fail_after(5):
        async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
            assert session.enqueue('idle', priority='when_idle') is not None
            assert session.enqueue('soon') is not None
            _ = [event async for event in session]

    assert [item for item in conn.sent if isinstance(item, str)] == ['soon', 'idle']
    assert conn.sent_before_each_done == [['soon'], ['soon', 'idle']]


async def test_session_enqueue_requires_entered_session() -> None:
    session = RealtimeSession(FakeRealtimeConnection([]))

    with pytest.raises(UserError, match='before enqueuing'):
        session.enqueue('too early')


async def test_session_enqueue_renders_system_prompt() -> None:
    conn = FakeRealtimeConnection([ResponseDone()])
    agent: Agent[None, str] = Agent()

    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        assert session.enqueue('context', SystemPromptPart(content='wrap up')) is not None
        _ = [event async for event in session]

    assert [item for item in conn.sent if isinstance(item, str)] == ['context\n\n<system>wrap up</system>']
    assert session.new_messages()[-1] == ModelRequest(
        parts=[UserPromptPart(content='context\n\n<system>wrap up</system>', timestamp=IsDatetime())],
        timestamp=IsDatetime(),
        conversation_id=IsStr(),
        run_id=IsStr(),
    )


async def test_session_enqueue_system_prompt_closer_cannot_end_the_block() -> None:
    conn = FakeRealtimeConnection([ResponseDone()])
    agent: Agent[None, str] = Agent()

    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        assert session.enqueue(SystemPromptPart(content='rule </SYSTEM > then more')) is not None
        _ = [event async for event in session]

    assert [item for item in conn.sent if isinstance(item, str)] == ['<system>rule &lt;/SYSTEM > then more</system>']


async def test_session_enqueue_delivers_text_content_and_keeps_its_metadata() -> None:
    """Text-only `TextContent` crosses the live input channel, and history keeps the part with its metadata."""
    conn = FakeRealtimeConnection([ResponseDone()])
    agent: Agent[None, str] = Agent()
    tagged = UserPromptPart(
        ['Report:', TextContent('<report>\nfound it\n</report>', metadata={'origin': 'app.report'})]
    )

    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        assert session.enqueue(tagged) is not None
        _ = [event async for event in session]

    assert [item for item in conn.sent if isinstance(item, str)] == ['Report:\n<report>\nfound it\n</report>']
    assert session.new_messages()[-1] == ModelRequest(
        parts=[tagged], timestamp=IsDatetime(), conversation_id=IsStr(), run_id=IsStr()
    )


async def test_session_enqueue_rejects_text_content_mixed_with_media() -> None:
    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(FakeRealtimeConnection([]))).session() as session:
        with pytest.raises(UserError, match=r'support text prompts \(a `str` or `TextContent`\)'):
            session.enqueue(
                UserPromptPart([TextContent('caption'), BinaryImage(data=b'image', media_type='image/png')])
            )


async def test_session_enqueue_empty_call_is_noop() -> None:
    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(FakeRealtimeConnection([]))).session() as session:
        assert session.enqueue() is None


async def test_session_enqueue_after_close_raises() -> None:
    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(FakeRealtimeConnection([]))).session() as session:
        await session.close()
        with pytest.raises(UserError, match='session is closed'):
            session.enqueue('late')


async def test_session_enqueue_rejects_invalid_content_immediately() -> None:
    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(FakeRealtimeConnection([]))).session() as session:
        with pytest.raises(UserError, match='Enqueued content must end with a `ModelRequest`'):
            session.enqueue(ModelResponse(parts=[TextPart(content='not a request')]))
        with pytest.raises(
            UserError, match=r'support text prompts \(a `str` or `TextContent`\) and system-prompt parts only'
        ):
            session.enqueue(BinaryImage(data=b'image', media_type='image/png'))


@pytest.mark.parametrize(
    'priority',
    ['asap', 'when_idle'],
)
async def test_agent_realtime_session_delivers_enqueued_text(priority: Literal['asap', 'when_idle']) -> None:
    agent: Agent[None, str] = Agent()
    enqueue_ids: list[str] = []

    @agent.tool
    def queue_followup(ctx: RunContext[object]) -> str:
        enqueue_id = ctx.enqueue('follow-up context', priority=priority)
        assert enqueue_id is not None
        enqueue_ids.append(enqueue_id)
        return 'queued'

    conn = _EnqueueConnection([])
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        events = [event async for event in session]

    assert [type(item).__name__ for item in conn.sent] == ['ToolResult', 'str']
    call_response, tool_return, followup = session.new_messages()
    assert isinstance(call_response, ModelResponse) and isinstance(call_response.parts[0], ToolCallPart)
    assert isinstance(tool_return, ModelRequest) and isinstance(tool_return.parts[0], ToolReturnPart)
    assert followup == ModelRequest(
        parts=[UserPromptPart(content='follow-up context', timestamp=IsDatetime())],
        timestamp=IsDatetime(),
        conversation_id=IsStr(),
        run_id=IsStr(),
    )
    enqueued_events = [event for event in events if isinstance(event, EnqueuedMessagesEvent)]
    assert len(enqueued_events) == 1
    assert enqueued_events[0].enqueue_id == enqueue_ids[0]
    assert enqueued_events[0].messages == (followup,)
    assert enqueued_events[0].messages[0] is followup


class _ConcurrentEnqueueConnection(FakeRealtimeConnection):
    """Block the first pending-message send while a second sync tool appends to the queue."""

    def __init__(self) -> None:
        super().__init__([])
        self.first_send_started = ThreadEvent()
        self.second_enqueued = ThreadEvent()

    async def send_input(self, content: RealtimeInput) -> None:
        self.sent.append(content)
        if content == 'first':
            self.first_send_started.set()
            while not self.second_enqueued.is_set():
                await asyncio.sleep(0)

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        yield ToolCall(tool_call_id='tc-1', tool_name='queue_concurrently', args='{"text": "first"}')
        yield ToolCall(tool_call_id='tc-2', tool_name='queue_concurrently', args='{"text": "second"}')
        while sum(isinstance(item, ToolResult) for item in self.sent) < 2:
            await asyncio.sleep(0)
        yield ResponseDone()


async def test_sync_tool_enqueue_during_drain_is_not_lost() -> None:
    agent: Agent[None, str] = Agent()
    conn = _ConcurrentEnqueueConnection()

    @agent.tool
    def queue_concurrently(ctx: RunContext[object], text: str) -> str:
        if text == 'second':
            assert conn.first_send_started.wait(timeout=5)
        assert ctx.enqueue(text) is not None
        if text == 'second':
            conn.second_enqueued.set()
        return text

    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        _ = [event async for event in session]

    assert [item for item in conn.sent if isinstance(item, str)] == ['first', 'second']
    prompts = [
        part.content
        for message in session.new_messages()
        if isinstance(message, ModelRequest)
        for part in message.parts
        if isinstance(part, UserPromptPart)
    ]
    assert prompts == ['first', 'second']


async def test_agent_realtime_session_rejects_non_text_enqueue() -> None:
    agent: Agent[object, str] = Agent()

    @agent.tool
    def queue_image(ctx: RunContext[object]) -> str:
        ctx.enqueue(BinaryImage(data=b'image', media_type='image/png'))
        return 'unreachable'  # pragma: no cover

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='queue_image', args='{}')])
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        with pytest.raises(
            UserError, match=r'support text prompts \(a `str` or `TextContent`\) and system-prompt parts only'
        ):
            _ = [event async for event in session]


@pytest.mark.parametrize(
    'messages',
    [
        [ModelResponse(parts=[TextPart(content='not a request')])],
        [ModelRequest(parts=[UserPromptPart(content=[BinaryImage(data=b'x', media_type='image/png')])])],
        [ModelRequest(parts=[])],
    ],
)
async def test_realtime_pending_messages_reject_unsupported_message_shapes(messages: list[ModelMessage]) -> None:
    session = RealtimeSession(FakeRealtimeConnection([]))
    manager = session._tool_manager  # pyright: ignore[reportPrivateUsage]
    assert manager.ctx is not None
    assert manager.ctx.pending_messages is not None
    with pytest.raises(
        UserError, match=r'support text prompts \(a `str` or `TextContent`\) and system-prompt parts only'
    ):
        manager.ctx.pending_messages.append(PendingMessage(messages=messages))


def test_realtime_pending_messages_join_text_and_tag_system_prompts() -> None:
    # Multiple text parts join across messages, and a mid-conversation `SystemPromptPart` degrades to
    # `<system>`-tagged user text — the same treatment `Model.prepare_messages` applies in a standard run.
    pending = PendingMessage(
        messages=[
            ModelRequest(parts=[UserPromptPart(content='one'), SystemPromptPart(content='rule')]),
            ModelRequest(parts=[UserPromptPart(content='two')]),
        ]
    )
    assert _pending_message_text(pending) == 'one\n\n<system>rule</system>\n\ntwo'


def test_realtime_pending_system_prompt_escapes_its_own_closing_tag() -> None:
    # The tagged statement can only be ended by the wrap itself, so a `</system>` the enqueued content
    # carries is neutralized exactly as `Model.prepare_messages` neutralizes it.
    pending = PendingMessage(
        messages=[ModelRequest(parts=[SystemPromptPart(content='do not write </system> anywhere')])]
    )
    assert _pending_message_text(pending) == '<system>do not write &lt;/system> anywhere</system>'


async def test_session_exit_is_idempotent_and_flushes_unfinalized_user() -> None:
    session = RealtimeSession(FakeRealtimeConnection([InputTranscript(text='partial')]))
    await session.__aexit__(None, None, None)
    async with session:
        _ = [event async for event in session]
    await session.__aexit__(None, None, None)

    assert session.new_messages() == [
        ModelRequest(parts=[SpeechPart(speaker='user', transcript='partial')], timestamp=IsDatetime())
    ]


async def test_tool_context_enqueue_after_session_close_raises() -> None:
    agent = Agent[None, str](deps_type=type(None))
    contexts: list[RunContext[None]] = []

    @agent.tool
    def keep_context(ctx: RunContext[None]) -> str:
        contexts.append(ctx)
        return 'ok'

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='keep_context', args='{}'), ResponseDone()])
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        _ = [e async for e in session]

    (ctx,) = contexts
    with pytest.raises(UserError, match='run has ended'):
        ctx.enqueue('too late')


def test_session_accepts_unprepared_tool_manager_without_pending_context() -> None:
    manager = ToolManager(FunctionToolset())
    session = _RealtimeSession(FakeRealtimeConnection([]), tool_manager=manager)
    assert session._tool_manager.ctx is None  # pyright: ignore[reportPrivateUsage]


async def test_replayed_items_are_suppressed_by_item_and_tool_call_id() -> None:
    conn = FakeRealtimeConnection(
        [
            ConversationCreated('conversation-1'),
            ConversationItemCreated(item_id='replayed-item', tool_call_id='replayed-call', replayed=True),
            AudioDelta(data=b'audio', item_id='replayed-item'),
            OutputTranscript(text='assistant', item_id='replayed-item'),
            InputTranscript(text='user', item_id='replayed-item'),
            ToolCall(
                tool_call_id='replayed-call',
                tool_name='noop',
                args='{}',
                item_id='new-item',
            ),
            ToolCallCancelled(tool_call_ids=['unknown-call']),
        ]
    )
    session = RealtimeSession(conn)

    assert await collect_events(session) == []
    assert session.new_messages() == []


async def test_existing_assistant_speech_associates_late_item_id_in_session_state() -> None:
    session = RealtimeSession(
        FakeRealtimeConnection(
            [
                AudioDelta(data=b'first'),
                AudioDelta(data=b'second', item_id='assistant-item'),
                OutputTranscript(text='spoken', item_id='assistant-item'),
                ResponseDone(),
            ]
        ),
        provider_name='openai',
    )
    _ = await collect_events(session)

    response = session.new_messages()[0]
    assert isinstance(response, ModelResponse)
    part = response.parts[0]
    assert isinstance(part, SpeechPart)
    assert part.id is None
    assert len(response.parts) == 1


async def test_empty_finalized_user_precedes_later_item() -> None:
    session = RealtimeSession(
        FakeRealtimeConnection(
            [
                InputTranscript(text='', is_final=True, item_id='empty'),
                InputTranscript(text='kept', is_final=True, item_id='kept'),
            ]
        )
    )
    _ = await collect_events(session)

    assert session.new_messages() == [
        ModelRequest(parts=[SpeechPart(speaker='user')], timestamp=IsDatetime()),
        ModelRequest(parts=[SpeechPart(speaker='user', transcript='kept')], timestamp=IsDatetime()),
    ]


def test_asap_notifications_without_live_loop_and_after_close_are_ignored() -> None:
    session = RealtimeSession(FakeRealtimeConnection([]))
    session._notify_pending_messages('asap')  # pyright: ignore[reportPrivateUsage]
    session._closed = True  # pyright: ignore[reportPrivateUsage]
    session._start_pending_message_drain('asap')  # pyright: ignore[reportPrivateUsage]


async def test_failed_asap_drain_is_forwarded_to_session_iterator() -> None:
    class _FailingSend(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            raise RuntimeError('send failed')

    session = RealtimeSession(_FailingSend([]))
    manager = session._tool_manager  # pyright: ignore[reportPrivateUsage]
    assert manager.ctx is not None
    assert manager.ctx.pending_messages is not None
    async with session:
        manager.ctx.pending_messages.append(
            PendingMessage(messages=[ModelRequest(parts=[UserPromptPart(content='queued')])], priority='asap')
        )
        with pytest.raises(RuntimeError, match='send failed'):
            _ = [event async for event in session]


async def test_tool_completion_drains_messages_deferred_until_usage_arrives(monkeypatch: pytest.MonkeyPatch) -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn)
    session._asap_drain_deferred = True  # pyright: ignore[reportPrivateUsage]
    session._pending_messages.append(  # pyright: ignore[reportPrivateUsage]
        PendingMessage(
            messages=[ModelRequest(parts=[UserPromptPart(content='after tool')])],
            priority='asap',
        )
    )
    validation_done = asyncio.Event()

    async def complete_after_usage(
        call_part: ToolCallPart,
        *,
        validation_done: asyncio.Event,
        execution_prerequisites: tuple[asyncio.Event, ...],
        response_usage_follows: bool,
        response_continues: bool,
        run_step: int,
        reserved_budget: bool,
    ) -> tuple[ToolReturnPart, None]:
        del validation_done, execution_prerequisites, response_usage_follows, response_continues
        del run_step, reserved_budget
        return ToolReturnPart(tool_name=call_part.tool_name, content='done', tool_call_id=call_part.tool_call_id), None

    monkeypatch.setattr(session, '_execute_tool', complete_after_usage)
    completion = asyncio.Event()
    await session._run_tool(  # pyright: ignore[reportPrivateUsage]
        ToolCallPart(tool_name='noop', args={}, tool_call_id='call'),
        validation_done=validation_done,
        execution_prerequisites=(),
        completion=completion,
        response_usage_follows=True,
        response_continues=False,
        run_step=0,
        reserved_budget=True,
        order_index=0,
        ordered_events=False,
    )

    assert 'after tool' in conn.sent


@pytest.mark.parametrize('consumer', ['iterating', 'taps_only'])
async def test_deferred_asap_drain_failure_after_tool_is_forwarded(
    monkeypatch: pytest.MonkeyPatch, consumer: Literal['iterating', 'taps_only']
) -> None:
    # The post-`finally` deferred `asap` drain in `_run_tool` runs OUTSIDE its try/except. If its
    # `connection.send` fails (e.g. the socket just dropped), `_tool_task_done` must forward the error to
    # the consumer — mirroring `_pending_message_task_done` — instead of letting it vanish as an
    # unretrieved-task-exception warning at GC, silently losing the enqueued follow-up.
    class _FailingDrain(BlockingRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            if isinstance(content, str):
                raise RuntimeError('drain send failed')
            # This test only drives the drain's text-turn send.
            await super().send_input(content)  # pragma: no cover

    conn = _FailingDrain([])
    session = RealtimeSession(conn)
    await session.__aenter__()
    event_task = asyncio.create_task(drain_events(session)) if consumer == 'iterating' else None
    transcripts = session.stream_transcripts()
    await asyncio.sleep(0)
    session._asap_drain_deferred = True  # pyright: ignore[reportPrivateUsage]
    session._pending_messages.append(  # pyright: ignore[reportPrivateUsage]
        PendingMessage(messages=[ModelRequest(parts=[UserPromptPart(content='after tool')])], priority='asap')
    )

    async def complete_after_usage(
        call_part: ToolCallPart,
        *,
        validation_done: asyncio.Event,
        execution_prerequisites: tuple[asyncio.Event, ...],
        response_usage_follows: bool,
        response_continues: bool,
        run_step: int,
        reserved_budget: bool,
    ) -> tuple[ToolReturnPart, None]:
        del validation_done, execution_prerequisites, response_usage_follows, response_continues
        del run_step, reserved_budget
        return ToolReturnPart(tool_name=call_part.tool_name, content='done', tool_call_id=call_part.tool_call_id), None

    monkeypatch.setattr(session, '_execute_tool', complete_after_usage)

    task = asyncio.create_task(
        session._run_tool(  # pyright: ignore[reportPrivateUsage]
            ToolCallPart(tool_name='noop', args={}, tool_call_id='call'),
            validation_done=asyncio.Event(),
            execution_prerequisites=(),
            completion=asyncio.Event(),
            response_usage_follows=True,
            response_continues=False,
            run_step=0,
            reserved_budget=True,
            order_index=0,
            ordered_events=False,
        )
    )
    task.add_done_callback(session._tool_task_done)  # pyright: ignore[reportPrivateUsage]
    await asyncio.gather(task, return_exceptions=True)
    await asyncio.sleep(0)  # let the done-callback run

    if event_task is not None:
        with pytest.raises(RuntimeError, match='drain send failed'):
            await event_task
        await session.close()
    else:
        assert await asyncio.wait_for(_collect(transcripts), timeout=_LIVENESS_TIMEOUT) == []
        with pytest.raises(RuntimeError, match='drain send failed'):
            await session.close()
    await session.close()


async def test_tool_call_limit_stops_pump_before_later_events() -> None:
    async def runner(*args: Any) -> str:
        return 'ok'

    session = RealtimeSession(
        FakeRealtimeConnection(
            [
                ToolCall(tool_call_id='first', tool_name='noop', args='{}'),
                ToolCall(tool_call_id='second', tool_name='noop', args='{}'),
                ResponseDone(),
            ]
        ),
        runner=runner,
        usage_limits=UsageLimits(tool_calls_limit=1),
    )

    async with session:
        with pytest.raises(UsageLimitExceeded, match='tool_calls_limit'):
            _ = [event async for event in session]
    assert session.usage.tool_calls == 1


async def test_close_settles_in_flight_state_into_history() -> None:
    # A session closed mid-turn settles what it still holds open, exactly as a reconnect settles
    # state the provider lost: the partial reply lands in history as interrupted and the running tool
    # call gets a cancelled return, so `all_messages()` hands off a valid history instead of dropping
    # the tail or ending on a dangling `ToolCallPart`.
    async def runner(*args: Any) -> str:
        await asyncio.Event().wait()  # never completes; cancelled at session close
        return 'unreachable'  # pragma: no cover

    session = RealtimeSession(
        FakeRealtimeConnection(
            [
                OutputTranscript(text='one moment', is_final=False),
                ToolCall(tool_call_id='tc1', tool_name='slow', args='{}'),
            ]
        ),
        runner=runner,
    )
    async with session:
        async for event in session:
            if isinstance(event, FunctionToolCallEvent):
                break

    messages = session.all_messages()
    response = messages[0]
    assert isinstance(response, ModelResponse)
    assert [type(part).__name__ for part in response.parts] == ['SpeechPart', 'ToolCallPart']
    cancelled = messages[1]
    assert isinstance(cancelled, ModelRequest)
    cancelled_part = cancelled.parts[0]
    assert isinstance(cancelled_part, ToolReturnPart)
    assert cancelled_part.tool_call_id == 'tc1'
    assert cancelled_part.outcome == 'interrupted'


async def test_close_settles_partial_reply_as_interrupted() -> None:
    # A reply still streaming when the session closes lands in history as an interrupted response,
    # instead of the buffered transcript silently vanishing from `all_messages()`.
    session = RealtimeSession(FakeRealtimeConnection([OutputTranscript(text='one moment', is_final=False)]))
    async with session:
        async for event in session:
            if isinstance(event, PartDeltaEvent):
                break

    messages = session.all_messages()
    assert len(messages) == 1
    response = messages[0]
    assert isinstance(response, ModelResponse)
    assert response.state == 'interrupted'
    speech = response.parts[0]
    assert isinstance(speech, SpeechPart) and speech.transcript == 'one moment'


async def test_tool_call_limit_counts_in_flight_calls() -> None:
    # `ToolManager` records a call on `usage.tool_calls` only once it *succeeds*, so with a slow tool
    # a burst of parallel calls would each compare against the same pre-burst count and all clear a
    # limit only one of them fits under. The projection must count calls still in flight.
    started = asyncio.Event()

    async def runner(*args: Any) -> str:
        started.set()
        await asyncio.Event().wait()  # never completes; cancelled at session close
        return 'unreachable'  # pragma: no cover

    session = RealtimeSession(
        FakeRealtimeConnection(
            [
                ToolCall(tool_call_id='first', tool_name='slow', args='{}'),
                ToolCall(tool_call_id='second', tool_name='slow', args='{}'),
                ResponseDone(),
            ]
        ),
        runner=runner,
        usage_limits=UsageLimits(tool_calls_limit=1),
    )

    async with session:
        with pytest.raises(UsageLimitExceeded, match='tool_calls_limit'):
            _ = [event async for event in session]
    assert started.is_set()  # the first call was running — and unrecorded — when the second was checked
    assert session.usage.tool_calls == 0


async def test_iterator_reuses_receive_pump_started_by_session_owner() -> None:
    session = RealtimeSession(FakeRealtimeConnection([OutputTranscript(text='Hi.', is_final=True), ResponseDone()]))
    async with session:
        assert [event async for event in session][-1] == RealtimeTurnCompleteEvent()


async def test_receive_pump_stops_when_event_handler_trips_limit(monkeypatch: pytest.MonkeyPatch) -> None:
    session = RealtimeSession(FakeRealtimeConnection([ResponseDone(), ResponseDone()]))
    handled = 0

    async def stop_after_first(event: RealtimeCodecEvent) -> bool:
        nonlocal handled
        handled += 1
        return True

    monkeypatch.setattr(session, '_handle_pump_event', stop_after_first)
    await session._pump(None)  # pyright: ignore[reportPrivateUsage]

    assert handled == 1


async def test_tool_manager_reports_validation_failure_when_retry_budget_is_exhausted(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manager = make_tool_manager()
    outcomes: list[bool] = []

    async def exhausted(*args: Any, **kwargs: Any) -> Any:
        raise UnexpectedModelBehavior('retry budget exhausted')

    async def record_validation(valid: bool) -> None:
        outcomes.append(valid)

    monkeypatch.setattr(manager, 'validate_tool_call', exhausted)
    with pytest.raises(UnexpectedModelBehavior, match='retry budget exhausted'):
        await manager.handle_call(
            ToolCallPart(tool_name='noop', args={}, tool_call_id='call'),
            on_validate=record_validation,
        )
    assert outcomes == [False]


async def test_agent_realtime_session_retry_limit_advances_across_tool_rounds() -> None:
    agent: Agent[None, str] = Agent(retries=1)

    @agent.tool_plain
    def double(x: int) -> str:
        raise ModelRetry(f'{x} is not allowed')

    conn = _ToolRoundConnection([])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events: list[RealtimeEvent] = []
        with pytest.raises(UnexpectedModelBehavior, match="Tool 'double' exceeded max retries count of 1"):
            async for event in session:
                events.append(event)

    results = [e.part for e in events if isinstance(e, FunctionToolResultEvent)]
    assert len(results) == 1
    retried = results[0]
    assert isinstance(retried, ToolReturnPart) and retried.outcome == 'retried'
    assert str(retried.content).startswith('1 is not allowed')
    assert conn.sent == [ToolResult(tool_call_id='tc1', output=retried.model_response_str(), failed=True)]


async def test_agent_realtime_session_runs_args_validator() -> None:
    agent: Agent[None, str] = Agent()

    def guard(ctx: RunContext[Any], city: str) -> None:
        raise ModelRetry('not allowed')

    # Never reached; the validator rejects first.
    @agent.tool_plain(args_validator=guard)
    def weather(city: str) -> str:  # pragma: no cover
        return f'sunny in {city}'

    conn = FakeRealtimeConnection(
        [ToolCall(tool_call_id='tc', tool_name='weather', args='{"city": "forbidden"}'), ResponseDone()]
    )
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]

    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert 'not allowed' in str(result.part.content)


@pytest.mark.parametrize(
    ('follow_up_content', 'expected_wire_content'),
    [
        ('extra context', ['extra context']),
        (
            ['extra context', BinaryContent(data=b'image', media_type='image/png')],
            ['extra context', BinaryContent(data=b'image', media_type='image/png')],
        ),
    ],
)
async def test_agent_realtime_session_tool_return_is_unwrapped(
    follow_up_content: str | list[str | BinaryContent], expected_wire_content: list[str | BinaryContent]
) -> None:
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    def info() -> ToolReturn:
        return ToolReturn(
            return_value={'value': 42},
            content=follow_up_content,
            metadata={'source': 'tool'},
        )

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='info', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]

    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart)
    assert result.part.content == {'value': 42}
    assert result.part.metadata == {'source': 'tool'}
    assert result.content == follow_up_content
    assert conn.sent == [
        ToolResult(
            tool_call_id='tc',
            output='{"value":42}',
            content=expected_wire_content,
        )
    ]
    request = next(message for message in session.new_messages() if isinstance(message, ModelRequest))
    assert request.parts == [
        result.part,
        UserPromptPart(content=follow_up_content, timestamp=IsDatetime()),
    ]


async def test_agent_realtime_session_denied_tool_returns_denial_message() -> None:
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    def danger() -> str:
        raise ApprovalRequired()

    def deny(ctx: RunContext[Any], requests: DeferredToolRequests) -> DeferredToolResults:
        return DeferredToolResults(approvals={call.tool_call_id: False for call in requests.approvals})

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='danger', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, capabilities=[HandleDeferredToolCalls(handler=deny)]).session() as session:
        events = [e async for e in session]

    lifecycle = [event for event in events if isinstance(event, (DeferredToolRequestsEvent, DeferredToolResultsEvent))]
    assert lifecycle == [
        DeferredToolRequestsEvent(
            DeferredToolRequests(approvals=[ToolCallPart(tool_name='danger', args='{}', tool_call_id='tc')])
        ),
        DeferredToolResultsEvent(DeferredToolResults(approvals={'tc': False})),
    ]
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart)
    assert result.part.outcome == 'denied'
    assert 'denied' in str(result.part.content).lower()


async def test_agent_realtime_session_deferred_call_answered_with_a_legacy_retry_prompt() -> None:
    """A handler can still answer a deferred call with a `RetryPromptPart` of its own.

    It settles the way the `ModelRetry` beside it in `DeferredToolResults` does: the retry answers
    this call, so the session records and sends the call's own retried result — the feedback alone,
    without the `'Fix the errors and try again.'` tail the old rendering appended.
    """
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    def buy(fruit: str) -> str:
        raise CallDeferred

    def out_of_stock(ctx: RunContext[Any], requests: DeferredToolRequests) -> DeferredToolResults:
        return DeferredToolResults(
            calls={
                call.tool_call_id: legacy_retry_prompt_part(content='pears are out of stock') for call in requests.calls
            }
        )

    conn = FakeRealtimeConnection(
        [ToolCall(tool_call_id='tc', tool_name='buy', args='{"fruit": "pear"}'), ResponseDone()]
    )
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, capabilities=[HandleDeferredToolCalls(handler=out_of_stock)]).session() as session:
        events = [e async for e in session]

    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert (result.part.tool_name, result.part.outcome) == ('buy', 'retried')
    assert conn.sent == snapshot(
        [ToolResult(tool_call_id='tc', output='{"error":"pears are out of stock"}', failed=True)]
    )


# --- declarative `requires_approval=True` gating ------------------------------------------------
#
# A tool can be deferred *declaratively* (`requires_approval=True` → `ToolDefinition.kind='unapproved'`)
# as well as by raising `ApprovalRequired`. The graph pipeline classifies by kind before executing
# anything; the session's `handle_call` path used to execute first and react to what was raised, so a
# `requires_approval=True` tool ran with approval silently skipped and no handler ever consulted. The
# four tests below pin the whole matrix, and each asserts *whether the body ran* — the thing that
# actually matters when the gate is approval.


def _approval_agent() -> tuple[Agent[None, str], list[str]]:
    """An agent whose only tool is declaratively approval-gated, plus an execution log."""
    executed: list[str] = []
    agent: Agent[None, str] = Agent()

    @agent.tool_plain(requires_approval=True)
    def transfer_funds() -> str:
        executed.append('ran')
        return 'transferred'

    return agent, executed


async def test_standard_run_pauses_on_a_declaratively_approval_gated_tool() -> None:
    # The reference behavior the session has to match: the run ends with the call awaiting approval,
    # and the body never runs.
    agent, executed = _approval_agent()

    def call_tool(messages: list[ModelMessage], info: AgentInfo) -> ModelResponse:
        return ModelResponse(parts=[ToolCallPart('transfer_funds', {}, tool_call_id='tc')])

    result = await agent.run('go', model=FunctionModel(call_tool), output_type=[str, DeferredToolRequests])
    assert isinstance(result.output, DeferredToolRequests)
    assert [call.tool_name for call in result.output.approvals] == ['transfer_funds']
    assert executed == []


async def test_realtime_session_does_not_execute_an_approval_gated_tool_without_a_handler() -> None:
    # No handler to resolve the approval: the session answers the model with the documented
    # explanation and — the point of the gate — never runs the tool.
    agent, executed = _approval_agent()

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='transfer_funds', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]

    assert executed == []
    # As in a run, the request is announced before (here: in place of) a handler resolving it, and no
    # results follow a request nothing resolved.
    lifecycle = [event for event in events if isinstance(event, (DeferredToolRequestsEvent, DeferredToolResultsEvent))]
    assert lifecycle == [
        DeferredToolRequestsEvent(
            DeferredToolRequests(approvals=[ToolCallPart(tool_name='transfer_funds', args='{}', tool_call_id='tc')])
        )
    ]
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart)
    assert 'requires approval' in str(result.part.content)
    assert 'cannot be completed during a realtime session' in str(result.part.content)
    # A refused approval is recorded as a failure, so a handoff to `Agent.run` can't read it as a
    # tool that ran and returned an error-shaped string.
    assert result.part.outcome == 'failed'


async def test_realtime_session_denies_an_approval_gated_tool_through_a_handler() -> None:
    # A `HandleDeferredToolCalls` handler that denies is now actually consulted, and the denial is
    # recorded as such rather than as a successful return.
    agent, executed = _approval_agent()

    def deny(ctx: RunContext[Any], requests: DeferredToolRequests) -> DeferredToolResults:
        return DeferredToolResults(approvals={call.tool_call_id: False for call in requests.approvals})

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='transfer_funds', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, capabilities=[HandleDeferredToolCalls(handler=deny)]).session() as session:
        events = [e async for e in session]

    assert executed == []
    lifecycle = [event for event in events if isinstance(event, DeferredToolRequestsEvent)]
    assert lifecycle == [
        DeferredToolRequestsEvent(
            DeferredToolRequests(approvals=[ToolCallPart(tool_name='transfer_funds', args='{}', tool_call_id='tc')])
        )
    ]
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart)
    assert result.part.outcome == 'denied'


async def test_realtime_session_executes_an_approval_gated_tool_once_approved() -> None:
    # Approval granted inline: the tool runs and its real return reaches the model, so the gate
    # blocks rather than breaks the tool.
    agent, executed = _approval_agent()

    def approve(ctx: RunContext[Any], requests: DeferredToolRequests) -> DeferredToolResults:
        return DeferredToolResults(approvals={call.tool_call_id: True for call in requests.approvals})

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='transfer_funds', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, capabilities=[HandleDeferredToolCalls(handler=approve)]).session() as session:
        events = [e async for e in session]

    assert executed == ['ran']
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart)
    assert result.part.content == 'transferred'
    assert result.part.outcome == 'success'


async def test_realtime_session_announces_a_deferred_call_before_its_handler_resolves_it() -> None:
    """`DeferredToolRequestsEvent` reaches the consumer while the handler is still deciding.

    A unit test because it pins event ordering against a handler that waits on the consumer, which a
    recording can't: a handler awaiting a person's answer only works if the consumer can see the
    request to ask them. As in a run, the requests come before the handler and the results after it.
    """
    agent, executed = _approval_agent()
    answer: asyncio.Future[bool] = asyncio.get_running_loop().create_future()

    async def ask_a_person(ctx: RunContext[Any], requests: DeferredToolRequests) -> DeferredToolResults:
        return DeferredToolResults(approvals={call.tool_call_id: await answer for call in requests.approvals})

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='transfer_funds', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    events: list[RealtimeEvent] = []
    with anyio.fail_after(5):
        async with agent.realtime(
            model, capabilities=[HandleDeferredToolCalls(handler=ask_a_person)]
        ).session() as session:
            async for event in session:
                events.append(event)
                if isinstance(event, DeferredToolRequestsEvent):
                    assert executed == []
                    answer.set_result(True)

    assert executed == ['ran']
    tool_events = [
        event
        for event in events
        if isinstance(
            event, (FunctionToolCallEvent, DeferredToolRequestsEvent, DeferredToolResultsEvent, FunctionToolResultEvent)
        )
    ]
    assert [type(event) for event in tool_events] == [
        FunctionToolCallEvent,
        DeferredToolRequestsEvent,
        DeferredToolResultsEvent,
        FunctionToolResultEvent,
    ]
    result = tool_events[-1]
    assert isinstance(result, FunctionToolResultEvent)
    assert isinstance(result.part, ToolReturnPart)
    assert result.part.content == 'transferred'


async def test_deferred_call_does_not_consume_the_tool_call_limit() -> None:
    # A `requires_approval=True` call with no handler is refused and never reaches the tool body, so it
    # never increments `usage.tool_calls`. The graph leaves such calls out of its pre-check projection
    # entirely (`function_indices` is built from `('function', 'unknown')`), so charging the budget for
    # one here would trip the limit over a call that costs nothing.
    agent, executed = _approval_agent()

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='transfer_funds', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    # A budget of zero: any charge at all would raise `UsageLimitExceeded`.
    async with agent.realtime(model, usage_limits=UsageLimits(tool_calls_limit=0)).session() as session:
        events = [e async for e in session]

    assert executed == []
    assert session.usage.tool_calls == 0
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart)
    assert 'requires approval' in str(result.part.content)


async def test_executed_call_still_consumes_the_tool_call_limit() -> None:
    # The other side of the same branch: an ordinary tool is charged exactly as before, so skipping the
    # reservation for deferred calls didn't quietly stop enforcing the limit.
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    def ordinary() -> str:  # pragma: no cover — the limit trips before the body runs
        return 'ran'

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='ordinary', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    events: list[RealtimeEvent] = []
    with pytest.raises(UsageLimitExceeded):
        async with agent.realtime(model, usage_limits=UsageLimits(tool_calls_limit=0)).session() as session:
            async for event in session:
                # Nothing streams ahead of the refused call.
                events.append(event)  # pragma: no cover

    # Refused before anything of it streams. (The response that made it ended in the same frame, so it is
    # recorded, and the call gets the interrupted return a call that never ran gets.)
    assert events == []


async def test_tools_from_one_response_share_a_run_step() -> None:
    # Pins the graph's invariant: every call from one response runs at the step in effect when that
    # response produced it, the way a graph batch shares the step advanced before its request.
    #
    # This passes against the previous code too — reading `self._tool_run_step` inside `_execute_tool`
    # happened to be safe, because `on_validate` sets `validation_done` *before* awaiting the barrier
    # and the pump blocks on it, pinning every manager sync ahead of the next upstream event. The
    # capture makes the invariant the code's own rather than a consequence of that interleaving, and
    # this test is what would catch it if either side of that subtle arrangement moved.
    seen_steps: list[int] = []
    agent: Agent[None, str] = Agent(deps_type=type(None))

    @agent.tool(sequential=True)
    def barrier(ctx: RunContext[None]) -> str:
        seen_steps.append(ctx.run_step)
        return 'first'

    @agent.tool
    def follower(ctx: RunContext[None]) -> str:
        seen_steps.append(ctx.run_step)
        return 'second'

    # The OpenAI shape: both calls belong to one response whose usage — and so whose finalization,
    # which advances the step — arrives after them. The follower is held behind the barrier until
    # after that advance, which is exactly when reading the step late would diverge.
    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='tc1', tool_name='barrier', args='{}', response_usage_follows=True),
            ToolCall(tool_call_id='tc2', tool_name='follower', args='{}', response_usage_follows=True),
            SessionUsage(usage=RequestUsage(input_tokens=10, output_tokens=5)),
            ResponseDone(),
        ]
    )
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        _ = [e async for e in session]

    assert len(seen_steps) == 2
    assert seen_steps[0] == seen_steps[1]


def _ordered_events_agent() -> Agent[None, str]:
    """Two tools where the *second* call finishes first, so completion order != call order."""
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    async def slow() -> str:
        await asyncio.sleep(0.05)
        return 'slow'

    @agent.tool_plain
    async def quick() -> str:
        return 'quick'

    return agent


async def test_parallel_ordered_events_emits_results_in_call_order() -> None:
    # `parallel_ordered_events` promises parallel execution with events in call order. The session used
    # to read the mode only to spot `'sequential'`, so this fell through to plain parallel and results
    # streamed in completion order — the setting silently did nothing.
    agent = _ordered_events_agent()
    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='tc1', tool_name='slow', args='{}'),
            ToolCall(tool_call_id='tc2', tool_name='quick', args='{}'),
            ResponseDone(),
        ]
    )
    model = FakeRealtimeModel(conn)
    with ToolManager.parallel_execution_mode('parallel_ordered_events'):
        async with agent.realtime(model).session() as session:
            events = [e async for e in session]

    results = [e.part.tool_name for e in events if isinstance(e, FunctionToolResultEvent)]
    assert results == ['slow', 'quick']
    # Execution stays concurrent — the provider still gets each result as it lands, so the fast tool's
    # `ToolResult` goes out first even though its event is held back.
    sent = [s.tool_call_id for s in conn.sent if isinstance(s, ToolResult)]
    assert sent == ['tc2', 'tc1']


async def test_parallel_default_still_emits_results_in_completion_order() -> None:
    # The other side of the branch: the default mode is unchanged, so the ordering buffer only engages
    # where it was asked for.
    agent = _ordered_events_agent()
    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='tc1', tool_name='slow', args='{}'),
            ToolCall(tool_call_id='tc2', tool_name='quick', args='{}'),
            ResponseDone(),
        ]
    )
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]

    results = [e.part.tool_name for e in events if isinstance(e, FunctionToolResultEvent)]
    assert results == ['quick', 'slow']


async def test_parallel_ordered_events_are_not_stranded_by_a_failing_sibling() -> None:
    # The buffer is released from the tool task's done-callback, which runs even when the tool raised,
    # so a sibling that produces no events can't leave the batch waiting forever.
    agent: Agent[None, str] = Agent()
    fine_finished = asyncio.Event()

    @agent.tool_plain
    async def boom() -> str:
        # Fail only once the sibling has fully run: `fine`'s buffered events are then waiting on this
        # first-in-order call to settle, which is exactly the state a hung release would strand.
        await fine_finished.wait()
        raise RuntimeError('tool exploded')

    @agent.tool_plain
    async def fine() -> str:
        fine_finished.set()
        return 'fine'

    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='tc1', tool_name='boom', args='{}'),
            ToolCall(tool_call_id='tc2', tool_name='fine', args='{}'),
            ResponseDone(),
        ]
    )
    model = FakeRealtimeModel(conn)
    with ToolManager.parallel_execution_mode('parallel_ordered_events'):
        with pytest.raises(RuntimeError, match='tool exploded'):
            async with agent.realtime(model).session() as session:
                _ = [e async for e in session]


async def test_tool_can_cancel_realtime_session() -> None:
    """A fake connection makes the absence of a provider-bound tool result directly assertable."""
    agent = Agent[None, str](deps_type=type(None))

    @agent.tool
    def cancel(ctx: RunContext[None]) -> str:
        ctx.cancel()
        return 'must be discarded'

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='cancel', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)

    session: _RealtimeSession | None = None
    with pytest.raises(RunCancelled) as exc_info:
        async with agent.realtime(model).session() as session:
            _ = [e async for e in session]

    assert session is not None
    assert session.closed
    parts = [part for message in exc_info.value.all_messages() for part in message.parts]
    assert any(isinstance(part, ToolCallPart) for part in parts)
    assert any(isinstance(part, ToolReturnPart) and part.outcome == 'interrupted' for part in parts)
    assert not any(isinstance(item, ToolResult) for item in conn.sent)


@pytest.fixture
async def loop_errors() -> AsyncIterator[list[dict[str, Any]]]:
    loop = asyncio.get_running_loop()
    previous_handler = loop.get_exception_handler()
    errors: list[dict[str, Any]] = []
    loop.set_exception_handler(lambda _loop, context: errors.append(context))
    try:
        yield errors
    finally:
        loop.set_exception_handler(previous_handler)


def _hang_up_agent() -> tuple[Agent[None, str], dict[str, asyncio.Task[None] | None]]:
    agent = Agent[None, str](deps_type=type(None))
    state: dict[str, asyncio.Task[None] | None] = {'task': None}

    @agent.tool
    async def hang_up(ctx: RunContext[None]) -> None:
        assert ctx.realtime_session is not None
        state['task'] = asyncio.current_task()
        await ctx.realtime_session.close()

    return agent, state


def _tool_returns(session: _RealtimeSession) -> list[tuple[str, str, str | None]]:
    return [
        (part.tool_call_id, str(part.content), part.outcome)
        for message in session.all_messages()
        if isinstance(message, ModelRequest)
        for part in message.parts
        if isinstance(part, ToolReturnPart)
    ]


async def test_tool_can_close_realtime_session(loop_errors: list[dict[str, Any]]) -> None:
    agent, state = _hang_up_agent()
    conn = IdleAfterToolConnection(ToolCall(tool_call_id='tc', tool_name='hang_up', args='{}'))

    with anyio.fail_after(5):
        async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
            _ = [event async for event in session]

    task = state['task']
    assert session.closed
    assert session.result is not None
    # The teardown task ran to completion before the session context exited.
    assert session._loop is None  # pyright: ignore[reportPrivateUsage]
    assert task is not None and task.done() and task.cancelled()
    assert conn.iteration_task is not None and conn.iteration_task.done()
    assert not any(isinstance(item, ToolResult) for item in conn.sent)
    assert _tool_returns(session) == [
        ('tc', 'The tool call was interrupted before a result was produced.', 'interrupted')
    ]
    assert loop_errors == []


async def test_tool_can_close_realtime_session_without_iterating(loop_errors: list[dict[str, Any]]) -> None:
    agent, state = _hang_up_agent()
    conn = IdleAfterToolConnection(ToolCall(tool_call_id='tc', tool_name='hang_up', args='{}'))

    with anyio.fail_after(5):
        async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
            async for _chunk in session.stream_audio():
                pass
        for _ in range(5):
            await asyncio.sleep(0)

    task = state['task']
    assert session.closed
    assert session._loop is None  # pyright: ignore[reportPrivateUsage]
    assert task is not None and task.done() and task.cancelled()
    assert not any(isinstance(item, ToolResult) for item in conn.sent)
    assert _tool_returns(session) == [
        ('tc', 'The tool call was interrupted before a result was produced.', 'interrupted')
    ]
    assert loop_errors == []


@pytest.mark.parametrize('consumer', ['iterating', 'taps_only'])
async def test_tool_close_ends_async_audio_sender_cleanly(
    loop_errors: list[dict[str, Any]], consumer: Literal['iterating', 'taps_only']
) -> None:
    """A microphone task owned by the app does not fail when a tool hangs up."""
    agent = Agent[None, str](deps_type=type(None))
    microphone_started = asyncio.Event()

    @agent.tool
    async def hang_up(ctx: RunContext[None]) -> None:
        assert ctx.realtime_session is not None
        await microphone_started.wait()
        await ctx.realtime_session.close()

    async def microphone() -> AsyncIterator[bytes]:
        microphone_started.set()
        while True:
            yield b'\x00\x00'
            await asyncio.sleep(0)

    conn = IdleAfterToolConnection(ToolCall(tool_call_id='tc', tool_name='hang_up', args='{}'))
    with anyio.fail_after(5):
        async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
            microphone_task = asyncio.create_task(session.send_audio(microphone()))
            if consumer == 'iterating':
                _ = [event async for event in session]
            else:
                assert [chunk async for chunk in session.stream_audio()] == []
            await microphone_task

    assert session.result is not None
    assert loop_errors == []


async def test_single_audio_chunk_still_fails_after_close() -> None:
    session = RealtimeSession(FakeRealtimeConnection([]))
    async with session:
        pass
    with pytest.raises(UserError, match='session is closed'):
        await session.send_audio(b'\x00\x00')


async def test_tool_that_swallows_the_cancel_after_closing_records_one_return(
    loop_errors: list[dict[str, Any]],
) -> None:
    agent = Agent[None, str](deps_type=type(None))

    @agent.tool
    async def hang_up(ctx: RunContext[None]) -> str:
        assert ctx.realtime_session is not None
        try:
            await ctx.realtime_session.close()
        except asyncio.CancelledError:
            pass
        return 'must not be recorded'

    conn = IdleAfterToolConnection(ToolCall(tool_call_id='tc', tool_name='hang_up', args='{}'))
    with anyio.fail_after(5):
        async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
            _ = [event async for event in session]

    assert session.closed
    assert not any(isinstance(item, ToolResult) for item in conn.sent)
    assert _tool_returns(session) == [
        ('tc', 'The tool call was interrupted before a result was produced.', 'interrupted')
    ]
    assert loop_errors == []


async def test_tool_closing_realtime_session_drains_sibling_tools(loop_errors: list[dict[str, Any]]) -> None:
    agent = Agent[None, str](deps_type=type(None))
    sibling_started = asyncio.Event()
    sibling_cancelled = asyncio.Event()
    closing_task: asyncio.Task[None] | None = None

    @agent.tool_plain
    async def slow() -> str:
        sibling_started.set()
        try:
            return await asyncio.get_running_loop().create_future()
        except asyncio.CancelledError:
            sibling_cancelled.set()
            raise

    @agent.tool
    async def hang_up(ctx: RunContext[None]) -> None:
        nonlocal closing_task
        assert ctx.realtime_session is not None
        closing_task = asyncio.current_task()
        await sibling_started.wait()
        await ctx.realtime_session.close()

    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='c1', tool_name='slow', args='{}'),
            ToolCall(tool_call_id='c2', tool_name='hang_up', args='{}'),
        ]
    )
    with anyio.fail_after(5):
        async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
            _ = [event async for event in session]

    assert session.closed
    assert session._loop is None  # pyright: ignore[reportPrivateUsage]
    assert sibling_cancelled.is_set()
    assert closing_task is not None and closing_task.done() and closing_task.cancelled()
    assert not any(isinstance(item, ToolResult) for item in conn.sent)
    assert _tool_returns(session) == [
        ('c1', 'The tool call was interrupted before a result was produced.', 'interrupted'),
        ('c2', 'The tool call was interrupted before a result was produced.', 'interrupted'),
    ]
    assert loop_errors == []


async def test_realtime_cancellation_does_not_wait_for_sync_tool_worker() -> None:
    """A unit test because a recording cannot observe whether the local worker thread outlives the session."""
    worker_started = ThreadEvent()
    worker_release = ThreadEvent()
    worker_finished = ThreadEvent()
    agent = Agent[None, str](deps_type=type(None))

    @agent.tool
    def cancel_and_block(ctx: RunContext[None]) -> str:
        ctx.cancel()
        worker_started.set()
        worker_release.wait()
        worker_finished.set()
        return 'must be discarded'

    conn = FakeRealtimeConnection(
        [ToolCall(tool_call_id='tc', tool_name='cancel_and_block', args='{}'), ResponseDone()]
    )

    async def consume() -> None:
        async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
            _ = [event async for event in session]

    task = asyncio.create_task(consume())
    await asyncio.to_thread(worker_started.wait)
    try:
        with pytest.raises(RunCancelled):
            await asyncio.wait_for(asyncio.shield(task), timeout=5)
        assert not worker_finished.is_set()
        assert not any(isinstance(item, ToolResult) for item in conn.sent)
    finally:
        worker_release.set()
        assert await asyncio.to_thread(worker_finished.wait, 5)
        await asyncio.gather(task, return_exceptions=True)


async def test_nested_run_cancellation_is_isolated_into_a_failed_tool_return() -> None:
    # A sub-agent run awaited inside a tool that cancels *itself* must not take the session with it.
    # The graph isolates exactly this into a failed tool return (#7199); the session's own cancellation
    # arrives as `CancelledError`, so a `RunCancelled` seen in a tool body is always a nested run's.
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    def delegate() -> str:
        raise RunCancelled('the sub-agent run was cancelled')

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='delegate', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]

    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart)
    assert result.part.outcome == 'failed'
    assert 'sub-agent run was cancelled' in str(result.part.content)
    # The session drained normally rather than re-raising, and the failed return is in history for the
    # model to react to — the conversation survives the sub-agent's decision.
    assert result.part in session.all_messages()[-1].parts


async def test_realtime_session_explains_a_declaratively_external_tool() -> None:
    # `kind='external'` diverged the same way, differently: `execute_tool_call` refuses outright with
    # `RuntimeError('External tools cannot be called')`, which would have escaped the session as an
    # internal error. Classified with the same helper, it now takes the `CallDeferred` path and gets
    # the documented explanation instead.
    agent: Agent[None, str] = Agent(
        toolsets=[ExternalToolset(tool_defs=[ToolDefinition(name='lookup', kind='external')])]
    )

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='lookup', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]

    assert not any(isinstance(e, RealtimeSessionErrorEvent) for e in events)
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert isinstance(result.part, ToolReturnPart)
    assert 'runs externally' in str(result.part.content)
    assert 'cannot be completed during a realtime session' in str(result.part.content)


async def test_agent_realtime_session_resolves_per_run_toolsets() -> None:
    agent: Agent[str, str] = Agent(deps_type=str)

    @agent.toolset
    def per_run(ctx: RunContext[str]) -> FunctionToolset[str]:
        assert ctx.deps == 'alice'  # the factory sees the run deps
        ts: FunctionToolset[str] = FunctionToolset()

        @ts.tool
        def whoami(tool_ctx: RunContext[str]) -> str:
            return f'deps={tool_ctx.deps}'

        return ts

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='whoami', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, deps='alice').session() as session:
        events = [e async for e in session]

    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert result.part.content == 'deps=alice'


async def test_agent_realtime_session_model_visible_to_tools() -> None:
    agent: Agent[None, str] = Agent()
    seen_name: str | None = None

    @agent.tool
    async def inspect_model(ctx: RunContext) -> str:
        nonlocal seen_name
        seen_name = ctx.model.model_name
        return f'system={ctx.model.system}'

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='inspect_model', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]

    assert seen_name == 'fake-realtime'
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert result.part.content == 'system=fake'


async def test_agent_realtime_session_uses_realtime_model_when_text_model_set() -> None:
    agent: Agent[None, str] = Agent('test')
    seen_system: str | None = None

    @agent.tool
    async def inspect_model(ctx: RunContext) -> str:
        nonlocal seen_system
        seen_system = ctx.model.system
        return 'ok'

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='tc', tool_name='inspect_model', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        _ = [e async for e in session]
    assert seen_system == 'fake'


async def test_agent_realtime_session_concurrent_tools_end_to_end() -> None:
    agent: Agent[None, str] = Agent()
    release = asyncio.Event()

    @agent.tool_plain
    async def slow_lookup() -> str:
        await release.wait()
        return 'background result'

    conn = FakeRealtimeConnection(
        [ToolCall(tool_call_id='bg', tool_name='slow_lookup', args='{}'), ResponseDone()],
        release=release,
    )
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        events = [e async for e in session]

    assert [type(e).__name__ for e in events] == snapshot(
        [
            'PartStartEvent',
            'PartEndEvent',
            'FunctionToolCallEvent',
            'FunctionToolResultEvent',
        ]
    )
    result = events[-1]
    assert isinstance(result, FunctionToolResultEvent)
    assert result.part.content == 'background result'


async def test_agent_realtime_session_forwards_model_settings() -> None:
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    settings = RealtimeModelSettings(max_tokens=50)
    async with agent.realtime(model, model_settings=settings).session() as session:
        _ = [e async for e in session]
    assert model.last_model_settings == settings


async def test_agent_realtime_session_merges_model_and_call_settings() -> None:
    """Call-time realtime settings override the model defaults key by key."""
    agent: Agent[None, str] = Agent(model_settings=ModelSettings(temperature=0.1, max_tokens=100))
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn, settings=RealtimeModelSettings(max_tokens=100, parallel_tool_calls=False))
    async with agent.realtime(
        model, model_settings=RealtimeModelSettings(parallel_tool_calls=True)
    ).session() as session:
        _ = [e async for e in session]
    assert model.last_model_settings == RealtimeModelSettings(max_tokens=100, parallel_tool_calls=True)


async def test_agent_realtime_session_ignores_regular_model_settings_override() -> None:
    """`Agent.override(model_settings=...)` does not affect realtime settings."""
    agent: Agent[None, str] = Agent(model_settings=ModelSettings(temperature=0.1))
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    with agent.override(model_settings=ModelSettings(temperature=0.9)):
        async with agent.realtime(model, model_settings=RealtimeModelSettings(max_tokens=50)).session() as session:
            _ = [e async for e in session]
    assert model.last_model_settings == RealtimeModelSettings(max_tokens=50)


async def test_agent_realtime_session_send_audio() -> None:
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        await session.send_audio(b'\xab\xcd')
    assert conn.sent == [BinaryAudio(data=b'\xab\xcd', media_type='audio/pcm')]


# --- parity with run/iter: instructions, toolsets, usage, usage_limits, capabilities, metadata ---


async def test_agent_realtime_session_dynamic_instructions() -> None:
    agent: Agent[None, str] = Agent(instructions='Base')

    @agent.instructions
    def extra() -> str:
        return 'Dynamic'

    @agent.instructions
    def skipped() -> str | None:
        return None  # a dynamic instruction returning None contributes nothing

    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        _ = [e async for e in session]
    # Static literal then dynamic function, double-newline separated — same as `run`/`iter`.
    assert model.last_instructions == 'Base\n\nDynamic'


async def test_agent_realtime_session_append_instructions_warn() -> None:
    agent: Agent[None, str] = Agent(instructions='Base')

    @agent.instructions(name='state', on_change='append')
    def state() -> str:
        return 'Current state'

    model = FakeRealtimeModel(FakeRealtimeConnection([ResponseDone()]))
    with pytest.warns(
        UserWarning, match="realtime sessions, so instruction blocks 'agent:state' are sent as session instructions"
    ):
        async with agent.realtime(model).session() as session:
            _ = [event async for event in session]
    assert model.last_instructions == 'Base\n\nCurrent state'


async def test_agent_realtime_session_sorts_static_instructions_before_dynamic() -> None:
    """A static toolset `InstructionPart` sorts before dynamic agent instructions, like `run`/`iter`.

    Regression: the session joined instruction parts in assembly order, so a toolset's static
    instruction landed after dynamic agent instruction functions instead of in the cacheable
    static prefix that classic runs build via `InstructionPart.sorted`.
    """

    class StaticInstructionsToolset(FunctionToolset[object]):
        async def get_instructions(self, ctx: RunContext[object]) -> list[InstructionPart]:
            return [InstructionPart(content='Static toolset', dynamic=False)]

    agent: Agent[None, str] = Agent(instructions='Base')

    @agent.instructions
    def extra() -> str:
        return 'Dynamic'

    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, toolsets=[StaticInstructionsToolset()]).session() as session:
        _ = [e async for e in session]
    assert model.last_instructions == 'Base\n\nStatic toolset\n\nDynamic'


async def test_agent_realtime_session_dynamic_instructions_see_message_history() -> None:
    """A dynamic instruction function sees `message_history` via `ctx.messages`, like `run`/`iter`.

    Regression: `realtime_session` used to leave `RunContext.messages` empty, so a dynamic instruction
    (or a capability `for_run` hook) that read `ctx.messages` saw `[]` even when the caller passed a
    `message_history`.
    """
    agent: Agent[None, str] = Agent()

    @agent.instructions
    def prior_count(ctx: RunContext) -> str:
        return f'{len(ctx.messages)} prior messages'

    seed = [
        ModelRequest(parts=[UserPromptPart(content='earlier question')]),
        ModelResponse(parts=[TextPart(content='earlier answer')]),
    ]
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, message_history=seed).session() as session:
        _ = [e async for e in session]
    assert model.last_instructions == '2 prior messages'


async def test_agent_realtime_session_additional_toolsets() -> None:
    agent: Agent[None, str] = Agent()
    extra_toolset: FunctionToolset[object] = FunctionToolset()

    @extra_toolset.tool_plain
    def extra_tool() -> str:
        return 'x'

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='t1', tool_name='extra_tool', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, toolsets=[extra_toolset]).session() as session:
        events = [e async for e in session]
    assert 'extra_tool' in [t.name for t in model.last_tools or []]
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert result.part.content == 'x'  # the extra toolset's tool is offered AND callable


async def test_agent_realtime_session_external_usage_accumulates() -> None:
    usage = RunUsage()
    conn = FakeRealtimeConnection([SessionUsage(usage=RequestUsage(input_tokens=7, output_tokens=3)), ResponseDone()])
    model = FakeRealtimeModel(conn)
    agent: Agent[None, str] = Agent()
    async with agent.realtime(model, usage=usage).session() as session:
        assert session.usage is usage  # the provided accumulator is used
        _ = [e async for e in session]
    assert usage.input_tokens == 7
    assert usage.output_tokens == 3


async def test_agent_realtime_session_prices_response_usage() -> None:
    usage = RequestUsage(
        input_tokens=1000,
        output_tokens=500,
        input_audio_tokens=800,
        output_audio_tokens=400,
    )
    conn = FakeRealtimeConnection(
        [OutputTranscript(text='priced response', is_final=True), SessionUsage(usage=usage), ResponseDone()]
    )
    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(conn, model_name='gpt-realtime', system='openai')).session() as session:
        _ = [event async for event in session]

    response = next(message for message in session.new_messages() if isinstance(message, ModelResponse))
    assert isinstance(response.usage.cost, Decimal) and response.usage.cost > 0
    assert session.usage.cost == response.usage.cost
    # The response tokens were already accumulated from `SessionUsage`; pricing must not add them again.
    assert session.usage.input_tokens == 1000
    assert session.usage.output_tokens == 500
    assert session.usage.input_audio_tokens == 800
    assert session.usage.output_audio_tokens == 400


async def test_agent_realtime_session_unpriced_response_keeps_cost_unknown() -> None:
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='unpriced response', is_final=True),
            SessionUsage(usage=RequestUsage(input_tokens=10, output_tokens=5)),
            ResponseDone(),
        ]
    )
    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(conn, model_name='unpriced-realtime-model')).session() as session:
        _ = [event async for event in session]

    response = next(message for message in session.new_messages() if isinstance(message, ModelResponse))
    assert response.usage.cost is None
    assert session.usage.cost is None


async def test_run_level_usage_is_not_attributed_to_or_finalize_response() -> None:
    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'done'

    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='first response', is_final=True),
            ToolCall(tool_call_id='pending', tool_name='noop', args='{}', response_usage_follows=True),
            SessionUsage(usage=RequestUsage(details={'input_transcription_seconds': 3}), response_scoped=False),
            OutputTranscript(text='second response', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, runner)

    _ = await collect_events(session)

    assert session.usage.details == {'input_transcription_seconds': 3}
    responses = [message for message in session.new_messages() if isinstance(message, ModelResponse)]
    assert len(responses) == 1
    assert responses[0].usage.details == {}


async def test_agent_realtime_session_token_limit_raises() -> None:
    conn = FakeRealtimeConnection(
        [SessionUsage(usage=RequestUsage(input_tokens=100, output_tokens=100)), ResponseDone()]
    )
    model = FakeRealtimeModel(conn)
    agent: Agent[None, str] = Agent()
    async with agent.realtime(model, usage_limits=UsageLimits(total_tokens_limit=50)).session() as session:
        with pytest.raises(UsageLimitExceeded, match='total_tokens_limit of 50'):
            _ = [e async for e in session]
    # The usage report the session stopped reading at counts toward the session; the response it was for never
    # started, so there's none in history.
    assert session.usage.input_tokens == 100 and session.usage.output_tokens == 100
    assert not any(isinstance(message, ModelResponse) for message in session.new_messages())


async def test_agent_realtime_session_cost_limit_raises_on_usage() -> None:
    conn = FakeRealtimeConnection([SessionUsage(usage=RequestUsage(cost=Decimal('0.51'))), ResponseDone()])
    agent: Agent[None, str] = Agent()
    async with agent.realtime(
        FakeRealtimeModel(conn), usage_limits=UsageLimits(cost_limit=Decimal('0.50'))
    ).session() as session:
        with pytest.raises(UsageLimitExceeded, match=r'`cost_limit` of 0.50'):
            _ = [e async for e in session]


async def test_agent_realtime_session_priced_cost_limit_raises_at_response_boundary() -> None:
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='over budget', is_final=True),
            SessionUsage(usage=RequestUsage(input_tokens=1000, output_tokens=500)),
            ResponseDone(),
        ]
    )
    agent: Agent[None, str] = Agent()
    async with agent.realtime(
        FakeRealtimeModel(conn, model_name='gpt-realtime', system='openai'),
        usage_limits=UsageLimits(cost_limit=Decimal('0.0001')),
    ).session() as session:
        with pytest.raises(UsageLimitExceeded, match=r'Exceeded the `cost_limit` of 0.0001'):
            _ = [event async for event in session]

    response = next(message for message in session.new_messages() if isinstance(message, ModelResponse))
    assert response.state == 'complete'
    assert response.usage.input_tokens == 1000
    assert response.usage.output_tokens == 500
    assert response.usage.cost == session.usage.cost


async def test_agent_realtime_session_priced_cost_limit_raises_with_only_transcript_view() -> None:
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='over budget', is_final=True),
            SessionUsage(usage=RequestUsage(input_tokens=1000, output_tokens=500)),
            ResponseDone(),
        ]
    )
    agent: Agent[None, str] = Agent()
    with pytest.raises(UsageLimitExceeded, match=r'Exceeded the `cost_limit` of 0.0001'):
        async with agent.realtime(
            FakeRealtimeModel(conn, model_name='gpt-realtime', system='openai'),
            usage_limits=UsageLimits(cost_limit=Decimal('0.0001')),
        ).session() as session:
            _ = [part async for part in session.stream_transcripts()]
            # The view ended because the limit tripped, after the response was finalized and priced;
            # the error itself is raised when the block exits.
            response = next(message for message in session.new_messages() if isinstance(message, ModelResponse))
            assert response.state == 'complete'
            assert response.usage.cost == session.usage.cost


async def test_when_idle_enqueue_after_pump_finishes_is_delivered() -> None:
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn)
    async with session:
        assert await drain_events(session) == []
        session._pending_messages.append(  # pyright: ignore[reportPrivateUsage]
            PendingMessage(
                messages=[ModelRequest(parts=[UserPromptPart(content='late idle message')])],
                priority='when_idle',
            )
        )
        for _ in range(10):  # pragma: no branch - the queued drain lands within a few loop passes
            if conn.sent:
                break
            await asyncio.sleep(0)

    assert conn.sent == ['late idle message']


async def test_agent_realtime_session_per_request_input_token_limit_raises() -> None:
    conn = FakeRealtimeConnection(
        [SessionUsage(usage=RequestUsage(input_tokens=51), response_scoped=True), ResponseDone()]
    )
    agent: Agent[None, str] = Agent()
    async with agent.realtime(
        FakeRealtimeModel(conn), usage_limits=UsageLimits(per_request_input_tokens_limit=50)
    ).session() as session:
        with pytest.raises(UsageLimitExceeded, match='per_request_input_tokens_limit of 50'):
            _ = [e async for e in session]


async def test_agent_realtime_session_per_request_input_token_limit_covers_a_tool_call_response() -> None:
    """OpenAI reports a tool-call response's usage right before `response.done`, which finalizes the
    response immediately; the per-request check must see that usage rather than the reset accumulator."""
    conn = FakeRealtimeConnection(
        [
            ToolCall(tool_call_id='tc1', tool_name='noop', args='{}', response_usage_follows=True),
            SessionUsage(usage=RequestUsage(input_tokens=51), response_scoped=True),
            ResponseDone(),
        ]
    )
    agent: Agent[None, str] = Agent()
    async with agent.realtime(
        FakeRealtimeModel(conn), usage_limits=UsageLimits(per_request_input_tokens_limit=50)
    ).session() as session:
        with pytest.raises(UsageLimitExceeded, match='per_request_input_tokens_limit of 50'):
            _ = [e async for e in session]


async def test_agent_realtime_session_request_limit_raises() -> None:
    conn = FakeRealtimeConnection(
        [
            SessionUsage(usage=RequestUsage(input_tokens=1, output_tokens=1)),
            OutputTranscript(text='first', is_final=True),
            ResponseDone(),
            SessionUsage(usage=RequestUsage(input_tokens=1, output_tokens=1)),
            OutputTranscript(text='second', is_final=True),
            ResponseDone(),
        ]
    )
    model = FakeRealtimeModel(conn)
    agent: Agent[None, str] = Agent()
    async with agent.realtime(model, usage_limits=UsageLimits(request_limit=1)).session() as session:
        events: list[RealtimeEvent] = []
        with pytest.raises(UsageLimitExceeded, match='next request would exceed the request_limit of 1'):
            async for event in session:
                events.append(event)
    assert sum(isinstance(event, RealtimeTurnCompleteEvent) for event in events) == 1
    assert session.usage.requests == 1


async def test_agent_realtime_session_request_limit_blocks_explicit_send() -> None:
    conn = FakeRealtimeConnection([])
    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(conn), usage_limits=UsageLimits(request_limit=0)).session() as session:
        with pytest.raises(UsageLimitExceeded, match='next request would exceed the request_limit of 0'):
            await session.send('hello')

    assert conn.sent == []


async def test_agent_realtime_session_request_limit_blocks_create_response() -> None:
    conn = FakeRealtimeConnection([])
    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(conn), usage_limits=UsageLimits(request_limit=0)).session() as session:
        with pytest.raises(UsageLimitExceeded, match='next request would exceed the request_limit of 0'):
            await session.create_response()

    assert conn.sent == []


async def test_concurrent_sends_cannot_both_take_the_last_request() -> None:
    """Each send is checked against `request_limit` as it goes out, counting what the sends ahead of it asked for."""
    conn = SlowSendConnection([])
    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(conn), usage_limits=UsageLimits(request_limit=1)).session() as session:
        results = await asyncio.gather(session.send('One?'), session.send('Two?'), return_exceptions=True)

    assert [type(result).__name__ for result in results] == ['NoneType', 'UsageLimitExceeded']
    assert conn.sent == ['One?']


async def test_agent_realtime_session_request_limit_blocks_tool_result_response() -> None:
    conn = FakeRealtimeConnection([ToolCall(tool_call_id='t1', tool_name='greet', args='{}')])
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    def greet() -> str:
        return 'hi'

    async with agent.realtime(FakeRealtimeModel(conn), usage_limits=UsageLimits(request_limit=1)).session() as session:
        with pytest.raises(UsageLimitExceeded, match='next request would exceed the request_limit of 1'):
            _ = [event async for event in session]

    assert conn.sent == []


async def test_agent_realtime_session_response_without_usage_counts_toward_request_limit() -> None:
    conn = FakeRealtimeConnection([OutputTranscript(text='response', is_final=True), ResponseDone()])
    agent: Agent[None, str] = Agent()
    async with agent.realtime(FakeRealtimeModel(conn), usage_limits=UsageLimits(request_limit=1)).session() as session:
        _ = [event async for event in session]
    assert session.usage.requests == 1


async def test_agent_realtime_session_tool_call_limit_raises() -> None:
    agent: Agent[None, str] = Agent()

    # Never runs: the limit trips first.
    @agent.tool_plain
    def greet() -> str:  # pragma: no cover
        return 'hi'

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='t1', tool_name='greet', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, usage_limits=UsageLimits(tool_calls_limit=0)).session() as session:
        with pytest.raises(UsageLimitExceeded, match='exceed the tool_calls_limit of 0'):
            _ = [e async for e in session]


async def test_agent_realtime_session_usage_limits_within_budget() -> None:
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    def greet() -> str:
        return 'hi'

    conn = FakeRealtimeConnection(
        [
            SessionUsage(usage=RequestUsage(input_tokens=1, output_tokens=1)),
            ToolCall(tool_call_id='t1', tool_name='greet', args='{}'),
            ResponseDone(),
        ]
    )
    model = FakeRealtimeModel(conn)
    limits = UsageLimits(total_tokens_limit=1000, tool_calls_limit=10)
    async with agent.realtime(model, usage_limits=limits).session() as session:
        events = [e async for e in session]
    assert not any(isinstance(e, RealtimeSessionErrorEvent) for e in events)
    assert any(isinstance(e, FunctionToolResultEvent) for e in events)


async def test_agent_realtime_session_resolves_conversation_id_like_a_run() -> None:
    # A session continues the conversation its history came from, and forks off it on `'new'`, exactly
    # as `run`/`iter` do — otherwise telemetry and a later handoff disagree about which conversation
    # this was, and `'new'` becomes a literal id shared by every session that passes it.
    history = [ModelRequest(parts=[UserPromptPart(content='earlier')], conversation_id='c1')]

    agent: Agent[None, str] = Agent()

    async def recorded_conversation_id(**kwargs: Any) -> str | None:
        # The resolved id is what gets stamped on everything the session records, so read it from there
        # rather than from a private attribute.
        async with agent.realtime(FakeRealtimeModel(FakeRealtimeConnection([])), **kwargs).session() as session:
            await session.send('hi')
            return session.new_messages()[0].conversation_id

    assert await recorded_conversation_id(message_history=history) == 'c1'
    forked = await recorded_conversation_id(message_history=history, conversation_id='new')
    assert forked not in (None, 'new', 'c1')
    assert await recorded_conversation_id()


async def test_agent_realtime_continues_a_text_runs_conversation() -> None:
    """A text run's `conversation` is spoken in directly: its history, running total and id all carry."""
    agent: Agent[None, str] = Agent(TestModel(custom_output_text='A joke.'))
    text = await agent.run('Tell me a joke.')

    async with agent.realtime(
        FakeRealtimeModel(FakeRealtimeConnection([])), conversation=text.conversation
    ).session() as session:
        await session.send('And another.')

        assert session.all_messages()[: len(text.all_messages())] == text.all_messages()
        assert session.usage.requests == text.usage.requests
        assert session.new_messages()[0].conversation_id == text.conversation_id
        # Handed back, the bundle still carries the text run's total, not a restarted one.
        assert session.conversation.usage.requests == text.usage.requests


def test_agent_realtime_rejects_a_conversation_alongside_its_pieces() -> None:
    agent: Agent[None, str] = Agent(TestModel())
    conversation = agent.run_sync('Hi').conversation

    with pytest.raises(UserError, match='`conversation` already carries `message_history`'):
        agent.realtime(
            FakeRealtimeModel(FakeRealtimeConnection([])),
            conversation=conversation,
            message_history=conversation.messages,
        )


async def test_agent_realtime_session_run_id_matches_a_run() -> None:
    seen_run_ids: list[str | None] = []
    agent: Agent[None, str] = Agent(deps_type=type(None))

    @agent.tool
    def record_run_id(ctx: RunContext[None]) -> str:
        seen_run_ids.append(ctx.run_id)
        return 'ok'

    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='hello', is_final=True),
            ToolCall(tool_call_id='t1', tool_name='record_run_id', args='{}'),
            OutputTranscript(text='hi', is_final=True),
            ResponseDone(),
        ]
    )
    async with agent.realtime(FakeRealtimeModel(conn), run_id='realtime-run-1').session() as session:
        _ = [event async for event in session]

    assert seen_run_ids == ['realtime-run-1']
    assert session.new_messages()
    assert all(message.run_id == 'realtime-run-1' for message in session.new_messages())


async def test_agent_realtime_session_generates_distinct_run_ids() -> None:
    agent: Agent[None, str] = Agent()

    async def recorded_run_id() -> str | None:
        async with agent.realtime(FakeRealtimeModel(FakeRealtimeConnection([]))).session() as session:
            await session.send('hi')
            return session.new_messages()[0].run_id

    first = await recorded_run_id()
    second = await recorded_run_id()
    assert first is not None
    assert second is not None
    assert first != second


@pytest.mark.parametrize('run_id', ['', 'prior-run'])
async def test_agent_realtime_session_rejects_invalid_run_id(run_id: str) -> None:
    history = [ModelRequest(parts=[UserPromptPart(content='earlier')], run_id='prior-run')]
    agent: Agent[None, str] = Agent()

    with pytest.raises(UserError, match='run_id'):
        async with agent.realtime(
            FakeRealtimeModel(FakeRealtimeConnection([])), message_history=history, run_id=run_id
        ).session():
            pass


async def test_agent_realtime_session_tool_context_matches_a_run() -> None:
    # `validation_context` and `root_capability` are both resolved from the context itself, so they're
    # easy to leave unset in a code path that builds its own. A tool validated in a session must see
    # the same Pydantic context as one validated in a run, and a capability introspecting the chain
    # must find its root rather than a `None` that contradicts a populated `ctx.capabilities`.
    seen: list[tuple[Any, Any]] = []

    agent: Agent[None, str] = Agent(deps_type=type(None), validation_context=lambda ctx: {'from': 'ctx'})

    @agent.tool
    def peek(ctx: RunContext[None]) -> str:
        seen.append((ctx.validation_context, ctx.root_capability))
        return 'ok'

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='t1', tool_name='peek', args='{}'), ResponseDone()])
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        _ = [e async for e in session]

    assert len(seen) == 1
    validation_context, root_capability = seen[0]
    assert validation_context == {'from': 'ctx'}
    assert root_capability is not None


async def test_agent_realtime_session_tool_context_sees_retry_override() -> None:
    seen: list[int] = []
    agent: Agent[None, str] = Agent(deps_type=type(None), retries=3)

    @agent.tool
    def peek(ctx: RunContext[None]) -> str:
        seen.append(ctx.max_retries)
        return 'ok'

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='t1', tool_name='peek', args='{}'), ResponseDone()])
    with agent.override(retries={'tools': 0}):
        async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
            _ = [event async for event in session]

    assert seen == [0]


async def test_agent_realtime_session_tool_sees_conversation_so_far() -> None:
    # A tool reads `ctx.messages` to reason about the conversation, exactly as it would in a classic
    # run. The session's context is built once at connect, so the turns that happened since have to be
    # synchronized into it before each call.
    seen: list[ModelMessage] = []

    agent: Agent[None, str] = Agent(deps_type=type(None))

    @agent.tool
    def recall(ctx: RunContext[None]) -> str:
        seen.extend(ctx.messages)
        return 'ok'

    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='what did I just say?', is_final=True),
            ToolCall(tool_call_id='t1', tool_name='recall', args='{}'),
            ResponseDone(),
        ]
    )
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        _ = [e async for e in session]

    assert [p.transcript for m in seen for p in m.parts if isinstance(p, SpeechPart)] == ['what did I just say?']


async def test_agent_realtime_session_native_tools_from_capability() -> None:
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, capabilities=[NativeTool(WebSearchTool())]).session() as session:
        _ = [e async for e in session]
    assert model.last_native_tools is not None
    assert any(isinstance(t, WebSearchTool) for t in model.last_native_tools)


async def test_agent_realtime_session_rejects_unsupported_native_tool() -> None:
    # A native tool the model doesn't support (per its `supported_native_tools` profile) with no local
    # fallback fails up front, before connecting — even when contributed by a capability. This runs the
    # same native ↔ local-tool swap the classic agent-run path applies, so the error points at `local=`.
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([])
    model = FakeRealtimeModel(conn, profile=_profile(supported_native_tools=frozenset()))
    with pytest.raises(
        UserError,
        match=r"not supported by this model.*WebSearch\(local='duckduckgo'\)",
    ):
        async with agent.realtime(model, capabilities=[NativeTool(WebSearchTool())]).session():
            pass  # pragma: no cover


async def test_agent_realtime_session_local_capability_tool_declared() -> None:
    def fetch(url: str) -> str:
        # Not executed in this wiring test.
        return f'content of {url}'  # pragma: no cover

    agent: Agent[None, str] = Agent(capabilities=[WebFetch(native=False, local=fetch)])
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        _ = [e async for e in session]
    assert model.last_tools is not None
    assert 'fetch' in [t.name for t in model.last_tools]
    assert model.last_native_tools == []  # native=False -> no url_context forwarded


class _HookCapability(AbstractCapability[object]):
    """Records and rewrites tool execution through the tool-lifecycle hooks."""

    def __init__(self) -> None:
        self.events: list[str] = []

    async def before_tool_execute(
        self, ctx: RunContext[object], *, call: ToolCallPart, tool_def: ToolDefinition, args: dict[str, Any]
    ) -> dict[str, Any]:
        self.events.append(f'before:{call.tool_name}')
        return args

    async def after_tool_execute(
        self,
        ctx: RunContext[object],
        *,
        call: ToolCallPart,
        tool_def: ToolDefinition,
        args: dict[str, Any],
        result: Any,
    ) -> Any:
        self.events.append(f'after:{result}')
        return f'[hooked] {result}'


async def test_agent_realtime_session_capability_tool_hooks() -> None:
    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    def greet() -> str:
        return 'hi'

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='t1', tool_name='greet', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    cap = _HookCapability()
    async with agent.realtime(model, capabilities=[cap]).session() as session:
        events = [e async for e in session]
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert result.part.content == '[hooked] hi'
    assert cap.events == ['before:greet', 'after:hi']


async def test_agent_realtime_session_capability_recovers_tool_error_for_taps_only_consumer() -> None:
    class RecoverToolError(AbstractCapability[object]):
        async def on_tool_execute_error(
            self,
            ctx: RunContext[object],
            *,
            call: ToolCallPart,
            tool_def: ToolDefinition,
            args: dict[str, Any],
            error: Exception,
        ) -> str:
            assert str(error) == 'service unavailable'
            return 'fallback result'

    agent: Agent[None, str] = Agent()

    @agent.tool_plain
    def lookup() -> str:
        raise ValueError('service unavailable')

    conn = BlockingRealtimeConnection([ToolCall(tool_call_id='t1', tool_name='lookup', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, capabilities=[RecoverToolError()]).session() as session:
        audio = asyncio.create_task(_collect(session.stream_audio()))
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            while not conn.sent:
                await asyncio.sleep(0)

    assert conn.sent == [ToolResult(tool_call_id='t1', output='fallback result')]
    assert await audio == []


async def test_agent_realtime_session_metadata_and_conversation_id() -> None:
    agent: Agent[None, str] = Agent()

    @agent.tool
    def whoami(ctx: RunContext) -> str:
        return f'{ctx.conversation_id}|{ctx.metadata}'

    conn = FakeRealtimeConnection([ToolCall(tool_call_id='t1', tool_name='whoami', args='{}'), ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model, conversation_id='conv-1', metadata={'tier': 'gold'}).session() as session:
        events = [e async for e in session]
    result = next(e for e in events if isinstance(e, FunctionToolResultEvent))
    assert 'conv-1' in str(result.part.content)
    assert 'gold' in str(result.part.content)


async def test_session_stamps_conversation_id_and_classic_resume_resolves_it() -> None:
    seeded = [ModelRequest(parts=[UserPromptPart(content='seed')])]
    conn = FakeRealtimeConnection(
        [
            InputTranscript(text='spoken', is_final=True),
            ToolCall(tool_call_id='t1', tool_name='f', args='{}'),
            OutputTranscript(text='answer', is_final=True),
            ResponseDone(),
        ]
    )

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'done'

    session = RealtimeSession(
        conn,
        runner,
        model_name='m',
        conversation_id='c1',
        message_history=seeded,
    )
    await session.send('typed')
    _ = await collect_events(session)

    assert session.all_messages()[0].conversation_id is None
    assert all(message.conversation_id == 'c1' for message in session.new_messages())
    assert resolve_conversation_id(None, session.all_messages()) == 'c1'


async def test_agent_realtime_session_native_tools_override_honored() -> None:
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    with agent.override(native_tools=[WebSearchTool()]):
        async with agent.realtime(model).session() as session:
            _ = [e async for e in session]
    assert model.last_native_tools is not None
    assert any(isinstance(t, WebSearchTool) for t in model.last_native_tools)


async def test_wrapper_agent_realtime_session_proxies() -> None:
    from pydantic_ai.agent import WrapperAgent

    inner: Agent[None, str] = Agent(instructions='Inner')
    wrapper = WrapperAgent(inner)
    conn = FakeRealtimeConnection([])
    model = FakeRealtimeModel(conn)
    images = [BinaryImage(data=bytes([index]), media_type='image/png') for index in range(3)]
    # The wrapped agent's session is used, and per-session options like `retain_images_every_n` forward
    # through the wrapper (and the durable-exec subclasses that extend it) rather than being dropped.
    async with wrapper.realtime(model).session(retain_images_every_n=2) as session:
        for image in images:
            await session.send(image)
        retained = session.new_messages()
    assert model.last_instructions == 'Inner'  # the wrapped agent's session was used
    assert retained == [
        ModelRequest(
            parts=[UserPromptPart(content=[images[0]], timestamp=IsDatetime())],
            timestamp=IsDatetime(),
            conversation_id=IsStr(),
            run_id=IsStr(),
        ),
        ModelRequest(
            parts=[UserPromptPart(content=[images[2]], timestamp=IsDatetime())],
            timestamp=IsDatetime(),
            conversation_id=IsStr(),
            run_id=IsStr(),
        ),
    ]


async def test_agent_realtime_session_drops_auto_injected_tool_search() -> None:
    agent: Agent[None, str] = Agent()
    conn = FakeRealtimeConnection([ResponseDone()])
    model = FakeRealtimeModel(conn)
    async with agent.realtime(model).session() as session:
        _ = [e async for e in session]
    assert model.last_native_tools == []


async def test_send_audio_first_chunk_bad_rolls_back_turn_state() -> None:
    """Regression: a non-bytes chunk from an async iterable must fail before it goes out, leaving no phantom
    empty user turn at the next boundary."""
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, audio_retention='input_audio')

    async def first_chunk_bad() -> AsyncIterator[bytes]:
        yield 123  # type: ignore[misc]

    async with session:
        with pytest.raises(ValidationError):
            await session.send_audio(first_chunk_bad())

        assert conn.sent == [], 'nothing should have reached the connection'

        # With the state clean, a later (empty) turn boundary must not record
        # a phantom user turn.
        await session.commit_audio()
        _ = await drain_events(session)

    assert session.new_messages() == []


async def test_send_audio_bad_later_chunk_keeps_earlier_chunks() -> None:
    """The chunk that fails goes nowhere, and the chunks that already succeeded remain sent (nothing is duplicated
    or dropped)."""
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn, audio_retention='input_audio')

    async def chunks() -> AsyncIterator[bytes]:
        yield b'good-bytes'
        yield 'not-bytes'  # type: ignore[misc]

    async with session:
        with pytest.raises(ValidationError):
            await session.send_audio(chunks())

        assert len(conn.sent) == 1


def test_session_conversation_bundles_what_a_text_run_needs() -> None:
    """A spoken conversation hands a text run the same bundle `AgentRunResult.conversation` does."""
    history: list[ModelMessage] = [ModelRequest(parts=[UserPromptPart(content='Earlier turn')])]
    session = RealtimeSession(
        FakeRealtimeConnection([]),
        message_history=history,
        usage=RunUsage(requests=2, input_tokens=30),
        conversation_id='conv-1',
    )

    conversation = session.conversation

    assert conversation.messages == history
    assert conversation.usage.requests == 2
    assert conversation.usage.input_tokens == 30
    assert conversation.conversation_id == 'conv-1'


def test_session_conversation_mints_an_id_when_the_session_has_none() -> None:
    session = RealtimeSession(FakeRealtimeConnection([]))

    conversation = session.conversation

    assert UUID(conversation.conversation_id).version == 7
    assert conversation.messages == []
    # One identity to store the conversation under, not a new one per read.
    assert session.conversation.conversation_id == conversation.conversation_id


async def test_session_conversation_stamps_the_turns_recorded_before_it() -> None:
    """The id is minted on the first read, but the turns before it belong to the same conversation.

    Without stamping them, the bundle would carry an id its own earlier messages don't, and a store
    keyed on either would split one conversation in two.
    """
    session = RealtimeSession(FakeRealtimeConnection([]))
    await session.send('turn it up')

    conversation = session.conversation

    assert [message.conversation_id for message in conversation.messages] == [conversation.conversation_id]


def test_session_conversation_continues_the_seeded_conversation() -> None:
    """A session seeded with a conversation's history continues it, as one `Agent.realtime` opens would."""
    history: list[ModelMessage] = [ModelRequest(parts=[UserPromptPart(content='Earlier turn')], conversation_id='c1')]
    session = RealtimeSession(FakeRealtimeConnection([]), message_history=history)

    assert session.conversation.conversation_id == 'c1'


def test_session_conversation_usage_is_a_copy() -> None:
    session = RealtimeSession(FakeRealtimeConnection([]), usage=RunUsage(requests=2))

    session.conversation.usage.requests += 10

    assert session.usage.requests == 2


async def test_cost_limit_passed_by_a_reply_settled_at_close_is_reported() -> None:
    """Hanging up mid-reply must not let an over-budget session exit cleanly.

    The reply never reaches `ResponseDone`, so it's settled (and priced) only as the connection goes, the moment
    its cost is first known. A taps-only caller never iterates, so `close()` is the only place it can be told the
    `cost_limit` it asked for was passed.
    """
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='over budget', is_final=True),
            SessionUsage(usage=RequestUsage(input_tokens=1000, output_tokens=500)),
        ]
    )
    agent: Agent[None, str] = Agent()
    with pytest.raises(UsageLimitExceeded, match=r'Exceeded the `cost_limit` of 0.0001'):
        async with agent.realtime(
            FakeRealtimeModel(conn, model_name='gpt-realtime', system='openai'),
            usage_limits=UsageLimits(cost_limit=Decimal('0.0001')),
        ).session() as session:
            _ = [part async for part in session.stream_transcripts()]


async def test_provider_output_reaches_a_view_subscribed_after_entry() -> None:
    """Receiving must not start before the caller has had a chance to subscribe.

    Every docs example creates its views inside the session block, so a pump running from `__aenter__`
    would publish the model's opening audio to no one and drop it: taps only ever receive what is
    emitted after they subscribe.
    """
    chunks = [b'g1', b'g2', b'g3']
    frames: list[RealtimeCodecEvent] = [AudioDelta(chunk) for chunk in chunks]
    frames.append(ResponseDone())
    conn = FakeRealtimeConnection(frames)
    played: list[bytes] = []

    async with RealtimeSession(conn) as session:
        for _ in range(10):  # a caller that takes a few loop turns to get to its first subscription
            await asyncio.sleep(0)
        view = session.stream_audio()

        async def drain() -> None:
            async for chunk in view:
                played.append(chunk)

        draining = asyncio.create_task(drain())
        async for _ in session:
            pass
        await draining

    assert played == chunks


async def test_wait_for_reply_returns_at_the_turn_boundary() -> None:
    conn = FakeRealtimeConnection(
        [OutputTranscript(text='hello there', is_final=True), ResponseDone()],
        after_input=True,
    )
    session = RealtimeSession(conn)
    async with session:
        await session.send('Say hello.')
        with anyio.fail_after(5):
            await session.wait_for_reply()
        assert session.all_messages() == snapshot(
            [
                ModelRequest(
                    parts=[UserPromptPart(content='Say hello.', timestamp=IsDatetime())], timestamp=IsDatetime()
                ),
                ModelResponse(
                    parts=[SpeechPart(speaker='assistant', transcript='hello there')],
                    timestamp=IsDatetime(),
                    finish_reason='stop',
                ),
            ]
        )


async def test_wait_for_reply_spans_a_tool_calling_turn() -> None:
    """The response that calls a tool is not the reply: the answer after the tool results is.

    The tool is held open so the waiter genuinely observes the gap between the tool-call response
    finalizing and the answer starting — releasing at that first response boundary would return here
    with nothing said yet.
    """
    release_tool = asyncio.Event()
    answer_sent = asyncio.Event()

    class _AnswersAfterTheTool(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='c1', tool_name='get_weather', args='{}')
            yield ResponseDone()
            await answer_sent.wait()
            yield OutputTranscript(text='it is sunny', is_final=True)
            yield ResponseDone()

    tool_started = asyncio.Event()

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        tool_started.set()
        await release_tool.wait()
        return 'sunny'

    session = RealtimeSession(_AnswersAfterTheTool([]), runner)
    async with session:
        await session.send('What is the weather?')
        waiting = asyncio.create_task(session.wait_for_reply())
        # Wait for the tool to be running rather than for a fixed number of loop turns, so the gap this
        # is about — the tool-call response finalized, the answer not yet begun — is actually reached.
        with anyio.fail_after(5):
            await tool_started.wait()
        assert not waiting.done(), 'returned at the tool-call response instead of the answer'

        release_tool.set()
        for _ in range(20):
            await asyncio.sleep(0)
        assert not waiting.done(), 'returned before the model answered'

        answer_sent.set()
        with anyio.fail_after(5):
            await waiting
    assert any(
        isinstance(part, SpeechPart) and part.transcript == 'it is sunny'
        for message in session.all_messages()
        for part in message.parts
    )


async def test_wait_for_reply_returns_immediately_when_nothing_is_owed() -> None:
    """A reply that finished before the call is not waited for all over again."""
    conn = FakeRealtimeConnection([OutputTranscript(text='hi', is_final=True), ResponseDone()])
    session = RealtimeSession(conn)
    async with session:
        await session.send('Say hi.')
        with anyio.fail_after(5):
            await session.wait_for_reply()
        # Nothing is owed now, so a second wait must not block until some later turn.
        with anyio.fail_after(5):
            await session.wait_for_reply()


async def test_wait_for_reply_runs_alongside_session_iteration() -> None:
    """The point of the method: it does not need to take over the event stream to find the boundary."""
    conn = FakeRealtimeConnection([OutputTranscript(text='hello', is_final=True), ResponseDone()])
    session = RealtimeSession(conn)
    seen: list[RealtimeEvent] = []
    async with session:
        waiting = asyncio.create_task(session.wait_for_reply())
        await session.send('Say hello.')
        async for event in session:
            seen.append(event)
        with anyio.fail_after(5):
            await waiting
    assert any(isinstance(event, RealtimeTurnCompleteEvent) for event in seen)


async def test_wait_for_reply_returns_when_the_session_closes() -> None:
    """A never-answered reply must not park the caller forever."""
    session = RealtimeSession(FakeRealtimeConnection([]))
    async with session:
        await session.send('Say hello.')
        closing = asyncio.create_task(session.close())
        with anyio.fail_after(5):
            await session.wait_for_reply()
        await closing


async def test_wait_for_reply_returns_when_the_receive_side_fails() -> None:
    """A reply that can no longer arrive must not park the caller: the pump died owing one."""

    class _DyingConnection(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield RealtimeInputSpeechStartEvent()
            raise RuntimeError('socket died')

    session = RealtimeSession(_DyingConnection([]))
    # The failure still surfaces at close, as it would without this method: the point is that
    # `wait_for_reply()` returns rather than parking the caller before that can happen.
    with pytest.raises(RuntimeError, match='socket died'):
        async with session:
            await session.send('Say hello.')
            assert session._pump_task is not None  # pyright: ignore[reportPrivateUsage]
            await session._pump_task  # pyright: ignore[reportPrivateUsage]
            with anyio.fail_after(5):
                await session.wait_for_reply()


async def test_wait_for_reply_returns_when_the_send_that_asked_for_it_failed() -> None:
    """A rolled-back reservation stops counting, or the failed send would park every later waiter."""

    class _RefusingConnection(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            raise RuntimeError('send failed')

        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield RealtimeInputSpeechStartEvent()
            await asyncio.Event().wait()  # the receive side stays open

    session = RealtimeSession(_RefusingConnection([]))
    async with session:
        with pytest.raises(RuntimeError, match='send failed'):
            await session.send('Say hello.')
        with anyio.fail_after(5):
            await session.wait_for_reply()


async def test_wait_for_reply_waits_for_every_requested_reply() -> None:
    """Two solicited replies are both waited for, not just the first to reach its boundary."""
    second_reply = asyncio.Event()

    class _TwoReplies(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield OutputTranscript(text='first', is_final=True)
            yield ResponseDone()
            await second_reply.wait()
            yield OutputTranscript(text='second', is_final=True)
            yield ResponseDone()

    session = RealtimeSession(_TwoReplies([]))
    async with session:
        await session.send('One.')
        await session.send('Two.')
        waiting = asyncio.create_task(session.wait_for_reply())
        for _ in range(20):
            await asyncio.sleep(0)
        assert not waiting.done(), 'returned at the first reply while a second was still requested'

        second_reply.set()
        with anyio.fail_after(5):
            await waiting
    assert any(
        isinstance(part, SpeechPart) and part.transcript == 'second'
        for message in session.all_messages()
        for part in message.parts
    )


async def test_wait_for_reply_wakes_when_a_concurrent_send_fails() -> None:
    """A waiter already parked on the only outstanding reservation is woken when its send fails.

    The rollback alone is not enough: nothing else is coming to wake the waiter, so the release has to
    signal as well or the caller parks until the session closes.
    """
    fail_send = asyncio.Event()

    class _FailsMidSend(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            await fail_send.wait()
            raise RuntimeError('send failed')

        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield RealtimeInputSpeechStartEvent()
            await asyncio.Event().wait()  # the receive side stays open

    session = RealtimeSession(_FailsMidSend([]))
    async with session:
        sending = asyncio.create_task(session.send('Say hello.'))
        for _ in range(10):
            await asyncio.sleep(0)
        waiting = asyncio.create_task(session.wait_for_reply())
        for _ in range(10):
            await asyncio.sleep(0)
        assert not waiting.done(), 'nothing was outstanding to wait on'

        fail_send.set()
        with anyio.fail_after(5):
            await waiting
        with pytest.raises(RuntimeError, match='send failed'):
            await sending


class _AnswersEachInput(FakeRealtimeConnection):
    """Answers every input as it is sent with the events `answer` gives for it, numbered as `send()` is called."""

    def __init__(self, answer: Callable[[int, RealtimeInput], list[RealtimeCodecEvent]]) -> None:
        super().__init__([])
        self._answer = answer
        self._events: asyncio.Queue[RealtimeCodecEvent] = asyncio.Queue()

    async def send_input(self, content: RealtimeInput) -> None:
        index = len(self.sent)
        await super().send_input(content)
        for event in self._answer(index, content):
            self._events.put_nowait(event)

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        while True:
            yield await self._events.get()


_REFUSAL = RealtimeSessionErrorEvent('Refused.', type='invalid_request_error', code='invalid_value')


async def test_wait_for_reply_returns_when_the_provider_refuses_the_response() -> None:
    """A refused request for a response releases its reservation, since no response will ever come."""
    conn = _AnswersEachInput(lambda index, _: [InputRejected(index, refused='response'), _REFUSAL])
    session = RealtimeSession(conn)
    async with session:
        await session.send('Say hello.')
        with anyio.fail_after(5):
            await session.wait_for_reply()
        # Only the request for a response was refused: the text itself joined the conversation.
        assert session.all_messages() == snapshot(
            [ModelRequest(parts=[UserPromptPart(content='Say hello.', timestamp=IsDatetime())], timestamp=IsDatetime())]
        )


async def test_refused_content_is_taken_out_of_history() -> None:
    """Content the provider refused never reached the model, so history must not claim it did."""

    def answer(index: int, content: RealtimeInput) -> list[RealtimeCodecEvent]:
        if content == TextContext('refused'):
            return [InputRejected(index, refused='content'), _REFUSAL]
        return []

    session = RealtimeSession(_AnswersEachInput(answer))
    async with session:
        await session.send('refused', respond=False)
        await session.send('kept', respond=False)
        for _ in range(20):  # let the pump read the refusal
            await asyncio.sleep(0)
        assert session.all_messages() == snapshot(
            [ModelRequest(parts=[UserPromptPart(content='kept', timestamp=IsDatetime())], timestamp=IsDatetime())]
        )


async def test_refused_image_frees_its_place_under_the_retention_cap() -> None:
    """A refused image is no longer retained, so it doesn't evict a real one to make room for itself."""
    refused = BinaryImage(data=b'refused', media_type='image/png')

    def answer(index: int, content: RealtimeInput) -> list[RealtimeCodecEvent]:
        return [InputRejected(index, refused='content'), _REFUSAL] if content == refused else []

    images = [BinaryImage(data=f'image-{index}'.encode(), media_type='image/png') for index in range(3)]
    session = RealtimeSession(_AnswersEachInput(answer), _noop_runner, retain_images_max=3)
    async with session:
        await session.send(images[0])
        await session.send(images[1])
        await session.send(refused)
        for _ in range(20):  # let the pump read the refusal
            await asyncio.sleep(0)
        await session.send(images[2])
        assert session.all_messages() == [
            ModelRequest(parts=[UserPromptPart(content=[image], timestamp=IsDatetime())], timestamp=IsDatetime())
            for image in images
        ]


async def test_image_refused_while_still_sending_is_not_retained() -> None:
    """A refusal read before the image's send returns must not leave the refused image counted under the cap."""
    refused = BinaryImage(data=b'refused', media_type='image/png')

    class _RefusesMidSend(_AnswersEachInput):
        async def send_input(self, content: RealtimeInput) -> None:
            await super().send_input(content)
            if content == refused:
                for _ in range(20):  # the pump reads the refusal before this send returns
                    await asyncio.sleep(0)

    def answer(index: int, content: RealtimeInput) -> list[RealtimeCodecEvent]:
        return [InputRejected(index, refused='content'), _REFUSAL] if content == refused else []

    images = [BinaryImage(data=f'image-{index}'.encode(), media_type='image/png') for index in range(3)]
    session = RealtimeSession(_RefusesMidSend(answer), _noop_runner, retain_images_max=2)
    async with session:
        await session.send(images[0])
        await session.send(images[1])
        await session.send(refused)
        await session.send(images[2])
        assert session.all_messages() == [
            ModelRequest(parts=[UserPromptPart(content=[image], timestamp=IsDatetime())], timestamp=IsDatetime())
            for image in images[1:]
        ]


async def test_refused_content_without_a_recorded_request_changes_nothing() -> None:
    """Refused content the session recorded nothing for (a bare response request) has nothing to take back."""
    conn = _AnswersEachInput(lambda index, _: [InputRejected(index, refused='content'), _REFUSAL])
    session = RealtimeSession(conn, _noop_runner)
    async with session:
        await session.create_response()
        waiting = asyncio.create_task(session.wait_for_reply())
        for _ in range(20):
            await asyncio.sleep(0)
        # The request for a response wasn't what was refused, so the reply is still owed.
        assert not waiting.done()
        await session.close()
        with anyio.fail_after(5):
            await waiting


async def test_refused_response_request_already_answered_releases_nothing() -> None:
    """A refusal arriving after a response took the reservation must not release another caller's.

    A response the provider started on its own (server VAD) takes whichever reservation is pending, so
    that is the reply the caller gets; releasing again would leave the next send's reply unwaited for.
    """

    def answer(index: int, content: RealtimeInput) -> list[RealtimeCodecEvent]:
        if index == 0:
            return [
                OutputTranscript(text='hi', is_final=True),
                InputRejected(index, refused='response'),
                _REFUSAL,
                ResponseDone(),
            ]
        return []

    class _GatedSecondReply(_AnswersEachInput):
        async def send_input(self, content: RealtimeInput) -> None:
            await super().send_input(content)
            if len(self.sent) == 2:
                self._events.put_nowait(OutputTranscript(text='again', is_final=True))

    conn = _GatedSecondReply(answer)
    session = RealtimeSession(conn)
    async with session:
        await session.send('Hi.')
        with anyio.fail_after(5):
            await session.wait_for_reply()
        await session.send('Again.')
        waiting = asyncio.create_task(session.wait_for_reply())
        for _ in range(20):
            await asyncio.sleep(0)
        assert not waiting.done(), 'the refusal released the reservation of the reply still owed'
        conn._events.put_nowait(ResponseDone())  # pyright: ignore[reportPrivateUsage]
        with anyio.fail_after(5):
            await waiting


async def test_error_naming_no_input_leaves_the_reply_owed() -> None:
    """An error that doesn't say which input it refused doesn't cancel the reply.

    Checked live: an OpenAI or xAI error that names no client event (an unsupported image format, an
    invalid event on xAI) still leaves the `response.create` after it to be answered.
    """
    conn = _AnswersEachInput(lambda index, _: [_REFUSAL])
    session = RealtimeSession(conn)
    async with session:
        await session.send('Say hello.')
        waiting = asyncio.create_task(session.wait_for_reply())
        for _ in range(20):
            await asyncio.sleep(0)
        assert not waiting.done(), 'an unattributed error released the reply'
        conn._events.put_nowait(OutputTranscript(text='hello', is_final=True))  # pyright: ignore[reportPrivateUsage]
        conn._events.put_nowait(ResponseDone())  # pyright: ignore[reportPrivateUsage]
        with anyio.fail_after(5):
            await waiting


async def test_wait_for_reply_returns_when_a_reconnect_discards_the_reply() -> None:
    """A reconnect settles the in-flight reply as interrupted; the model will never finish saying it."""
    reconnected = asyncio.Event()

    class _ReconnectsMidReply(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            await self._input_sent.wait()  # (the reply to the input)
            yield OutputTranscript(text='half a sen', is_final=False)
            yield RealtimeSessionReconnectEvent(state_restored=False)
            reconnected.set()
            await asyncio.Event().wait()  # the receive side stays open, but that reply is gone

    session = RealtimeSession(_ReconnectsMidReply([]))
    async with session:
        await session.send('Say hello.')
        with anyio.fail_after(5):
            await session.wait_for_reply()


async def test_wait_for_reply_wakes_when_a_concurrent_image_send_fails() -> None:
    """The image path reserves a response too, so its rollback has to wake a waiter just like text's.

    Every outbound call that reserves a response goes through the same release helper; this pins the
    path that does not go through `send(str)`.
    """
    fail_send = asyncio.Event()

    class _FailsMidSend(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            await fail_send.wait()
            raise RuntimeError('send failed')

        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield RealtimeInputSpeechStartEvent()
            await asyncio.Event().wait()  # the receive side stays open

    session = RealtimeSession(_FailsMidSend([]))
    async with session:
        image = BinaryImage(data=b'png', media_type='image/png')
        sending = asyncio.create_task(session.send(image, respond=True))
        for _ in range(10):
            await asyncio.sleep(0)
        waiting = asyncio.create_task(session.wait_for_reply())
        for _ in range(10):
            await asyncio.sleep(0)
        assert not waiting.done(), 'nothing was outstanding to wait on'

        fail_send.set()
        with anyio.fail_after(5):
            await waiting
        with pytest.raises(RuntimeError, match='send failed'):
            await sending


@pytest.mark.parametrize('more_expected', [False, True])
async def test_turn_complete_waits_for_a_provider_that_says_more_is_coming(more_expected: bool) -> None:
    """A response that ends with `more_expected` isn't the end of the exchange, so no turn boundary yet.

    This is how a background-reasoning model's spoken filler is kept from claiming the model is done:
    it completes a real response, with no tool call in it for the session to infer a continuation from,
    while the provider is still working. See `ResponseDone.more_expected`.
    """
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='Let me check that for you.', is_final=True),
            ResponseDone(more_expected=more_expected),
        ]
    )
    session = RealtimeSession(conn)

    async with session:
        events = await drain_events(session)

    assert (RealtimeTurnCompleteEvent() in events) is not more_expected
    # The response is settled either way: deferred while the exchange continues, then closed out when the
    # session does, so history never ends on an open response.
    assert [type(m).__name__ for m in session.all_messages()] == ['ModelResponse']


async def test_interrupted_response_is_not_absorbed_by_what_comes_next() -> None:
    """A barged-in utterance is over, so it closes even when the provider says more is expected.

    Otherwise the interrupted speech would be merged into the model's next response and history would
    lose the fact that the user cut it off.
    """
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='Let me check tha', is_final=True),
            ResponseDone(more_expected=True, interrupted=True),
            OutputTranscript(text='Sorry, go ahead.', is_final=True),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn)

    async with session:
        await drain_events(session)

    responses = [m for m in session.all_messages() if isinstance(m, ModelResponse)]
    assert [r.state for r in responses] == ['interrupted', 'complete']
    assert [len(r.parts) for r in responses] == [1, 1]


async def test_interrupted_response_still_closes_the_turn() -> None:
    """A barge-in ends the exchange even when the provider says work is still in flight.

    Without this, a caller waiting on `RealtimeTurnCompleteEvent` — which is every documented consumer
    shape — would wait forever on a provider that reports the interaction as still in progress.
    """
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='Let me check tha', is_final=True),
            ResponseDone(more_expected=True, interrupted=True),
        ]
    )
    session = RealtimeSession(conn)

    async with session:
        events = await drain_events(session)

    assert RealtimeTurnCompleteEvent() in events


async def test_wait_for_reply_holds_through_a_stalled_exchange() -> None:
    """A spoken filler the provider says isn't the end is not the reply: the answer after the tool is.

    A background-reasoning model speaks, ends that response with `more_expected`, and only then calls
    the tool it was stalling for — so, unlike `test_wait_for_reply_spans_a_tool_calling_turn`, nothing in
    the first response tells the session a tool is coming. Returning there would hand the caller back a
    session that is about to start talking again.
    """
    filler_done = asyncio.Event()
    continue_exchange = asyncio.Event()

    class _StallsThenCallsTheTool(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield OutputTranscript(text='Let me check that for you.', is_final=True)
            yield ResponseDone(more_expected=True)
            filler_done.set()
            await continue_exchange.wait()
            yield ToolCall(tool_call_id='c1', tool_name='get_weather', args='{}')
            yield OutputTranscript(text='it is sunny', is_final=True)
            yield ResponseDone()

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'sunny'

    session = RealtimeSession(_StallsThenCallsTheTool([]), runner)
    async with session:
        await session.send('What is the weather?')
        waiting = asyncio.create_task(session.wait_for_reply())
        with anyio.fail_after(5):
            await filler_done.wait()
        for _ in range(20):
            await asyncio.sleep(0)
        assert not waiting.done(), 'returned at the filler instead of the answer'

        continue_exchange.set()
        with anyio.fail_after(5):
            await waiting


def _two_stalled_utterances() -> list[RealtimeCodecEvent]:
    """A background-reasoning model speaking twice in one exchange, with no tool call between.

    Each utterance is its own provider response with its own usage report; only the first carries
    `more_expected`, since the exchange isn't over until the second.
    """
    return [
        OutputTranscript(text='Let me think.', is_final=True),
        SessionUsage(usage=RequestUsage(input_tokens=60, output_tokens=4)),
        ResponseDone(more_expected=True),
        OutputTranscript(text='The answer is 42.', is_final=True),
        SessionUsage(usage=RequestUsage(input_tokens=70, output_tokens=5)),
        ResponseDone(),
    ]


async def test_stalled_utterances_without_a_tool_call_stay_separate_responses() -> None:
    """A response is held open only for the tool call it was stalling for, not for more speech.

    Merging the two would sum distinct provider responses' usage into one `ModelResponse`: 130 input
    tokens for what were two requests of 60 and 70, one request counted where two were made.
    """
    session = RealtimeSession(FakeRealtimeConnection(_two_stalled_utterances()))
    async with session:
        events = await drain_events(session)

    responses = [m for m in session.all_messages() if isinstance(m, ModelResponse)]
    assert [[cast(SpeechPart, p).transcript for p in r.parts] for r in responses] == [
        ['Let me think.'],
        ['The answer is 42.'],
    ]
    assert [r.usage.input_tokens for r in responses] == [60, 70]
    assert session.usage.requests == 2
    # Still one exchange: the provider said the first response wasn't its last.
    assert events.count(RealtimeTurnCompleteEvent()) == 1


async def test_stalled_utterances_are_checked_against_per_request_limits_individually() -> None:
    session = RealtimeSession(
        FakeRealtimeConnection(_two_stalled_utterances()),
        usage_limits=UsageLimits(per_request_input_tokens_limit=100),
    )
    async with session:
        await drain_events(session)
    assert session.usage.input_tokens == 130


async def test_stalled_utterances_count_against_the_request_limit_individually() -> None:
    session = RealtimeSession(
        FakeRealtimeConnection(_two_stalled_utterances()), usage_limits=UsageLimits(request_limit=1)
    )
    with pytest.raises(UsageLimitExceeded):
        async with session:
            await drain_events(session)


async def test_a_user_interjecting_mid_stall_is_recorded_after_the_filler() -> None:
    """The held filler was already spoken, so a user turn that arrives next goes after it in history.

    Holding the filler out of history until the exchange ended would anchor the user's interjection
    before it — handing a standard run, or a re-seeded session, the reply before the words it answers.
    """
    session = RealtimeSession(
        FakeRealtimeConnection(
            [
                InputTranscript(text='Find flights', is_final=False),
                OutputTranscript(text='Let me check.', is_final=True),
                ResponseDone(more_expected=True),
                InputTranscript(text='Actually never mind', is_final=False),
                ResponseDone(interrupted=True),
                OutputTranscript(text='OK.', is_final=True),
                ResponseDone(),
            ]
        )
    )
    async with session:
        await drain_events(session)

    assert [
        (type(m).__name__, p.transcript) for m in session.all_messages() for p in m.parts if isinstance(p, SpeechPart)
    ] == [
        ('ModelRequest', 'Find flights'),
        ('ModelResponse', 'Let me check.'),
        ('ModelRequest', 'Actually never mind'),
        ('ModelResponse', 'OK.'),
    ]


async def test_a_reconnect_mid_stall_keeps_the_spoken_filler_complete() -> None:
    """A drop between a filler and its tool call settles the filler as the complete response it was.

    Gemini doesn't resume an in-flight generation on the re-dialed connection, so the tool call the
    filler was held for can't arrive; the codec closes the lost remainder of the exchange with an
    interrupted terminal before the reconnect, and the filler must not be folded into that.
    """
    session = RealtimeSession(
        FakeRealtimeConnection(
            [
                OutputTranscript(text='Let me check.', is_final=True),
                ResponseDone(more_expected=True),
                ResponseDone(interrupted=True),
                RealtimeSessionReconnectEvent(state_restored=True),
                OutputTranscript(text='Here you go.', is_final=True),
                ResponseDone(),
            ]
        )
    )
    async with session:
        await drain_events(session)

    assert [
        (m.state, [p.transcript for p in m.parts if isinstance(p, SpeechPart)])
        for m in session.all_messages()
        if isinstance(m, ModelResponse)
    ] == [('complete', ['Let me check.']), ('interrupted', []), ('complete', ['Here you go.'])]


class _ToolBatchConnection(FakeRealtimeConnection):
    """One response calls `fast` and `slow` in parallel, and the model answers once it has every result.

    Like Gemini Live (and the OpenAI connection, which asks for one response per batch), it answers a
    response's tool calls with a single reply once all their results have arrived.
    """

    def __init__(self, calls: list[RealtimeCodecEvent] | None = None, *, input_tokens: int = 1) -> None:
        super().__init__([])
        self.calls = calls or [
            ToolCall(tool_call_id='c1', tool_name='fast', args='{}', response_usage_follows=True),
            ToolCall(tool_call_id='c2', tool_name='slow', args='{}', response_usage_follows=True),
        ]
        self.input_tokens = input_tokens
        self.all_results_in = asyncio.Event()
        self.close_response = asyncio.Event()
        self.after_close: list[RealtimeCodecEvent] = []

    @property
    def _answers_tool_calls_per_response(self) -> bool:
        return True

    def results(self) -> list[ToolResult]:
        return [content for content in self.sent if isinstance(content, ToolResult)]

    async def send_input(self, content: RealtimeInput) -> None:
        await super().send_input(content)
        if len(self.results()) == len(self.calls):
            self.all_results_in.set()

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        for call in self.calls:
            yield call
        await self.close_response.wait()
        yield SessionUsage(usage=RequestUsage(input_tokens=self.input_tokens), finish_reason='tool_call')
        for event in self.after_close:
            yield event
        await self.all_results_in.wait()
        yield OutputTranscript(text='all done', is_final=True)
        yield ResponseDone()
        await asyncio.Event().wait()  # pragma: no cover


def _requests_counted(session: _RealtimeSession) -> int:
    """The requests counted against `request_limit`: those made, and those under way or asked for."""
    return session.usage.requests + session._core.requests_ahead()  # pyright: ignore[reportPrivateUsage]


async def _until(condition: Callable[[], bool]) -> None:
    """Yield to the event loop until `condition()` holds, failing if it never does."""
    with anyio.fail_after(_LIVENESS_TIMEOUT):
        while not condition():
            await asyncio.sleep(0)


def _slow_until(release: asyncio.Event) -> Callable[[str, dict[str, Any], str], Awaitable[str]]:
    """A runner whose `slow` tool waits for `release`, and whose other tools return at once."""

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        if name == 'slow':
            await release.wait()
        return f'{name} result'

    return runner


@pytest.mark.parametrize('results_before_the_response_completes', [False, True])
async def test_parallel_tool_calls_are_one_response_answered_once(results_before_the_response_completes: bool) -> None:
    """A response's parallel calls are one `ModelResponse`, answered by one reply the session waits for.

    Counting a reply per result left one owed forever when the provider answered the batch once, so
    `wait_for_reply()` hung for the rest of the session. Results that all land before the calling
    response is complete count the reply once it is.
    """
    release_slow = asyncio.Event()
    conn = _ToolBatchConnection()
    if not results_before_the_response_completes:
        conn.close_response.set()
    session = RealtimeSession(conn, _slow_until(release_slow))
    async with session:
        events = asyncio.create_task(drain_events(session))
        await _until(lambda: bool(conn.results()))
        release_slow.set()
        await _until(lambda: conn.all_results_in.is_set())
        conn.close_response.set()
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await _until(lambda: not session._core.reply_outstanding())  # pyright: ignore[reportPrivateUsage]
            await session.wait_for_reply()
        await session.close()
        events.cancel()

    assert [result.tool_call_id for result in conn.results()] == ['c1', 'c2']
    responses = [message for message in session.all_messages() if isinstance(message, ModelResponse)]
    assert [[type(part).__name__ for part in response.parts] for response in responses] == [
        ['ToolCallPart', 'ToolCallPart'],
        ['SpeechPart'],
    ]
    assert session.usage.requests == 2


async def test_parallel_tool_calls_answer_is_waited_for_while_a_call_still_runs() -> None:
    """`wait_for_reply()` doesn't return between the first result and the answer to the whole batch."""
    release_slow = asyncio.Event()
    conn = _ToolBatchConnection()
    conn.close_response.set()
    session = RealtimeSession(conn, _slow_until(release_slow))
    async with session:
        events = asyncio.create_task(drain_events(session))
        await _until(lambda: bool(conn.results()))
        waiting = asyncio.create_task(session.wait_for_reply())
        for _ in range(10):
            await asyncio.sleep(0)
        assert not waiting.done()
        release_slow.set()
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await waiting
        assert session._core.requests_ahead() == 0  # pyright: ignore[reportPrivateUsage]
        await session.close()
        events.cancel()


async def test_connection_answering_each_result_keeps_a_reply_per_result() -> None:
    """A custom connection that asks for a response after each result keeps being counted that way."""

    class _PerResult(_ToolBatchConnection):
        @property
        def _answers_tool_calls_per_response(self) -> bool:
            return False

    conn = _PerResult()
    conn.close_response.set()
    session = RealtimeSession(conn, _slow_until(asyncio.Event()))
    async with session:
        events = asyncio.create_task(drain_events(session))
        await _until(lambda: bool(conn.results()))
        # `c1`'s result asked for a reply, and `c2`'s will ask for another.
        await _until(lambda: _requests_counted(session) == 2)
        assert session._core.result_asks_reply('c2')  # pyright: ignore[reportPrivateUsage]
        await session.close()
        events.cancel()


async def test_provider_cancelled_call_leaves_no_reply_owed() -> None:
    """A call the provider cancels (a barge-in) means its batch won't be answered: no reply is owed or waited for.

    Not for the result that already went out either.
    """
    conn = _ToolBatchConnection()
    conn.close_response.set()
    conn.after_close = [ToolCallCancelled(tool_call_ids=['c2'])]
    session = RealtimeSession(conn, _slow_until(asyncio.Event()))
    async with session:
        events = asyncio.create_task(drain_events(session))
        await _until(lambda: bool(conn.results()) and 'c2' not in session._pending_tool_calls)  # pyright: ignore[reportPrivateUsage]
        for _ in range(10):
            await asyncio.sleep(0)
        assert conn.results() == [ToolResult(tool_call_id='c1', output='fast result')]
        assert session._core.requests_ahead() == 0  # pyright: ignore[reportPrivateUsage]
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await session.wait_for_reply()
        await session.close()
        events.cancel()


async def test_result_after_a_sibling_was_cancelled_is_sent_without_counting_a_reply() -> None:
    """A result that lands after the provider cancelled a sibling still goes out, but no reply is owed for it."""
    release_slow = asyncio.Event()
    conn = _ToolBatchConnection(
        [
            ToolCall(tool_call_id='c1', tool_name='slow', args='{}', response_usage_follows=True),
            ToolCall(tool_call_id='c2', tool_name='f', args='{}', response_usage_follows=True),
        ]
    )
    conn.close_response.set()
    conn.after_close = [ToolCallCancelled(tool_call_ids=['c2'])]

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        await (release_slow.wait() if name == 'slow' else asyncio.Event().wait())
        return f'{name} result'

    session = RealtimeSession(conn, runner)
    async with session:
        events = asyncio.create_task(drain_events(session))
        # Once the provider cancelled `c2`, `c1`'s result asks for no reply.
        await _until(lambda: not session._core.result_asks_reply('c1'))  # pyright: ignore[reportPrivateUsage]
        assert 'c1' in session._pending_tool_calls  # pyright: ignore[reportPrivateUsage]
        release_slow.set()
        await _until(lambda: bool(conn.results()))
        for _ in range(10):
            await asyncio.sleep(0)
        assert conn.results() == [ToolResult(tool_call_id='c1', output='slow result')]
        # Only the calling response is a request.
        assert _requests_counted(session) == 1
        await session.close()
        events.cancel()


async def test_lost_conversation_leaves_no_tool_batch_reply_owed() -> None:
    """A reconnect that lost the conversation doesn't count a reply for results it may not have."""

    class _DropsMidBatch(_ToolBatchConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='c1', tool_name='fast', args='{}', response_usage_follows=True)
            yield ToolCall(tool_call_id='c2', tool_name='slow', args='{}', response_usage_follows=True)
            await self.close_response.wait()
            yield RealtimeSessionReconnectEvent(state_restored=False)
            await asyncio.Event().wait()

    conn = _DropsMidBatch()
    session = RealtimeSession(conn, _slow_until(asyncio.Event()))
    async with session:
        events = asyncio.create_task(drain_events(session))
        await _until(lambda: bool(conn.results()))
        conn.close_response.set()
        await _until(lambda: not session._pending_tool_calls)  # pyright: ignore[reportPrivateUsage]
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await session.wait_for_reply()
        assert session._core.requests_ahead() == 0  # pyright: ignore[reportPrivateUsage]
        assert not session._core.result_asks_reply('c2')  # pyright: ignore[reportPrivateUsage]
        await session.close()
        events.cancel()


async def test_tool_batch_reply_that_would_exceed_the_request_limit_ends_the_session() -> None:
    """The reply a batch may be owed is a request like any other, checked against `request_limit`.

    Checked before a result goes out even when it isn't known to be the last: once out, the connection
    would ask for the reply as soon as the calling response is done, before the session could refuse it.
    """
    conn = _ToolBatchConnection([ToolCall(tool_call_id='c1', tool_name='fast', args='{}', response_usage_follows=True)])
    session = RealtimeSession(conn, _slow_until(asyncio.Event()), usage_limits=UsageLimits(request_limit=1))
    with pytest.raises(UsageLimitExceeded):
        async with session:
            events = asyncio.create_task(drain_events(session))
            await asyncio.wait_for(events, _LIVENESS_TIMEOUT)
    assert conn.results() == []


async def test_tool_batch_reply_is_not_counted_when_the_calling_response_trips_a_usage_limit() -> None:
    """Limits are checked against the calling response before its batch counts the next one."""
    conn = _ToolBatchConnection(
        [ToolCall(tool_call_id='c1', tool_name='fast', args='{}', response_usage_follows=True)], input_tokens=5
    )
    session = RealtimeSession(
        conn, _slow_until(asyncio.Event()), usage_limits=UsageLimits(per_request_input_tokens_limit=1)
    )
    with pytest.raises(UsageLimitExceeded, match='per_request_input_tokens_limit'):
        async with session:
            events = asyncio.create_task(drain_events(session))
            await _until(lambda: bool(conn.results()))
            conn.close_response.set()
            await asyncio.wait_for(events, _LIVENESS_TIMEOUT)
    assert session._core.requests_ahead() == 0  # pyright: ignore[reportPrivateUsage]


@pytest.mark.parametrize('failing_call', ['c1', 'c2'])
async def test_tool_result_that_fails_to_send_leaves_no_reply_owed(failing_call: str) -> None:
    """A provider missing one of a batch's results won't answer it, so no reply stays counted.

    `c2` is the last result, sent with the reply counted; `c1` goes out while `c2` still runs.
    """

    class _RefusesTheSlowResult(_ToolBatchConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            if isinstance(content, ToolResult) and content.tool_call_id == failing_call:
                raise RuntimeError('send failed')
            await super().send_input(content)

    release_slow = asyncio.Event()
    conn = _RefusesTheSlowResult()
    conn.close_response.set()
    session = RealtimeSession(conn, _slow_until(release_slow))
    with pytest.raises(RuntimeError, match='send failed'):
        async with session:
            events = asyncio.create_task(drain_events(session))
            if failing_call == 'c2':
                await _until(lambda: bool(conn.results()))
            release_slow.set()
            await _until(lambda: bool(session._parked_errors))  # pyright: ignore[reportPrivateUsage]
            # Only the calling response is a request.
            assert _requests_counted(session) == 1
            with anyio.fail_after(_LIVENESS_TIMEOUT):
                await session.wait_for_reply()
            await asyncio.wait_for(events, _LIVENESS_TIMEOUT)


async def test_tool_result_outside_any_batch_is_a_reply_of_its_own() -> None:
    """A result whose call is in no batch has no sibling to wait for: its reply is counted with it."""
    conn = FakeRealtimeConnection([])
    session = RealtimeSession(conn)
    await session._send_tool_result(  # pyright: ignore[reportPrivateUsage]
        ToolCallPart(tool_name='noop', args={}, tool_call_id='c1'), 'done', []
    )
    assert conn.sent == [ToolResult(tool_call_id='c1', output='done')]
    assert session._core.requests_ahead() == 1  # pyright: ignore[reportPrivateUsage]


async def test_tool_result_outside_any_batch_that_fails_to_send_counts_no_reply() -> None:
    class _Refuses(FakeRealtimeConnection):
        async def send_input(self, content: RealtimeInput) -> None:
            raise RuntimeError('send failed')

    session = RealtimeSession(_Refuses([]))
    with pytest.raises(RuntimeError, match='send failed'):
        await session._send_tool_result(  # pyright: ignore[reportPrivateUsage]
            ToolCallPart(tool_name='noop', args={}, tool_call_id='c1'), 'done', []
        )
    assert session._core.requests_ahead() == 0  # pyright: ignore[reportPrivateUsage]


async def test_wait_for_reply_counts_merged_response_requests_once() -> None:
    """Requests the connection merged into one held `response.create` are not waited for separately."""
    answer = asyncio.Event()

    class _MergesTwoTurns(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield OutputTranscript(text='Paris', is_final=True)
            await answer.wait()
            yield ResponseDone()
            # The second and third turns were sent while the first reply was in flight: one deferred
            # `response.create` answers both.
            yield OutputTranscript(text='Madrid. Rome.', is_final=True)
            yield ResponseDone()

    session = RealtimeSession(_MergesTwoTurns([]))
    async with session:
        await session.send('France?')
        await _until(lambda: _reply_under_way(session))
        await session.send('Spain?')
        await session.send('Italy?')
        answer.set()
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await session.wait_for_reply()
        assert session._core.requests_ahead() == 0  # pyright: ignore[reportPrivateUsage]


async def test_wait_for_reply_returns_when_a_tool_fails_while_the_session_is_iterated() -> None:
    """A tool that raised ends the session's reply: the result the model was waiting for never comes."""

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        raise ValueError('tool exploded')

    session = RealtimeSession(
        BlockingRealtimeConnection([ToolCall(tool_call_id='c1', tool_name='boom', args='{}')]), runner
    )
    with pytest.raises(ValueError, match='tool exploded'):
        async with session:
            await session.send('Go.')
            events = asyncio.create_task(drain_events(session))
            with anyio.fail_after(_LIVENESS_TIMEOUT):
                await session.wait_for_reply()
            await events


async def test_wait_for_reply_after_a_failed_tool_still_waits_for_a_later_reply() -> None:
    """A failed tool ends only its own exchange: a reply asked for afterwards is waited for as usual."""
    answer = asyncio.Event()

    class _AnswersLater(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='c1', tool_name='boom', args='{}')
            await answer.wait()
            yield OutputTranscript(text='later', is_final=True)
            yield ResponseDone()

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        raise ValueError('tool exploded')

    session = RealtimeSession(_AnswersLater([]), runner)
    errors: list[BaseException] = []

    async def consume() -> None:
        # A consumer that reports the tool's failure and keeps listening.
        while True:
            try:
                async for _ in session:
                    pass
            except ValueError as e:
                errors.append(e)
            else:
                return

    async with session:
        events = asyncio.create_task(consume())
        waiting = asyncio.create_task(session.wait_for_reply())
        await session.send('Go.')
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await waiting
            await _until(lambda: bool(errors))
        await session.send('Try again.')
        later = asyncio.create_task(session.wait_for_reply())
        for _ in range(10):
            await asyncio.sleep(0)
        assert not later.done()
        answer.set()
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await later
            await events


async def test_tool_failure_ends_the_wait_for_a_turn_sent_while_it_ran() -> None:
    """A turn sent while a tool ran waits behind that tool's round, which the failure ends: so does the wait for it.

    The provider queues a reply asked for during a tool round behind it (SIM-15), so once the result never comes,
    nothing the session can see promises that reply: `wait_for_reply()` returns, and the reply, if it comes, is
    recorded all the same.
    """
    fail_now = asyncio.Event()
    answer = asyncio.Event()

    class _AnswersTheQueuedTurn(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='c1', tool_name='boom', args='{}', response_usage_follows=True)
            yield SessionUsage(usage=RequestUsage(input_tokens=1), finish_reason='tool_call')
            await answer.wait()
            yield OutputTranscript(text='B answered', is_final=True)
            yield ResponseDone()

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        await fail_now.wait()
        raise ValueError('tool exploded')

    session = RealtimeSession(_AnswersTheQueuedTurn([]), runner)
    errors: list[BaseException] = []

    async def consume() -> None:
        while True:
            try:
                async for _ in session:
                    pass
            except ValueError as e:
                errors.append(e)
            else:
                return

    async with session:
        events = asyncio.create_task(consume())
        await session.send('A')
        await _until(lambda: 'c1' in session._pending_tool_calls)  # pyright: ignore[reportPrivateUsage]
        await session.send('B')  # reserved while A's tool runs
        fail_now.set()
        await _until(lambda: bool(errors))
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await session.wait_for_reply()
        answer.set()
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await events
    assert 'B answered' in [
        part.transcript for message in session.all_messages() for part in message.parts if isinstance(part, SpeechPart)
    ]


async def test_tool_failure_does_not_hide_a_later_server_started_reply() -> None:
    """After a tool fails, a reply the server starts on its own (server VAD) is still waited for."""
    reply_started = asyncio.Event()
    finish_reply = asyncio.Event()

    class _ServerReplies(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='c1', tool_name='boom', args='{}')
            await _until(lambda: bool(session._parked_errors))  # pyright: ignore[reportPrivateUsage]
            yield OutputTranscript(text='unprompted')
            reply_started.set()
            await finish_reply.wait()
            yield ResponseDone()

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        raise ValueError('tool exploded')

    session = RealtimeSession(_ServerReplies([]), runner)
    errors: list[BaseException] = []

    async def consume() -> None:
        while True:
            try:
                async for _ in session:
                    pass
            except ValueError as e:
                errors.append(e)
            else:
                return

    async with session:
        events = asyncio.create_task(consume())
        await reply_started.wait()
        await _until(lambda: _reply_under_way(session))
        waiting = asyncio.create_task(session.wait_for_reply())
        for _ in range(10):
            await asyncio.sleep(0)
        assert not waiting.done()
        finish_reply.set()
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await waiting
            await events


async def test_reconnect_with_tools_running_leaves_no_reply_to_count() -> None:
    """A call a reconnect cancels settles without a result, so its response's results get no reply."""

    class _DropsWhileRunning(_ToolBatchConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='c1', tool_name='slow', args='{}', response_usage_follows=True)
            yield RealtimeSessionReconnectEvent(state_restored=False)
            await asyncio.Event().wait()

    conn = _DropsWhileRunning()
    session = RealtimeSession(conn, _slow_until(asyncio.Event()))
    async with session:
        events = asyncio.create_task(drain_events(session))
        await _until(lambda: not session._pending_tool_calls and session.all_messages() != [])  # pyright: ignore[reportPrivateUsage]
        assert not session._core.result_asks_reply('c1')  # pyright: ignore[reportPrivateUsage]
        await session.close()
        events.cancel()


async def test_failed_tool_leaves_no_reply_to_count() -> None:
    """A tool that raised settles its call without a result, so its response's results can't be answered."""

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        raise ValueError('tool exploded')

    conn = _ToolBatchConnection([ToolCall(tool_call_id='c1', tool_name='boom', args='{}', response_usage_follows=True)])
    conn.close_response.set()
    session = RealtimeSession(conn, runner)
    with pytest.raises(ValueError, match='tool exploded'):
        async with session:
            events = asyncio.create_task(drain_events(session))
            await _until(lambda: bool(session._parked_errors))  # pyright: ignore[reportPrivateUsage]
            assert not session._core.result_asks_reply('c1')  # pyright: ignore[reportPrivateUsage]
            assert conn.results() == []
            await asyncio.wait_for(events, _LIVENESS_TIMEOUT)


async def test_tool_failure_while_another_exchange_streams_still_ends_its_exchange() -> None:
    """A tool failing while an unrelated reply streams doesn't leave the failed exchange owed."""
    fail_now = asyncio.Event()
    finish_b = asyncio.Event()

    class _BStreamsWhileAFails(FakeRealtimeConnection):
        async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
            yield ToolCall(tool_call_id='c1', tool_name='boom', args='{}', response_usage_follows=True)
            yield SessionUsage(usage=RequestUsage(input_tokens=1), finish_reason='tool_call')
            yield OutputTranscript(text='B is streaming')
            fail_now.set()
            await finish_b.wait()
            # The wait can end, and the session close, before this is read.
            yield ResponseDone()  # pragma: lax no cover
            await asyncio.Event().wait()  # pragma: no cover

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        await fail_now.wait()
        raise ValueError('tool exploded')

    session = RealtimeSession(_BStreamsWhileAFails([]), runner)
    errors: list[BaseException] = []

    async def consume() -> None:
        while True:
            try:
                async for _ in session:
                    pass
            except ValueError as e:
                errors.append(e)
            else:
                return

    async with session:
        events = asyncio.create_task(consume())
        await session.send('A')
        await _until(lambda: bool(errors))
        finish_b.set()
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            await session.wait_for_reply()
        await session.close()
        events.cancel()


async def test_wait_for_reply_returns_when_a_tool_result_trips_the_request_limit() -> None:
    """The request a tool result would make can exceed `request_limit`; the reply then never comes."""

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'done'

    session = RealtimeSession(
        BlockingRealtimeConnection(
            [
                ToolCall(tool_call_id='c1', tool_name='noop', args='{}', response_usage_follows=True),
                SessionUsage(usage=RequestUsage(input_tokens=1), finish_reason='tool_call'),
            ],
            after_input=True,
        ),
        runner,
        usage_limits=UsageLimits(request_limit=1),
    )
    with pytest.raises(UsageLimitExceeded):
        async with session:
            await session.send('Go.')
            events = asyncio.create_task(drain_events(session))
            with anyio.fail_after(_LIVENESS_TIMEOUT):
                await session.wait_for_reply()
            await events
    returns = [part for message in session.all_messages() for part in message.parts if isinstance(part, ToolReturnPart)]
    assert [part.outcome for part in returns] == ['failed']


# --- context window ----------------------------------------------------------------------------


def _reply(tokens: RequestUsage) -> list[RealtimeCodecEvent]:
    return [OutputTranscript(text='hi', is_final=True), SessionUsage(tokens), ResponseDone()]


async def test_context_window_used_is_derived_from_the_latest_response() -> None:
    """Without a provider-reported fraction, the session computes it as a standard run does."""
    conn = FakeRealtimeConnection(
        [
            *_reply(RequestUsage(input_tokens=100, output_tokens=20)),
            *_reply(RequestUsage(input_tokens=200, output_tokens=50)),
        ]
    )
    session = RealtimeSession(conn, profile=RealtimeModelProfile({**_profile(), 'context_window': 1000}))
    assert session.context_window_used is None
    await collect_events(session)
    assert session.context_window_used == 0.25


@pytest.mark.parametrize(
    'profile',
    [
        pytest.param(_profile(), id='unknown-window'),
        pytest.param(RealtimeModelProfile({**_profile(), 'context_window': 0}), id='empty-window'),
        pytest.param(
            RealtimeModelProfile({**_profile(), 'context_window': 1000, 'response_usage_covers_context': False}),
            id='usage-not-context',
        ),
    ],
)
async def test_context_window_used_is_none_when_it_cannot_be_derived(profile: RealtimeModelProfile) -> None:
    """An unknown window, or response usage that doesn't measure the context (xAI, GPT-Live), gives `None`."""
    session = RealtimeSession(
        FakeRealtimeConnection(_reply(RequestUsage(input_tokens=200, output_tokens=50))), profile=profile
    )
    await collect_events(session)
    assert session.context_window_used is None


async def test_context_window_used_is_none_without_response_tokens() -> None:
    session = RealtimeSession(
        FakeRealtimeConnection(_reply(RequestUsage())),
        profile=RealtimeModelProfile({**_profile(), 'context_window': 1000}),
    )
    await collect_events(session)
    assert session.context_window_used is None


async def test_context_window_used_is_none_before_any_response() -> None:
    session = RealtimeSession(
        FakeRealtimeConnection([]),
        message_history=[ModelRequest.user_text_prompt('hi')],
        profile=RealtimeModelProfile({**_profile(), 'context_window': 1000}),
    )
    assert session.context_window_used is None


async def test_reported_context_window_used_is_the_latest_snapshot() -> None:
    """A provider-reported fraction wins over the derived one, and is replaced, not summed: it can go down
    after the provider compacts. A usage report that says nothing about it leaves it as it was."""
    conn = FakeRealtimeConnection(
        [
            SessionUsage(RequestUsage(), response_scoped=False, context_window_used=0.5),
            *_reply(RequestUsage(input_tokens=900, output_tokens=50)),
            SessionUsage(RequestUsage(), response_scoped=False, context_window_used=0.2),
            SessionUsage(RequestUsage(audio_seconds=1), response_scoped=False),
        ]
    )
    session = RealtimeSession(conn, profile=RealtimeModelProfile({**_profile(), 'context_window': 1000}))
    await collect_events(session)
    assert session.context_window_used == 0.2
    assert session.usage.audio_seconds == 1


async def test_run_context_context_window_used_in_a_session() -> None:
    """Inside a session, `ctx.context_window_used` is the session's value, not one computed from the run."""
    observed: list[float | None] = []
    agent = Agent(deps_type=type(None))

    @agent.tool
    async def check_context(ctx: RunContext[None]) -> str:
        observed.append(ctx.context_window_used)
        return 'done'

    conn = FakeRealtimeConnection(
        [
            SessionUsage(RequestUsage(), response_scoped=False, context_window_used=0.4),
            ToolCall(tool_call_id='tc', tool_name='check_context', args='{}'),
            ResponseDone(),
        ]
    )
    async with agent.realtime(FakeRealtimeModel(conn)).session() as session:
        async for _ in session:
            pass

    assert observed == [0.4]


async def test_user_turn_anchored_to_refused_content_is_still_recorded() -> None:
    """The user started speaking right after content the provider then refused: their turn outlives its anchor.

    The refusal takes the content back out of history, so the place the turn was anchored to is gone; the turn is
    kept anyway, at the end, rather than lost.
    """

    def answer(index: int, content: RealtimeInput) -> list[RealtimeCodecEvent]:
        return [
            RealtimeInputSpeechStartEvent(item_id='item_u1'),
            InputRejected(index, refused='content'),
            _REFUSAL,
            InputTranscript('hello', is_final=True, item_id='item_u1'),
        ]

    session = RealtimeSession(_AnswersEachInput(answer))
    async with session:
        await session.send('refused', respond=False)
        for _ in range(20):  # let the pump read everything
            await asyncio.sleep(0)
        assert session.all_messages() == snapshot(
            [ModelRequest(parts=[SpeechPart(speaker='user', transcript='hello')], timestamp=IsDatetime())]
        )


# --- ending the provider session on close ---------------------------------------------------------


class _EndingConnection(BlockingRealtimeConnection):
    """A connection that stays open, and reports usage only as `_end_session()` ends the provider session."""

    transport_errors = (ConnectionError,)

    def __init__(
        self,
        reports: Sequence[SessionUsage] = (),
        *,
        fails: bool = False,
        hangs: bool = False,
        events: Sequence[RealtimeCodecEvent] = (),
    ) -> None:
        super().__init__(list(events))
        self._reports = list(reports)
        self._fails = fails
        self._hangs = hangs
        self.ended = 0

    async def _end_session(self) -> AsyncIterator[SessionUsage]:
        self.ended += 1
        for report in self._reports:
            yield report
        if self._fails:
            raise ConnectionError('the link went away')
        if self._hangs:
            await asyncio.Event().wait()


async def test_closing_records_the_usage_the_provider_reports_as_its_session_ends() -> None:
    """A provider that bills by the session (GPT-Live) reports its last seconds only when the session ends."""
    conn = _EndingConnection(
        [SessionUsage(RequestUsage(audio_seconds=5), response_scoped=False, context_window_used=0.25)]
    )
    async with RealtimeSession(conn, _noop_runner) as session:
        # Reading the connection, as a session that is used does.
        stream = asyncio.ensure_future(anext(aiter(session)))
        await asyncio.sleep(0)
    stream.cancel()

    assert conn.ended == 1
    assert session.usage.audio_seconds == 5
    assert session.context_window_used == 0.25


async def test_closing_records_a_response_report_on_a_provider_whose_responses_are_requests() -> None:
    """Such a provider counts a request as it records a response: a report made at the close only adds usage."""
    conn = _EndingConnection([SessionUsage(RequestUsage(input_tokens=10))])
    async with RealtimeSession(conn, _noop_runner, usage_limits=UsageLimits(request_limit=0)) as session:
        pass

    assert session.usage.input_tokens == 10
    assert session.usage.requests == 0


async def test_a_session_that_never_read_still_ends_the_provider_session() -> None:
    conn = _EndingConnection([SessionUsage(RequestUsage(audio_seconds=2), response_scoped=False)])
    async with RealtimeSession(conn, _noop_runner) as session:
        pass

    assert conn.ended == 1
    assert session.usage.audio_seconds == 2


async def test_a_sideband_does_not_end_the_provider_session() -> None:
    """Ending it would end the browser's WebRTC call, which closing a sideband only detaches from."""
    conn = _EndingConnection([SessionUsage(RequestUsage(audio_seconds=2), response_scoped=False)])
    async with RealtimeSession(conn, _noop_runner, owns_media=False):
        pass

    assert conn.ended == 0


async def test_a_session_stopped_by_a_usage_limit_still_ends_the_provider_session() -> None:
    """A limit stops the session reading, not the provider: its session is still open, and still bills."""
    conn = _EndingConnection(
        [SessionUsage(RequestUsage(audio_seconds=3), response_scoped=False)],
        events=[SessionUsage(RequestUsage(input_tokens=10), response_scoped=False)],
    )
    session = RealtimeSession(conn, _noop_runner, usage_limits=UsageLimits(input_tokens_limit=5))
    with pytest.raises(UsageLimitExceeded):
        async with session:
            async for _ in session:
                pass  # pragma: no cover

    assert conn.ended == 1
    assert session.usage.audio_seconds == 3


@pytest.mark.parametrize('failure', ['fails', 'hangs'])
async def test_a_provider_that_does_not_end_its_session_cleanly_keeps_what_it_reported(
    failure: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Closing still finishes, promptly, with the usage reported before the link failed or the provider went quiet."""
    monkeypatch.setattr(realtime_session_module, '_END_SESSION_TIMEOUT', 0.01)
    conn = _EndingConnection(
        [SessionUsage(RequestUsage(audio_seconds=2), response_scoped=False)],
        fails=failure == 'fails',
        hangs=failure == 'hangs',
    )
    with anyio.fail_after(_LIVENESS_TIMEOUT):
        async with RealtimeSession(conn, _noop_runner) as session:
            pass

    assert conn.ended == 1
    assert session.usage.audio_seconds == 2


async def test_a_cancelled_session_does_not_wait_to_end_the_provider_session() -> None:
    conn = _EndingConnection(hangs=True)
    with anyio.move_on_after(0.01):
        async with RealtimeSession(conn, _noop_runner):
            await asyncio.Event().wait()

    assert conn.ended == 0


async def test_usage_reported_as_the_session_ends_counts_against_the_limits() -> None:
    conn = _EndingConnection([SessionUsage(RequestUsage(input_tokens=10), response_scoped=False)])
    with pytest.raises(UsageLimitExceeded):
        async with RealtimeSession(conn, _noop_runner, usage_limits=UsageLimits(input_tokens_limit=5)):
            pass


async def test_a_connection_whose_responses_are_not_requests_counts_each_usage_report() -> None:
    """A version 1 connection whose model makes requests of its own (as GPT-Live's backend does) counts each report."""
    conn = FakeRealtimeConnection(
        [
            OutputTranscript(text='Hi.', is_final=True),
            SessionUsage(RequestUsage(input_tokens=1)),
            SessionUsage(RequestUsage(input_tokens=2)),
            ResponseDone(),
        ]
    )
    session = RealtimeSession(conn, profile=RealtimeModelProfile(responses_are_requests=False))
    async with session:
        await drain_events(session)
    assert (session.usage.requests, session.usage.input_tokens) == (2, 3)


async def test_a_connection_whose_frames_are_no_generator_is_read_to_the_end() -> None:
    """`frames()` can return any async iterator: there's only nothing to close when the session stops reading."""

    class _ListedFrames:
        def __init__(self, frames: list[RealtimeFrame]) -> None:
            self._frames = frames

        def __aiter__(self) -> _ListedFrames:
            return self

        async def __anext__(self) -> RealtimeFrame:
            if not self._frames:
                raise StopAsyncIteration
            return self._frames.pop(0)

    class _Listed(FakeRealtimeConnection):
        def frames(self) -> AsyncIterator[RealtimeFrame]:
            return _ListedFrames(
                [
                    [ResponseStarted(response_id='r1'), OutputTranscript(text='Hi.', is_final=True)],
                    [ResponseDone(), ResponseEnded(response_id='r1', status='completed')],
                ]
            )

    session = RealtimeSession(_Listed([]))
    await collect_events(session)
    assert [
        part.transcript for message in session.all_messages() for part in message.parts if isinstance(part, SpeechPart)
    ] == ['Hi.']


async def test_a_response_over_the_request_limit_within_one_frame_is_neither_recorded_nor_counted() -> None:
    """The session refuses a response as it handles the frame that started it, which can have ended it too."""

    class _OneFrame(FakeRealtimeConnection):
        async def frames(self) -> AsyncIterator[RealtimeFrame]:
            yield [
                ResponseStarted(response_id='r1'),
                OutputTranscript(text='Hi.', is_final=True),
                ResponseDone(),
                ResponseEnded(response_id='r1', status='completed'),
            ]
            await asyncio.Event().wait()  # pragma: lax no cover

    model = FakeRealtimeModel(_OneFrame([]))
    agent: Agent[None, str] = Agent()
    async with agent.realtime(model, usage_limits=UsageLimits(request_limit=0)).session() as session:
        with pytest.raises(UsageLimitExceeded, match='request_limit of 0'):
            async for _ in session:
                pass
    assert session.usage.requests == 0
    assert session.all_messages() == []


async def test_a_response_whose_first_frame_trips_a_token_limit_is_recorded() -> None:
    """A token limit its own usage tripped stops the session, but the response was made: it is recorded and counted."""

    class _OneFrame(FakeRealtimeConnection):
        async def frames(self) -> AsyncIterator[RealtimeFrame]:
            yield [
                ResponseStarted(response_id='r1'),
                SessionUsage(usage=RequestUsage(input_tokens=100)),
                OutputTranscript(text='Hi.', is_final=True),
            ]
            await asyncio.Event().wait()  # pragma: lax no cover

    model = FakeRealtimeModel(_OneFrame([]))
    agent: Agent[None, str] = Agent()
    async with agent.realtime(model, usage_limits=UsageLimits(input_tokens_limit=50)).session() as session:
        with pytest.raises(UsageLimitExceeded, match='next request would exceed the input_tokens_limit of 50'):
            async for _ in session:
                pass
    assert session.usage.requests == 1
    assert [type(message).__name__ for message in session.all_messages()] == ['ModelResponse']


async def test_a_turn_committed_while_a_response_is_spoken_follows_it() -> None:
    """A turn the user commits while a response is spoken follows that response in history."""
    conn = _ContinuousMicrophoneConnection(
        [
            AudioDelta(data=b'\x01\x00'),
            OutputTranscript(text='Hello.', is_final=True),
            _MIC,
            _RELEASE,
            ResponseDone(),
            InputTranscript(text='Hi.', is_final=True),
        ]
    )
    session = RealtimeSession(conn, audio_retention='all')
    conn.session = session
    async with session:
        await drain_events(session)
    assert [
        (type(message).__name__, [part.transcript for part in message.parts if isinstance(part, SpeechPart)])
        for message in session.all_messages()
    ] == snapshot([('ModelResponse', ['Hello.']), ('ModelRequest', ['Hi.'])])


async def test_context_window_used_moves_with_the_usage_counted_in_the_same_frame() -> None:
    """A frame's usage is counted as the frame is applied: its `context_window_used` is taken then too.

    Before, the session took it only when it handled the usage report itself, after the frame's earlier events:
    a reply waiter woken by the frame read the new usage with the old fraction.
    """

    class _AnswersWithUsage(FakeRealtimeConnection):
        async def frames(self) -> AsyncIterator[RealtimeFrame]:
            await self._input_sent.wait()
            yield [
                ResponseStarted(response_id='r1', answers=(0,)),
                OutputTranscript(text='Hi.', is_final=True),
                ResponseDone(),
                ResponseEnded(response_id='r1', status='completed'),
                SessionUsage(RequestUsage(input_tokens=10), response_scoped=False, context_window_used=0.42),
            ]
            # (The session can stop reading before it asks for the next frame.)
            await asyncio.Event().wait()  # pragma: lax no cover

    session = RealtimeSession(_AnswersWithUsage([]))
    async with session:
        await session.send('Hello')
        await session.wait_for_reply()
        assert (session.usage.input_tokens, session.context_window_used) == (10, 0.42)


async def test_context_window_used_is_the_frames_latest_even_when_handling_stops_early() -> None:
    """A limit tripped by a frame's first usage report stops the session handling the rest: the fraction is still the
    frame's latest, as the usage counted is all of the frame's."""

    class _TwoReports(FakeRealtimeConnection):
        async def frames(self) -> AsyncIterator[RealtimeFrame]:
            yield [
                SessionUsage(RequestUsage(input_tokens=10), response_scoped=False, context_window_used=0.4),
                SessionUsage(RequestUsage(input_tokens=20), response_scoped=False, context_window_used=0.2),
            ]
            # (The session can stop reading before it asks for the next frame.)
            await asyncio.Event().wait()  # pragma: lax no cover

    session = RealtimeSession(_TwoReports([]), usage_limits=UsageLimits(input_tokens_limit=5))
    with pytest.raises(UsageLimitExceeded):
        async with session:
            async for _ in session:
                pass
    assert (session.usage.input_tokens, session.context_window_used) == (30, 0.2)


async def test_a_stale_usage_report_still_moves_the_context_window_used() -> None:
    """A report about a response already over isn't counted, but it is still the provider's latest context reading."""

    class _StaleReport(FakeRealtimeConnection):
        async def frames(self) -> AsyncIterator[RealtimeFrame]:
            yield [StaleEvent(SessionUsage(RequestUsage(input_tokens=10), context_window_used=0.3))]

    session = RealtimeSession(_StaleReport([]))
    await collect_events(session)
    assert (session.usage.input_tokens, session.context_window_used) == (0, 0.3)


class _PrunesToolItems(FakeRealtimeConnection):
    """Answers a tool's result, and deletes the tool rounds the session says are over.

    With `link_drops`, the first attempt hits a dead link; another frame comes once `more` is set.
    """

    transport_errors = (ConnectionResetError,)

    def __init__(self, *, link_drops: bool = False, keeps: bool = False) -> None:
        super().__init__([])
        self.link_drops = link_drops
        self.keeps = keeps
        self.attempts = 0
        self.pruned: list[str] = []
        self.result_sent = asyncio.Event()
        self.more = asyncio.Event()

    @property
    def _prunes_tool_calls(self) -> bool:
        return True

    async def send_input(self, content: RealtimeInput) -> None:
        await super().send_input(content)
        # (The tool's result is all the session sends.)
        self.result_sent.set()

    async def codec_events(self) -> AsyncIterator[RealtimeCodecEvent]:
        yield ToolCall(tool_call_id='c1', tool_name='noop', args='{}')
        await self.result_sent.wait()
        yield OutputTranscript(text='Done.', is_final=True)
        yield ResponseDone()
        await self.more.wait()
        yield SessionUsage(RequestUsage(input_tokens=1), response_scoped=False)
        await asyncio.Event().wait()

    async def _prune_tool_calls(self, calls: Sequence[ToolCallPart]) -> Sequence[str]:
        self.attempts += 1
        if self.link_drops and self.attempts == 1:
            raise ConnectionResetError('connection reset by peer')
        if self.keeps:
            return []
        self.pruned.extend(call.tool_call_id for call in calls)
        return [call.tool_call_id for call in calls]


@pytest.mark.parametrize('link_drops', [False, True])
async def test_tool_rounds_the_connection_prunes_leave_the_replay(link_drops: bool) -> None:
    """Once the answer completes, the connection is asked to prune the round: what it deleted, a replay leaves out.

    A link that drops as it deletes prunes nothing: the round stays in the replay, and is pruned once the next frame
    is handled (from the conversation the reconnect replayed it into).
    """

    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'done'

    def calls(messages: list[ModelMessage]) -> list[str]:
        return [part.tool_call_id for message in messages for part in message.parts if isinstance(part, ToolCallPart)]

    conn = _PrunesToolItems(link_drops=link_drops)
    session = RealtimeSession(conn, runner)
    async with session:
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            async for event in session:  # pragma: no branch
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break
            await _until(lambda: conn.attempts == 1)
        assert calls(session._core.replayable_messages()) == ([] if not link_drops else ['c1'])  # pyright: ignore[reportPrivateUsage]
        conn.more.set()
        await _until(lambda: conn.pruned == ['c1'])
        assert calls(session._core.replayable_messages()) == []  # pyright: ignore[reportPrivateUsage]

    assert calls(session.all_messages()) == ['c1']


async def test_tool_rounds_the_connection_keeps_stay_in_the_replay() -> None:
    async def runner(name: str, args: dict[str, Any], call_id: str) -> str:
        return 'done'

    conn = _PrunesToolItems(keeps=True)
    session = RealtimeSession(conn, runner)
    async with session:
        with anyio.fail_after(_LIVENESS_TIMEOUT):
            async for event in session:  # pragma: no branch
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break
            await _until(lambda: conn.attempts == 1)
        replayed = session._core.replayable_messages()  # pyright: ignore[reportPrivateUsage]
        assert any(isinstance(part, ToolCallPart) for message in replayed for part in message.parts)
