"""WebSocket cassette utilities for realtime provider tests.

Realtime providers talk over a persistent WebSocket rather than the request/response HTTP that
the HTTP cassettes capture, so those can't record their traffic. These helpers record and
replay the actual JSON frames exchanged with the provider, letting cassette-backed tests exercise
the *real* protocol offline:

- OpenAI Realtime and Azure OpenAI connect through the OpenAI realtime module's `websockets`
  reference; xAI uses its own module reference.
- Gemini Live connects through the `google-genai` SDK, which itself uses `websockets` under
  `google.genai.live.ws_connect` (patched there). The SDK calls `.send`, `.recv(decode=False)`, and
  `.close` on the returned object, so the same raw-frame engine serves both providers.

The replay path validates outbound frames as well as replaying inbound ones, so a cassette pins both
provider behaviour *and* the exact wire messages the library sends. Recording scrubs anything
secret-looking, redacts internal provider backend config a provider may echo back (e.g. xAI's
`session.updated` carries VAD/ASR tuning and an internal service address), and truncates inbound audio
payloads so cassettes stay small.

Each interaction also records when it happened, in seconds since the recording's first interaction.
Replay still delivers frames back to back, but exposes that recorded time as a clock
(`ReplayWebSocket.now`) reading when the inbound frame being handled was recorded. An adapter that infers a turn
boundary from wall-clock silence (GPT-Live) reads that clock instead of the real one, so a replayed
silence lasts as long as the recorded one did, without the suite waiting it out. Cassettes recorded
before timing was captured replay as before, against the real clock.
"""

from __future__ import annotations as _annotations

import asyncio
import collections
import json
import os
import re
import time
from collections.abc import AsyncGenerator, Awaitable, Callable, Generator
from contextlib import asynccontextmanager, contextmanager, suppress
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, cast
from unittest import mock

from pydantic_ai._utils import is_str_dict

from ..conftest import try_import

with try_import() as imports_successful:
    import yaml
    from websockets.exceptions import ConnectionClosedError, ConnectionClosedOK
    from websockets.frames import Close


_MessageKind = Literal['message']
_CloseKind = Literal['close']
_Direction = Literal['sent', 'received']

ProviderName = Literal['openai', 'gemini', 'xai', 'elevenlabs', 'openai_live', 'elevenlabs_agents']

# Outbound frame fields that carry random client-generated ids, normalized to stable placeholders so
# replay can validate frame *structure* without depending on a fresh random value each run.
_CLIENT_ID_KEYS = frozenset({'id', 'item_id', 'previous_item_id'})
_CLIENT_ID_RE = re.compile(r'^[0-9a-f]{24}$')

# Inbound audio payloads are truncated to this many decoded bytes at record time. The exact audio
# content isn't asserted (tests use transcripts and `IsBytes()`/length checks), so a short prefix
# keeps cassettes tiny without changing the event shapes the session produces.
_MAX_AUDIO_BYTES = 32

# OpenAI names its output-audio delta event differently on the GA vs beta surfaces.
_OPENAI_AUDIO_DELTA_TYPES = frozenset(
    {'response.output_audio.delta', 'response.audio.delta', 'session.output_audio.delta'}
)
# GPT-Live's outbound audio event, the counterpart of OpenAI Realtime's `input_audio_buffer.append`.
_AUDIO_APPEND_TYPES = frozenset({'input_audio_buffer.append', 'session.input_audio.append'})


def _gemini_realtime_audio(frame: dict[str, Any]) -> dict[str, Any] | None:
    """The `realtime_input.audio` blob of an outbound Gemini microphone frame, if it is one."""
    realtime_input = frame.get('realtime_input')
    if not isinstance(realtime_input, dict):
        return None
    audio = cast('dict[str, Any]', realtime_input).get('audio')
    return cast('dict[str, Any]', audio) if isinstance(audio, dict) else None


def _transcription_model(frame: dict[str, Any]) -> object:
    """The input transcription model an OpenAI GA `session.update` frame sets, if any."""
    value: object = frame
    for key in ('session', 'audio', 'input', 'transcription', 'model'):
        value = value.get(key) if is_str_dict(value) else None
    return value


def _is_audio_send(frame: dict[str, Any]) -> bool:
    """Whether an outbound frame is microphone audio, on the OpenAI, GPT-Live, Gemini, or ElevenLabs protocol."""
    return (
        frame.get('type') in _AUDIO_APPEND_TYPES
        or _gemini_realtime_audio(frame) is not None
        # ElevenLabs: the one client frame without a `type`.
        or isinstance(frame.get('user_audio_chunk'), str)
    )


# Value patterns that must never land in a cassette (API keys / bearer tokens). Belt-and-braces:
# keys travel in connection headers / the URL, not in frames, but a provider could echo one back.
_SECRET_RE = re.compile(
    r'(sk-[A-Za-z0-9_\-]{8,}|(?<![A-Za-z0-9])sk_[A-Za-z0-9]{20,}|ek_[A-Za-z0-9_\-]{8,}|AIza[A-Za-z0-9_\-]{10,}|xai-[A-Za-z0-9_\-]{8,}|Bearer\s+\S+)'
)
_SECRET_PLACEHOLDER = '<scrubbed>'

# The credential values actually configured for a recording session. Azure keys are opaque strings
# with no recognizable prefix, so pattern matching can't catch them: any exact occurrence of a
# configured value is redacted from every frame instead.
_SECRET_ENV_VARS = (
    'OPENAI_API_KEY',
    'AZURE_OPENAI_API_KEY',
    'AZURE_VOICELIVE_API_KEY',
    'GEMINI_API_KEY',
    'GOOGLE_API_KEY',
    'XAI_API_KEY',
    'ELEVENLABS_API_KEY',
)


def _configured_secret_values() -> tuple[str, ...]:
    """The non-trivial credential values currently configured, longest first so prefixes can't shadow."""
    values = {value for var in _SECRET_ENV_VARS if (value := os.environ.get(var)) and len(value) >= 8}
    return tuple(sorted(values, key=len, reverse=True))


# Frame keys whose values are internal provider backend config, not part of the public wire protocol
# the session consumes. Providers can echo these back on inbound frames (xAI's `session.updated`
# carries VAD/ASR tuning blocks that include an internal gRPC service address and model artifact
# names), so their whole subtree is redacted to keep provider infrastructure details out of cassettes.
# Redacting inbound values is safe: the session ignores these fields and no test asserts on them.
_INTERNAL_CONFIG_KEYS = frozenset(
    {
        'xvad_settings',
        'asr_classifier',
        'response_patient_starter_config',
        'model_address',
        'xvad_model_name',
    }
)


@dataclass
class CassetteMessage:
    """A single JSON WebSocket frame."""

    direction: _Direction
    data: dict[str, Any]
    kind: _MessageKind = 'message'
    at: float | None = field(default=None, compare=False)
    """Seconds since the recording's first interaction; `None` in a cassette recorded before timing was captured.

    Left out of equality: the same frames in the same order are the same conversation, whenever they arrived.
    """


@dataclass
class CassetteClose:
    """A terminal WebSocket close observed while receiving."""

    code: int
    reason: str
    ok: bool
    kind: _CloseKind = 'close'
    at: float | None = field(default=None, compare=False)
    """Seconds since the recording's first interaction; `None` in a cassette recorded before timing was captured.

    Left out of equality: the same frames in the same order are the same conversation, whenever they arrived.
    """


RealtimeCassetteInteraction = CassetteMessage | CassetteClose


@dataclass
class RealtimeCassette:
    """An ordered list of normalized WebSocket interactions."""

    version: int = 1
    interactions: list[RealtimeCassetteInteraction] = field(default_factory=list['RealtimeCassetteInteraction'])
    _disconnect: Callable[[], Awaitable[None]] | None = field(default=None, init=False, repr=False, compare=False)
    _replay: ReplayWebSocket | None = field(default=None, init=False, repr=False, compare=False)
    _origin: float | None = field(default=None, init=False, repr=False, compare=False)

    def elapsed(self) -> float:
        """Seconds since this recording's first interaction, to the millisecond. Used while recording."""
        now = time.monotonic()
        if self._origin is None:
            self._origin = now
        return round(now - self._origin, 3)

    async def disconnect(self) -> None:
        """Force the active recorded connection to drop; replay consumes the recorded close next."""
        if self._disconnect is None:
            raise RuntimeError('The realtime cassette has no active WebSocket connection.')
        await self._disconnect()

    async def before_audio_send(self) -> None:
        """Hold a microphone frame until it is the next thing the recording has happen. A no-op when recording.

        Call it before each `send_audio()` in a test that streams a microphone alongside other traffic:
        see `ReplayWebSocket.wait_for_audio_send_turn`.
        """
        if self._replay is not None:
            await self._replay.wait_for_audio_send_turn()

    def bind_disconnect(self, disconnect: Callable[[], Awaitable[None]]) -> None:
        """Bind the active transport's test-only disconnect operation."""
        self._disconnect = disconnect

    @classmethod
    def load(cls, path: Path) -> RealtimeCassette:
        # libyaml's loader where PyYAML was built with it: the pure-Python one takes a noticeable share of a
        # second over a cassette's thousands of frames.
        loader = getattr(yaml, 'CSafeLoader', yaml.SafeLoader)
        raw = cast('dict[str, Any]', yaml.load(path.read_text(encoding='utf-8'), Loader=loader))
        interactions: list[RealtimeCassetteInteraction] = []
        for item in cast('list[dict[str, Any]]', raw.get('interactions', [])):
            at = item.get('at')
            if item.get('kind') == 'close':
                interactions.append(
                    CassetteClose(code=item['code'], reason=item.get('reason', ''), ok=item['ok'], at=at)
                )
            else:
                interactions.append(CassetteMessage(direction=item['direction'], data=item['data'], at=at))
        return cls(version=raw.get('version', 1), interactions=interactions)

    def dump(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        interactions: list[dict[str, Any]] = [
            {
                **(
                    {'kind': 'message', 'direction': i.direction}
                    if isinstance(i, CassetteMessage)
                    else {'kind': 'close', 'code': i.code, 'reason': i.reason, 'ok': i.ok}
                ),
                # Before the payload, so a reader scanning a cassette sees when each frame happened.
                **({'at': i.at} if i.at is not None else {}),
                **({'data': i.data} if isinstance(i, CassetteMessage) else {}),
            }
            for i in self.interactions
        ]
        path.write_text(
            yaml.safe_dump(
                {'version': self.version, 'interactions': interactions}, sort_keys=False, allow_unicode=True
            ),
            encoding='utf-8',
        )


CassettePlan = Literal['replay', 'record', 'error_missing']


def realtime_cassette_plan(*, cassette_exists: bool, record_mode: str | None) -> CassettePlan:
    """Decide replay vs. record, mirroring the repo's `--record-mode` values."""
    mode = (record_mode or 'none').strip().lower()
    if mode in {'rewrite', 'all'}:
        return 'record'
    if mode == 'once':
        return 'replay' if cassette_exists else 'record'
    # 'none' (and anything else): replay only.
    return 'replay' if cassette_exists else 'error_missing'


def _scrub(value: Any) -> Any:
    """Recursively redact secret-looking strings and internal provider config from a frame."""
    if isinstance(value, str):
        value = _SECRET_RE.sub(_SECRET_PLACEHOLDER, value)
        for secret in _configured_secret_values():
            value = value.replace(secret, _SECRET_PLACEHOLDER)
        return value
    if isinstance(value, dict):
        return {
            key: _SECRET_PLACEHOLDER if key in _INTERNAL_CONFIG_KEYS else _scrub(item)
            for key, item in cast('dict[str, Any]', value).items()
        }
    if isinstance(value, list):
        return [_scrub(item) for item in cast('list[Any]', value)]
    return value


def _truncate_b64_audio(payload: str) -> str:
    """Truncate a base64 audio payload to the first `_MAX_AUDIO_BYTES` decoded bytes."""
    # base64 encodes 3 bytes per 4 chars; keep enough chars for the byte budget, on a 4-char boundary.
    keep = ((_MAX_AUDIO_BYTES + 2) // 3) * 4
    return payload[:keep]


def _truncate_audio(frame: dict[str, Any]) -> dict[str, Any]:
    """Shrink audio payloads in place-ish, returning a frame safe to store in a cassette.

    Handles the OpenAI inbound shape (`{'type': 'response.output_audio.delta', 'delta': <b64>}`), the
    OpenAI outbound shape (`{'type': 'input_audio_buffer.append', 'audio': <b64>}`), their GPT-Live
    counterparts (`session.output_audio.delta` / `session.input_audio.append`), and the Gemini shape
    (`inlineData.data`, used in both directions, and the `realtime_input.audio.data` /
    `realtime_input.video.data` the SDK sends for microphone audio and images). Transcript deltas (also
    keyed `delta` on OpenAI, but on non-audio event types) are left untouched.

    Outbound audio matters as much as inbound: a test that streams a microphone for several turns
    sends megabytes of PCM, and a cassette is a file in git that a human is meant to be able to read.
    What the bytes *are* is never what a test asserts — only that the frame was sent at that point —
    so both sides truncate identically and outbound frames still compare equal on replay.
    """
    if frame.get('type') in _OPENAI_AUDIO_DELTA_TYPES and isinstance(frame.get('delta'), str):
        return {**frame, 'delta': _truncate_b64_audio(frame['delta'])}
    if frame.get('type') in _AUDIO_APPEND_TYPES and isinstance(frame.get('audio'), str):
        return {**frame, 'audio': _truncate_b64_audio(frame['audio'])}
    if (audio := _gemini_realtime_audio(frame)) is not None and isinstance(audio.get('data'), str):
        audio = {**audio, 'data': _truncate_b64_audio(audio['data'])}
        return {**frame, 'realtime_input': {**frame['realtime_input'], 'audio': audio}}
    realtime_input = frame.get('realtime_input')
    if isinstance(realtime_input, dict):
        # A Gemini video frame (`session.send(image)`): as large as any audio, and just as unasserted.
        video = cast('dict[str, Any]', realtime_input).get('video')
        if isinstance(video, dict) and isinstance(data := cast('dict[str, Any]', video).get('data'), str):
            video = {**cast('dict[str, Any]', video), 'data': _truncate_b64_audio(data)}
            return {**frame, 'realtime_input': {**cast('dict[str, Any]', realtime_input), 'video': video}}
    # ElevenLabs outbound microphone chunk (the one client message without a `type` field).
    if isinstance(frame.get('user_audio_chunk'), str):
        return {**frame, 'user_audio_chunk': _truncate_b64_audio(frame['user_audio_chunk'])}
    # ElevenLabs inbound audio: truncate the payload and drop the per-character TTS timing block,
    # which is hundreds of numbers per frame that the session never reads.
    if frame.get('type') == 'audio' and isinstance(audio_event := frame.get('audio_event'), dict):
        audio_event = cast('dict[str, Any]', audio_event)
        payload = audio_event.get('audio_base_64')
        if isinstance(payload, str):  # pragma: no branch
            audio_event = {key: value for key, value in audio_event.items() if key != 'alignment'}
            return {**frame, 'audio_event': {**audio_event, 'audio_base_64': _truncate_b64_audio(payload)}}

    def _walk(value: Any) -> Any:
        if isinstance(value, dict):
            node = cast('dict[str, Any]', value)
            inline = node.get('inlineData')
            if isinstance(inline, dict):
                inline = cast('dict[str, Any]', inline)
                data = inline.get('data')
                if isinstance(data, str):
                    return {**node, 'inlineData': {**inline, 'data': _truncate_b64_audio(data)}}
            return {key: _walk(item) for key, item in node.items()}
        if isinstance(value, list):
            return [_walk(item) for item in cast('list[Any]', value)]
        return value

    return cast('dict[str, Any]', _walk(frame))


class _SentFrameNormalizer:
    """Map random client-generated ids in outbound frames to stable `<client-id-N>` placeholders, and the library version to one."""

    def __init__(self) -> None:
        self._ids: dict[str, str] = {}

    def normalize(self, value: Any) -> Any:
        if isinstance(value, dict):
            result: dict[str, Any] = {}
            for key, item in cast('dict[str, Any]', value).items():
                if key in _CLIENT_ID_KEYS and isinstance(item, str) and _CLIENT_ID_RE.fullmatch(item):
                    result[key] = self._ids.setdefault(item, f'<client-id-{len(self._ids) + 1}>')
                elif key == 'version' and isinstance(item, str) and item.startswith('pydantic-ai/'):
                    # The library version an ElevenLabs `source_info` reports changes with every commit.
                    result[key] = 'pydantic-ai/<version>'
                else:
                    result[key] = self.normalize(item)
            return result
        if isinstance(value, list):
            return [self.normalize(item) for item in cast('list[Any]', value)]
        return value


# How long replay waits for someone else's move (the reader consuming a recorded inbound frame, or
# another sender sending the frame recorded before a microphone frame) before concluding it won't
# come. Generous, because it only bounds how long a real mismatch takes to report; replay that is
# making progress never comes near it.
_REPLAY_PROGRESS_GRACE = 2.0

# Outbound frames a session sends once it has stopped reading, to end the provider session: GPT-Live's
# `session.close`. Whatever the provider sent before it is read afterwards, by the same code that waits
# for the provider to confirm the close, so on replay the close overtakes those frames instead of
# waiting for a reader that only starts once the send returns.
_SESSION_END_TYPES = frozenset({'session.close'})


class ReplayWebSocket:
    """Replay a recorded WebSocket conversation, validating outbound frames as they are sent.

    Send/receive interleaving is preserved: the realtime session runs a background reader task, so
    `recv()` must block while the next recorded interaction is an outbound send rather than eagerly
    consuming a future inbound frame.
    """

    def __init__(self, cassette: RealtimeCassette, *, hold_open: bool = False) -> None:
        # A copy: a session-ending send reorders it (see `_SESSION_END_TYPES`), and the cassette is the recording.
        self._interactions = list(cassette.interactions)
        # Recorded before ElevenLabs Agents typed turns went out under an id naming their input (see
        # `_CascadeLifecycle.text_sent`): the server made ids up for them, which the replies' `in_response_to_ids` name.
        self._unnamed_user_messages = any(
            isinstance(interaction, CassetteMessage)
            and interaction.direction == 'sent'
            and interaction.data.get('type') == 'user_message'
            and 'id' not in interaction.data
            for interaction in self._interactions
        )
        self._hold_open = hold_open
        self._position = 0
        cassette._replay = self  # pyright: ignore[reportPrivateUsage]
        self._normalizer = _SentFrameNormalizer()
        self._condition = asyncio.Condition()
        self._readers = 0
        # Whether the connection streams its own idle audio (see `_patched_idle_audio`), whose recorded
        # frames other sends must wait behind rather than claim. Set once the pump starts. A recording in
        # which the application also streams audio can't tell its frames from the pump's, so replay only
        # supports the pump in sessions that send no audio of their own.
        self.pumps_audio = False
        self._closed = False
        self._now = 0.0
        # When each inbound frame handed out and not yet taken up by `begin_handling_frame()` was recorded.
        self._delivered: collections.deque[float | None] = collections.deque()
        # Mirrors the `websockets` attributes a connection exposes once closed, so code that inspects
        # the close after iteration ends (a normal close doesn't raise) sees what was recorded.
        self.close_code: int | None = None
        self.close_reason: str = ''

    async def send(self, message: str | bytes) -> None:
        text = message.decode('utf-8') if isinstance(message, bytes) else message
        actual = _truncate_audio(self._normalizer.normalize(_scrub(json.loads(text))))
        async with self._condition:
            if actual.get('type') in _SESSION_END_TYPES:
                self._take_next_send_ahead_of_unread_frames()
            interaction = self._peek()
            # A caller that keeps sending (streaming a microphone) runs ahead of the recorded inbound
            # frames sitting between its sends. Let the reader drain those first rather than failing the
            # send that follows them. A reader iterating the socket is known to be draining them; one
            # that calls `recv()` directly (GPT-Live keeps a single read in flight as its own task) is
            # only visible by the frames it consumes, so wait while it keeps consuming them. With nobody
            # consuming them at all, this is the genuine "sent a frame the recording doesn't have" case.
            # A recorded frame of idle audio belongs to the connection's pump, which sends it on its own
            # turn: another send waits for it to go out first, then drains whatever follows it the same way.
            while isinstance(interaction, CassetteMessage) and (
                interaction.direction == 'received'
                or (self.pumps_audio and not _is_audio_send(actual) and _is_audio_send(interaction.data))
            ):
                if interaction.direction == 'received' and self._readers:
                    await self._condition.wait()
                elif not await self._progressed():
                    break
                interaction = self._peek()
            if not isinstance(interaction, CassetteMessage) or interaction.direction != 'sent':
                raise AssertionError(
                    f'Outbound WebSocket frame had no matching recorded send (position {self._position}).\n'
                    f'sent={actual!r}'
                )
            self._advance()
        # Truncated on this side too: cassettes recorded before Gemini's microphone frames were
        # truncated hold them in full.
        expected = _truncate_audio(interaction.data)
        if 'event_id' not in expected:
            # Recorded before OpenAI-protocol client frames carried an `event_id` (the id a refusal
            # echoes, see `client_event_id`); the rest of the frame is still pinned.
            actual.pop('event_id', None)
        if actual.get('type') == 'conversation.item.create' and 'id' not in (expected.get('item') or {}):
            # Recorded before a user message item was created under an id naming its input (see
            # `client_item_id`); only that id is let through, and the rest of the item is still pinned.
            item: dict[str, Any] = actual.get('item') or {}
            if str(item.get('id', '')).startswith('pydantic_ai_item_'):
                del item['id']
        if (
            actual.get('type') == 'user_message'
            and 'id' not in expected
            and str(actual.get('id', '')).startswith('pydantic_ai_input_')
        ):
            # Recorded before a typed turn went out under an id naming its input (see `_unnamed_user_messages`);
            # only that id is let through, and the rest of the frame is still pinned.
            del actual['id']
        if actual.get('type') == 'response.create' and 'response' not in expected:
            # Recorded before a `response.create` carried the `metadata` naming the inputs it answers (see
            # `response_request_metadata`); only that is let through, and the rest of the frame is still pinned.
            if (response := actual.get('response')) is not None and set(response) == {'metadata'}:
                del actual['response']
        if actual.get('type') == 'session.update' and _transcription_model(expected) == 'gpt-realtime-whisper':
            # Recorded before OpenAI's `input_transcription_model='auto'` resolved to `gpt-live-transcribe`;
            # only that model is let through, and the rest of the frame is still pinned.
            if _transcription_model(actual) == 'gpt-live-transcribe':
                actual['session']['audio']['input']['transcription']['model'] = 'gpt-realtime-whisper'
        assert actual == expected, (
            f'Outbound WebSocket frame did not match cassette at position {self._position - 1}.\n'
            f'expected={expected!r}\nactual={actual!r}'
        )

    async def wait_for_audio_send_turn(self) -> None:
        """Wait until the recording's next interaction is a microphone frame.

        A recording made at a microphone's pace interleaves the microphone with everything else: the
        frames the provider sent in between, and the session's own sends (a tool result, say). Replay
        streams the microphone as fast as it can, so without this a microphone frame would take the slot
        of a frame another sender was recorded sending, and the session would handle it before the
        provider frames that preceded it on the wire. The wait has to happen here, before the audio send,
        because the session holds its send lock for the whole of a send: an audio send waiting inside
        `send()` would block the very frame it waits for. Returns once no progress is being made, leaving
        `send()` to report the mismatch.
        """
        async with self._condition:
            while (upcoming := self._peek()) is not None and not (
                isinstance(upcoming, CassetteMessage) and upcoming.direction == 'sent' and _is_audio_send(upcoming.data)
            ):
                if not await self._progressed():
                    return

    async def wait_for_pumped_audio_turn(self) -> None:
        """Wait until the recording's next interaction is a frame of idle audio, which the pump then sends.

        Stands in for the pump's real-time wait, so replay sends exactly the frames the recording has, in
        their recorded places. Once none are left, the pump waits for good, until the connection cancels it.
        """
        async with self._condition:
            while not (
                isinstance(upcoming := self._peek(), CassetteMessage)
                and upcoming.direction == 'sent'
                and _is_audio_send(upcoming.data)
            ):
                await self._condition.wait()

    async def _progressed(self) -> bool:
        """Wait for the replay position to move, reporting whether it did within the grace period."""
        position = self._position
        with suppress(asyncio.TimeoutError):
            await asyncio.wait_for(self._condition.wait(), timeout=_REPLAY_PROGRESS_GRACE)
        return self._position != position

    async def recv(self, *, decode: bool | None = None) -> str | bytes:
        async with self._condition:
            payload = await self._next_inbound()
        text = json.dumps(payload)
        return text.encode('utf-8') if decode is False else text

    async def _next_inbound(self) -> dict[str, Any]:
        """Advance to the next recorded inbound frame, waiting out any recorded sends before it."""
        while True:
            interaction = self._peek()
            if interaction is None:
                if self._hold_open and not self._closed:
                    await self._condition.wait()
                    continue
                # The recording ran out: the session outlived what was captured, which replays as
                # the ordinary end-of-conversation close.
                self.close_code, self.close_reason = 1000, ''
                raise ConnectionClosedOK(None, None)
            if isinstance(interaction, CassetteClose):
                self._advance()
                self.close_code, self.close_reason = interaction.code, interaction.reason
                close = Close(interaction.code, interaction.reason)
                raise (ConnectionClosedOK if interaction.ok else ConnectionClosedError)(close, None)
            if interaction.direction == 'received':
                self._advance()
                self._delivered.append(interaction.at)
                data = interaction.data
                if self._unnamed_user_messages and data.get('type') == 'agent_response':
                    # The ids the server made up name nothing the connection sent: replayed without them, revising nothing.
                    data = {**data, 'agent_response_event': dict(data['agent_response_event'])}
                    data['agent_response_event'].pop('in_response_to_ids', None)
                return data
            await self._condition.wait()

    async def __aiter__(self):
        # While something is iterating, recorded inbound frames are going to be consumed, which is what
        # lets `send()` wait behind them instead of rejecting the send that follows them. Counted around
        # the whole iteration, not each `recv()`: the reader spends most of its time handling the frame
        # it just got, and a send arriving in that gap must still be allowed to wait.
        self._readers += 1
        try:
            while True:
                try:
                    yield await self.recv()
                except ConnectionClosedOK:
                    return
        finally:
            self._readers -= 1
            async with self._condition:
                self._condition.notify_all()

    async def close(self, *args: Any, **kwargs: Any) -> None:
        del args, kwargs
        async with self._condition:
            self._closed = True
            self._condition.notify_all()

    @property
    def timed(self) -> bool:
        """Whether the replayed recording captured when each interaction happened."""
        return any(interaction.at is not None for interaction in self._interactions)

    def now(self) -> float:
        """When the inbound frame being handled was recorded: a clock that runs at the recording's pace.

        Replay delivers frames as fast as the session takes them, so the real clock barely moves between
        frames that were seconds apart on the wire. Anything that measures time on the wire (GPT-Live's
        turn clock, see `_patched_turn_clock`) reads this instead, and sees each gap as recorded.

        It moves only in `begin_handling_frame()`, never as a side effect of replay making progress: a
        read the consumer started early, or a send that was waiting on an inbound frame, would otherwise
        move it past the frame still being handled, and what the consumer measured would depend on how
        asyncio happened to schedule those tasks.
        """
        return self._now

    def begin_handling_frame(self) -> None:
        """Move the clock to when the next delivered inbound frame was recorded, as its consumer takes it up.

        Delivered frames are taken up in the order they were read, so no frame needs to be named.
        """
        at = self._delivered.popleft()
        if at is not None:
            self._now = max(self._now, at)

    def _take_next_send_ahead_of_unread_frames(self) -> None:
        """Move the next recorded send in front of the inbound frames recorded before it. Call with the condition held."""
        for index in range(self._position, len(self._interactions)):
            interaction = self._interactions[index]
            if not (isinstance(interaction, CassetteMessage) and interaction.direction == 'received'):
                if isinstance(interaction, CassetteMessage):
                    self._interactions.insert(self._position, self._interactions.pop(index))
                return

    def _advance(self) -> None:
        """Consume the next interaction. Call with the condition held."""
        self._position += 1
        self._condition.notify_all()

    def _peek(self) -> RealtimeCassetteInteraction | None:
        if self._position >= len(self._interactions):
            return None
        return self._interactions[self._position]


class RecordingWebSocket:
    """Wrap a live WebSocket, recording JSON frames (secrets scrubbed, inbound audio truncated)."""

    def __init__(self, ws: Any, cassette: RealtimeCassette) -> None:
        self._ws = ws
        self._cassette = cassette
        self._normalizer = _SentFrameNormalizer()

    async def send(self, message: str | bytes) -> None:
        text = message.decode('utf-8') if isinstance(message, bytes) else message
        data = _truncate_audio(self._normalizer.normalize(_scrub(json.loads(text))))
        self._cassette.interactions.append(CassetteMessage(direction='sent', data=data, at=self._cassette.elapsed()))
        await self._ws.send(message)

    async def recv(self, **kwargs: Any) -> str | bytes:
        try:
            raw = await self._ws.recv(**kwargs)
        except ConnectionClosedOK as e:
            self._record_close(e, ok=True)
            raise
        except ConnectionClosedError as e:
            self._record_close(e, ok=False)
            raise
        text = raw.decode('utf-8') if isinstance(raw, bytes) else raw
        data = _truncate_audio(_scrub(json.loads(text)))
        self._cassette.interactions.append(
            CassetteMessage(direction='received', data=data, at=self._cassette.elapsed())
        )
        return raw

    def __aiter__(self) -> RecordingWebSocket:
        return self

    async def __anext__(self) -> str | bytes:
        try:
            return await self.recv()
        except ConnectionClosedOK:
            raise StopAsyncIteration

    async def close(self, *args: Any, **kwargs: Any) -> None:
        await self._ws.close(*args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._ws, name)

    def _record_close(self, exc: ConnectionClosedOK | ConnectionClosedError, *, ok: bool) -> None:
        close = exc.rcvd or exc.sent
        self._cassette.interactions.append(
            CassetteClose(
                code=close.code if close is not None else 1000,
                reason=close.reason if close is not None else '',
                ok=ok,
                at=self._cassette.elapsed(),
            )
        )


def _connect_target(provider: ProviderName) -> tuple[Any, str]:
    """The module and attribute name of the `connect` callable to patch for `provider`."""
    if provider == 'openai':
        from pydantic_ai.realtime import openai as rt_openai

        return rt_openai.websockets, 'connect'
    if provider == 'openai_live':
        # GPT-Live is a separate protocol from the Realtime API, but it dials with the same
        # `websockets` library, so the raw-frame engine serves it too.
        from pydantic_ai.realtime import openai_live as rt_openai_live

        return rt_openai_live.websockets, 'connect'
    if provider == 'xai':
        # xAI clones the OpenAI Realtime protocol and connects with the `websockets` library directly,
        # so the same raw-frame engine serves it (patched at its own module reference).
        from pydantic_ai.realtime import xai as rt_xai

        return rt_xai.websockets, 'connect'
    if provider == 'elevenlabs':
        # Same raw-frame engine as xAI: an OpenAI-protocol clone dialed with the `websockets` library.
        from pydantic_ai.realtime import elevenlabs as rt_elevenlabs

        return rt_elevenlabs.websockets, 'connect'
    if provider == 'elevenlabs_agents':
        # ElevenLabs speaks its own agent protocol over the `websockets` library directly.
        from pydantic_ai.realtime import elevenlabs_agents as rt_elevenlabs_agents

        return rt_elevenlabs_agents.websockets, 'connect'
    from google.genai import live

    return live, 'ws_connect'


@contextmanager
def patched_ws_connect(
    provider: ProviderName, cassette: RealtimeCassette, plan: CassettePlan, *, hold_open: bool = False
) -> Generator[None]:
    """Patch the provider's WebSocket `connect` to replay from (or record into) `cassette`."""
    target, attr = _connect_target(provider)
    real_connect = getattr(target, attr)
    replay = ReplayWebSocket(cassette, hold_open=hold_open) if plan == 'replay' else None

    @asynccontextmanager
    async def connect(*args: Any, **kwargs: Any) -> AsyncGenerator[ReplayWebSocket | RecordingWebSocket]:
        if plan == 'replay':
            assert replay is not None
            # A reconnect continues at the next recorded interaction rather than rewinding the
            # cassette to the first handshake. Reusing the cursor also preserves outbound-ID
            # normalization across sockets in one logical realtime session.
            cassette.bind_disconnect(replay.close)
            yield replay
        # Only runs while recording.
        else:  # pragma: no cover
            async with real_connect(*args, **kwargs) as ws:
                recording = RecordingWebSocket(ws, cassette)

                async def disconnect() -> None:
                    await recording.close(code=1011, reason='test reconnect')

                cassette.bind_disconnect(disconnect)
                yield recording

    with (
        mock.patch.object(target, attr, connect),
        _patched_turn_clock(provider, replay),
        _patched_idle_audio(provider, replay),
    ):
        yield


@contextmanager
def _patched_idle_audio(provider: ProviderName, replay: ReplayWebSocket | None) -> Generator[None]:
    """Pace GPT-Live's idle-audio pump by the recording rather than by the clock.

    The pump sends a frame of silence every 100 ms of wall-clock time, and replay runs far faster than the
    recording did, so on the real clock it would send a different number of frames in different places.
    Instead each frame waits for the recording's next idle-audio frame to come up.
    """
    if replay is None or provider != 'openai_live':
        yield
        return
    from pydantic_ai.realtime import openai_live as rt_openai_live

    connection = rt_openai_live.OpenAILiveConnection
    start_idle_audio = connection._start_idle_audio  # pyright: ignore[reportPrivateUsage]

    def start_pumping(self: rt_openai_live.OpenAILiveConnection) -> None:
        replay.pumps_audio = True
        start_idle_audio(self)

    async def wait_for_recorded_frame(self: rt_openai_live.OpenAILiveConnection) -> None:
        await replay.wait_for_pumped_audio_turn()

    with (
        mock.patch.object(connection, '_start_idle_audio', start_pumping),
        mock.patch.object(connection, '_wait_for_idle_frame', wait_for_recorded_frame),
    ):
        yield


@contextmanager
def _patched_turn_clock(provider: ProviderName, replay: ReplayWebSocket | None) -> Generator[None]:
    """Point GPT-Live's turn clock at the replay's recorded time, when the cassette recorded it.

    GPT-Live ends a turn after a stretch of wall-clock silence rather than on a server event, and replay
    delivers frames back to back, so against the real clock no silence ever lasts long enough and the
    turns of a multi-turn conversation run together. Against `ReplayWebSocket.now` every gap lasts as
    long as it did on the wire, so the turn ends where it did while recording, however fast (or slowly,
    on a loaded CI runner) the replay runs.

    The clock moves as the connection starts mapping each frame, which is where it reads the clock (on
    the frame, and at the silence check after it). That's not when the frame was read: the connection
    keeps its next read in flight while it handles the current frame. A turn that ended in the gap
    between two frames ends as the second one is handled; Live's audio track keeps frames coming ten
    times a second, so that is at most 100 ms late. A cassette without timing keeps the real clock,
    which is what it was written against.
    """
    if replay is None or provider != 'openai_live' or not replay.timed:
        yield
        return
    from pydantic_ai.realtime import openai_live as rt_openai_live

    connection = rt_openai_live.OpenAILiveConnection
    map_frame = connection._map_frame  # pyright: ignore[reportPrivateUsage]

    def map_frame_on_recorded_time(self: rt_openai_live.OpenAILiveConnection, raw: str | bytes) -> Any:
        replay.begin_handling_frame()
        return map_frame(self, raw)

    with (
        mock.patch.object(rt_openai_live, '_now', replay.now),
        mock.patch.object(connection, '_map_frame', map_frame_on_recorded_time),
    ):
        yield


def ws_cassettes_available() -> bool:
    return imports_successful()
