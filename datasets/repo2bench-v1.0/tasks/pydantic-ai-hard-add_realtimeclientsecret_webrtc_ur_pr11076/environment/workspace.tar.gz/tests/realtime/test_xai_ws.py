"""Cassette-backed tests for the xAI Grok Voice realtime provider, exercising the real WebSocket protocol.

These complement the network-free `test_xai.py` unit tests: the fakes there pin the xAI-specific event
mapping, session config, and handshake cheaply, while these replay recorded provider frames end-to-end
through [`Agent.realtime`][pydantic_ai.agent.Agent.realtime] to prove the real protocol —
the streamed part events, the tool round-trip, and message-history seeding.

Recording requires xAI realtime API access (`XAI_API_KEY` with the voice-agent capability); when the
cassette is missing offline the `xai_ws_cassette` fixture skips rather than errors.
"""

from __future__ import annotations as _annotations

from decimal import Decimal
from pathlib import Path
from typing import Any

import anyio
import pytest
from inline_snapshot import snapshot

from pydantic_ai import Agent, RunUsage
from pydantic_ai.messages import (
    BinaryContent,
    FunctionToolCallEvent,
    FunctionToolResultEvent,
    ModelRequest,
    ModelResponse,
    PartDeltaEvent,
    PartStartEvent,
    RealtimeSessionErrorEvent,
    SpeechPart,
    SpeechPartDelta,
    TextPart,
    ToolCallPart,
    ToolReturnPart,
    UserPromptPart,
)
from pydantic_ai.realtime import (
    RealtimeModelProfile,
    RealtimeSessionReconnectEvent,
    RealtimeTurnCompleteEvent,
)

from ..conftest import IsDatetime, IsStr, try_import
from .ws_cassettes import CassetteClose, CassetteMessage, RealtimeCassette
from .ws_helpers import collapse_event_types, sent_frames_containing

with try_import() as imports_successful:
    from pydantic_ai.providers.xai import XaiProvider
    from pydantic_ai.realtime.xai import XaiRealtimeModel, XaiRealtimeModelSettings

pytestmark = [
    pytest.mark.skipif(not imports_successful(), reason='xai-sdk / websockets not installed'),
]

MODEL = 'grok-voice-latest'


async def test_text_in_audio_out_turn(xai_ws_cassette: tuple[XaiProvider, RealtimeCassette]) -> None:
    """A text-in turn yields streamed audio+transcript parts and a classic-shaped history."""
    provider, cassette = xai_ws_cassette
    model = XaiRealtimeModel(MODEL, provider=provider)
    agent = Agent(instructions='Answer in two or three words.')

    events: list[Any] = []
    async with agent.realtime(model).session(audio_retention='output_audio') as session:
        await session.send('Say a short greeting.')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    assert sent_frames_containing(cassette, 'Answer in two or three words.') == snapshot(
        [
            {
                'type': 'session.update',
                'session': {
                    'instructions': 'Answer in two or three words.',
                    'turn_detection': {'type': 'server_vad', 'create_response': True, 'interrupt_response': True},
                    'audio': {
                        'input': {
                            'format': {'type': 'audio/pcm', 'rate': 24000},
                            'transcription': {'model': 'grok-transcribe'},
                        },
                        'output': {'format': {'type': 'audio/pcm', 'rate': 24000}},
                    },
                },
            }
        ]
    )

    messages = session.all_messages()
    assert collapse_event_types(events) == snapshot(
        ['PartStartEvent', 'PartDeltaEvent', 'PartEndEvent', 'RealtimeTurnCompleteEvent']
    )
    assert [type(m).__name__ for m in messages] == snapshot(['ModelRequest', 'ModelResponse'])
    assert messages[0] == ModelRequest(
        parts=[UserPromptPart(content='Say a short greeting.', timestamp=IsDatetime())],
        timestamp=IsDatetime(),
        conversation_id=IsStr(),
        run_id=IsStr(),
    )
    response = messages[1]
    assert isinstance(response, ModelResponse)
    assert response.model_name == MODEL
    part = response.parts[0]
    assert isinstance(part, SpeechPart)
    assert part.speaker == 'assistant'
    assert part.transcript == snapshot('Hello there!')
    assert isinstance(part.audio, BinaryContent)
    assert part.audio.media_type == 'audio/wav'
    assert len(part.audio.data) > 0

    # xAI reports usage at the top level of the `response.done` frame (its nested `response.usage` is
    # empty), so the session accounts for it via the top-level fallback — including the audio/text
    # token split. Without the fallback every field here is zero.
    assert session.usage == snapshot(
        RunUsage(
            input_tokens=5,
            output_tokens=42,
            audio_seconds=1,
            output_audio_tokens=39,
            details={
                'input_text_tokens': 5,
                'output_text_tokens': 3,
                'audio_tokens': 39,
                'billable_audio_seconds': 1,
            },
            cost=Decimal('0.001333333333333333333333333333'),
            requests=1,
        )
    )


async def test_thinking_disabled(xai_ws_cassette: tuple[XaiProvider, RealtimeCassette]) -> None:
    """`thinking=False` sends xAI's documented `reasoning.effort='none'` and completes a live turn."""
    provider, cassette = xai_ws_cassette
    model = XaiRealtimeModel(
        MODEL,
        provider=provider,
        settings=XaiRealtimeModelSettings(thinking=False),
    )
    agent = Agent(instructions='Answer in two or three words.')

    async with agent.realtime(model).session() as session:
        await session.send('Say a short greeting.')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    updates = sent_frames_containing(cassette, 'reasoning')
    assert len(updates) == 1
    assert updates[0]['session']['reasoning'] == {'effort': 'none'}
    assert any(isinstance(message, ModelResponse) for message in session.all_messages())


async def test_audio_in_server_vad_turn(
    xai_ws_cassette: tuple[XaiProvider, RealtimeCassette], assets_path: Path
) -> None:
    """A spoken user turn (audio in, server VAD) is transcribed into a user turn in history.

    The default microphone workflow — no explicit turn control, input transcription on by default —
    must land the user's turn in history, not just the assistant's reply (the dropped-user-turn guard).

    It also pins how xAI's cumulative partials reach a live transcript: they arrive *while* the user is
    still speaking (before `RealtimeInputSpeechEndEvent`), and a snapshot that revises earlier words rather than
    extending them is surfaced as a replacement, since an append-only delta cannot unsay text.
    """
    provider, _ = xai_ws_cassette
    model = XaiRealtimeModel(MODEL, provider=provider)
    agent = Agent(instructions='Reply in a few words.')
    pcm = assets_path.joinpath('marcelo_24khz.pcm').read_bytes()

    events: list[Any] = []
    async with agent.realtime(model).session() as session:
        # Stream the clip in ~100 ms chunks like a live mic; the trailing silence lets server VAD end it.
        for start in range(0, len(pcm), 4800):
            await session.send_audio(pcm[start : start + 4800])
        with anyio.fail_after(45):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    # Pin the canonical spoken-turn event order: speech start -> stop -> user turn -> assistant reply.
    assert collapse_event_types(events) == snapshot(
        [
            'RealtimeInputSpeechStartEvent',
            'PartStartEvent',
            'PartDeltaEvent',
            'RealtimeInputSpeechEndEvent',
            'PartDeltaEvent',
            'PartEndEvent',
            'PartStartEvent',
            'PartDeltaEvent',
            'PartEndEvent',
            'RealtimeTurnCompleteEvent',
        ]
    )

    # Every delta carries the turn's transcript so far, so rendering that one field is correct through
    # the revision with no accumulating and no provider-specific branch.
    user_deltas = [
        event.delta
        for event in events
        if isinstance(event, PartDeltaEvent)
        and isinstance(event.delta, SpeechPartDelta)
        and event.delta.speaker == 'user'
    ]
    assert [(delta.transcript_delta, delta.transcript) for delta in user_deltas] == snapshot(
        [('Hello?', 'Hello?'), ('', 'Hello, my name is'), (' Marcelo.', 'Hello, my name is Marcelo.')]
    )
    rendered = user_deltas[-1].transcript or ''

    messages = session.all_messages()
    user_speech = [part for message in messages if isinstance(message, ModelRequest) for part in message.parts]
    assert len(user_speech) == 1
    user_part = user_speech[0]
    assert isinstance(user_part, SpeechPart) and user_part.speaker == 'user'
    assert user_part.transcript == snapshot('Hello, my name is Marcelo.')
    assert rendered.strip() == user_part.transcript
    responses = [message for message in messages if isinstance(message, ModelResponse)]
    assert responses and isinstance(responses[-1].parts[0], SpeechPart)

    # xAI bills Grok Voice by audio second: `billable_audio_seconds` is the authoritative cost and is
    # captured in usage `details` (it can't be reconstructed from token counts).
    assert session.usage.details.get('billable_audio_seconds') == snapshot(5)
    # Reported under the name pricing knows it by as well, so the session has a real cost. Grok Voice
    # has no token prices at all, so without it the token counts price to a confident zero: a
    # `cost_limit` would never trip and no unavailable-cost warning would say why.
    assert session.usage.audio_seconds == snapshot(5)
    assert session.usage.cost is not None and session.usage.cost > 0


@pytest.mark.realtime_ws_hold_open
async def test_push_to_talk_replies_only_when_asked(
    xai_ws_cassette: tuple[XaiProvider, RealtimeCassette], assets_path: Path, realtime_recording: bool
) -> None:
    """With turn detection off, committed audio gets a reply only when `create_response()` asks for one.

    xAI answers a commit of speech by itself, so the commit is held back and sent in place of
    `response.create`. Text sent in between reaches xAI first, and history follows that order. A second
    `create_response()` with nothing new behind it is answered again, as on every other provider: xAI would
    drop it without a word, so it first clears the buffer, which is empty.
    """
    provider, cassette = xai_ws_cassette
    model = XaiRealtimeModel(MODEL, provider=provider, settings=XaiRealtimeModelSettings(turn_detection=False))
    agent = Agent(instructions='Reply in a few words.')
    pcm = assets_path.joinpath('marcelo_24khz.pcm').read_bytes()

    async with agent.realtime(model).session() as session:
        for start in range(0, len(pcm), 4800):
            await session.send_audio(pcm[start : start + 4800])
        await session.commit_audio()
        await session.send('Greet me by name.', respond=False)
        if realtime_recording:  # pragma: no cover
            # Long enough for a reply to the commit to have started, had the commit been sent.
            await anyio.sleep(3)
        await session.create_response()
        with anyio.fail_after(30):
            await session.wait_for_reply()
        await session.create_response()
        with anyio.fail_after(30):
            await session.wait_for_reply()

    interactions = [message for message in cassette.interactions if isinstance(message, CassetteMessage)]
    commit_at = next(
        index
        for index, message in enumerate(interactions)
        if message.direction == 'sent' and message.data['type'] == 'input_audio_buffer.commit'
    )
    # Nothing was answered before the request, and the commit went out after the text, in its place.
    assert not any(message.data['type'] == 'response.created' for message in interactions[:commit_at])
    sent_types = [message.data['type'] for message in interactions if message.direction == 'sent']
    assert sent_types[sent_types.index('conversation.item.create') :] == snapshot(
        ['conversation.item.create', 'input_audio_buffer.commit', 'input_audio_buffer.clear', 'response.create']
    )
    # History follows what xAI was sent: the text, then the committed speech, then one reply per request.
    messages = session.all_messages()
    assert [[type(part).__name__ for part in message.parts] for message in messages] == snapshot(
        [['UserPromptPart'], ['SpeechPart'], ['SpeechPart'], ['SpeechPart']]
    )
    assert [type(message).__name__ for message in messages] == snapshot(
        ['ModelRequest', 'ModelRequest', 'ModelResponse', 'ModelResponse']
    )


async def test_tool_call_round(xai_ws_cassette: tuple[XaiProvider, RealtimeCassette]) -> None:
    """A tool call is executed by the session and its result folded back into a classic-shaped history.

    Unlike OpenAI in text mode, Grok Voice *speaks* before it calls a tool, so the tool call arrives in
    the same (mixed audio + function-call) response that fires the first `RealtimeTurnCompleteEvent`; the model then
    speaks the answer in a second turn. The loop runs until the tool result has come back and the model
    has finished the follow-up turn.
    """
    provider, cassette = xai_ws_cassette
    model = XaiRealtimeModel(MODEL, provider=provider)
    agent = Agent(instructions='Use the get_weather tool for any weather question, then answer in one short sentence.')

    @agent.tool_plain
    def get_weather(city: str) -> str:
        """Look up the weather for a city."""
        return f'It is foggy and 12 degrees in {city}.'

    events: list[Any] = []
    seen_result = spoke_after_result = False
    async with agent.realtime(model).session() as session:
        await session.send('What is the weather in London?')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                events.append(event)
                # The tool call rides in the first (mixed) turn, so stop only once the model has spoken
                # a follow-up turn *after* the tool result — the actual answer.
                if isinstance(event, FunctionToolResultEvent):
                    seen_result = True
                elif isinstance(event, PartStartEvent) and seen_result:
                    spoke_after_result = True
                elif isinstance(event, RealtimeTurnCompleteEvent) and spoke_after_result:
                    break

    assert sent_frames_containing(cassette, 'Look up the weather for a city.') == snapshot(
        [
            {
                'type': 'session.update',
                'session': {
                    'instructions': 'Use the get_weather tool for any weather question, then answer in one short sentence.',
                    'turn_detection': {'type': 'server_vad', 'create_response': True, 'interrupt_response': True},
                    'audio': {
                        'input': {
                            'format': {'type': 'audio/pcm', 'rate': 24000},
                            'transcription': {'model': 'grok-transcribe'},
                        },
                        'output': {'format': {'type': 'audio/pcm', 'rate': 24000}},
                    },
                    'tools': [
                        {
                            'type': 'function',
                            'name': 'get_weather',
                            'parameters': {
                                'additionalProperties': False,
                                'properties': {'city': {'type': 'string'}},
                                'required': ['city'],
                                'type': 'object',
                            },
                            'description': 'Look up the weather for a city.',
                        }
                    ],
                },
            }
        ]
    )

    call_events = [e for e in events if isinstance(e, FunctionToolCallEvent)]
    result_events = [e for e in events if isinstance(e, FunctionToolResultEvent)]
    assert len(call_events) == 1
    assert call_events[0].part.tool_name == 'get_weather'
    assert call_events[0].part.args_as_dict() == {'city': 'London'}
    assert len(result_events) == 1
    assert isinstance(result_events[0].part, ToolReturnPart)
    assert result_events[0].part.content == 'It is foggy and 12 degrees in London.'

    messages = session.all_messages()
    assert [type(m).__name__ for m in messages] == snapshot(
        ['ModelRequest', 'ModelResponse', 'ModelRequest', 'ModelResponse']
    )
    assert messages[0] == ModelRequest(
        parts=[UserPromptPart(content='What is the weather in London?', timestamp=IsDatetime())],
        timestamp=IsDatetime(),
        conversation_id=IsStr(),
        run_id=IsStr(),
    )
    # The tool call rides along with the assistant's spoken intro in the first response.
    tool_response = messages[1]
    assert isinstance(tool_response, ModelResponse)
    tool_calls = [p for p in tool_response.parts if isinstance(p, ToolCallPart)]
    assert tool_calls == [
        ToolCallPart(
            tool_name='get_weather',
            args=IsStr(),
            tool_call_id=IsStr(),
        )
    ]
    assert (tool_response.usage.input_tokens, tool_response.usage.output_tokens) == (7, 113)
    tool_return = messages[2]
    assert isinstance(tool_return, ModelRequest)
    assert tool_return.parts == [
        ToolReturnPart(
            tool_name='get_weather',
            content='It is foggy and 12 degrees in London.',
            tool_call_id=IsStr(),
            timestamp=IsDatetime(),
        )
    ]
    final = messages[3]
    assert isinstance(final, ModelResponse)
    assert (final.usage.input_tokens, final.usage.output_tokens) == (0, 269)
    final_part = final.parts[0]
    assert isinstance(final_part, SpeechPart)
    assert final_part.transcript is not None and 'fog' in final_part.transcript.lower()


async def test_message_history_seeding(xai_ws_cassette: tuple[XaiProvider, RealtimeCassette]) -> None:
    """Seeded prior turns are sent on the wire and reflected in the model's reply."""
    provider, cassette = xai_ws_cassette
    model = XaiRealtimeModel(MODEL, provider=provider)
    agent = Agent()

    history = [
        ModelRequest(parts=[UserPromptPart(content='My name is Alice and my favorite color is teal.')]),
        ModelResponse(parts=[TextPart(content='Nice to meet you, Alice!')]),
    ]

    events: list[Any] = []
    async with agent.realtime(model, message_history=history).session() as session:
        await session.send('What is my name and favorite color?')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    break

    # A server-side rejection of the seeded items (e.g. a bad content-type shape) surfaces as a
    # `RealtimeSessionErrorEvent`; assert none occurred so a broken seed payload fails the test loudly.
    assert [event for event in events if isinstance(event, RealtimeSessionErrorEvent)] == []

    # The seeded user/assistant turns were sent as `conversation.item.create` frames on the wire.
    assert sent_frames_containing(cassette, 'My name is Alice') == snapshot(
        [
            {
                'type': 'conversation.item.create',
                'item': {
                    'type': 'message',
                    'role': 'user',
                    'content': [{'type': 'input_text', 'text': 'My name is Alice and my favorite color is teal.'}],
                },
            }
        ]
    )
    # The seeded assistant turn is sent as an `output_text` item (its own serialization path, distinct
    # from the user seed above), so a wrong role/item/content shape fails here rather than passing on a
    # mere substring match.
    assert sent_frames_containing(cassette, 'Nice to meet you') == snapshot(
        [
            {
                'type': 'conversation.item.create',
                'item': {
                    'type': 'message',
                    'role': 'assistant',
                    'content': [{'type': 'output_text', 'text': 'Nice to meet you, Alice!'}],
                },
            }
        ]
    )

    # `all_messages()` carries the seeded history ahead of this session's turns.
    messages = session.all_messages()
    assert messages[:2] == history
    reply = messages[-1]
    assert isinstance(reply, ModelResponse)
    reply_part = reply.parts[0]
    assert isinstance(reply_part, SpeechPart)
    transcript = (reply_part.transcript or '').lower()
    assert 'alice' in transcript and 'teal' in transcript


async def test_reconnect_replays_history_after_drop(xai_ws_cassette: tuple[XaiProvider, RealtimeCassette]) -> None:
    """A forced WebSocket drop reconnects into a new xAI conversation seeded with the local history.

    xAI's own conversation resumption restores assistant turns but leaves the user's text out (checked
    live), so the model would no longer know the code word. Replaying the history keeps it.
    """
    provider, cassette = xai_ws_cassette
    model = XaiRealtimeModel(MODEL, provider=provider, settings={'reconnect': {'base_delay': 0.0, 'jitter': False}})
    agent = Agent(instructions='Answer in one short sentence.')

    events: list[Any] = []
    disconnected = False
    sent_followup = False
    async with agent.realtime(model).session() as session:
        await session.send('Remember exactly: the code word is cobalt. Briefly acknowledge it.')
        with anyio.fail_after(30):
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent) and not disconnected:
                    disconnected = True
                    await cassette.disconnect()
                elif isinstance(event, RealtimeSessionReconnectEvent):
                    await session.send('What code word did I ask you to remember?')
                    sent_followup = True
                elif sent_followup and isinstance(event, RealtimeTurnCompleteEvent):
                    break

    assert sent_frames_containing(cassette, 'resumption') == []
    assert [event for event in events if isinstance(event, RealtimeSessionReconnectEvent)] == [
        RealtimeSessionReconnectEvent(state_restored=True)
    ]

    conversation_ids = [
        message.data['conversation']['id']
        for message in cassette.interactions
        if isinstance(message, CassetteMessage) and message.data.get('type') == 'conversation.created'
    ]
    assert len(conversation_ids) == 2
    assert conversation_ids[0] != conversation_ids[1]
    close_index = next(
        i for i, interaction in enumerate(cassette.interactions) if isinstance(interaction, CassetteClose)
    )
    replayed_items = [
        interaction.data['item']
        for interaction in cassette.interactions[close_index + 1 :]
        if isinstance(interaction, CassetteMessage)
        and interaction.direction == 'sent'
        and interaction.data.get('type') == 'conversation.item.create'
        and 'What code word' not in str(interaction.data)
    ]
    assert [item['role'] for item in replayed_items] == snapshot(['user', 'assistant'])
    assert 'cobalt' in str(replayed_items[0]).lower()

    messages = session.all_messages()
    assert [type(message).__name__ for message in messages] == [
        'ModelRequest',
        'ModelResponse',
        'ModelRequest',
        'ModelResponse',
    ]
    responses = [message for message in messages if isinstance(message, ModelResponse)]
    final_part = responses[-1].parts[0]
    assert isinstance(final_part, SpeechPart)
    assert 'cobalt' in (final_part.transcript or '').lower()
    # xAI's billed seconds are a running total per conversation, which the new one starts again: each
    # conversation's seconds count once.
    billed = [
        message.data['usage']['billable_audio_seconds']
        for message in cassette.interactions
        if isinstance(message, CassetteMessage) and message.data.get('type') == 'response.done'
    ]
    assert session.usage.audio_seconds == sum(billed) == snapshot(2)


async def test_reconnect_replays_a_tool_round(xai_ws_cassette: tuple[XaiProvider, RealtimeCassette]) -> None:
    """A tool call and its result replayed after a drop are still known to the model.

    xAI's own resumption dropped the `function_call` item (checked live); replay sends both.
    """
    provider, cassette = xai_ws_cassette
    model = XaiRealtimeModel(MODEL, provider=provider, settings={'reconnect': {'base_delay': 0.0, 'jitter': False}})
    agent = Agent(instructions='Answer in one short sentence. Always use get_weather for weather questions.')

    @agent.tool_plain
    def get_weather(city: str) -> str:
        """Look up the weather for a city."""
        return f'It is foggy and 12 degrees in {city}.'

    disconnected = False
    sent_followup = False
    async with agent.realtime(model).session() as session:
        await session.send('What is the weather in Paris?')
        with anyio.fail_after(45):
            async for event in session:  # pragma: no branch
                if isinstance(event, RealtimeTurnCompleteEvent) and not disconnected:
                    # The turn ends after the answer to the tool's result, so the replay has a tool round to carry.
                    disconnected = True
                    await cassette.disconnect()
                elif isinstance(event, RealtimeSessionReconnectEvent):
                    await session.send('How many degrees did the weather tool report? Answer with just the number.')
                    sent_followup = True
                elif sent_followup and isinstance(event, RealtimeTurnCompleteEvent):
                    break

    close_index = next(
        i for i, interaction in enumerate(cassette.interactions) if isinstance(interaction, CassetteClose)
    )
    replayed_types = [
        interaction.data['item']['type']
        for interaction in cassette.interactions[close_index + 1 :]
        if isinstance(interaction, CassetteMessage)
        and interaction.direction == 'sent'
        and interaction.data.get('type') == 'conversation.item.create'
    ]
    assert replayed_types == snapshot(
        ['message', 'message', 'function_call', 'function_call_output', 'message', 'message']
    )
    # No `error` frame refused the replayed tool round.
    assert not [
        message
        for message in cassette.interactions[close_index + 1 :]
        if isinstance(message, CassetteMessage) and message.data.get('type') == 'error'
    ]
    final = [message for message in session.all_messages() if isinstance(message, ModelResponse)][-1].parts[0]
    assert isinstance(final, SpeechPart)
    assert '12' in (final.transcript or '')


@pytest.mark.usefixtures('no_genai_prices_context_window')
def test_profile_allow_seeding() -> None:
    """Unit guard: the model advertises session seeding, which the seeding cassette test relies on.

    Kept as a plain unit assertion (not a cassette test) because it pins intrinsic capability flags a
    recording wouldn't protect. Grok Voice has no image input or output truncation, and seeds from text
    history only (no image or audio seeding).
    """
    profile = XaiRealtimeModel(MODEL, provider=XaiProvider(api_key='xai-test-key')).profile
    assert profile == RealtimeModelProfile(
        supports_image_input=False,
        image_input_requires_response=False,
        supports_manual_turn_control=True,
        supports_interruption=True,
        supports_output_truncation=False,
        supports_text_output=False,  # Grok Voice always speaks
        supports_session_seeding=True,
        supports_webrtc=False,
        supports_seeding_images=False,
        supports_seeding_audio=False,
        supports_thinking=True,
        # Grok Voice answers the user while a tool call is outstanding (verified live).
        async_tool_call_mode='always',
        supports_async_tool_calls=True,  # deprecated, derived from `async_tool_call_mode`
        supports_tool_return_schema=False,
        supported_native_tools=frozenset(),
        emits_input_speech_events=True,
        synthesizes_turn_boundary=False,
        responses_are_requests=True,
        response_usage_covers_context=False,
        audio_input_sample_rate=24000,
        audio_output_sample_rate=24000,
        context_window=None,
    )


async def test_speech_resumed_before_the_commit_continues_the_turn(
    xai_ws_cassette: tuple[XaiProvider, RealtimeCassette], assets_path: Path, realtime_recording: bool
) -> None:
    """The user pauses for 400 ms mid-turn: xAI takes back the stop its server VAD heard.

    Recorded facts: xAI starts a reply at the stop, a few hundred milliseconds before it commits the turn. Speech
    heard before the commit makes it report `speech_started` again for the *same* item, and it drops that reply
    without ever sending a `response.done` for it. It then hears the user stop again, starts another reply, and
    commits the turn. The session records the turn once, ends the dropped reply as cancelled (as a barge-in would),
    and records the reply that follows.
    """
    provider, cassette = xai_ws_cassette
    model = XaiRealtimeModel(MODEL, provider=provider)
    agent = Agent(instructions='Reply in a few words.')
    bytes_per_second = 48_000
    question = assets_path.joinpath('amsterdam_population_question_24khz.pcm').read_bytes()
    follow_up = assets_path.joinpath('favorite_color_question_24khz.pcm').read_bytes()
    pcm = b''.join(
        [
            bytes(bytes_per_second * 3 // 10),
            question[: bytes_per_second * 32 // 10],
            bytes(bytes_per_second * 4 // 10),
            follow_up[bytes_per_second * 4 // 10 : bytes_per_second * 16 // 10],
            bytes(bytes_per_second * 3),
        ]
    )

    async with agent.realtime(model).session() as session:
        with anyio.fail_after(60):
            for start in range(0, len(pcm), 4800):
                await session.send_audio(pcm[start : start + 4800])
                if realtime_recording:  # pragma: no cover
                    # A live microphone's pace: a burst of audio is heard quite differently.
                    await anyio.sleep(0.1)
            turns_complete = 0
            async for event in session:  # pragma: no branch
                if isinstance(event, RealtimeTurnCompleteEvent):
                    turns_complete += 1
                    # The dropped reply's, then the one that answers the turn.
                    if turns_complete == 2:
                        break

    received = [
        message.data
        for message in cassette.interactions
        if isinstance(message, CassetteMessage) and message.direction == 'received'
    ]
    speech_starts = [frame['item_id'] for frame in received if frame['type'] == 'input_audio_buffer.speech_started']
    assert len(speech_starts) == 2 and speech_starts[0] == speech_starts[1]
    created = [frame['response']['id'] for frame in received if frame['type'] == 'response.created']
    done = [frame['response']['id'] for frame in received if frame['type'] == 'response.done']
    assert len(created) == 2 and done == created[1:]

    # One user turn; the dropped reply, which said nothing, recorded as interrupted as a barge-in's would be; then
    # the reply that answers the turn.
    request, dropped, reply = session.all_messages()
    assert isinstance(request, ModelRequest) and isinstance(request.parts[0], SpeechPart)
    assert request.parts[0].transcript == snapshot(
        'Can you look up on the web how many people live in Amsterdam? What is my favorite color?'
    )
    assert isinstance(dropped, ModelResponse) and isinstance(reply, ModelResponse)
    assert (dropped.provider_response_id, dropped.state, dropped.parts) == (created[0], 'interrupted', [])
    assert (reply.provider_response_id, reply.state) == (created[1], 'complete')


async def test_handle_barge_in_over_live_speech(
    xai_ws_cassette: tuple[XaiProvider, RealtimeCassette], assets_path: Path
) -> None:
    """`handle_barge_in=True` against Grok Voice: the provider owns the whole wire-side interruption.

    xAI's default server VAD interrupts the response on speech onset, and the model supports no
    output truncation — so a barge-in must put *nothing* on the wire: the session's job is only the
    local flush that keeps stale audio out of the playback stream. In this recording the reply had
    already completed server-side by the time the user spoke over it (generation outruns playback),
    which is exactly when a client-side cancel would have been applied to the *next* response —
    the session sent nothing. History still records the reply the user spoke over as interrupted where
    playback stopped (here before the first chunk finished playing), with its transcript whole.
    """
    provider, cassette = xai_ws_cassette
    model = XaiRealtimeModel(MODEL, provider=provider)
    agent = Agent(instructions='Reply in a few words.')
    pcm = assets_path.joinpath('marcelo_24khz.pcm').read_bytes()

    events: list[Any] = []
    async with agent.realtime(model).session(handle_barge_in=True) as session:
        stream = session.stream_audio()
        with anyio.fail_after(90):
            for start in range(0, len(pcm), 4800):
                await session.send_audio(pcm[start : start + 4800])
            # Wait for the reply's audio to start flowing before speaking over it.
            assert len(await anext(stream)) > 0
            for start in range(0, len(pcm), 4800):
                await session.send_audio(pcm[start : start + 4800])
            turns_complete = 0
            async for event in session:  # pragma: no branch
                events.append(event)
                if isinstance(event, RealtimeTurnCompleteEvent):
                    turns_complete += 1
                    if turns_complete == 2:
                        break

    # Nothing went out for the barge-in: no truncate (unsupported) and no cancel (the server
    # already interrupts on speech; a client cancel racing it can kill the next reply instead).
    assert sent_frames_containing(cassette, 'conversation.item.truncate') == []
    assert sent_frames_containing(cassette, 'response.cancel') == []
    responses = [message for message in session.all_messages() if isinstance(message, ModelResponse)]
    assert [response.state for response in responses] == snapshot(['interrupted', 'complete'])
    assert [
        [(part.interrupted_at_ms, part.transcript) for part in response.parts if isinstance(part, SpeechPart)]
        for response in responses
    ] == snapshot([[(0, 'Hello Marcelo! Nice to meet you!')], [(None, 'Hi Marcelo!')]])
