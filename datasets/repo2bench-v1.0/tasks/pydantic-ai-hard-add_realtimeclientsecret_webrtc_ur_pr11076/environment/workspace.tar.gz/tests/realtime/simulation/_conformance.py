"""The lifecycle contract a connection's codec event stream must obey, checked event by event.

Used two ways: on the live stream of every simulated session (wrapped around the session's pump), and
over every recorded WebSocket cassette in `tests/realtime/cassettes/` (see `test_conformance.py`), so
the adapters are held to the same rules against real provider traces.

The rules are the ones the current (v1) codec vocabulary can express; each names what the session
would get wrong if an adapter broke it:

- `codec.duplicate_tool_call`: a tool call id is reported twice (the tool would run twice);
- `codec.unknown_cancellation`: a `ToolCallCancelled` names a call never reported;
- `codec.content_after_terminal`: audio, transcript, a tool call, or usage for a response arrives after
  that response's `ResponseDone` (it would land on whatever response the session is assembling next);
- `codec.duplicate_terminal`: a response's `ResponseDone` arrives twice (the second would close
  whatever response the session is assembling next);
- `codec.overlapping_responses`: content for one response arrives while another is still open (neither
  its `ResponseDone` nor its usage seen yet): a provider runs one response at a time;
- `codec.event_after_fatal`: anything follows a non-recoverable `RealtimeSessionErrorEvent`.

The three rules keyed on response ids (`content_after_terminal`, `duplicate_terminal`,
`overlapping_responses`) only apply to the OpenAI-protocol adapters, which report the provider's response
ids. Gemini Live and GPT-Live have none, so for them those rules never fire; their turn boundaries are
checked by the simulator's invariants against the fake server's ground truth instead. They don't apply to a
stream whose connection brackets each response by id with lifecycle events either (`brackets_responses`):
the session then assembles each response apart, so responses can overlap (the `response.done` of a reply the
user barged in on can come after the next reply started), and the connection marks what trails a terminal
stale. The lifecycle rules below hold such a connection to its brackets instead.

A connection on the second version of the lifecycle contract (`_lifecycle.py`) is also held to the rules
its lifecycle events promise, checked on its lifecycle stream (`LifecycleChecker(lifecycle=True)`):

- `lifecycle.duplicate_start` / `lifecycle.end_without_start` / `lifecycle.duplicate_end`: a response
  isn't bracketed by exactly one `ResponseStarted` and one `ResponseEnded`;
- `lifecycle.content_outside_response`: content, usage, or a terminal for a response that isn't between
  its start and its end;
- `lifecycle.unknown_answer`: a response answers an input the connection was never sent;
- `lifecycle.input_settled_twice`: an input is answered, refused, or lost more than once;
- `lifecycle.bad_revision`: an `AnswersRevised` claims an input for a response that isn't under way, or releases one
  the response wasn't answering;
- `lifecycle.input_added_twice`: an input joins the conversation twice;
- `lifecycle.cut_of_unknown_item`: an `OutputItemCut` names an output item no content named;
- `lifecycle.turn_started_twice` / `lifecycle.turn_end_without_start`: a spoken turn isn't bracketed by
  one start and one end (or discard);
- `lifecycle.unended_at_close` / `lifecycle.turn_unended_at_close`: the stream ended with a response or
  a spoken turn still open.
"""

from __future__ import annotations as _annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from pydantic_ai.messages import RealtimeSessionErrorEvent, RealtimeSessionReconnectEvent
from pydantic_ai.realtime._lifecycle import (
    AnswersRevised,
    InputAdded,
    InputLost,
    LifecycleEvent,
    OutputItemCut,
    OutputItemDetails,
    ResponseEnded,
    ResponseRequestRefused,
    ResponseStarted,
    ToolCallsAbandoned,
    UserTurnClosed,
    UserTurnEnded,
    UserTurnStarted,
)
from pydantic_ai.realtime.codec import (
    AudioDelta,
    OutputTranscript,
    RealtimeCodecEvent,
    ResponseDone,
    SessionUsage,
    ToolCall,
    ToolCallCancelled,
)


@dataclass
class ConformanceIssue:
    code: str
    detail: str
    position: int


@dataclass
class LifecycleChecker:
    """Feed it a connection's events in order; it collects every contract violation.

    With `lifecycle`, it is fed a connection's lifecycle stream, and holds it to the lifecycle rules too.
    """

    lifecycle: bool = False
    brackets_responses: bool = False
    """Whether the connection brackets each response by id with lifecycle events, so the codec rules keyed on
    response ids don't apply to its codec stream (see the module docstring)."""
    inputs_sent: Callable[[], int] | None = None
    """How many inputs the connection has been sent so far, for `lifecycle.unknown_answer`."""
    issues: list[ConformanceIssue] = field(default_factory=list[ConformanceIssue])
    events: int = 0
    _tool_calls: set[str] = field(default_factory=set[str])
    _ended: set[str] = field(default_factory=set[str])
    _open: str | None = None
    _fatal: bool = False
    _started: set[str] = field(default_factory=set[str])
    _open_responses: set[str] = field(default_factory=set[str])
    _made_up_ids: set[str] = field(default_factory=set[str])
    """Responses the lifecycle named itself (`ResponseStarted.provider_id=False`), for a protocol that names them
    only in their terminal."""
    _responses_ended: set[str] = field(default_factory=set[str])
    _settled_inputs: set[int] = field(default_factory=set[int])
    _answers: dict[str, set[int]] = field(default_factory=dict[str, set[int]])
    """The inputs each response answers, as revised."""
    _added_inputs: set[int] = field(default_factory=set[int])
    _turns: set[str] = field(default_factory=set[str])
    _open_turns: set[str] = field(default_factory=set[str])
    _joined_turns: set[str] = field(default_factory=set[str])
    _items: set[str] = field(default_factory=set[str])
    """The output items content named, for `lifecycle.cut_of_unknown_item`."""

    def feed(self, event: RealtimeCodecEvent | LifecycleEvent) -> list[ConformanceIssue]:
        position = self.events
        self.events += 1
        found: list[ConformanceIssue] = []

        def issue(code: str, detail: str) -> None:
            found.append(ConformanceIssue(code, detail, position))

        if isinstance(event, LifecycleEvent):
            self._feed_lifecycle(event, issue)
        elif self.lifecycle:
            # The codec rules are checked on the codec stream; this one carries the same events, minus stale ones.
            self._feed_lifecycle_content(event, issue)
        else:
            self._feed_codec(event, issue)
        self.issues.extend(found)
        return found

    def _feed_lifecycle_content(self, event: RealtimeCodecEvent, issue: Callable[[str, str], None]) -> None:
        if isinstance(event, (AudioDelta, OutputTranscript)) and event.item_id is not None:
            self._items.add(event.item_id)
        response_id = event.provider_response_id if isinstance(event, ResponseDone) else _content_response_id(event)
        if (
            isinstance(event, ResponseDone)
            and response_id not in self._open_responses
            and not self._open_responses.isdisjoint(self._made_up_ids)
        ):
            # The terminal names the response under way, which the lifecycle had to make an id up for (ElevenLabs
            # names a reply only in its last frame): the session records the name it reports.
            return
        if response_id is not None and response_id not in self._open_responses:
            issue('lifecycle.content_outside_response', f'{type(event).__name__} for {response_id!r} outside it')

    def _feed_codec(self, event: RealtimeCodecEvent, issue: Callable[[str, str], None]) -> None:
        if self._fatal:
            issue('codec.event_after_fatal', f'{type(event).__name__} after a non-recoverable error')
        if isinstance(event, RealtimeSessionReconnectEvent):
            # A new connection: ids are only unique per server session, and the open response is gone.
            self._ended.clear()
            self._open = None
        if isinstance(event, ToolCall):
            if event.tool_call_id in self._tool_calls:
                issue('codec.duplicate_tool_call', f'tool call {event.tool_call_id!r} reported twice')
            self._tool_calls.add(event.tool_call_id)
        if isinstance(event, ToolCallCancelled):
            unknown = [call_id for call_id in event.tool_call_ids if call_id not in self._tool_calls]
            if unknown:
                issue('codec.unknown_cancellation', f'cancellation of calls never reported: {unknown}')
        response_id = None if self.brackets_responses else _content_response_id(event)
        if response_id is not None and response_id in self._ended:
            issue('codec.content_after_terminal', f'{type(event).__name__} for {response_id!r} after its ResponseDone')
        elif response_id is not None:
            if self._open is not None and self._open != response_id:
                issue('codec.overlapping_responses', f'content for {response_id!r} while {self._open!r} is still open')
            # A response's usage comes with its terminal: a function-call-only response has no `ResponseDone`.
            self._open = None if isinstance(event, SessionUsage) else response_id
        if isinstance(event, ResponseDone) and event.provider_response_id is not None and not self.brackets_responses:
            if event.provider_response_id in self._ended:
                issue('codec.duplicate_terminal', f'second ResponseDone for {event.provider_response_id!r}')
            self._ended.add(event.provider_response_id)
            if self._open == event.provider_response_id:
                self._open = None
        if isinstance(event, RealtimeSessionErrorEvent) and not event.recoverable:
            self._fatal = True

    def _feed_lifecycle(self, event: LifecycleEvent, issue: Callable[[str, str], None]) -> None:
        if isinstance(event, ResponseStarted):
            self._feed_start(event, issue)
        elif isinstance(event, ResponseEnded):
            if event.response_id in self._responses_ended:
                issue('lifecycle.duplicate_end', f'{event.response_id!r} ended twice')
            elif event.response_id not in self._open_responses:
                issue('lifecycle.end_without_start', f'{event.response_id!r} ended without starting')
            self._open_responses.discard(event.response_id)
            self._responses_ended.add(event.response_id)
        elif isinstance(event, (UserTurnStarted, UserTurnEnded, UserTurnClosed)):
            self._feed_turn(event, issue)
        elif isinstance(event, InputAdded):
            if event.input_id in self._added_inputs:
                issue('lifecycle.input_added_twice', f'input {event.input_id} joined the conversation twice')
            self._added_inputs.add(event.input_id)
        elif isinstance(event, AnswersRevised):
            self._feed_revision(event, issue)
        elif isinstance(event, OutputItemCut):
            # (A cut can come after its response ended: generation outruns playback.)
            if event.item_id not in self._items:
                issue('lifecycle.cut_of_unknown_item', f'cut of output item {event.item_id!r} no content named')
        elif isinstance(event, ToolCallsAbandoned):
            pass  # Nothing to check: a call can be abandoned before its response ends or after.
        elif isinstance(event, OutputItemDetails):
            if event.response_id not in self._open_responses:
                issue('lifecycle.content_outside_response', f'output item details for {event.response_id!r} outside it')
        else:
            assert isinstance(event, (InputLost, ResponseRequestRefused)), f'unknown lifecycle event {event!r}'
            self._settle(event.input_ids, issue)

    def _feed_turn(
        self, event: UserTurnStarted | UserTurnEnded | UserTurnClosed, issue: Callable[[str, str], None]
    ) -> None:
        if isinstance(event, UserTurnStarted):
            if event.turn_id in self._turns:
                issue('lifecycle.turn_started_twice', f'spoken turn {event.turn_id!r} started twice')
            self._turns.add(event.turn_id)
            self._open_turns.add(event.turn_id)
        elif isinstance(event, UserTurnEnded):
            if event.turn_id not in self._open_turns:
                issue('lifecycle.turn_end_without_start', f'spoken turn {event.turn_id!r} ended without starting')
            self._open_turns.discard(event.turn_id)
            self._joined_turns.add(event.turn_id)
        else:
            # A turn can be closed once it joined, too: it just gets no more audio or transcript.
            if event.turn_id not in self._open_turns and event.turn_id not in self._joined_turns:
                issue('lifecycle.turn_end_without_start', f'spoken turn {event.turn_id!r} closed without starting')
            self._open_turns.discard(event.turn_id)
            self._joined_turns.discard(event.turn_id)

    def _feed_start(self, event: ResponseStarted, issue: Callable[[str, str], None]) -> None:
        if event.response_id in self._started:
            issue('lifecycle.duplicate_start', f'{event.response_id!r} started twice')
        self._started.add(event.response_id)
        self._open_responses.add(event.response_id)
        if not event.provider_id:
            self._made_up_ids.add(event.response_id)
        sent = self.inputs_sent() if self.inputs_sent is not None else 0
        if unknown := [input_id for input_id in event.answers if not 0 <= input_id < sent]:
            issue('lifecycle.unknown_answer', f'{event.response_id!r} answers inputs never sent: {unknown}')
        self._answers[event.response_id] = set(event.answers)
        self._settle(event.answers, issue)

    def _feed_revision(self, event: AnswersRevised, issue: Callable[[str, str], None]) -> None:
        answers = self._answers.setdefault(event.response_id, set())
        if event.claimed and event.response_id not in self._open_responses:
            issue('lifecycle.bad_revision', f'{event.response_id!r} claims {event.claimed} while not under way')
        if stray := [input_id for input_id in event.released if input_id not in answers]:
            issue('lifecycle.bad_revision', f'{event.response_id!r} releases {stray}, which it was not answering')
        # A released input is owed again, and settled by whatever answers it next.
        answers.difference_update(event.released)
        self._settled_inputs.difference_update(event.released)
        answers.update(event.claimed)
        self._settle(event.claimed, issue)

    def _settle(self, input_ids: tuple[int, ...], issue: Callable[[str, str], None]) -> None:
        # Checked one at a time, so an event naming an input twice settles it twice too.
        twice: list[int] = []
        for input_id in input_ids:
            if input_id in self._settled_inputs:
                twice.append(input_id)
            self._settled_inputs.add(input_id)
        if twice:
            issue('lifecycle.input_settled_twice', f'inputs settled a second time: {twice}')

    def finish(self) -> list[ConformanceIssue]:
        """The stream ended: nothing may still be open."""
        found = [
            ConformanceIssue('lifecycle.unended_at_close', f'{response_id!r} never ended', self.events)
            for response_id in sorted(self._open_responses)
        ]
        found += [
            ConformanceIssue('lifecycle.turn_unended_at_close', f'spoken turn {turn_id!r} never ended', self.events)
            for turn_id in sorted(self._open_turns)
        ]
        self.issues.extend(found)
        return found


def _content_response_id(event: RealtimeCodecEvent) -> str | None:
    if isinstance(event, (AudioDelta, OutputTranscript, ToolCall)):
        return event.response_id
    if isinstance(event, SessionUsage) and event.response_scoped:
        return event.provider_response_id
    return None
